# NOIR / SEVEN v3.0.4 검증 기록

- 원본: v3.0.3 (GitHub/Render 배포 ZIP에 합칠 수 있는 동일 Node.js 게임 구조)
- 변경: `src/ai/utterance-corpus.json` 신규, `src/ai/utterance-parser.js` 신규, `src/bot-mind.js`에서 의도 분류 및 실게임 답변 연결, `src/discourse-frame.js`에서 전언/의견 구별, `tools/build_v289.js`에서 모바일/오프라인 번들 통합.
- 데이터: 37개 의도, 예시 411개. 71개와 38개의 별도 표현으로 문법 가드를 반복적으로 개선하였으므로 **일반화 성능에 대한 독립적인 통계가 아님**.
- 회귀 테스트: `npm test` 총 395개 통과, 실패 0개.
- 대표 실게임 답변 검증: 공개 생존 인원, 현재 단계, 경찰 능력, 밤 사망자 정보, 공개 채팅 이력, 공개 직업 주장 변경, 투표 스킵 거절, 밤 건너뛰기 거절, 투표 제안, 전체 직업 질문, 비밀 정보 비노출.
- 접선 비밀 채팅: 인물 제안/회피/변경/조사 결과 응답과 기존 34개 전용 테스트 모두 통과.
- 배포용 ZIP을 별도 경로에 압축 해제하고 실제 Node.js 서버를 실행했다. `/health`는 `version=3.0.4-beta`, `ai.mode=rules`, `ai.enabled=false`, `offlineMemory=true`, `offlineReasoning=true`, `dialogueIntents=37`, `dialogueExamples=411`을 반환했다. HTTP 핵심 자산 요청은 200이었고, 7인 방 생성·직업 상자 선택·첫날 밤 진입도 통과했다.
- Chromium 모바일 390×844 뷰포트에서 독립 오프라인 HTML을 네트워크 차단 상태로 실행했다. 6명의 독립 기억을 확인했고, 그룹 직업 요청에 각 AI가 응답했으며, `5번한테 표 몰자`도 5번에 관한 투표 제안으로 답했다. 외부 요청·페이지 JavaScript 오류·가로 넘침은 없었다.
- Android/iOS 앱 소스의 번들 엔진은 같은 파일로 갱신했으나, APK/IPA 빌드 및 실기기 테스트는 수행하지 않았다.
- 실제 서비스(사용자 Render)에 대한 업로드·배포는 ZIP 제공 후 사용자가 커밋해야 한다. 본 검증이 곧바로 운영 서버 배포를 뜻하지는 않는다.
- 한계: 온라인 LLM 없이 완전한 자유 한국어 이해를 보장하지 않는다. 시뮬레이터/Chromium 검증은 Android/iPhone 실기기 테스트와 다르다.
