# NOIR / SEVEN - public website release instructions

This is the complete source code of the mobile-compatible multiplayer web app,
including the Node.js server that owns room state and executes game rules.
The public website is NOT published until deployed to a hosting provider.

## Recommended deployment: Render Web Service

1. Connect your Render account to ChatGPT to authorize an actual deployment.
   Alternatively, upload this source tree to a Git repository you own and connect it to Render.
2. Deploy the repository as a **Render Blueprint** using `render.yaml` or create
   a Web Service using runtime Node, build command `npm install --omit=dev`,
   start command `npm start`, and HTTP health-check path `/health`.
3. If you create the Web Service manually, choose Singapore for nearby Korean
   players, Node.js 22, and set MAFIA_TEST_SPEED=1 (default).
4. Once Render reports Live, open the Render-provided HTTPS URL on Android,
   iPhone, or desktop. Share exactly that URL, or use the in-game invite link.
5. To add the game to a phone's home screen, use the browser's Add to home screen.

Your public game URL is assigned by Render AFTER deployment.
Do not confuse `localhost:3000` with a public URL.

## Operations and limitations

The v2.6 rule is that any confirmed loss of a participating human connection
aborts an active match without awarding victory; AI does not replace the player.
On free Render instances, the service can spin down after inactivity; cold start
may take time. Server restarts reset in-memory rooms (no persistent storage).
For a production release, add monitoring, rate limiting, abuse controls, and
browser/device testing. The software is a beta, not a production security audit.

## Verifying the deployment

- Visit `https://<YOUR-SERVICE>.onrender.com/health` after the deployment.
- It should return JSON containing `ok: true`.
- Open the root URL on two phones, create a room, join it via code, then
  add AI players to reach a total of seven.
- Keep both devices connected throughout an active match.

## Local tests

Run `npm test`; run `npm start` and browse to `http://localhost:3000`.
