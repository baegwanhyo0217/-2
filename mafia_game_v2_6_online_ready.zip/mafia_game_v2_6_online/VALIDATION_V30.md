# NOIR / SEVEN v3.0 beta - Validation checklist

## Automated tests

- Original v2.8.9 rule and dialogue tests retained.
- New v3.0 agent tests: configuration, independent memories, hidden-role
  observation boundary, direct replies, legal votes and night targets, model
  failure fallback, stale result rejection, provider credentials and local API.
- Run `npm test` in full project source directory.

## Local smoke tests

- Start Node server and query `GET /health`.
- Visit `/`, `/offline.html`, `/app.js` and `/sw.js`.
- Test that HTTP health includes v3.0 and a non-sensitive AI mode indicator.
- Test an AI-generated response with a fake local model server, then disable
  the model and ensure the rules-based fallback still keeps the match playable.

## Not verified

- Real OpenAI billable calls and actual Ollama inference quality.
- Android/iOS on-device local LLM (not included) and mixed BLE connections.
- Human-level reasoning quality in long natural-language sessions.

## Verified in this release

- `npm test`: **313 tests passed, 0 failed**.
- Deployed-layout ZIP extracted and passed `node --check`.
- Real Node HTTP smoke test: `/health` returned `3.0.0-beta`, `ai.mode=rules`;
  `/`, `/offline.html`, `/app.js`, `/sw.js` all returned HTTP 200.
- `GET /src/ai/memory.js` returned HTTP 404 (server-side AI internals are not web-served).
- Real server-side end-to-end test against a **mock** Chat Completions HTTP server:
  human public question -> isolated agent prompt -> JSON reply -> game chat.
- No user API key or paid external model was invoked for these tests.
