# NOIR / SEVEN v3.0.5 - Mafia night targeting fairness

## Problem reproduced

The v3.0.4 rules-based Mafia bot sorted candidate targets by suspicion
and chose among the first three 60% of the time. Sorting preserved
player join order when suspicion scores tied. Because the human host is
usually player #1, this made the human an unfairly frequent victim.

With 8,000 reproducible seeded first-night selections and Mafia at #2,
player #1 was targeted 26.65% of the time, while players #5, #6 and #7
were each targeted about 6.7% of the time.

## Fix

- Each legal target has equal baseline attack weight when no actionable
  public information exists; no player-number or human/bot preference.
- Publicly claimed roles (e.g. police) or direct public pressure on the
  Mafia can modestly raise target weight, preserving strategic gameplay.
- The rules engine still controls legal targets, including self-target
  prohibition, contact rules, and already-confirmed actions.
- The AI Mafia still obeys eligible proposals and vetoes from a contacted
  human Spy in secret chat.
- Optional cloud LLM prompts now explicitly discourage automatic targeting
  of the room host or a human participant.
- The browser offline engine and native Android/iOS embedded engine share
  the exact same updated rules implementation.

## Verify

Run `npm test` from the full project; v3.0.5 contains new targeting
regression tests plus all existing rule, memory, speech and contact tests.

`node tools/build_v289.js` refreshes the portable HTML and embedded
engine copies. A cloud LLM is optional; these changes work with LLM off.

## Deployment

Replace the root GitHub file `mafia_game_v2_6_online_ready.zip` with the
v3.0.5 release file, commit it, then deploy the new GitHub commit on Render.
As with older releases, the build command is
`unzip -oq mafia_game_v2_6_online_ready.zip && test -f mafia_game_v2_6_online/server.js`.
The start command is `node mafia_game_v2_6_online/server.js`.

No GitHub or Render changes are made by downloading this package.
