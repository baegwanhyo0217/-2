(function(){
'use strict';
const cryptoShim={
 randomUUID(){
  const a=new Uint8Array(16);
  if(globalThis.crypto?.getRandomValues)globalThis.crypto.getRandomValues(a);
  else for(let i=0;i<16;i++)a[i]=Math.floor(Math.random()*256);
  a[6]=(a[6]&15)|64;a[8]=(a[8]&63)|128;
  const h=Array.from(a,n=>n.toString(16).padStart(2,'0'));
  return h.slice(0,4).join('')+'-'+h.slice(4,6).join('')+'-'+h.slice(6,8).join('')+'-'+h.slice(8,10).join('')+'-'+h.slice(10).join('');
 },
 randomBytes(n){const a=new Uint8Array(n);if(globalThis.crypto?.getRandomValues)globalThis.crypto.getRandomValues(a);else for(let i=0;i<n;i++)a[i]=Math.floor(Math.random()*256);return {toString:()=>Array.from(a,b=>b.toString(16).padStart(2,'0')).join('')};}
};
const botModule={exports:{}};
(function(module,exports){
'use strict';

// Offline-first social-deduction agents. Each bot reads only public statements and
// its own role/investigations/contact information. No remote text API or cheat access.
// Speech is assembled from a context-specific argument, an attitude, evidence,
// and a question or conclusion; it is not a list of full canned chat messages.
const ROLE_WORDS = ['마피아', '스파이', '경찰', '의사', '건달', '시민'];
const PERSONAS = [
  { label:'신중', direct:0.25, talk:3, doubt:0.35, rhythm:['음','일단','잠깐'] },
  { label:'직설', direct:0.92, talk:5, doubt:0.62, rhythm:['잠깐만','솔직히'] },
  { label:'분석', direct:0.60, talk:4, doubt:0.75, rhythm:['정리하면','내 생각엔','일단 사실만 보면'] },
  { label:'감정', direct:0.82, talk:4, doubt:0.48, rhythm:['어','잠깐','이상한데'] },
  { label:'조용', direct:0.18, talk:2, doubt:0.27, rhythm:['음'] },
  { label:'설득', direct:0.60, talk:4, doubt:0.64, rhythm:['보니까','일단'] },
];

function choice(xs,rng) { return xs.length ? xs[Math.min(xs.length-1,Math.floor(rng()*xs.length))] : ''; }
function stamp(target) { return target ? `${target.number}번` : ''; }
function clamp(v,lo,hi) { return Math.min(hi,Math.max(lo,v)); }
function normalize(text) { return String(text||'').replace(/\s+/g,' ').trim(); }
function roleAsQuote(role) {
  const last=role.charCodeAt(role.length-1);
  const hasJong=last>=0xAC00 && last<=0xD7A3 && (last-0xAC00)%28!==0;
  return role+(hasJong?'이라고':'라고');
}
function includesSelfClaim(text) {
  return /(?:나는|난|내가|제가|저는|전|나|내 직업|제 직업|저)\s*(?:(?:진짜|사실|원래|확실히)\s*)?(?:경찰|의사|시민|마피아|건달|스파이)/.test(text) ||
    /(?:경찰|의사|시민|마피아|건달|스파이)\s*(?:입니다|이에요|이야|인데|이니까)/.test(text) && !/(?:너|쟤|그 사람|\d번)\s*(?:경찰|의사|시민|마피아|건달|스파이)/.test(text);
}
function claimedRole(text) {
  const t=normalize(text);
  const original=t.match(/(?:^|[,.!?;，]\s*|(?:^|\s)(?:음|솔직히|사실|근데|저기|일단|참고로)\s+|^(?:너네|너희|다들|여러분)\s+)(?:나는|난|내가|제가|저는|전|나|내\s*직업(?:은|이)?|제\s*직업(?:은|이)?|저)\s*(?:(?:진짜|사실|원래|확실히)\s*)?(?:경찰|의사|시민|마피아|건달|스파이)/);
  const additional=t.match(new RegExp(`(?:^|\\s)(?:\\uB098\\uB3C4|\\uC800\\uB3C4)\\s*(${ROLE_WORDS.join('|')})`));
  const selected=original && additional ? (original.index<=additional.index?original:additional) : (original||additional);
  if(!selected)return null;
  const fragment=selected[0];
  const role=ROLE_WORDS.find(word=>fragment.endsWith(word));
  if(!role)return null;
  const rest=t.slice(selected.index+fragment.length);
  // A short question about one's own role is not a declaration; a completed
  // declaration followed by a separate question still counts.
  const firstPunctuation=rest.match(/[.!?\uFF1F]/)?.[0];
  if(firstPunctuation==='?' || firstPunctuation==='\uFF1F')return null;
  // Negative self-statements do not constitute a positive role claim.
  if(/^\s*(?:\uD300)?\s*(?:\uC774|\uAC00)?\s*\uC544\uB2C8/.test(rest))return null;
  return role;
}
// Negative first-person role declarations are public claims about what a speaker
// denies, never positive evidence of their role.
function deniedRole(text) {
  const t=normalize(text);
  if(isQuestion(t))return null;
  const m=t.match(/^(?:(?:너네|너희|다들|여러분|아까|아니|근데)\s+)?(?:나는|난|내가|저는|전|제가|저|나|내\s*직업(?:은|이)?)\s*(?:진짜\s*)?(경찰|의사|시민|마피아|건달|스파이)\s*(?:이|가|은|는)?\s*(?:아니(?:야|다|에요|라고|라고\s*했|라니까|라며)|아닌데|아닙니다|아니라고)/);
  return m?.[1]||null;
}
function orderedMentions(text,players) {
  const matches=[];
  for(const p of players){
    const num=new RegExp(`(?:^|[^0-9])(${p.number})\\s*(?:번|호)(?![0-9])`);
    const found=num.exec(text);
    if(found)matches.push({id:p.id,index:found.index+(found[0].length-found[0].trimStart().length)});
    else if(p.name && p.name.length>1){const i=text.indexOf(p.name);if(i!==-1)matches.push({id:p.id,index:i});}
  }
  return matches.sort((a,b)=>a.index-b.index).map(x=>x.id);
}
function topicSwitchTarget(text,view) {
  const t=normalize(text);
  const m=t.match(/(\d+)\s*번[^.!?]{0,28}?(?:말고|아니고|그만하고|됐고)\s*(\d+)\s*번/);
  if(!m)return null;
  return view.everyone.find(p=>p.number===Number(m[2]))?.id||null;
}
function isReportedSkipVote(text) {
  return /(?:\d+\s*번|그\s*사람|걔).{0,28}(?:스킵|건너뛰).{0,14}(?:한다고|한다던데|했는데|했다|했어|하겠다고|하자고)/.test(text);
}
function declaredStance(text,players) {
  const t=normalize(text);
  if(/[?？]/.test(t) || /(?:왜|누구|어떻게)\s*(?:찍|투표|스킵|건너뛰)/.test(t))return null;
  // Reports of another player's stance are not the current speaker's own vote.
  if(isReportedSkipVote(t))return null;
  // Only *voluntary, stated* voting intentions are evidence, never inferred hidden votes.
  if(/(?:나는|난|내가|저는|전)\s*(?:이번엔|오늘|일단|지금은)?\s*(?:스킵|건너뛰)/.test(t) ||
    /(?:스킵|건너뛰)(?:하자|할게|할래|하고 싶어)/.test(t))return 'SKIP';
  const refs=mentions(t,players);
  const declares=/(?:찍을게|찍자|투표할게|투표하자|퇴출시키자|뽑을게|표\s*줄게)/.test(t);
  if(declares && refs.length)return refs[0];
  return null;
}
function mentions(text, players) {
  const found=[];
  for(const p of players) {
    const num = new RegExp(`(?:^|[^0-9])${p.number}\\s*(?:번|호|번님)(?![0-9])`);
    if (num.test(text) || (p.name && p.name.length>1 && text.includes(p.name))) found.push(p.id);
  }
  return found;
}
function mindFor(p,rng=Math.random) {
  if (!p.mind) p.mind = {
    persona: choice(PERSONAS,rng), suspicion:Object.create(null), trust:Object.create(null),
    claims:Object.create(null), observations:[], attacks:Object.create(null),
    accusations:[], seenPublic:[], seenSecret:[], spoken:[], turns:0,
    lastOpinion:null, lastRespondedId:null, visitedLast:[], watched:[],
    claimChanges:[], answerIds:[], publicStances:Object.create(null), stanceChanges:[], roleDenials:Object.create(null)
  };
  return p.mind;
}
function adjust(mind,id,score) {
  if (!id) return;
  mind.suspicion[id]=clamp((mind.suspicion[id]||0)+score,-7,9);
}
function legalView(room,p) {
  const view=room.botKnowledge(p);
  const everyone=room.players.map(q=>({id:q.id,number:q.number,name:q.name,alive:q.alive,bot:q.bot}));
  return { ...view, everyone, publicChat:room.publicChat, publicLog:room.publicLog,
    publicVote:room.voteOutcome && ['VOTE_RESULT','GAME_OVER'].includes(room.phase) ? room.voteOutcome : null,
    phaseStart:room.phaseStart,
    secretChat:view.partnerId ? room.secretChat : [] };
}
function findOwnResult(view,id) {return view.investigations.findLast(x=>x.targetId===id) || null;}
function readStatements(p,view,rng) {
  const mind=mindFor(p,rng);
  const roster=view.everyone;
  for(const entry of view.publicChat) {
    if(mind.seenPublic.includes(entry.id)) continue;
    mind.seenPublic.push(entry.id);
    if(entry.senderId===p.id) continue;
    const words=normalize(entry.text);
    const refs=mentions(words,roster);
    const speaker=roster.find(x=>x.id===entry.senderId);
    if(!speaker) continue;
    const claim=claimedRole(words);
    const denial=deniedRole(words);
    if(denial){
      if(mind.claims[speaker.id]?.role===denial){
        mind.claimChanges.push({speakerId:speaker.id,from:denial,to:'그 직업 부인',id:entry.id,at:entry.at});
        adjust(mind,speaker.id,1.2);
      }
      mind.roleDenials[speaker.id]={role:denial,at:entry.at,text:words};
      if(mind.claims[speaker.id]?.role===denial)delete mind.claims[speaker.id];
    }
    if (claim) {
      const previous=mind.claims[speaker.id];
      if(previous && previous.role!==claim) {
        adjust(mind,speaker.id,2.3);
        mind.claimChanges.push({speakerId:speaker.id,from:previous.role,to:claim,id:entry.id,at:entry.at});
      }
      mind.claims[speaker.id]={role:claim,at:entry.at,text:words};
      // A police bot knows no other player can simultaneously be the police.
      if(view.role==='POLICE' && claim==='경찰') adjust(mind,speaker.id,5);
      // A spy can compare an actual investigated role against a claimant.
      const verified=findOwnResult(view,speaker.id);
      if(view.role==='SPY' && verified?.actualRole && claim && verified.displayed!==claim) adjust(mind,speaker.id,2.4);
      if(view.role==='POLICE' && verified?.displayed==='마피아팀' && claim!=='마피아') adjust(mind,speaker.id,4);
      if(claim==='경찰' && !/(조사|결과|\d번)/.test(words)) adjust(mind,speaker.id,0.4);
    }

    const aggressive=/(\uC758\uC2EC|\uC218\uC0C1|\uB9C8\uD53C\uC544|\uAC70\uC9D3|\uAD6C\uB77C|\uB9D0 \uBC14\uAFD4)/.test(words);
    const negated=/(\uC544\uB2C8|\uC5C6|\uB2E8\uC815\uD558\uC9C0|\uBABB \uBBFF|\uD655\uC2E4\uD558\uC9C0)/.test(words);
    const affirmative=/(\uB9C8\uD53C\uC544(?:\uD300)?\s*(?:\uAC19\uC544|\uC774\uC57C|\uC57C|\uB2E4)|\uC758\uC2EC\uD574|\uC218\uC0C1\uD574|\uAC70\uC9D3\uB9D0|\uAD6C\uB77C)/.test(words);
    const actualAccusation=aggressive && affirmative && !isQuestion(words) && !negated;
    if(actualAccusation && refs.length) {
      for(const id of refs) if(id!==speaker.id) {
        mind.accusations.push({by:speaker.id,target:id,text:words,at:entry.at});
        // Human testimony is a weak conversational signal, not proof.
        // Bot accusations never amplify another bot's suspicion score.
        if(!speaker.bot)adjust(mind,id,0.08);
      }
    }
    // Being challenged by another bot is not a reason to retaliate.
    if(actualAccusation && refs.includes(p.id))
      mind.attacks[speaker.id]=(mind.attacks[speaker.id]||0)+1;
    // A false investigation contradicting the agent's *own* information.
    const claimedInvestigation=/(조사|확인|결과)/.test(words);
    if(claimedInvestigation && refs.length && /(마피아팀|마피아라고|마피아야)/.test(words)) {
      const accused=refs.find(id=>id!==speaker.id) || refs[0];
      const own=findOwnResult(view,accused);
      if(view.role==='POLICE' && own?.displayed==='시민팀') adjust(mind,speaker.id,1.8);
      if(view.role==='SPY' && own?.actualRole && own.actualRole!=='MAFIA') adjust(mind,speaker.id,2);
    }
    const statedVote=declaredStance(words,roster);
    if(statedVote!==null) {
      const before=mind.publicStances[speaker.id];
      if(before && before!==statedVote) {
        mind.stanceChanges.push({speakerId:speaker.id,from:before,to:statedVote,at:entry.at,id:entry.id});
        // A changed opinion can have an innocent explanation.
      }
      mind.publicStances[speaker.id]=statedVote;
    }

    mind.observations.push({kind:'message',speakerId:speaker.id,mentions:refs,text:words,at:entry.at,id:entry.id,claim});
  }
  if(mind.seenPublic.length>250) mind.seenPublic=mind.seenPublic.slice(-250);
  if(mind.observations.length>80) mind.observations=mind.observations.slice(-80);
  if(mind.accusations.length>50) mind.accusations=mind.accusations.slice(-50);
  if(mind.claimChanges.length>30) mind.claimChanges=mind.claimChanges.slice(-30);
  if(mind.stanceChanges.length>30)mind.stanceChanges=mind.stanceChanges.slice(-30);
  // Only a contacted Mafia/Spy may inspect the secret messages.
  for(const entry of view.secretChat) {
    if(mind.seenSecret.includes(entry.id)) continue;
    mind.seenSecret.push(entry.id);
    if(entry.senderId===p.id) continue;
    mind.observations.push({kind:'secret',speakerId:entry.senderId,text:entry.text,at:entry.at,id:entry.id});
  }
  if(mind.seenSecret.length>150) mind.seenSecret=mind.seenSecret.slice(-150);
  return mind;
}
function chooseWeighted(items,rng) {
  const total=items.reduce((s,x)=>s+Math.max(0,x.w),0);
  let k=rng()*total;
  for(const entry of items) {k-=Math.max(0,entry.w);if(k<=0)return entry.item;}
  return items[items.length-1]?.item;
}
function candidates(p,view,validIds,excludeIds=[]) {
  const excluded=new Set([...excludeIds,p.id]);
  return view.alivePlayers.filter(q=>validIds.includes(q.id) && !excluded.has(q.id));
}
function suspicion(mind,view,id) {
  const v=mind.suspicion[id]||0;
  const result=view.investigations.findLast(i=>i.targetId===id);
  if(view.role==='POLICE') return v+(result?.displayed==='마피아팀'?12:result?.displayed==='시민팀'?-2.4:0);
  return v;
}
function strongestSuspect(p,view,mind,validIds) {
  const vals=candidates(p,view,validIds,view.partnerId?[view.partnerId]:[]);
  vals.sort((a,b)=>suspicion(mind,view,b.id)-suspicion(mind,view,a.id));
  return vals[0] || null;
}
function chooseNight(room,p,rng) {
  const view=legalView(room,p), mind=readStatements(p,view,rng);
  const opts=room.validTargets(p);
  if(!opts.length) return null;
  const possible=candidates(p,view,opts);
  if(p.role==='DOCTOR') {
    const likelyThreat = strongestSuspect(p,view,mind,opts);
    const publicTarget = view.publicChat.slice(-6).flatMap(x=>mentions(x.text,view.alivePlayers)).find(x=>x!==p.id);
    if(publicTarget && opts.includes(publicTarget) && rng()<0.26) return publicTarget;
    if(rng()<0.50 || !likelyThreat) return p.id;
    return choice(possible,rng)?.id || p.id;
  }
  if(['POLICE','SPY'].includes(p.role)) {
    const seen=new Set(view.investigations.map(x=>x.targetId));
    const fresh=possible.filter(x=>!seen.has(x.id));
    if(p.role==='SPY' && !view.partnerId) {
      // The spy cannot know which uninvestigated player is actually Mafia.
      const scored=fresh.slice().sort((a,b)=>(mind.suspicion[b.id]||0)-(mind.suspicion[a.id]||0));
      return (rng()<0.63 ? scored[0] : choice(fresh,rng))?.id || choice(possible,rng).id;
    }
    const scored=fresh.slice().sort((a,b)=>suspicion(mind,view,b.id)-suspicion(mind,view,a.id));
    return (rng()<0.72 ? scored[0] : choice(fresh,rng))?.id || choice(possible,rng).id;
  }
  if(p.role==='GANGSTER') {
    const suspect=strongestSuspect(p,view,mind,opts);
    if(suspect && suspicion(mind,view,suspect.id)>0.9 && rng()<0.72) return suspect.id;
  }
  if(p.role==='MAFIA') {
    const expectedTrust = possible.slice().sort((a,b)=>(mind.suspicion[a.id]||0)-(mind.suspicion[b.id]||0));
    return (rng()<0.60 ? choice(expectedTrust.slice(0,Math.min(3,expectedTrust.length)),rng) : choice(possible,rng))?.id;
  }
  return choice(possible,rng)?.id;
}
function chooseVote(room,p,rng) {
  const view=legalView(room,p),mind=readStatements(p,view,rng);
  const list=candidates(p,view,view.alivePlayers.map(q=>q.id),view.partnerId?[view.partnerId]:[]);
  if(!list.length) return 'SKIP';
  const winner=list.slice().sort((a,b)=>suspicion(mind,view,b.id)-suspicion(mind,view,a.id))[0];
  const score=suspicion(mind,view,winner.id);
  if(p.role==='POLICE' && score>8) return winner.id;
  if(p.team==='MAFIA') {
    // After contact, avoid voting out the known partner. Before contact, the spy is unknown.
    if(rng()<0.12 && score<0.4)return 'SKIP';
    return (score>0.25 || rng()<0.65) ? winner.id : choice(list,rng).id;
  }
  if(score>=1.4) return rng()<0.89?winner.id:'SKIP';
  if(view.night===1 && rng()<0.45) return 'SKIP';
  if(rng()<0.2) return 'SKIP';
  return rng()<0.63 ? winner.id : choice(list,rng).id;
}
// Public conversation analysis uses witnessed statements, not invented evidence.
// A question is handled as a request for an answer, never as an excuse to ask more questions.
function formatRef(view,id) {
  const q=view.everyone.find(x=>x.id===id);
  return q ? `${q.number}번` : '그 사람';
}
function makeSentence({preface,observation,argument,ask},rng) {
  const parts=[];
  if(preface && rng()<0.73)parts.push(preface);
  if(observation)parts.push(observation);
  if(argument)parts.push(argument);
  if(ask)parts.push(ask);
  return normalize(parts.join(' ')).slice(0,218);
}

// Player messages can be questions, statements, corrections and short follow-ups.
// Routing and answering must inspect the SAME utterance; never substitute a
// generic discussion topic for a player's non-question contribution.
function isQuestion(text) {
  const t=normalize(text).replace(/[.!~]+$/,'').trim();
  if(!t)return false;
  if(/[?？]/.test(t))return true;
  // Public AI statements end with a period; a quoted 'who' or 'why' inside
  // such a statement must NEVER trigger a new bot-to-bot answer cascade.
  if(/[.。]\s*$/.test(normalize(text)) && !/(?:말해\s*줘|답해\s*줘|알려\s*줘)$/.test(t))return false;
  if(/^(?:나는|난|내가|저는|전|제가|저)\s*.{0,20}(?:시민|경찰|의사|마피아|스파이|건달)(?:이야|야|입니다|이에요|인데)$/.test(t))return false;
  if(/(?:말해\s*줘|답해\s*줘|알려\s*줘|설명해\s*줘|해명해\s*봐|대답해|알려줘|말해봐|답해봐)$/.test(t))return true;
  if(/(?:왜|누구|누가|누굴|뭐|무슨|어떻게|어느|몇\s*번|뭔데|뭐야)/.test(t) &&
    /(?:왜|누구|누가|누굴|뭐|무슨|어떻게|어느|몇\s*번|뭔데|뭐야|생각해|의심해|맞아|이야|냐|니|했어|할거야|할래|말해|찍어|찍을래|투표해|수상해|알아)/.test(t))return true;
  if(/(?:직업|역할).{0,12}(?:말해|알려|뭐|뭔데)|(?:마피아|경찰|시민|의사|스파이|건달).{0,6}(?:맞아|냐|니)$/.test(t))return true;
  if(/(?:너|넌|네가|니가).{0,35}(?:의심해|믿어|동의해|수상해|같아|생각해|찍을래|투표할래)$/.test(t))return true;
  if(/^(?:너|넌|네가|니가|당신)\s*.{0,18}(?:마피아|경찰|의사|시민|건달|스파이)(?:야|냐|니|맞아)$/.test(t))return true;
  return false;
}
function intentOf(text) {
  const t=normalize(text);
  if(!isQuestion(t))return null;
  if(/(?:뭔\s*소리|무슨\s*말|무슨\s*뜻|이해.*?안\s*돼|다시\s*설명|방금.*?(?:말|뜻)|아까.*?무슨\s*말|그게\s*뭐)/.test(t))return 'clarify';
  if(/(?:왜.*?(?:싸우|싸워|다투|다퉈)|그만.*?(?:싸우|싸워|다투)|싸우는\s*이유)/.test(t))return 'deescalate';
  if(/(?:\d+\s*번.{0,20}(?:스킵|건너뛰).{0,20}(?:했|한다|하겠).{0,20}(?:왜|투표)|왜.{0,20}(?:투표|찍).{0,20}(?:스킵|건너뛰))/.test(t))return 'vote_contradiction';
  if(/(?:경찰(?:이|은|은\s*대체)?\s*(?:대체\s*)?누구|누가\s*(?:진짜\s*)?경찰|누구(?:가|야|지)?\s*경찰|경찰\s*몇\s*번)/.test(t))return 'who_police';
  if(/(?:\d+\s*번.*?\d+\s*번).{0,30}(?:중에|둘\s*중|누가\s*더|어느\s*쪽|비교|더\s*수상)|(?:중에|둘\s*중).{0,40}(?:누가\s*더|수상|의심|마피아)/.test(t))return 'compare';
  if(/(?:누가\s*(?:죽|사망)|(?:지난밤|어젯밤).*?(?:죽|사망)|사망자.*누구)/.test(t))return 'death';
  if(/(?:조사.*?(?:누구|몇\s*번|결과|했어|했니|했냐|했냐고|알려|말해)|(?:누구|몇\s*번|\d+번).*?조사|조사\s*기록|(?:시민팀|마피아팀).*?(?:나왔|맞아))/.test(t))return 'investigation';
  if(/(?:왜.*?(?:의심|수상|찍|못\s*믿|마피아|거짓말)|(?:의심|수상).*?이유|근거|증거|해명|왜.*?그렇게|무슨\s*이유)/.test(t))return 'evidence';
  if(/(?:투표|스킵|건너뛰|누구\s*찍|누굴\s*찍|표를\s*줄|누구\s*뽑)/.test(t))return 'vote';
  if(/(?:너|넌|네가|니가|너는|당신)\s*(?:은|는)?\s*(?:마피아|경찰|의사|시민|건달|스파이)(?:야|이야|니|냐|맞아)/.test(t))return 'role';
  if(/(?:누가\s*마피아|누굴\s*의심|누구.*?의심|누구.*?수상|어떻게\s*생각|생각은|믿어|동의해|(?:말|주장).{0,10}(?:동의|맞아|어때|믿어)|마피아.*?누구|(?:\d+\s*번|그\s*사람|걔).*?(?:마피아|시민|의심|수상|거짓말))/.test(t))return 'opinion';
  if(/(?:직업|역할|(?:너|넌|네가|니가|당신).*?(?:경찰|의사|시민|스파이|마피아|건달)|(?:경찰|의사|시민|스파이|건달).*?(?:맞아|이야|인가|냐|니))/.test(t))return 'role';
  return 'general';
}
function directAddressee(text,view) {
  const t=normalize(text).replace(/^(?:(?:그럼|그러면|근데|그런데|혹시|저기|잠깐|일단|그래서|자|야)[,，:：\s]+){1,2}/, '');
  const m=t.match(/^(\d+)\s*번(?:님)?(?=\s|[,，:：!?]|(?:아|야|너|넌|네가|니가))/);
  if(!m)return null;
  const after=t.slice(m[0].length);
  // “4번은 마피아 같다” is ABOUT 4, not addressed TO 4.
  if(/^(?:은|는|이|가|을|를|의|이랑|하고|한테|에게|부터|도)/.test(after))return null;
  if(/^\s*(?:[,，:：!?]|아|야|너|넌|네가|니가|네\s*(?:직업|역할|말|가|생각)|니\s*(?:직업|역할|생각)|본인\s*(?:직업|생각)|직업|역할|말해|답해|왜|넌\s*누구|마피아|경찰|시민|의사|스파이|건달|\d+번)/.test(after))
    return view.everyone.find(q=>q.number===Number(m[1]))?.id || null;
  return null;
}
function previousDialogue(view,entry,p) {
  const i=view.publicChat.findIndex(x=>x.id===entry.id);
  if(i<=0)return null;
  const prior=view.publicChat.slice(Math.max(0,i-12),i).reverse().filter(x=>x.at>=view.phaseStart);
  const latestFromBot=prior.find(x=>x.senderId===p.id);
  const latestOverall=prior[0];
  return {latestFromBot,latestOverall,prior};
}
function contextualSubject(entry,p,view,mind) {
  const from=entry.senderId||entry.speakerId;
  const addressed=directAddressee(entry.text,view);
  const switched=topicSwitchTarget(entry.text,view);
  if(switched)return switched;
  const explicit=orderedMentions(entry.text,view.everyone).filter(id=>id!==addressed && id!==p.id);
  if(explicit.length)return explicit[0];
  // '5번 왜 거짓말했어?' addresses 5 directly. The subject is 5, not missing.
  if(addressed===p.id && /(?:왜|네\s*직업|니\s*직업|너\s*마피아|너\s*거짓말|네가\s*한|본인)/.test(entry.text))return p.id;
  if(/(?:왜\s*(?:나|날|내)|나를\s*(?:왜|의심)|내가\s*수상|날\s*의심)/.test(entry.text))return from;
  const ctx=previousDialogue(view,entry,p);
  if(/(?:그\s*사람|걔|그\s*애|그\s*말|그거|아까|방금|그게|맞아|아니|동의|네\s*말)/.test(entry.text)){
    const priorFromSpeaker=ctx?.prior?.find(x=>x.senderId===from && mentions(x.text,view.everyone).some(id=>id!==p.id));
    if(priorFromSpeaker){const refs=mentions(priorFromSpeaker.text,view.everyone).filter(id=>id!==p.id);if(refs.length)return refs[0];}
    const priorBot=ctx?.latestFromBot || ctx?.latestOverall;
    if(priorBot){const refs=mentions(priorBot.text,view.everyone).filter(id=>id!==p.id);if(refs.length)return refs[0];}
  }
  if(mind.lastOpinion?.targetId && /(?:그\s*사람|걔|그\s*말|그거)/.test(entry.text))return mind.lastOpinion.targetId;
  if(/(?:너|넌|네가|니가|너는|네\s*직업)/.test(entry.text))return p.id;
  return null;
}
function statementKind(text) {
  const t=normalize(text);
  if(/(?:그만\s*싸|싸우지\s*마|말싸움\s*그만|서로\s*싸|논쟁\s*그만|시끄러|그만\s*다퉈|근거\s*없이.{0,24}(?:마피아|의심|수상|몰아).{0,12}(?:하지\s*마|몰아가지\s*마)|근거\s*없(?:이|는).{0,22}(?:단정|몰아가|비난)|증거\s*없이.{0,22}(?:단정|의심)|근거 없는 의심 그만)/.test(t))return 'deescalate';
  if(/\d+\s*번[^.!?]{0,28}(?:말고|아니고|됐고)\s*\d+\s*번/.test(t))return 'topic-switch';
  if(/(?:\d+\s*번).{0,15}(?:말에|의견에|주장에|말은|말이).{0,14}(?:동의|맞는\s*것|맞아|옳아|틀려|동의\s*안|동의하지)/.test(t))return /(?:동의\s*안|동의하지|틀려)/.test(t)?'disagree':'agree-ref';
  if(deniedRole(t))return 'role-denial';
  if(/\d+\s*번[^.!?]{0,24}\d+\s*번.{0,16}(?:같은\s*팀|한\s*팀|같은\s*편)/.test(t))return 'team-theory';
  if(/(?:내\s*말(?:\s*좀)?\s*들|말\s*좀\s*들어|내\s*말\s*무시|내가\s*말\s*하잖|사람\s*말\s*좀)/.test(t))return 'listen';
  if(/^(?:아니|아니\s*그게|그게\s*아니|정정할게|다시\s*말하면|내\s*말은)/.test(t))return 'correction';
  if(/(?:안녕|하이|ㅎㅇ|반가워)/.test(t) && t.length<17)return 'greeting';
  if(/^(?:응|ㅇㅇ|그래|맞아|맞지|동의|인정|좋아|오케이|ㅇㅋ|그렇지)/.test(t))return 'agree';
  if(claimedRole(t))return 'claim';
  if(/(?:내가|나는|난|전|제가|저는).{0,18}(?:조사했|조사해봤|조사\s*결과)/.test(t))return 'investigation';
  if(/(?:나는|난|내가|저는|전).{0,22}(?:스킵|건너뛰)/.test(t) || /(?:스킵|건너뛰)(?:할게|하자|할래|하려고|하고\s*싶)/.test(t))return 'skip';
  if(/(?:투표할게|찍을게|표\s*줄게|퇴출시키자|투표하자)/.test(t))return 'vote';
  if(/(?:의심\s*(?:안|하지\s*않|하지\s*말)|수상하지\s*않|마피아\s*(?:아니|같지\s*않)|마피아가\s*아니|믿어|결백|무죄)/.test(t))return 'defense';
  if(/(?:의심|수상|마피아\s*(?:같|인\s*것|야|다)|거짓말|구라|말\s*바꿨|수상해)/.test(t))return 'accusation';
  if(/(?:나는|난|내가|저는|전).{0,12}(?:마피아가?\s*아니|스파이가?\s*아니)/.test(t))return 'denial';
  return 'other';
}
function isReactiveMessage(text) {return normalize(text).length>=2;}

function askedForBot(obs,p,view,chat,forced=false) {
  if(!obs || (obs.senderId||obs.speakerId)===p.id || !intentOf(obs.text)) return false;
  if(forced)return true;
  const addressee=directAddressee(obs.text,view);
  if(addressee)return addressee===p.id;
  if(obs.mentions.includes(p.id) && /(?:너|네가|니가|넌|너는)/.test(obs.text))return true;
  // '너' after a bot's own statement is an implicit direct address.
  const idx=chat.findIndex(x=>x.id===obs.id);
  const prior=idx>0?chat[idx-1]:null;
  if(prior?.senderId===p.id && /(?:너|네가|니가|넌|너는|넌데)/.test(obs.text))return true;
  if(obs.mentions.length && !/다들|모두|여러분|누구든/.test(obs.text))return false;
  return /(?:다들|모두|여러분|누구|의견|어떻게|왜)/.test(obs.text);
}

function discussionLedger(room,phaseStart) {
  if(!room.aiDiscussionLedger || room.aiDiscussionLedger.phaseStart!==phaseStart)
    room.aiDiscussionLedger={phaseStart,answered:new Set(),topics:new Set(),genericCount:0};
  return room.aiDiscussionLedger;
}
function reserveTopic(room,phaseStart,key,generic=false) {
  const ledger=discussionLedger(room,phaseStart);
  if(ledger.topics.has(key) || (generic && ledger.genericCount>=6))return false;
  ledger.topics.add(key);
  if(generic)ledger.genericCount++;
  return true;
}

function pickQuestion(room,p,view,mind,replyToId) {
  const chat=view.publicChat;
  const answered=discussionLedger(room,view.phaseStart).answered;
  if(replyToId) {
    const chosen=chat.find(x=>x.id===replyToId);
    if(chosen && chosen.senderId!==p.id && !answered.has(chosen.id) && !mind.answerIds.includes(chosen.id) &&
      (!chosen.bot || askedForBot({...chosen,mentions:mentions(chosen.text,view.everyone)},p,view,chat,true)))
      return {...chosen,mentions:mentions(chosen.text,view.everyone)};
  }
  const recent=chat.slice(-14).filter(x=>x.at>=view.phaseStart && x.senderId!==p.id &&
     !mind.answerIds.includes(x.id) && !answered.has(x.id))
    .map(x=>({...x,mentions:mentions(x.text,view.everyone)}));
  return recent.filter(x=>askedForBot(x,p,view,chat)).sort((a,b)=>{
    const da=Number(directAddressee(a.text,view)===p.id);
    const db=Number(directAddressee(b.text,view)===p.id);
    return (db-da)*100 + (chat.findIndex(x=>x.id===b.id)-chat.findIndex(x=>x.id===a.id));
  })[0]||null;
}
function finishInteraction(room,p,view,mind,entry,response) {
  discussionLedger(room,view.phaseStart).answered.add(entry.id);
  mind.answerIds.push(entry.id);
  if(mind.answerIds.length>100)mind.answerIds=mind.answerIds.slice(-100);
  return normalize(`${formatRef(view,entry.senderId||entry.speakerId)}, ${response}`).slice(0,218);
}
function findRecentWords(view,senderId,entryId) {
  const idx=view.publicChat.findIndex(x=>x.id===entryId);
  return view.publicChat.slice(0,idx<0?undefined:idx).reverse().find(x=>x.senderId===senderId && x.at>=view.phaseStart)?.text||'';
}
function factFor(p,view,mind,id,channel='PUBLIC') {
  if(!id)return null;
  const ref=formatRef(view,id);
  const own=findOwnResult(view,id);
  if(view.role==='POLICE' && own) return {strong:own.displayed==='마피아팀',targetId:id,
    text:`${own.night}번째 밤에 ${ref}을 조사했어. 결과는 ${own.displayed}이었어.${own.displayed==='시민팀'?' 다만 스파이도 시민팀으로 표시돼.':''}`,
    kind:'police-result'};
  if(channel==='SECRET' && view.role==='SPY' && own?.actualRole) return {strong:true,targetId:id,
    text:`접선 전에 ${ref}을 조사했고 실제 직업은 ${own.displayed}이었어.`,kind:'spy-result'};
  const shift=mind.claimChanges.findLast(x=>x.speakerId===id);
  if(shift) return {strong:true,targetId:id,
    text:shift.to==='그 직업 부인'?
      `${ref}은 처음엔 ${roleAsQuote(shift.from)} 했다가 나중엔 그 직업이 아니라고 말했어. 공개 발언이 바뀐 건 확인되지만 이유는 알 수 없어.`:
      `${ref}은 처음엔 ${roleAsQuote(shift.from)} 했다가 나중엔 ${roleAsQuote(shift.to)} 했어. 직업 주장이 바뀐 건 채팅에서 직접 확인했어.`,kind:'role-change'};
  if(view.role==='POLICE' && id!==p.id && mind.claims[id]?.role==='경찰') return {strong:true,targetId:id,
    text:`${ref}이 경찰이라고 주장했는데 나도 경찰이야. 경찰은 한 명뿐이니 둘 다 진짜일 수는 없어.`,kind:'counterclaim'};
  const changed=mind.stanceChanges.findLast(x=>x.speakerId===id);
  if(changed) {
    const phrase=value=>value==='SKIP'?'투표 건너뛰기':`${formatRef(view,value)} 투표`;
    return {strong:false,targetId:id,text:`${ref}은 아까 ${phrase(changed.from)}를 이야기했다가 ${phrase(changed.to)}로 입장을 바꿨어. 다만 입장이 바뀐 것만으로 마피아라고 단정할 수는 없어.`,kind:'changed-vote-intent'};
  }
  const claim=mind.claims[id];
  if(claim)return {strong:false,targetId:id,
    text:`${ref}은 자신이 ${roleAsQuote(claim.role)} 주장했어. 하지만 직업을 말했다고 실제로 증명된 건 아니야.`,kind:'unverified-claim'};
  // An accusation is evidence that the ACCUSATION was spoken, not proof of the target's team.
  const discussed=mind.accusations.findLast(x=>x.target===id && x.by!==p.id);
  if(discussed)return {strong:false,targetId:id,
    text:`${formatRef(view,discussed.by)}이 ${ref}을 의심한다고 말했어. 그 말만으로 ${ref}이 마피아라는 증거는 아니야.`,kind:'second-hand'};
  return null;
}
function evidenceAnswer(p,view,mind,id,{direct=false}={}) {
  const ref=formatRef(view,id);
  const evidence=factFor(p,view,mind,id);
  if(!evidence)return direct ?
    `${ref}을 의심할 만한 확인된 근거는 아직 없어. 내가 먼저 의심했다면 성급했어. 지금은 단정하지 않겠어.` :
    `${ref}에 대해 확인된 단서가 없어서 마피아라고 말할 수 없어.`;
  if(evidence.strong)return `${direct?'내가 그렇게 판단한 근거는 이거야. ':''}${evidence.text}`;
  return `${evidence.text} 그래서 지금은 의심만으로 몰아가면 안 된다고 봐.`;
}
function summarizeVisibleFact(p,view,mind,id) {
  if(!id)return '그 사람이 누구인지 특정할 수 없어.';
  const f=factFor(p,view,mind,id);
  if(f?.strong)return f.text;
  if(f && f.kind!=='second-hand')return f.text;
  return `${formatRef(view,id)}의 실제 직업은 알 수 없어. 정체를 입증할 공개 증거는 아직 없어.`;
}
function replyToStatement(room,p,view,mind,entry,rng) {
  const t=normalize(entry.text), kind=statementKind(t), from=entry.senderId||entry.speakerId;
  const addressed=directAddressee(t,view), subject=contextualSubject(entry,p,view,mind);
  const named=mentions(t,view.everyone).filter(x=>x!==addressed && x!==p.id);
  const ref=subject?formatRef(view,subject):null;
  const prev=findRecentWords(view,from,entry.id);
  let response='';
  if(kind==='topic-switch') {
    response=subject?`알겠어. ${formatRef(view,subject)}에 관한 이야기로 바꾸자. ${summarizeVisibleFact(p,view,mind,subject)}`:
      '알겠어. 앞서 말한 대상 대신 새로 언급한 사람의 발언을 확인하자.';
  } else if(kind==='agree-ref' || kind==='disagree') {
    const source=orderedMentions(t,view.everyone)[0];
    const stated=view.publicChat.slice(0,view.publicChat.findIndex(x=>x.id===entry.id))
      .findLast(x=>x.senderId===source);
    if(source && stated){
      const quote=normalize(stated.text).slice(0,65);
      response=kind==='agree-ref'?`${formatRef(view,source)}이 “${quote}”라고 말했지. 네가 그 의견에 동의한다는 뜻으로 이해했어. 사실 여부는 별도로 확인하자.`:
        `${formatRef(view,source)}이 “${quote}”라고 말했지. 네가 그 의견에 동의하지 않는다는 뜻이구나. 반박 이유가 공개 기록에 있는지 보자.`;
    } else response=kind==='agree-ref'?`${formatRef(view,source)}의 의견에 동의한다는 뜻이구나. 그 사람이 실제로 무엇을 말했는지는 지금 공개 기록에서 확인되지 않아.`:
      `${formatRef(view,source)}의 의견에 동의하지 않는다는 뜻이구나. 실제 발언 기록을 보고 판단하자.`;
  } else if(kind==='role-denial') {
    response=`네가 ${deniedRole(t)}은 아니라고 분명히 말한 건 들었어. 그 말을 반대로 해석하거나 그 직업이라고 몰아가진 않을게. 하지만 실제 직업은 아직 확인되지 않았어.`;
  } else if(kind==='team-theory') {
    const refs=orderedMentions(t,view.everyone);
    response=`${formatRef(view,refs[0])}과 ${formatRef(view,refs[1])}이 같은 팀이라는 추측이구나. 팀 관계는 공개된 발언만으로 확인할 수 없어. 실제로 일치하는 행동이나 조사 결과가 있는지 살펴봐야 해.`;
  } else if(kind==='deescalate') {
    response='알겠어. 근거 없는 의심과 마피아 단정을 반복하지 않을게. 확인된 사실과 추측을 구분해서 이야기하자.';
  } else if(kind==='listen') {
    const id=subject||(prev?mentions(prev,view.everyone).filter(x=>x!==p.id)[0]:null);
    if(id)response=`네 말 듣고 있어. 아까 ${formatRef(view,id)}에 대해 이야기한 것도 기억해. ${summarizeVisibleFact(p,view,mind,id)}`;
    else response='네 말 듣고 있어. 내 추측부터 꺼내지 말고 네가 제시한 내용에 맞춰 답할게.';
  } else if(kind==='greeting') {
    response='안녕. 지금 나온 공개 정보만 근거로 이야기할게.';
  } else if(kind==='correction') {
    const denial=/(?:안\s*의심|의심\s*안|의심하지\s*않|마피아\s*아니|마피아\s*같지\s*않)/.test(t);
    if(subject && denial)response=`내가 잘못 알아들었어. ${ref}을 의심하지 않는다는 뜻이지. ${summarizeVisibleFact(p,view,mind,subject)}`;
    else if(subject)response=`알겠어, ${ref}에 대한 말을 정정한 거구나. ${summarizeVisibleFact(p,view,mind,subject)}`;
    else response='내가 네 말을 다르게 이해했어. 앞의 추측을 일단 빼고 방금 정정한 내용으로 보겠어.';
  } else if(kind==='agree') {
    const recent=previousDialogue(view,entry,p)?.latestFromBot || previousDialogue(view,entry,p)?.latestOverall;
    if(recent && /스킵|건너뛰/.test(recent.text))response='응, 근거가 모자라면 스킵하는 쪽에 동의한다는 거지. 그건 무리하게 사람을 몰아가는 것보다 신중한 선택이야.';
    else if(recent && /(?:의심|수상|마피아|거짓말)/.test(recent.text))response=`내가 방금 한 말에 동의한다는 거지. 그래도 실제 증거와 추측은 따로 보자.`;
    else response='응, 네 의견은 들었어. 확인되지 않은 사실은 그대로 단정하지 않겠어.';
  } else if(kind==='claim') {
    const role=claimedRole(t);
    if(role==='경찰' && view.role==='POLICE')response='네가 경찰이라고 주장했지. 하지만 나도 경찰이야. 경찰은 한 명뿐이니 서로 주장이 충돌해. 조사 결과로 비교해 보자.';
    else response=`네가 ${roleAsQuote(role)} 주장한 건 들었어. 아직 검증된 정보는 아니니까, 뒤에 나오는 발언이나 조사 결과와 함께 판단할게.`;
    if(subject && subject!==from && subject!==p.id && /(?:조사|마피아팀|시민팀)/.test(t))
      response+=` ${ref}에 관한 말도 네 주장으로 기억해 둘게.`;
  } else if(kind==='investigation') {
    const claimedTeam=/(?:마피아팀|시민팀)/.exec(t)?.[0];
    response=subject ? `네가 ${ref}을 조사했다고 말한 거지${claimedTeam?' 결과가 '+claimedTeam+'이라는 주장도 들었어':''}. 그건 네가 발표한 정보이고, 내가 직접 검증한 결과라고 단정할 수는 없어.` :
      '네가 조사했다고 한 건 알겠어. 누구를 조사한 건지 번호가 있어야 그 발언을 다른 정보와 비교할 수 있어.';
  } else if(kind==='skip') {
    response='이번 투표는 스킵하겠다는 거구나. 확실한 근거가 없다면 나도 억지로 퇴출시키는 건 신중해야 한다고 봐.';
  } else if(kind==='vote') {
    response=subject?`${ref}에게 투표하겠다는 뜻이구나. ${summarizeVisibleFact(p,view,mind,subject)} 그걸 감안해 각자 판단하자.`:
      '투표하자는 뜻은 알겠어. 다만 누구에게 표를 줄 건지와 그 근거는 구분해서 이야기하자.';
  } else if(kind==='defense' || kind==='denial') {
    if(subject && subject!==p.id)response=`${ref}을 섣불리 의심하지 말자는 거지. ${summarizeVisibleFact(p,view,mind,subject)} 근거가 없으면 퇴출을 밀어붙이지 않겠어.`;
    else response='네가 마피아가 아니라고 밝힌 건 들었어. 그 자체가 증명은 아니지만, 근거 없이 너를 몰아가지는 않겠어.';
  } else if(kind==='accusation') {
    if(subject && named.length>1 && /(?:랑|과|와|둘|서로|다르|비교)/.test(t))response=`${formatRef(view,named[0])}과 ${formatRef(view,named[1])}의 말을 비교하자는 거구나. 둘의 발언이 실제로 어긋나는지 채팅 내용을 보고 판단해야 해.`;
    else if(subject)response=`${ref}이 수상하다는 의견은 들었어. ${summarizeVisibleFact(p,view,mind,subject)} 이 내용만으로 단정하지는 않을게.`;
    else response='누군가 수상하다는 말은 들었어. 다만 대상이 특정되지 않아서 누구의 발언을 검토해야 할지 모르겠어.';
  } else if(named.length>=2 && /(?:랑|과|와|서로|비교|다르)/.test(t)) {
    response=`${formatRef(view,named[0])}과 ${formatRef(view,named[1])}을 비교하자는 이야기지. 실제로 어떤 주장에 차이가 있는지 확인해 보자.`;
  } else if(subject && subject!==p.id) {
    response=`${ref}에 대해 이야기하는 거지. ${summarizeVisibleFact(p,view,mind,subject)}`;
  } else if(/(?:고마워|ㄱㅅ|감사)/.test(t)) {
    response='응. 새 정보가 나오면 같이 따져 보자.';
  } else if(/(?:이해가\s*안|뭔\s*소리|말이\s*안\s*돼)/.test(t)) {
    response='내 설명이 엉뚱했구나. 내가 말한 사실과 추측을 구분해서 다시 말할게. 지금 확인된 단서는 많지 않아.';
  } else {
    response='네가 말한 내용에 바로 맞춰 답하려고 했는데, 게임 안에서 확인할 수 있는 구체적 대상이나 단서가 없어. 아는 척해서 지어내지는 않을게.';
  }
  return finishInteraction(room,p,view,mind,entry,response);
}
function topicOf(question,p,view,mind) {
  return contextualSubject(question,p,view,mind);
}
function answerQuestion(room,p,view,mind,question,rng) {
  const intent=intentOf(question.text);
  const fromId=question.senderId||question.speakerId;
  const id=topicOf(question,p,view,mind);
  const ref=id?formatRef(view,id):null;
  const q=normalize(question.text);
  const prior=previousDialogue(view,question,p);
  let response='';
  if(intent==='who_police') {
    const declared=Object.entries(mind.claims).filter(([id,c])=>c.role==='경찰').map(([id])=>formatRef(view,id));
    if(view.role==='POLICE') response=declared.length?
      `나는 경찰이야. 공개적으로 경찰이라고 주장한 사람은 ${declared.join(', ')}이지만, 다른 사람의 주장까지 진짜라는 뜻은 아니야.`:
      '나는 경찰이야. 내 조사 결과와 다른 사람들의 발언을 비교해서 판단해 줘.';
    else response=declared.length?
      `경찰이라고 공개적으로 주장한 사람은 ${declared.join(', ')}이야. 다만 누가 진짜 경찰인지는 확인되지 않았어.`:
      '아직 공개적으로 경찰이라고 밝힌 사람은 확인하지 못했어. 비공개 직업은 임의로 추측해서 알려줄 수 없어.';
  } else if(intent==='compare') {
    const pair=orderedMentions(q,view.everyone).filter(x=>x!==p.id || !directAddressee(q,view)).slice(0,2);
    if(pair.length<2)response='비교할 두 사람의 번호를 알려줘. 기록에 없는 단서는 만들지 않을게.';
    else {
      const [a,b]=pair,fa=factFor(p,view,mind,a),fb=factFor(p,view,mind,b);
      const aa=formatRef(view,a),bb=formatRef(view,b);
      if(fa?.strong && !fb?.strong)response=`${aa}과 ${bb}을 비교하면 ${aa}에게 더 분명한 단서가 있어. ${fa.text} ${bb}에 관해선 확인된 강한 단서가 없어.`;
      else if(fb?.strong && !fa?.strong)response=`${aa}과 ${bb}을 비교하면 ${bb}에게 더 분명한 단서가 있어. ${fb.text} ${aa}에 관해선 확인된 강한 단서가 없어.`;
      else if(fa?.strong && fb?.strong)response=`${aa}과 ${bb} 모두 따져볼 단서가 있어. ${fa.text} ${fb.text}`;
      else response=`${aa}과 ${bb} 모두 확인된 결정적인 근거가 부족해. 지금은 둘 중 누가 더 수상하다고 단정할 수 없어.`;
    }
  } else if(intent==='vote_contradiction') {
    const source=orderedMentions(q,view.everyone)[0];
    const publicStance=source?mind.publicStances[source]:null;
    const line=source?view.publicChat.findLast(x=>x.senderId===source&&/(?:스킵|건너뛰)/.test(x.text)&&x.id!==question.id):null;
    if(source && (publicStance==='SKIP'||line))response=`${formatRef(view,source)}이 스킵하겠다고 말한 기록이 있어. 그건 ${formatRef(view,source)}에게 투표하라는 뜻이 아니야. 실제 투표는 별개이고, 누가 투표를 요구했는지는 기록을 봐야 해.`;
    else if(source)response=`${formatRef(view,source)}이 스킵한다고 했다는 네 말은 들었어. 다만 공개 기록에서 확인되지 않으니 사실로 단정하진 않을게. 스킵과 특정인 투표는 다른 선택이야.`;
    else response='스킵하겠다는 말과 누군가에게 투표하자는 말은 달라. 누가 어떤 입장을 밝혔는지 공개 발언을 확인해 보자.';
  } else if(intent==='clarify') {
    const last=prior?.latestFromBot||prior?.latestOverall;
    if(last) {
      const content=normalize(last.text).slice(0,95);
      if(/(?:주장|진짜|증명|확인되지|확정)/.test(content))
        response=`아까 내가 말한 건 “${content}”이야. 누군가 그렇게 말했다는 사실과 그 말이 진짜라는 건 다르다는 뜻이야.`;
      else response=`내가 방금 “${content}”라고 했지. 확인된 정보와 아직 추측인 부분을 구분해서 보자는 뜻이야.`;
    } else response='내가 바로 앞에서 한 말이 보이지 않아. 어떤 발언을 말하는지 번호나 내용을 짚어주면 정확히 설명할게.';
  } else if(intent==='deescalate') {
    response='서로 같은 의심을 반복하기보다 근거를 보자는 뜻이야. 나도 확인되지 않은 말을 사실처럼 되풀이하지 않을게.';
  } else if(intent==='death') {
    const line=view.publicLog.filter(x=>/지난밤 .*사망|지난밤 사망자는 없습니다/.test(x.text)).at(-1);
    response=line?`${line.text} 그게 지금 공개된 결과야. 누가 공격했는지는 공개되지 않았어.`:'아직 밤 사망 결과가 발표되지 않았어.';
  } else if(intent==='investigation') {
    if(view.role==='POLICE') {
      const specified=id && id!==p.id && id!==fromId?findOwnResult(view,id):null;
      if(specified)response=`${ref}은 ${specified.night}번째 밤에 조사했어. 결과는 ${specified.displayed}이야.${specified.displayed==='시민팀'?' 다만 스파이는 시민팀으로 나올 수 있어.':''}`;
      else if(id && id!==p.id && id!==fromId && /(?:조사했|조사\s*결과)/.test(q))response=`${ref}은 아직 조사한 기록이 없어. 결과를 지어내지 않을게.`;
      else response=view.investigations.length?`내가 직접 조사한 기록은 ${view.investigations.slice(-3).map(x=>`${formatRef(view,x.targetId)}: ${x.displayed}`).join(', ')}야. 시민팀 결과에 스파이가 포함될 수 있어.`:'나는 경찰이지만 아직 공개할 조사 결과가 없어.';
    } else if(view.role==='SPY' || view.role==='MAFIA') {
      response='내가 가진 비공개 정보를 여기서 확인해 주지는 않을게. 공개된 조사 주장은 따로 검증해야 해.';
    } else {
      response='난 경찰 조사 결과를 갖고 있지 않아. 다른 사람이 공개한 조사 주장은 들을 수 있지만 내가 조사했다고 말할 순 없어.';
    }
  } else if(intent==='vote') {
    if(id && id!==p.id && id!==fromId && /(?:\d+번|그\s*사람|걔)/.test(q)) {
      const evidence=factFor(p,view,mind,id);
      response=evidence?.strong?`${ref}을 투표 대상으로 생각할 만한 단서는 있어. ${evidence.text}`:`${ref}에게 투표하자는 말이지. 하지만 지금 ${ref}을 퇴출시킬 충분한 근거는 없어. 나는 스킵도 고려하고 있어.`;
    } else {
      const eligible=view.alivePlayers.filter(x=>x.id!==p.id && x.id!==view.partnerId);
      const top=strongestSuspect(p,view,mind,eligible.map(x=>x.id));
      const evidence=top?factFor(p,view,mind,top.id):null;
      response=top && evidence?.strong && suspicion(mind,view,top.id)>0.8?`지금은 ${formatRef(view,top.id)}에게 투표할 생각이야. ${evidence.text}`:
        '확인된 근거가 부족하니 이번엔 스킵을 고려 중이야. 새 증거가 나오면 판단을 바꿀게.';
    }
  } else if(intent==='role') {
    const aboutOther=id && id!==p.id && id!==fromId;
    if(aboutOther) {
      response=summarizeVisibleFact(p,view,mind,id);
    } else if(/(?:너|넌|네가|니가|당신).*?마피아/.test(q)) {
      response=view.team==='MAFIA'?'나는 마피아가 아니야. 하지만 내 말만 믿지 말고 공개된 행동으로 판단해.':'아니, 나는 마피아팀이 아니야. 내 주장도 다른 정보와 대조해서 판단해 줘.';
    } else if(view.role==='POLICE') {
      response=view.investigations.length?`나는 경찰이야. 내가 직접 조사한 결과는 ${view.investigations.map(x=>`${formatRef(view,x.targetId)} ${x.displayed}`).join(', ')}야.`:'나는 경찰이야. 조사 결과는 아직 없어.';
    } else if(view.team==='MAFIA') {
      response='내 직업은 지금 밝히지 않을게. 내가 무슨 직업이라고 말하든 그 주장만으로 확인되진 않으니까.';
    } else {
      response=rng()<0.60?`내 직업은 ${({CITIZEN:'시민',GANGSTER:'건달',DOCTOR:'의사',POLICE:'경찰'})[view.role]}이야. 이 말만으로 확정하지는 마.`:'직업은 아직 공개하지 않을게. 대신 확인 가능한 발언을 기준으로 이야기하자.';
    }
  } else if(intent==='evidence') {
    if(!id)response='어느 사람에 대한 근거를 묻는지 정확하지 않아. 번호로 말해 주면 그 사람의 공개된 발언을 확인할게.';
    else if(id===p.id && directAddressee(q,view)===p.id && /(?:거짓말|구라|말\s*바꿨)/.test(q)) {
      const priorOwn=view.publicChat.filter(x=>x.senderId===p.id && x.id!==question.id).slice(-3);
      response=priorOwn.length?`${formatRef(view,p.id)}인 내가 한 말이 서로 모순된다는 뜻으로 들었어. 공개된 내 발언 기록을 기준으로 확인해야 해. 추측을 사실이라고 말하진 않을게.`:`${formatRef(view,p.id)}인 내가 거짓말했다는 근거는 지금 공개 기록에 없어. 확인할 만한 내 발언이 나오면 그걸 기준으로 판단하자.`;
    } else if(id===fromId && /(?:왜.*?(?:나|날|내)|나를.*?의심)/.test(q)) {
      const hadAccused=view.publicChat.some(x=>x.senderId===p.id && mentions(x.text,view.everyone).includes(fromId) &&
        /(?:의심|수상|마피아|거짓말)/.test(x.text));
      response=hadAccused?evidenceAnswer(p,view,mind,fromId,{direct:true}):'나는 너를 마피아라고 단정해서 지목한 적은 없어. 의심할 근거는 아직 없어. 네 발언을 확인하고 판단하려는 거야.';
    } else response=evidenceAnswer(p,view,mind,id,{direct:true});
  } else if(intent==='opinion') {
    if(/(?:내\s*말|내가\s*한\s*말|나를|날).{0,18}(?:믿|동의)/.test(q)) {
      const recent=findRecentWords(view,fromId,question.id);
      if(recent && claimedRole(recent))response=`네가 아까 ${roleAsQuote(claimedRole(recent))} 말한 건 기억해. 다만 그 발언만으로 진짜인지 확인할 수는 없어.`;
      else response='네 말을 무시한 건 아니야. 다만 믿는 것과 사실로 확인하는 건 구분해서 판단하려고 해.';
    } else {
    const broad=/(?:누가|누굴|누구).{0,20}(?:마피아|의심|수상)|(?:마피아|의심).{0,15}누구/.test(q);
    if(id && id!==p.id && !broad) {
      const recent=view.publicChat.findLast(x=>x.senderId===id && x.id!==question.id);
      if(/(?:말에\s*동의|말\s*믿|그\s*말\s*맞|뭐라고\s*했)/.test(q) && recent)response=`${ref}이 “${normalize(recent.text).slice(0,70)}”라고 말한 건 들었어. 그렇지만 그 말이 사실인지는 다른 단서와 비교해야 해.`;
      else response=summarizeVisibleFact(p,view,mind,id);
    } else {
      const eligible=view.alivePlayers.filter(x=>x.id!==p.id && x.id!==view.partnerId);
      const strong=eligible.map(x=>({x,fact:factFor(p,view,mind,x.id)})).filter(x=>x.fact?.strong);
      response=strong.length?`${formatRef(view,strong[0].x.id)}을 살펴볼 이유가 있어. ${strong[0].fact.text}`:
        '현재 누가 마피아인지 확실한 단서가 없어. 말투가 아니라 조사 결과와 실제 발언을 기준으로 보려고 해.';
    }
    }
  } else {
    if(/(?:맞지|맞아|동의해)/.test(q))response='네 말이 어떤 주장인지는 들었어. 다만 직업이나 마피아 여부는 검증 없이 맞다고 확정할 수 없어.';
    else if(id && id!==p.id)response=`${ref}에 관해 묻는 거지. ${summarizeVisibleFact(p,view,mind,id)}`;
    else response='질문을 정확히 이해하지 못했어. 알아듣지 못한 부분을 임의로 추리하지 않을게. 대상이나 행동을 구체적으로 말해줘.';
  }
  return finishInteraction(room,p,view,mind,question,response);
}
function decideSpeech(room,p,channel,rng,options={}) {
  const view=legalView(room,p),mind=readStatements(p,view,rng),profile=mind.persona;
  mind.turns++;
  const opener=choice(profile.rhythm,rng);
  if(channel==='SECRET') {
    const fresh=view.investigations.filter(x=>x.actualRole && x.actualRole!=='MAFIA' && view.alivePlayers.some(y=>y.id===x.targetId))
      .find(x=>!mind.spoken.includes('spy:'+x.targetId));
    if(p.role==='SPY' && fresh) {
      mind.spoken.push('spy:'+fresh.targetId);
      return `${formatRef(view,fresh.targetId)}을 조사했고 실제 직업은 ${fresh.displayed}이었어. 이건 내가 직접 알아낸 정보야. 살해 대상을 정할 때 참고해.`;
    }
    const focus=strongestSuspect(p,view,mind,view.alivePlayers.map(x=>x.id));
    return p.role==='MAFIA' ? `오늘 공격 대상은 내가 정할게. ${focus?formatRef(view,focus.id)+'은 공개 채팅에서 언급됐지만':'공개된 정보가 부족하니'} 이유 없이 단정하지 말고 판단하자.` :
      `지금까지 얻은 조사 정보와 낮 채팅을 함께 보자. 최종 공격 대상은 네가 정해.`;
  }
  const asked=pickQuestion(room,p,view,mind,options.replyToId);
  if(asked) return intentOf(asked.text) ? answerQuestion(room,p,view,mind,asked,rng) : replyToStatement(room,p,view,mind,asked,rng);
  const mafiaResult=view.role==='POLICE' && view.investigations.findLast(x=>x.displayed==='마피아팀' && view.alivePlayers.some(y=>y.id===x.targetId));
  if(mafiaResult && !mind.spoken.includes('police:'+mafiaResult.targetId) && reserveTopic(room,view.phaseStart,'police-result:'+p.id+':'+mafiaResult.targetId)) {
    mind.spoken.push('police:'+mafiaResult.targetId);
    return `내가 경찰이고 ${mafiaResult.night}번째 밤에 ${formatRef(view,mafiaResult.targetId)}을 조사했어. 결과는 마피아팀이야. 그 사람이 왜 의심받는지 설명할 수 있는 실제 조사 결과야.`;
  }
  const counter=Object.entries(mind.claims).find(([id,c])=>id!==p.id && c.role==='경찰' && view.role==='POLICE');
  if(counter && !mind.spoken.includes('counter:'+counter[0]) && reserveTopic(room,view.phaseStart,'counterclaim:'+p.id+':'+counter[0])) {
    mind.spoken.push('counter:'+counter[0]);
    return `${formatRef(view,counter[0])}은 경찰이라고 주장했지. 나도 경찰이야. 경찰은 한 명뿐이니까 둘 다 진짜일 수는 없어. 이게 내 의심의 이유야.`;
  }
  const shift=mind.claimChanges.findLast(x=>!mind.spoken.includes('changed:'+x.id) && !discussionLedger(room,view.phaseStart).topics.has('role-change:'+x.id));
  if(shift) {
    reserveTopic(room,view.phaseStart,'role-change:'+shift.id);
    mind.spoken.push('changed:'+shift.id);
    mind.lastOpinion={targetId:shift.speakerId,reason:'role-change'};
    return shift.to==='그 직업 부인'?
      `${formatRef(view,shift.speakerId)}은 앞에선 ${shift.from}이라고 했다가 지금은 그 직업이 아니라고 말했어. 바뀐 이유는 아직 모르니까 확인해 보자.`:
      `${formatRef(view,shift.speakerId)}은 앞에서 ${shift.from}, 뒤에는 ${roleAsQuote(shift.to)} 했어. 직업 주장이 바뀐 건 실제 채팅에 남아 있으니 그 이유를 확인하고 판단하자.`;
  }
  const voteShift=mind.stanceChanges.findLast(x=>!mind.spoken.includes('vote-shift:'+x.id) && !discussionLedger(room,view.phaseStart).topics.has('vote-shift:'+x.id));
  if(voteShift) {
    reserveTopic(room,view.phaseStart,'vote-shift:'+voteShift.id);
    mind.spoken.push('vote-shift:'+voteShift.id);
    const phrase=value=>value==='SKIP'?'건너뛰기':formatRef(view,value)+' 투표';
    return `${formatRef(view,voteShift.speakerId)}은 처음엔 ${phrase(voteShift.from)}, 지금은 ${phrase(voteShift.to)}라고 했어. 생각이 바뀔 순 있지만 이유는 아직 확인되지 않았어.`;
  }
  const lastClaim=Object.entries(mind.claims).find(([id,c])=>!mind.spoken.includes('claim:'+id+':'+c.role) && !discussionLedger(room,view.phaseStart).topics.has('claim:'+id+':'+c.role) && !mind.claimChanges.some(x=>x.speakerId===id) && id!==p.id);
  if(lastClaim) {
    reserveTopic(room,view.phaseStart,'claim:'+lastClaim[0]+':'+lastClaim[1].role);
    mind.spoken.push('claim:'+lastClaim[0]+':'+lastClaim[1].role);
    return `${formatRef(view,lastClaim[0])}이 ${roleAsQuote(lastClaim[1].role)} 주장했어. 말 자체는 확인됐지만 진짜 그 직업인지는 아직 증명되지 않았어. 말과 조사 결과는 구분해야 해.`;
  }
  const list=view.alivePlayers.filter(x=>x.id!==p.id);
  const strong=list.map(x=>({q:x,fact:factFor(p,view,mind,x.id)}))
    .filter(x=>x.fact?.strong).sort((a,b)=>suspicion(mind,view,b.q.id)-suspicion(mind,view,a.q.id));
  const topicForFact=entry=>{
    if(entry.fact.kind==='role-change') {
      const shift=mind.claimChanges.findLast(x=>x.speakerId===entry.q.id);
      return shift?'role-change:'+shift.id:null;
    }
    if(entry.fact.kind==='police-result')return 'police-result:'+p.id+':'+entry.q.id;
    if(entry.fact.kind==='counterclaim')return 'counterclaim:'+p.id+':'+entry.q.id;
    return 'fact:'+entry.q.id+':'+entry.fact.kind;
  };
  if(strong.length) {
    const entry=strong.find(x=>topicForFact(x) && !discussionLedger(room,view.phaseStart).topics.has(topicForFact(x)));
    if(entry) {
      reserveTopic(room,view.phaseStart,topicForFact(entry));
      mind.spoken.push('fact:'+entry.q.id+':'+entry.fact.kind);
      mind.lastOpinion={targetId:entry.q.id,reason:entry.fact.kind};
      return `${opener}, ${entry.fact.text} 이건 막연한 느낌이 아니라 확인 가능한 단서야.`;
    }
  }
  const publicResult=view.publicLog.findLast(x=>/지난밤 .*사망|지난밤 사망자는 없습니다/.test(x.text));
  const topics=[
    `현재 공개된 사실은 ${publicResult?.text || '아직 밤 사망 결과가 없다는 점'}이야. 그 이유가 누구 때문인지는 알려지지 않았어.`,
    `나는 아직 누가 마피아인지 확신할 증거가 없어. 말투만으로 누군가를 퇴출시키는 건 위험해.`,
    `누가 다른 사람을 의심한다는 사실과 실제로 마피아라는 증거는 달라. 두 가지를 구분해서 판단하자.`,
    `자기 직업을 주장하는 건 누구나 할 수 있어. 조사 내용이나 앞서 했던 말과 맞는지 확인해야 해.`,
    `확실한 근거가 없으면 이번 투표를 건너뛰고 다음 밤 정보를 기다리는 것도 합리적이야.`,
    `나는 지금은 판단을 보류할게. 새 단서가 나오기 전까지 같은 의심을 반복하지는 않겠어.`
  ];
  const offset=(p.number + Math.floor(view.night||1)*2 + mind.turns-1)%topics.length;
  const index=Array.from({length:topics.length},(_,i)=>(offset+i)%topics.length)
    .find(i=>reserveTopic(room,view.phaseStart,'topic:'+i,true));
  if(index===undefined)return null;
  mind.spoken.push('topic:'+index);
  if(mind.spoken.length>160)mind.spoken=mind.spoken.slice(-120);
  return `${opener}, ${topics[index]}`;
}

module.exports={ mindFor, legalView, readStatements, decideSpeech, chooseNight, chooseVote, claimedRole, mentions, isQuestion, directAddressee, isReactiveMessage };

})(botModule,botModule.exports);
const engineModule={exports:{}};
(function(module,exports,require){
'use strict';

const crypto = require('node:crypto');
const BotMind = require('./bot-mind');
const ROLES = ['MAFIA', 'SPY', 'POLICE', 'DOCTOR', 'GANGSTER', 'CITIZEN', 'CITIZEN'];
const ROLE_KO = {
  MAFIA: '마피아', SPY: '스파이', POLICE: '경찰', DOCTOR: '의사',
  GANGSTER: '건달', CITIZEN: '시민'
};
const TEAM = { MAFIA: 'MAFIA', SPY: 'MAFIA', POLICE: 'CITIZEN',
  DOCTOR: 'CITIZEN', GANGSTER: 'CITIZEN', CITIZEN: 'CITIZEN' };
const DEFAULT_DURATIONS = {
  NIGHT: 60000, NIGHT_RESULT: 4500, DAY: 60000,
  VOTE1: 30000, EXTRA_DISCUSSION: 45000, VOTE2: 30000,
  VOTE_RESULT: 4500
};
const MAX_CHAT_LENGTH = 220;
const BOT_NAMES = ['도윤', '서아', '민준', '하린', '지호', '수빈', '유진'];

function rule(condition, message) { if (!condition) throw new Error(message); }
function shuffled(items, rng) {
  const out = items.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}
function pick(items, rng) { return items.length ? items[Math.floor(rng() * items.length)] : null; }
function sanitizeName(value) {
  return String(value || '').replace(/[\r\n<>]/g, '').trim().slice(0, 18) || '익명';
}
function sanitizeChat(value) {
  return String(value || '').replace(/[\u0000-\u001F\u007F]/g, '').trim().slice(0, MAX_CHAT_LENGTH);
}
function publicActor(p) {
  return { id: p.id, number: p.number, name: p.name, bot: p.bot, alive: p.alive,
    boxPicked: p.boxIndex !== null, roleReady: p.roleReady };
}

class MafiaRoom {
  constructor(code, options = {}) {
    this.code = code;
    this.now = options.now || Date.now;
    this.rng = options.rng || Math.random;
    this.durations = { ...DEFAULT_DURATIONS, ...options.durations };
    this.onChange = options.onChange || (() => {});
    this.players = [];
    this.hostId = null;
    this.phase = 'LOBBY';
    this.phaseStart = this.now();
    this.deadline = null;
    this.night = 0;
    this.boxAssignments = null;
    this.boxOwners = null;
    this.actions = new Map();
    this.votes = new Map();
    this.contact = null;
    this.stunnedId = null;
    this.pendingNight = null;
    this.voteOutcome = null;
    this.publicLog = [];
    this.publicChat = [];
    this.secretChat = [];
    this.winningTeam = null;
    this.abortReason = null;
    this.botPlans = [];
    this.updatedAt = this.now();
  }

  update() { this.updatedAt = this.now(); this.onChange(this); }
  getPlayer(id) { return this.players.find(p => p.id === id); }
  hasActiveMatch() { return !['LOBBY', 'ABORTED', 'GAME_OVER'].includes(this.phase); }
  isHost(p) { return !!p && p.id === this.hostId; }
  ensureHost(p) { rule(this.isHost(p), '방장만 사용할 수 있습니다.'); }
  ensurePhase(...phases) { rule(phases.includes(this.phase), '현재 단계에서는 사용할 수 없습니다.'); }
  nextNumber() {
    for (let n = 1; n <= 7; n++) if (!this.players.some(p => p.number === n)) return n;
    return null;
  }

  createPlayer(name, bot = false) {
    this.ensurePhase('LOBBY');
    rule(this.players.length < 7, '방 인원이 가득 찼습니다.');
    const id = crypto.randomUUID();
    const p = {
      id, number: this.nextNumber(), name: sanitizeName(name), bot,
      token: bot ? null : crypto.randomBytes(24).toString('hex'),
      connected: false, connection: null, role: null, team: null, alive: true,
      boxIndex: null, roleReady: false, notices: [], investigations: [],
      lastChatAt: -Infinity
    };
    this.players.push(p);
    if (!this.hostId && !bot) this.hostId = id;
    this.log(`${p.number}번 ${p.name}님이 입장했습니다.${bot ? ' (AI)' : ''}`);
    this.update();
    return p;
  }

  addBots(actor, count = 1) {
    this.ensureHost(actor);
    this.ensurePhase('LOBBY');
    rule(Number.isInteger(count) && count >= 1 && count <= 6, 'AI 추가 인원이 올바르지 않습니다.');
    rule(this.players.length + count <= 7, '참가 인원은 7명까지입니다.');
    for (let i = 0; i < count; i++) {
      const used = new Set(this.players.map(p => p.name));
      const name = BOT_NAMES.find(n => !used.has(n)) || `AI ${i + 1}`;
      this.createPlayer(name, true);
    }
  }
  removeBots(actor) {
    this.ensureHost(actor);
    this.ensurePhase('LOBBY');
    this.players = this.players.filter(p => !p.bot);
    this.log('AI 플레이어를 제거했습니다.');
    this.update();
  }
  removeHuman(p, reason = '접속 종료') {
    if (!this.players.includes(p)) return;
    const mustAbort = this.hasActiveMatch();
    this.players = this.players.filter(x => x.id !== p.id);
    if (this.hostId === p.id) this.hostId = this.players.find(x => !x.bot)?.id || null;
    if (mustAbort) this.abort(`${p.number}번 ${p.name}: ${reason}`);
    else { this.log(`${p.number}번 ${p.name}님이 나갔습니다.`); this.update(); }
  }

  log(text) {
    this.publicLog.push({ at: this.now(), text });
    if (this.publicLog.length > 50) this.publicLog.shift();
  }
  notice(p, text, type = 'info') {
    if (!p) return;
    p.notices.push({ id: crypto.randomUUID(), at: this.now(), text, type });
    if (p.notices.length > 20) p.notices.shift();
  }
  phaseTo(phase, duration = null) {
    this.phase = phase;
    this.phaseStart = this.now();
    this.deadline = duration === null ? null : this.phaseStart + duration;
    this.botPlans = [];
    this.scheduleBots();
    this.update();
  }

  startDraft(actor) {
    this.ensureHost(actor);
    this.ensurePhase('LOBBY');
    rule(this.players.length === 7, '게임을 시작하려면 7명이 필요합니다.');
    rule(this.players.filter(p => !p.bot).every(p => p.connected), '모든 실제 플레이어가 연결되어야 합니다.');
    this.clearRoundState();
    this.boxAssignments = shuffled(ROLES, this.rng);
    this.boxOwners = Array(7).fill(null);
    this.log('직업 상자 7개가 준비되었습니다. 각자 한 개를 선택하세요.');
    this.phaseTo('BOXES');
  }
  clearRoundState() {
    this.night = 0;
    this.contact = null;
    this.stunnedId = null;
    this.pendingNight = null;
    this.voteOutcome = null;
    this.winningTeam = null;
    this.abortReason = null;
    this.publicChat = [];
    this.secretChat = [];
    this.actions.clear();
    this.votes.clear();
    for (const p of this.players) {
      p.role = null; p.team = null; p.alive = true; p.boxIndex = null;
      p.roleReady = false; p.notices = []; p.investigations = []; p.mind = null;
    }
  }
  chooseBox(p, index) {
    this.ensurePhase('BOXES');
    rule(p && this.players.includes(p), '참가자만 상자를 선택할 수 있습니다.');
    rule(!p.bot, 'AI의 상자는 서버가 배정합니다.');
    rule(Number.isInteger(index) && index >= 0 && index < 7, '올바르지 않은 상자입니다.');
    rule(p.boxIndex === null, '이미 상자를 선택했습니다.');
    rule(this.boxOwners[index] === null, '이미 선택된 상자입니다.');
    this.assignBox(p, index);
    this.completeBotBoxesIfReady();
    this.update();
  }
  assignBox(p, index) {
    this.boxOwners[index] = p.id;
    p.boxIndex = index;
    p.role = this.boxAssignments[index];
    p.team = TEAM[p.role];
    this.notice(p, `당신의 직업은 ${ROLE_KO[p.role]}입니다.`, 'role');
  }
  completeBotBoxesIfReady() {
    if (!this.players.filter(p => !p.bot).every(p => p.boxIndex !== null)) return;
    for (const p of this.players.filter(p => p.bot)) {
      const open = this.boxOwners.map((owner, i) => owner === null ? i : -1).filter(i => i !== -1);
      this.assignBox(p, pick(open, this.rng));
      p.roleReady = true;
    }
    this.maybeBeginAfterDraft();
  }
  confirmRole(p) {
    this.ensurePhase('BOXES');
    rule(p && p.boxIndex !== null, '먼저 직업 상자를 선택하세요.');
    p.roleReady = true;
    this.maybeBeginAfterDraft();
    this.update();
  }
  maybeBeginAfterDraft() {
    if (this.players.length === 7 && this.players.every(p => p.boxIndex !== null && p.roleReady)) this.startNight();
  }

  usable(p) {
    if (!p || !p.alive) return false;
    if (p.role === 'CITIZEN') return false;
    if (p.role === 'SPY' && this.contact && this.night > this.contact.night) return false;
    return true;
  }
  validTargets(p) {
    if (!this.usable(p)) return [];
    return this.players.filter(q => q.alive && (
      p.role === 'DOCTOR' || q.id !== p.id
    ) && !(
      p.role === 'MAFIA' && this.contact && this.night > this.contact.night && q.role === 'SPY'
    )).map(q => q.id);
  }
  startNight() {
    this.night += 1;
    this.pendingNight = null;
    this.stunnedId = null;
    this.actions.clear();
    this.voteOutcome = null;
    for (const p of this.players) if (this.usable(p)) {
      this.actions.set(p.id, { selected: null, confirmed: false, target: null,
        auto: false, fromLastSelection: false, confirmedAt: null });
    }
    this.log(`${this.night}번째 밤이 시작되었습니다.`);
    this.phaseTo('NIGHT', this.durations.NIGHT);
  }
  selectAbility(p, targetId) {
    this.ensurePhase('NIGHT');
    rule(this.usable(p), '야간 능력을 사용할 수 없습니다.');
    const action = this.actions.get(p.id);
    rule(action && !action.confirmed, '이미 행동을 확정하여 변경할 수 없습니다.');
    rule(this.validTargets(p).includes(targetId), '해당 플레이어는 선택할 수 없습니다.');
    action.selected = targetId;
    this.update();
  }
  confirmAbility(p, targetId) {
    this.ensurePhase('NIGHT');
    const action = this.actions.get(p?.id);
    rule(action && !action.confirmed, '행동을 확정할 수 없습니다.');
    rule(action.selected !== null && action.selected === targetId, '먼저 대상을 임시 선택하세요.');
    rule(this.validTargets(p).includes(targetId), '유효하지 않은 대상입니다.');
    action.confirmed = true;
    action.target = targetId;
    action.confirmedAt = this.now();
    this.notice(p, '능력 사용 대상이 확정되었습니다. 더 이상 변경할 수 없습니다.');
    if (this.allActionsConfirmed()) this.resolveNight();
    else this.update();
  }
  allActionsConfirmed() {
    return Array.from(this.actions.values()).every(a => a.confirmed);
  }
  finalizeNightActions() {
    for (const [id, action] of this.actions) {
      if (action.confirmed) continue;
      const p = this.getPlayer(id);
      if (action.selected !== null && this.validTargets(p).includes(action.selected)) {
        action.target = action.selected;
        action.fromLastSelection = true;
        this.notice(p, '제한 시간이 종료되어 마지막으로 선택한 대상이 확정되었습니다.');
      } else if (p.role === 'DOCTOR') {
        action.target = p.id;
        action.auto = true;
        this.notice(p, '대상을 선택하지 않아 자신을 자동 치료합니다.');
      } else {
        action.target = pick(this.validTargets(p), this.rng);
        action.auto = true;
        this.notice(p, '제한 시간이 종료되어 대상이 자동 선택되었습니다.');
      }
      action.confirmed = true;
      action.confirmedAt = this.now();
    }
  }
  playerByRole(role) { return this.players.find(p => p.role === role); }
  actionTarget(role) {
    const p = this.playerByRole(role);
    return p && this.actions.get(p.id)?.target || null;
  }
  resolveNight() {
    if (this.phase !== 'NIGHT') return;
    this.finalizeNightActions();
    const mafia = this.playerByRole('MAFIA');
    const spy = this.playerByRole('SPY');
    const police = this.playerByRole('POLICE');
    const doctor = this.playerByRole('DOCTOR');
    const gangster = this.playerByRole('GANGSTER');
    const mafiaTarget = this.actionTarget('MAFIA');
    const spyTarget = this.actionTarget('SPY');
    const policeTarget = this.actionTarget('POLICE');
    const doctorTarget = this.actionTarget('DOCTOR');
    const gangsterTarget = this.actionTarget('GANGSTER');

    // Investigations are simultaneous, irrespective of the order in which clients submitted.
    if (spyTarget && spy?.alive && this.actions.has(spy.id)) {
      const target = this.getPlayer(spyTarget);
      spy.investigations.push({ night: this.night, targetId: target.id,
        actualRole: target.role, displayed: ROLE_KO[target.role] });
      this.notice(spy, `${target.number}번 ${target.name}의 실제 직업: ${ROLE_KO[target.role]}`, 'investigation');
    }
    if (policeTarget && police?.alive) {
      const target = this.getPlayer(policeTarget);
      const displayed = target.role === 'MAFIA' ? '마피아팀' : '시민팀';
      police.investigations.push({ night: this.night, targetId: target.id, displayed });
      this.notice(police, `${target.number}번 ${target.name}의 소속 조사 결과: ${displayed}`, 'investigation');
    }

    const beforeContact = !this.contact;
    const contactA = beforeContact && spy?.alive && spyTarget === mafia?.id;
    const contactB = beforeContact && spy?.alive && mafiaTarget === spy.id;
    if (contactA || contactB) {
      this.contact = { night: this.night, type: contactA ? 'A' : 'B' };
      this.notice(mafia, '스파이와 접선했습니다. 다음 날 밤부터 비밀 채팅을 사용할 수 있습니다.', 'contact');
      this.notice(spy, '마피아와 접선했습니다. 다음 날 밤부터 비밀 채팅을 사용할 수 있으며 조사 능력은 종료됩니다.', 'contact');
    }
    const attackCanceled = !!(spy?.alive && mafiaTarget === spy.id);
    if (attackCanceled && mafia) {
      this.notice(mafia, '스파이 대상 공격이 취소되었습니다. 이번 밤에는 추가 공격할 수 없습니다.', 'contact');
    }
    const effectiveAttack = attackCanceled ? null : mafiaTarget;
    const saved = !!(effectiveAttack && doctor?.alive && doctorTarget === effectiveAttack);
    const deathId = effectiveAttack && !saved ? effectiveAttack : null;
    if (doctor?.alive && doctorTarget) {
      this.notice(doctor, saved ? '당신이 선택한 플레이어를 살렸습니다.' :
        '당신이 선택한 플레이어는 공격받지 않았습니다.', saved ? 'success' : 'info');
    }
    this.pendingNight = { deathId, stunId: gangster?.alive ? gangsterTarget : null,
      attackTargetId: mafiaTarget, effectiveAttack, saved, contactType: contactA ? 'A' : contactB ? 'B' : null };
    this.phaseTo('NIGHT_RESULT', this.durations.NIGHT_RESULT);
  }
  publishMorning() {
    if (this.phase !== 'NIGHT_RESULT') return;
    const result = this.pendingNight || {};
    const victim = result.deathId ? this.getPlayer(result.deathId) : null;
    if (victim) victim.alive = false;
    const stunned = result.stunId ? this.getPlayer(result.stunId) : null;
    this.stunnedId = stunned?.alive ? stunned.id : null;
    if (stunned?.alive) this.notice(stunned, '당신은 오늘 투표에 참여할 수 없습니다.', 'warning');
    if (victim) this.log(`지난밤 ${victim.number}번 ${victim.name}이(가) 사망했습니다.`);
    else this.log('지난밤 사망자는 없습니다.');
    if (this.checkVictory()) return;
    this.log('날이 밝았습니다. 1분 동안 토론을 진행해 주세요.');
    this.phaseTo('DAY', this.durations.DAY);
  }

  canChat(p, channel = 'PUBLIC') {
    if (!p || !p.alive || !this.players.includes(p)) return false;
    if (channel === 'PUBLIC') return ['DAY', 'EXTRA_DISCUSSION'].includes(this.phase);
    if (channel === 'SECRET') return this.phase === 'NIGHT' &&
      !!this.contact && this.night > this.contact.night &&
      ['MAFIA', 'SPY'].includes(p.role) &&
      this.playerByRole('MAFIA')?.alive && this.playerByRole('SPY')?.alive;
    return false;
  }
  sendChat(p, channel, input) {
    rule(this.canChat(p, channel), '현재 채팅을 사용할 수 없습니다.');
    const text = sanitizeChat(input);
    rule(text.length > 0, '채팅 메시지를 입력하세요.');
    rule(this.now() - p.lastChatAt >= 650, '메시지를 너무 빠르게 보내고 있습니다.');
    // Minimal abuse filter, not a game mechanic. Messages are always rendered as text, never HTML.
    rule(!/(?:시발|씨발|병신|개새끼)/i.test(text), '부적절한 표현은 전송할 수 없습니다.');
    p.lastChatAt = this.now();
    const entry = { id: crypto.randomUUID(), at: this.now(), senderId: p.id,
      number: p.number, name: p.name, bot: p.bot, text, channel };
    const arr = channel === 'SECRET' ? this.secretChat : this.publicChat;
    arr.push(entry);
    if (arr.length > 100) arr.shift();
    this.update();
    if (channel === 'PUBLIC') this.scheduleReactions(p, text, entry);
  }

  startVote(number) {
    this.votes.clear();
    this.voteOutcome = null;
    this.log(number === 1 ? '1차 투표가 시작되었습니다.' : '재투표가 시작되었습니다.');
    this.phaseTo(number === 1 ? 'VOTE1' : 'VOTE2', this.durations[number === 1 ? 'VOTE1' : 'VOTE2']);
  }
  canVote(p) {
    return !!p && p.alive && this.stunnedId !== p.id &&
      ['VOTE1', 'VOTE2'].includes(this.phase);
  }
  submitVote(p, targetId) {
    rule(this.canVote(p), '투표할 수 없습니다.');
    rule(!this.votes.has(p.id), '이미 투표를 제출했습니다.');
    rule(targetId === 'SKIP' || (targetId !== p.id &&
      this.players.some(q => q.id === targetId && q.alive)), '유효하지 않은 투표 대상입니다.');
    this.votes.set(p.id, { targetId, at: this.now() });
    this.notice(p, targetId === 'SKIP' ? '투표 건너뛰기를 제출했습니다.' : '투표를 제출했습니다.');
    this.update();
  }
  tallyVote() {
    const counts = new Map();
    for (const entry of this.votes.values()) {
      counts.set(entry.targetId, (counts.get(entry.targetId) || 0) + 1);
    }
    if (!this.votes.size) return { kind: 'EMPTY', counts: [], valid: 0 };
    const max = Math.max(...counts.values());
    const winners = Array.from(counts.entries()).filter(([, n]) => n === max).map(([id]) => id);
    const list = Array.from(counts.entries()).map(([targetId, count]) => ({ targetId, count }));
    return { kind: winners.length > 1 ? 'TIE' : winners[0] === 'SKIP' ? 'SKIP' : 'EXPEL',
      targetId: winners.length === 1 ? winners[0] : null,
      tiedIds: winners.length > 1 ? winners : [], counts: list, valid: this.votes.size };
  }
  resolveVote() {
    if (!['VOTE1', 'VOTE2'].includes(this.phase)) return;
    const isFirst = this.phase === 'VOTE1';
    const outcome = this.tallyVote();
    this.voteOutcome = { ...outcome, round: isFirst ? 1 : 2 };
    if (outcome.kind === 'TIE' && isFirst) {
      this.log('최다 득표 동률이 발생했습니다. 45초 동안 추가 토론합니다.');
      this.phaseTo('EXTRA_DISCUSSION', this.durations.EXTRA_DISCUSSION);
      return;
    }
    if (outcome.kind === 'EXPEL') {
      const eliminated = this.getPlayer(outcome.targetId);
      eliminated.alive = false;
      this.log(`투표 결과 ${eliminated.number}번 ${eliminated.name}이(가) 퇴출되었습니다.`);
      if (this.checkVictory()) return;
    } else if (outcome.kind === 'SKIP') {
      this.log('투표 건너뛰기가 단독 최다 득표했습니다. 퇴출자는 없습니다.');
    } else if (outcome.kind === 'EMPTY') {
      this.log('유효표가 없습니다. 투표 무효, 퇴출자는 없습니다.');
    } else {
      this.log('재투표에서도 동률이 발생했습니다. 퇴출자는 없습니다.');
    }
    this.phaseTo('VOTE_RESULT', this.durations.VOTE_RESULT);
  }
  checkVictory() {
    const mafia = this.playerByRole('MAFIA');
    if (!mafia?.alive) { this.finishGame('CITIZEN'); return true; }
    if (!this.players.some(p => p.alive && p.team === 'CITIZEN')) {
      this.finishGame('MAFIA'); return true;
    }
    return false;
  }
  finishGame(team) {
    this.winningTeam = team;
    this.log(team === 'CITIZEN' ? '마피아가 제거되었습니다. 시민팀이 승리했습니다!' :
      '시민팀 전원이 제거되었습니다. 마피아팀이 승리했습니다!');
    this.phaseTo('GAME_OVER');
  }
  abort(reason) {
    if (['ABORTED', 'GAME_OVER', 'LOBBY'].includes(this.phase)) return;
    this.abortReason = reason || '연결 문제';
    this.winningTeam = null;
    this.pendingNight = null;
    this.actions.clear(); this.votes.clear();
    this.log(`게임 연결 문제로 판이 중단되었습니다. ${this.abortReason}`);
    this.phaseTo('ABORTED');
  }
  resetLobby(actor) {
    this.ensureHost(actor);
    this.ensurePhase('GAME_OVER', 'ABORTED');
    if (this.phase === 'ABORTED') this.players = this.players.filter(p => !p.bot);
    this.clearRoundState();
    this.boxOwners = null; this.boxAssignments = null;
    this.log('새 게임을 위한 인원 모집을 시작합니다.');
    this.phaseTo('LOBBY');
  }

  // The bot only sees its own role, its own investigation history, public data,
  // and a contact partner once contact has genuinely happened.
  botKnowledge(p) {
    const partner = this.contact ?
      this.players.find(q => q.id !== p.id && ['MAFIA', 'SPY'].includes(q.role)) : null;
    return { role: p.role, team: p.team, selfId: p.id, playerNumber: p.number,
      alivePlayers: this.players.filter(q => q.alive).map(q => ({ id: q.id, number: q.number, name: q.name })),
      investigations: p.investigations.map(i => ({ ...i })),
      partnerId: ['MAFIA', 'SPY'].includes(p.role) && this.contact ? partner?.id : null,
      contacted: ['MAFIA','SPY'].includes(p.role) && !!this.contact, night: this.night };
  }
  botNightTarget(p) {
    return BotMind.chooseNight(this,p,this.rng);
  }
  botVoteTarget(p) {
    return BotMind.chooseVote(this,p,this.rng);
  }
  botChatText(p, channel, replyToId = null) {
    const mind=BotMind.mindFor(p,this.rng);
    if(!mind.recentLines) mind.recentLines=[];
    let line=BotMind.decideSpeech(this,p,channel,this.rng,replyToId?{replyToId}:{});
    // Do not replace a direct answer with a generic line merely for duplicate avoidance.
    if(!line)return null;
    if(!replyToId && mind.recentLines.includes(line))
      line=BotMind.decideSpeech(this,p,channel,this.rng);
    if(!line)return null;
    mind.recentLines.push(line);
    if(mind.recentLines.length>12)mind.recentLines.shift();
    return line;
  }
  scheduleReactions(sender,text,entry) {
    if (!['DAY','EXTRA_DISCUSSION'].includes(this.phase) || !entry) return;
    const now=this.now();
    if(!sender.bot && !this.players.includes(sender))return;
    if(this.deadline-now<1150)return;
    const isQuestion=BotMind.isQuestion(text);
    const view={everyone:this.players};
    const directId=BotMind.directAddressee(text,view);
    const addressed=this.players.filter(x=>x.bot && x.alive && x.id!==sender.id &&
      (directId ? x.id===directId : x.name.length>1 &&
        new RegExp('^'+x.name+'(?:[,:：，\\s]|님|아|야)').test(text)));
    // Bot-to-bot spontaneous reactions create feedback loops; permit only an
    // explicitly addressed question. Human statements are meaningful turns too.
    if(sender.bot && (!isQuestion || !/[?？]/.test(text) || !addressed.length))return;
    if(!sender.bot && !BotMind.isReactiveMessage(text))return;
    const candidates=this.players.filter(x=>x.bot && x.alive && x.id!==sender.id);
    if(!candidates.length)return;
    let bot=addressed[0] || null;
    const prior=this.publicChat.length>=2?this.publicChat[this.publicChat.length-2]:null;
    const referBack=/(?:뭔\s*소리|무슨\s*말|무슨\s*뜻|방금|그게\s*무슨|설명해|응|맞아|그래|동의|아니\s*그게|그건\s*아니)/.test(text);
    if(!bot && !sender.bot && referBack && prior?.bot)
      bot=candidates.find(x=>x.id===prior.senderId)||null;
    if(!bot && !sender.bot && /(?:너|넌|네가|니가|너는|네\s*말)/.test(text) && prior?.bot)
      bot=candidates.find(x=>x.id===prior.senderId)||null;
    if(!bot && !sender.bot && isQuestion && /(?:왜.*?(?:나|날|내)|나를.*?의심)/.test(text))
      bot=candidates.findLast(x=>x.mind?.lastOpinion?.targetId===sender.id)||null;
    if(!bot && !sender.bot) {
      const subjects=BotMind.mentions(text,this.players);
      // An accusation ABOUT a bot should be assessed by another participant,
      // unless the player addresses that bot directly.
      bot=pick(candidates.filter(x=>!subjects.includes(x.id)),this.rng)||pick(candidates,this.rng);
    }
    if(!bot)return;
    // Prevent flood when a human types numerous fragments. Direct questions
    // still take priority, up to the ordinary discussion deadline.
    const queued=this.botPlans.filter(x=>!x.done && x.kind==='PUBLIC_CHAT' && x.replyToId).length;
    if(queued>=12 && !isQuestion)return;
    const at=Math.min(Math.max(now+900,bot.lastChatAt+780),this.deadline-140);
    if(at<=now)return;
    const pending=this.botPlans.find(plan=>!plan.done && plan.id===bot.id && plan.kind==='PUBLIC_CHAT');
    if(pending) {
      if(pending.replyToId && pending.replyToId!==entry.id) {
        const followUpAt=Math.min(Math.max(at,pending.at+900),this.deadline-140);
        if(followUpAt>now)this.botPlans.push({id:bot.id,kind:'PUBLIC_CHAT',at:followUpAt,done:false,replyToId:entry.id});
      } else {
        pending.at=Math.min(pending.at,at);
        pending.replyToId=entry.id;
      }
      return;
    }
    this.botPlans.push({id:bot.id,kind:'PUBLIC_CHAT',at,done:false,replyToId:entry.id});
  }
  scheduleBots() {
    const duration = this.deadline !== null ? this.deadline - this.phaseStart : 0;
    const schedule = (p, kind, minFraction, maxFraction) => {
      const at = this.phaseStart + Math.max(80, duration * (minFraction + this.rng() * (maxFraction - minFraction)));
      this.botPlans.push({ id: p.id, kind, at, done: false });
    };
    if (this.phase === 'NIGHT') {
      for (const p of this.players.filter(x => x.bot && x.alive)) {
        if (this.usable(p)) schedule(p, 'ABILITY', 0.05, 0.22);
        if (this.canChat(p, 'SECRET')) {
          schedule(p, 'SECRET_CHAT', 0.015, 0.12);
          if (this.rng() < 0.68) schedule(p, 'SECRET_CHAT', 0.26, 0.65);
        }
      }
    }
    if (['DAY', 'EXTRA_DISCUSSION'].includes(this.phase)) {
      const speakers=this.players.filter(x => x.bot && x.alive);
      const offset=speakers.length?Math.floor(this.rng()*speakers.length):0;
      for(let i=0;i<speakers.length;i++) {
        const p=speakers[(i+offset)%speakers.length];
        BotMind.mindFor(p,this.rng);
        // Space out contributions over the discussion instead of making every
        // bot interrupt at once in the first ten seconds.
        const fraction=0.055+(i+this.rng()*0.45)*0.78/speakers.length;
        this.botPlans.push({id:p.id,kind:'PUBLIC_CHAT',at:this.phaseStart+Math.max(80,duration*fraction),done:false});
        if(this.rng()<0.30)schedule(p,'PUBLIC_CHAT',0.72,0.92);
      }
    }
    if (['VOTE1', 'VOTE2'].includes(this.phase)) {
      for (const p of this.players.filter(x => x.bot && x.alive && this.stunnedId !== x.id)) {
        schedule(p, 'VOTE', 0.10, 0.60);
      }
    }
  }
  actBot(plan) {
    const p = this.getPlayer(plan.id);
    if (!p?.alive) return;
    try {
      if (plan.kind === 'ABILITY' && this.phase === 'NIGHT' && this.usable(p)) {
        const t = this.botNightTarget(p);
        if (t) {
          this.selectAbility(p, t);
          this.confirmAbility(p, t);
        }
      } else if (plan.kind === 'SECRET_CHAT' && this.canChat(p, 'SECRET')) {
        this.sendChat(p, 'SECRET', this.botChatText(p, 'SECRET'));
      } else if (plan.kind === 'PUBLIC_CHAT' && this.canChat(p, 'PUBLIC')) {
        // A direct reply should not be lost to the chat anti-spam cooldown.
        if(this.now()-p.lastChatAt<660) {
          const when=p.lastChatAt+690;
          if(when<this.deadline) this.botPlans.push({...plan,at:when,done:false});
          return;
        }
        const line=this.botChatText(p, 'PUBLIC', plan.replyToId);
        if(line)this.sendChat(p, 'PUBLIC', line);
      } else if (plan.kind === 'VOTE' && this.canVote(p) && !this.votes.has(p.id)) {
        this.submitVote(p, this.botVoteTarget(p));
      }
    } catch (e) { /* A bot missing a turn is subject to the ordinary automatic rules. */ }
  }
  tick() {
    if (this.deadline === null) return;
    const now = this.now();
    // Copy because actions can change the phase while iterating.
    for (const plan of this.botPlans.slice()) {
      if (plan.done || plan.at > now) continue;
      plan.done = true;
      const expected = this.phase;
      this.actBot(plan);
      if (this.phase !== expected) break;
    }
    if (this.deadline === null || now < this.deadline) return;
    switch (this.phase) {
      case 'NIGHT': this.resolveNight(); break;
      case 'NIGHT_RESULT': this.publishMorning(); break;
      case 'DAY': this.startVote(1); break;
      case 'VOTE1': case 'VOTE2': this.resolveVote(); break;
      case 'EXTRA_DISCUSSION': this.startVote(2); break;
      case 'VOTE_RESULT': this.startNight(); break;
      default: break;
    }
  }

  snapshotFor(p) {
    const finished = this.phase === 'GAME_OVER';
    const privateAction = this.actions.get(p?.id);
    const canSeeSecret = p && ['MAFIA', 'SPY'].includes(p.role) &&
      !!this.contact && this.night > this.contact.night;
    const seesPartner = !!p && ['MAFIA', 'SPY'].includes(p.role) && !!this.contact;
    const partner = seesPartner ? this.players.find(q => q.id !== p.id && ['MAFIA', 'SPY'].includes(q.role)) : null;
    return {
      code: this.code, phase: this.phase, phaseStart: this.phaseStart,
      deadline: this.deadline, serverNow: this.now(), night: this.night,
      players: this.players.map(x => ({ ...publicActor(x),
        ...(finished ? { role: x.role, team: x.team } : {}) })),
      hostId: this.hostId,
      seatsMax: 7,
      boxes: this.boxOwners ? this.boxOwners.map((id, index) => ({ index, chosen: id !== null,
        pickerId: id })) : [],
      me: p ? { id: p.id, number: p.number, name: p.name, role: p.role,
        roleKo: p.role ? ROLE_KO[p.role] : null, team: p.team, alive: p.alive,
        connected: p.connected, boxIndex: p.boxIndex, roleReady: p.roleReady,
        isHost: this.isHost(p), canAct: this.phase === 'NIGHT' && this.usable(p),
        validTargets: this.phase === 'NIGHT' ? this.validTargets(p) : [],
        action: privateAction ? { selected: privateAction.selected, confirmed: privateAction.confirmed,
          target: privateAction.target, auto: privateAction.auto } : null,
        teamAction: p.role === 'SPY' && this.phase === 'NIGHT' && this.contact &&
          this.night > this.contact.night && this.playerByRole('MAFIA')?.alive ? (() => {
            const a = this.actions.get(this.playerByRole('MAFIA').id);
            return a ? { selected:a.selected, confirmed:a.confirmed, target:a.target } : null;
          })() : null,
        canVote: this.canVote(p), voted: this.votes.has(p.id),
        stunned: this.stunnedId === p.id,
        canPublicChat: this.canChat(p, 'PUBLIC'), canSecretChat: this.canChat(p, 'SECRET'),
        notices: p.notices.slice(-12), investigations: p.investigations.slice(),
        contact: seesPartner ? { night: this.contact.night, type: this.contact.type,
          partnerId: partner?.id, partnerNumber: partner?.number, partnerName: partner?.name } : null } : null,
      publicLog: this.publicLog.slice(-18), publicChat: this.publicChat.slice(-80),
      secretChat: canSeeSecret ? this.secretChat.slice(-80) : [],
      voteOutcome: ['VOTE_RESULT', 'GAME_OVER'].includes(this.phase) ? this.voteOutcome : null,
      winningTeam: finished ? this.winningTeam : null,
      abortReason: this.phase === 'ABORTED' ? this.abortReason : null
    };
  }
}

module.exports = { MafiaRoom, ROLES, ROLE_KO, TEAM, DEFAULT_DURATIONS,
  shuffled, sanitizeChat, sanitizeName };

})(engineModule,engineModule.exports,(name)=>{
 if(name==='node:crypto')return cryptoShim;
 if(name==='./bot-mind')return botModule.exports;
 throw new Error('Offline engine cannot import '+name);
});
globalThis.NOIR_OFFLINE_ENGINE=engineModule.exports;
})();
