(function(){
'use strict';
const cryptoShim={
 randomUUID(){
  const a=new Uint8Array(16);
  if(globalThis.crypto?.getRandomValues)globalThis.crypto.getRandomValues(a);
  else for(let i=0;i<16;i++)a[i]=Math.floor(Math.random()*256);
  a[6]=(a[6]&15)|64;a[8]=(a[8]&63)|128;
  const h=Array.from(a,n=>n.toString(16).padStart(2,'0'));
  return h.slice(0,4).join('')+'-'+h.slice(4,6).join('')+'-'+h.slice(6,8).join('')+'-'+h.slice(8,10).join('')+'-'+h.slice(10).join('');
 },
 randomBytes(n){const a=new Uint8Array(n);if(globalThis.crypto?.getRandomValues)globalThis.crypto.getRandomValues(a);else for(let i=0;i<n;i++)a[i]=Math.floor(Math.random()*256);return {toString:()=>Array.from(a,b=>b.toString(16).padStart(2,'0')).join('')};}
};
const discourseModule={exports:{}};
(function(module,exports){
'use strict';
/*
 * Compositional Korean discourse frames for offline NOIR / SEVEN.
 * This is not a generative language model. Lexical *families* identify features
 * (evidence, confidence, intent, negation, timing, and source attribution),
 * and rules combine them. Unknown expressions remain uncertain rather than
 * inventing a fact or forcing every utterance into a scripted example.
 * Keeping the frame independent of roles prevents secret information leakage.
 */
const normalize = text => String(text || '').normalize('NFKC').replace(/\s+/g, ' ').trim();
const EVIDENCE = /(?:증거|근거|단서|확증|정황|정보|자료|기록|조사\s*결과|확인된\s*(?:사실|내용)|뒷받침|입증)/;
const DECISION = /(?:판단|결론|결정|지목|투표|퇴출|몰아가|단정|확신|의심|찍|선택)/;
const CONFIDENCE_NEG = /(?:확신(?:이|은|도)?\s*(?:없|안\s*서|못\s*(?:하|하겠|서))|확신\s*못|장담\s*못|확실(?:치|하지|하진)\s*않|불확실|불분명|불투명|애매|모호|헷갈|모르겠|모르겠다|모르는\s*것|누군지\s*모르|누가\s*마피아인지\s*모르|잘\s*모르|아직\s*몰|감이\s*안\s*(?:잡히|잡힌|잡혀)|긴가민가|섣부르|섣불리\s*판단|확답(?:은|도)?\s*못|자신(?:이|은)?\s*없)/;
const EVIDENCE_LACK = /(?:없|없어|없다|부족|모자|빈약|약해|약하|희박|불충분|안\s*보이|못\s*보|확인\s*못|찾지\s*못|안\s*나왔|안\s*나와|나오지\s*않|적다|적은|적어|미약|뚜렷하지\s*않)/;
const EVIDENCE_PRESENT = /(?:있어|있다|있지|나왔|나와|확보|발견|찾았|직접\s*봤|증명|확인했|충분해|확실해|명백해|확정됐)/;
const DEFER = /(?:보류|유보|관망|지켜\s*(?:보|볼|봐)|두고\s*(?:보|볼|봐)|좀\s*더\s*(?:보|볼|봐)|기다리|추가\s*정보|다음\s*정보|다음\s*날|다음\s*밤|내일\s*보|나중에\s*판단|천천히\s*(?:결정|판단|하)|결론.*?(?:이르|미루|나중|성급|늦추)|판단.*?(?:이르|미루|나중|늦추)|결정.*?(?:이르|미루|나중|늦추)|지목.*?(?:이른|이르|성급)|퇴출.*?(?:시키지\s*말|하지\s*말)|(?:새|추가)\s*(?:단서|정보).{0,15}(?:나오|생기).{0,12}(?:다시|그때)|서두르지|성급하게\s*판단|당장은\s*못|지금은\s*못|잠시\s*멈추|미뤄\s*두)/;
const SKIP = /(?:스킵|패스|기권|생략|건너\s*뛰|넘어\s*가|넘기|넘길|넘겨|지나가|표(?:를|는)?\s*(?:안\s*던|안\s*주|안\s*찍|던지지|주지\s*않|찍지\s*않)|표.{0,17}(?:안\s*할|안\s*하|하지\s*않)|누구(?:한테|에게)도.{0,16}표.{0,14}(?:싫|안|못)|아무도\s*(?:안\s*찍|찍지\s*말|안\s*뽑|뽑지\s*말)|투표\s*(?:안|하지\s*말|보류|유보|없)|표결\s*(?:없|보류|유보))/;
const NIGHT = /(?:밤|야간|밤\s*턴|밤\s*단계|야간\s*단계|야간\s*행동|나이트)/;
const VOTE = /(?:투표|표결|표(?:를|는)?\s*(?:던지|주|찍)|스킵\s*표|표\s*행사|퇴출|지목|찍을)/;
const DISAGREE_WITH_ABSENCE = /(?:(?:없(?:어|다|다고|다는|는)?|부족(?:하|해|하다|하다는)?).{0,18}(?:말(?:한|했)?\s*게|뜻|건|것은|게)\s*아니|(?:없는|부족한)\s*건\s*아니|없는\s*것\s*같지\s*않|부족하지\s*않|확신\s*없다는\s*게\s*아니)/;
const NEGATE_SKIP = /(?:스킵|패스|기권).{0,25}(?:못\s*받아들|안\s*받아들|거절)|(?:스킵|패스|기권|건너\s*뛰|넘어\s*가|넘기).{0,14}(?:하지\s*마|하면\s*안|하진\s*않|하지\s*않|할\s*생각\s*없|안\s*해|안\s*할|안\s*함|아니|싫)|(?:스킵|패스)\s*(?:안\s*할|하지\s*말)|(?:건너\s*뛰지\s*말|넘기지\s*말)/;
const REPORT_START = /^(?:(?:저기|근데|그런데|참고로|아까|방금|듣기로는)[,\s]*)?(?:\d+\s*(?:번|호)|그\s*사람|걔|쟤|누군가|누가)\s*(?:은|는|이|가|도)?\s*/;
const REPORT_VERB = /(?:한다고|한다는|한다던데|하겠다고|하자고|하던데|했대|한대|라(?:고|며)|말(?:했|하)|주장|했다(?:더라|던데)|했었다(?:더라|던데))/;
const REQUEST_EVIDENCE = /(?:왜|무슨\s*이유|어떤\s*이유|이유.{0,10}(?:뭐|뭔|알려)|뭘\s*보고|대체\s*뭘\s*보고|뭘\s*믿고|뭔\s*근거|무슨\s*증거|무슨\s*단서|(?:증거|근거|단서).{0,16}(?:있|뭐|어디|말해|알려|보여|갖고|나왔|확인했|제시)|(?:내놓|제시|보여\s*줘|들어\s*봐|말해\s*봐).{0,16}(?:증거|근거|단서)?)/;
const ASK_MARK = /[?？]|(?:뭐야|뭔데|왜|어떻게|할까|할래|어때|말해\s*줘|보여\s*줘|알려\s*줘|있나|있니|있냐|될까|맞아|맞지|뭐지|뭐냐|뭐임)\s*[.!~]*$/;
const ABSENCE_RE = /(?:없|부족|모자|적어|빈약|불충분)/;
const DENY_ABSENCE = /(?:증거|근거|단서|확신).{0,12}(?:없|부족).{0,18}(?:(?:게|건|것|뜻|말)(?:\s*(?:아니|아냐))|(?:아니|아냐)|말한\s*적\s*없)|(?:없(?:는|다는|다고)|부족(?:하다는|하다고)).{0,12}(?:뜻|말|건|게).{0,8}(?:아니|아냐)/;

function clauses(text) {
  // Discourse particles matter: in “수상하지만 근거는 없다” the latter
  // clause overrides confidence in the former, while its subject persists.
  return normalize(text).split(/(?:[.!?。！？]+\s*|[,，;；]+\s*|\s*(?:하지만|그치만|그렇지만|그러나|반면에|그런데|근데|다만)\s*)/)
    .map(s=>s.trim()).filter(Boolean);
}
function near(left,right,text,distance=21) {
  const a=text.search(left),b=text.search(right);
  if(a<0||b<0)return false;
  return Math.abs(a-b)<=distance;
}
function evidenceIsMissing(t) {
  if (/(?:없(?:다|어|다는|다고|다던|는)?|부족(?:해|하다|하다는)?).{0,18}(?:뜻|말|건|게|것).{0,7}(?:아니|않)/.test(t))return false;
  const noEvidence=near(EVIDENCE,EVIDENCE_LACK,t,24) ||
    /(?:뒷받침|입증|확인)(?:할|할만한)?\s*(?:만한)?\s*(?:게|것|자료)?\s*(?:없|안|못)/.test(t) ||
    /(?:말|느낌|추측|감|주장)(?:만|뿐)\s*(?:이라|인데|으로는|가지고(?:는)?|으로).{0,24}(?:사람|확신|판단|단정|결론|못|안|어렵|찍)/.test(t);
  return noEvidence && !DISAGREE_WITH_ABSENCE.test(t);
}
function strongEvidence(t) {
  if(!EVIDENCE.test(t)||evidenceIsMissing(t))return false;
  return near(EVIDENCE,EVIDENCE_PRESENT,t,24);
}
function seemsUncertain(t){
  return CONFIDENCE_NEG.test(t) ||
    /(?:누굴|누가|누구를|누구인지|누군지|어느\s*쪽인지).{0,20}(?:모르|못\s*(?:정|고르|판단)|헷갈)/.test(t) ||
    /(?:확실|분명|뚜렷|납득|결정적).{0,16}(?:않|안\s*되|못|없|부족)/.test(t) ||
    /(?:누굴|누구를|누가).{0,22}(?:안\s*정|못\s*정|고르기\s*어렵)/.test(t) ||
    /(?:단정|퇴출|찍|결론|결정).{0,16}(?:못|어렵|이르|지\s*말)/.test(t);
}
function isReported(t){
  // “7번이 마피아라고 생각해/확신해” is MY allegation, not 7번's report.
  // Bare “라고” is insufficient evidence of reported speech.
  if(/(?:라고|라며)\s*(?:확신|생각|판단|믿|봐|보는|추측|추정|느끼|의심)/.test(t))return false;
  // A sentence about another player's uncertainty or vote is not a report
  // of the *speaker's* own intention.
  return REPORT_START.test(t) && REPORT_VERB.test(t) && !/(?:난|나는|내가|나도|저는|내\s*생각)/.test(t.slice(0,25));
}
function askFrom(t) {
  const q=ASK_MARK.test(t) || /(?:근거|증거|단서).{0,14}(?:제시해(?:\s*봐)?|내놔|말해\s*줘|보여\s*줘|알려\s*줘)\s*[.!]*$/.test(t);
  // Mere “근거가 없어?” asks whether evidence exists; it does not assert lack.
  const evidenceQuestion = q && (EVIDENCE.test(t) || REQUEST_EVIDENCE.test(t));
  return {question:q,evidenceQuestion};
}

function parse(text,{phase='DAY'}={}) {
  const t=normalize(text);
  const pieces=clauses(t);
  const last=pieces.at(-1)||t;
  const ask=askFrom(t);
  const reported=isReported(t);
  const eLack=evidenceIsMissing(t);
  const eYes=strongEvidence(t);
  const unclear=seemsUncertain(t);
  const waiting=DEFER.test(t);
  const rejectSkip=SKIP.test(t) && NEGATE_SKIP.test(t);
  const deniedAbsence=DENY_ABSENCE.test(t) || DISAGREE_WITH_ABSENCE.test(t) || /(?:확신|증거|근거|단서).{0,15}(?:없|부족).{0,14}(?:건|게|말|뜻).{0,6}(?:아니|아냐)/.test(t);
  const proposedSkip=SKIP.test(t) && !rejectSkip;
  const sleep=NIGHT.test(t);
  const hasVote=VOTE.test(t);
  const nightSkip=sleep && proposedSkip && (!hasVote || near(NIGHT,SKIP,t,15) && !near(VOTE,SKIP,t,13));
  const voteSkip=proposedSkip && !nightSkip;
  const explicitNoVote=/(?:아무도|누구도|사람|한\s*명도).{0,16}(?:찍지\s*말|안\s*찍|표\s*주지\s*말|투표하지\s*말)/.test(t);
  const deferOnly=waiting && !voteSkip && !nightSkip;
  const requestEvidence=ask.evidenceQuestion && (REQUEST_EVIDENCE.test(t) || /(?:증거|근거|단서|정황).{0,14}(?:있|없|뭐|보여|알려)/.test(t));
  const evidencePolarity= eLack ? 'insufficient' : eYes ? 'available' : null;
  let act=null,confidence=0;
  if(reported) {
    // Reported speech about somebody else must be interpreted downstream as
    // a record to verify, NOT as the current speaker's policy.
    return {act:null,reported:true,question:ask.question, evidencePolarity,uncertain:unclear,waiting,phase,t};
  }
  // Questions are routed ahead of assertions; the question may ask about a
  // hypothetical or deny an earlier statement, not state a new vote intention.
  if(deniedAbsence && !ask.question){act='DENY_ABSENCE';confidence=3;}
  else if(rejectSkip){act='REJECT_SKIP';confidence=3;}
  else if(requestEvidence){act='ASK_EVIDENCE';confidence=3;}
  else if(nightSkip){act='NIGHT_SKIP';confidence=3;}
  else if(voteSkip){act='VOTE_SKIP';confidence=3;}
  else if(eLack){act='LOW_EVIDENCE';confidence=3;}
  else if(deferOnly){act='DEFER';confidence=2;}
  else if(unclear){act='UNCERTAIN';confidence=2;}
  else if(eYes && /(?:\b|^)(?:난|나는|내가|내\s*생각|확실|진짜|있어|있지)/.test(t)){act='EVIDENCE_CLAIM';confidence=2;}
  else if(explicitNoVote){act='VOTE_SKIP';confidence=2;}
  if(act==='LOW_EVIDENCE' && DISAGREE_WITH_ABSENCE.test(t))act=null;
  if(act==='UNCERTAIN' && /(?:안\s*모르는|모르는\s*건\s*아니|확신이\s*없는\s*건\s*아니)/.test(t))act=null;
  // Don't infer the user promised to SKIP from “스킵할까?”; the decision is
  // still tentative. Only explicit affirmative declarations count elsewhere.
  return {act,confidence,reported:false,question:ask.question,evidencePolarity,uncertain:unclear,
    waiting,nightSkip,voteSkip,explicitNoVote,phase,t,last};
}
module.exports={parse,normalize,clauses,evidenceIsMissing,isReported};

})(discourseModule,discourseModule.exports);
const memoryModule={exports:{}};
(function(module,exports){
'use strict';

const PERSONAS = Object.freeze([
  { style:'analytical', goal:'compare verifiable evidence before making claims' },
  { style:'careful', goal:'avoid unjustified accusations and ask precise questions' },
  { style:'direct', goal:'answer questions clearly and state uncertainty openly' },
  { style:'negotiator', goal:'seek explanations before committing to a vote' },
  { style:'skeptical', goal:'check contradictions without equating suspicion with proof' },
  { style:'strategic', goal:'plan votes and actions while respecting role constraints' }
]);

class AgentMemory {
  constructor(agentNumber) {
    this.persona = PERSONAS[(Number(agentNumber) - 1 + PERSONAS.length) % PERSONAS.length];
    this.publicIds = new Set();
    this.secretIds = new Set();
    this.privateKeys = new Set();
    this.systemIds = new Set();
    this.evidenceApplied = new Set();
    this.beliefEvidenceKeys = new Set();
    this.events = [];
    this.decisions = [];
    this.beliefs = new Map();
    this.spoken = [];
    this.turns = 0;
  }
  observe(view) {
    for (const e of view.publicChat) {
      if (this.publicIds.has(e.id)) continue;
      this.publicIds.add(e.id);
      this.events.push({ id:e.id, type:'PUBLIC_STATEMENT', number:e.number,
        text:e.text, reliability:'unverified_statement' });
    }
    for (const e of view.secretChat) {
      if (this.secretIds.has(e.id)) continue;
      this.secretIds.add(e.id);
      this.events.push({ id:e.id, type:'SECRET_STATEMENT', number:e.number,
        text:e.text, reliability:'unverified_partner_statement' });
    }
    for (const r of view.ownInvestigations) {
      const k = `${r.night}:${r.targetId}`;
      if (this.privateKeys.has(k)) continue;
      this.privateKeys.add(k);
      this.events.push({ id:'inv:'+k, type:'OWN_INVESTIGATION', targetId:r.targetId,
        displayed:r.displayed, ...(r.actualRole ? { actualRole:r.actualRole } : {}),
        reliability:'confirmed_private_observation' });
    }
    // Authoritative announcements are public facts, not player allegations.
    // Never convert a player's claimed role into a verified game event.
    for (const e of view.publicLog || []) {
      const key = `game:${e.at}:${e.text}`;
      if (this.systemIds.has(key)) continue;
      this.systemIds.add(key);
      this.events.push({id:key,type:'PUBLIC_GAME_EVENT',text:String(e.text).slice(0,220),
        reliability:'confirmed_public_event'});
    }
    if (this.events.length > 150) this.events.splice(0, this.events.length-150);
  }
  applyBeliefs(updates, visibleIds) {
    if (!Array.isArray(updates)) return;
    for (const change of updates.slice(0,4)) {
      if (!change || typeof change !== 'object' || typeof change.targetId !== 'string') continue;
      if (!visibleIds.has(change.targetId)) continue;
      const ids = Array.isArray(change.evidenceIds) ? [...new Set(change.evidenceIds.filter(
        id => typeof id==='string' && this.events.some(e=>e.id===id)))].slice(0,4) : [];
      // Repeating the same evidence for the same target cannot inflate a belief.
      // A mixture of old/new evidence contributes only its novel share.
      const fresh = ids.filter(id=>!this.beliefEvidenceKeys.has(change.targetId+'\0'+id));
      if (!fresh.length) continue;
      const delta = Number(change.delta);
      if (!Number.isFinite(delta) || Math.abs(delta)>2) continue;
      const adjustedDelta=delta*fresh.length/ids.length;
      const prev=this.beliefs.get(change.targetId) || { score:0, reasons:[] };
      const next={ score:Math.max(-5,Math.min(5,prev.score+adjustedDelta)),
        reasons:[...prev.reasons,{note:String(change.reason||'uncertain').slice(0,100), evidenceIds:fresh}].slice(-5) };
      this.beliefs.set(change.targetId,next);
      for(const id of fresh)this.beliefEvidenceKeys.add(change.targetId+'\0'+id);
    }
  }
  addInferredEvidence(key,targetId,delta,reason,evidenceIds,visibleIds) {
    if (this.evidenceApplied.has(key)) return;
    this.evidenceApplied.add(key);
    this.applyBeliefs([{targetId,delta,reason,evidenceIds}],visibleIds);
  }
  recordDecision(entry) {
    if (!entry || typeof entry !== 'object') return;
    this.decisions.push({kind:String(entry.kind||''),targetId:entry.targetId || null,
      night:Number(entry.night)||0,phase:String(entry.phase||''),
      evidenceIds:Array.isArray(entry.evidenceIds) ? entry.evidenceIds.slice(0,5) : [],
      basis:String(entry.basis||'rules_based_heuristic').slice(0,100)});
    if (this.decisions.length > 15) this.decisions.shift();
  }
  recordSpeech(text) {
    this.spoken.push(text);
    if (this.spoken.length>9) this.spoken.shift();
    this.turns++;
  }
  compact() {
    return {
      persona:this.persona,
      events:this.events.slice(-30),
      beliefs:Array.from(this.beliefs,([targetId,value])=>({targetId,...value})),
      recentOwnSpeech:this.spoken.slice(-6),
      latestDecisions:this.decisions.slice(-5),
      turns:this.turns
    };
  }
}
module.exports = { AgentMemory, PERSONAS };

})(memoryModule,memoryModule.exports);
const corpusModule={exports:{
  "version": "3.0.4",
  "method": "Offline Korean intent prototypes + compositional feature extraction; not an LLM; example bank is not exhaustive",
  "intents": [
    {
      "id": "ROLE_REQUEST",
      "kind": "question",
      "topic": "role",
      "examples": [
        "너 무슨 직업이야",
        "너 직업 공개해봐",
        "정체를 밝히라고",
        "네 역할을 알려줄래",
        "무슨 역할 맡았어",
        "역할 설명해주면 안 돼",
        "직업 좀 까봐",
        "각자 포지션 밝히자",
        "본인 정체 얘기해봐",
        "직업을 공개할 생각 있냐",
        "너 누구 편인지 알려줘",
        "나한테만 직업 말해줘",
        "5번은 대체 무슨 직업",
        "6번 자기 직업 말해",
        "시민이야 경찰이야",
        "무슨 포지션이야",
        "너 뭐하는 사람이야",
        "한 명씩 역할을 밝혀"
      ]
    },
    {
      "id": "ROLE_SILENCE",
      "kind": "statement",
      "topic": "role",
      "examples": [
        "직업은 밝히지 마",
        "역할 공개하지 마라",
        "지금은 정체를 숨기자",
        "직업 이야기는 그만",
        "누구든 자기 직업 말하지 말자",
        "역할을 비밀로 해",
        "직업은 밝힐 필요 없어",
        "정체 공개 금지",
        "네 직업 얘기는 하지 마"
      ]
    },
    {
      "id": "WHO_POLICE",
      "kind": "question",
      "topic": "role",
      "examples": [
        "경찰은 대체 누구야",
        "경찰이라고 한 사람 누구",
        "경찰 나온 사람 있니",
        "누가 경찰이래",
        "경찰이 누구인지 밝혀",
        "경찰이라고 주장한 번호",
        "경찰 자처한 사람이 있나",
        "경찰 누구라고 했어",
        "경찰이라고 밝힌 사람 기억해",
        "진짜 경찰이 누구야",
        "경찰 몇 번이야"
      ]
    },
    {
      "id": "INVESTIGATION_QUERY",
      "kind": "question",
      "topic": "investigation",
      "examples": [
        "어젯밤 조사한 사람이 누구야",
        "누구 조사했어",
        "조사 결과 나왔니",
        "무슨 조사 결과가 있지",
        "누구를 확인해 봤냐",
        "조사해서 알아낸 내용 알려줘",
        "경찰 조사했던 번호 말해봐",
        "조사한 애가 어느 팀이야",
        "5번 조사 결과 공유해봐",
        "수사 내역 있어",
        "탐문한 기록 보여줘",
        "밤에 검사한 사람 누구",
        "확인한 대상이 누구인지",
        "정보 조사한 거 말해"
      ]
    },
    {
      "id": "EVIDENCE_QUERY",
      "kind": "question",
      "topic": "evidence",
      "examples": [
        "왜 그렇게 의심해",
        "그 사람 찍는 이유가 뭐야",
        "그 판단의 근거는",
        "무슨 증거로 몰아가는 거지",
        "결정적인 단서는 뭐임",
        "증거 있으면 보여봐",
        "왜 4번이 수상하다고 보는지 설명해",
        "납득할 이유를 대 봐",
        "판단의 이유가 뭐냐",
        "증거부터 제시해",
        "확신하는 근거 알려줘",
        "뭘 보고 5번이 마피아라고",
        "정황 하나라도 있냐",
        "어떤 기록이 있어",
        "확실한 단서가 있는가"
      ]
    },
    {
      "id": "EVIDENCE_LACK",
      "kind": "statement",
      "topic": "evidence",
      "examples": [
        "아직 뚜렷한 물증은 없는 거 같아",
        "그냥 느낌일 뿐이잖아",
        "확실히 확인된 단서는 없지",
        "말만으로 판결하긴 어려워",
        "입증할 자료도 없는데",
        "뒷받침할 정황이 모자라",
        "그냥 감만으로는 모르겠어",
        "확증은 아직 찾지 못했어",
        "의심하기에는 근거가 약해",
        "납득할 만한 이유가 부족해",
        "증거가 빈약하다고 봐",
        "지금은 증명할 수 없잖아",
        "사실로 확인된 내용이 부족해"
      ]
    },
    {
      "id": "EVIDENCE_HAS",
      "kind": "statement",
      "topic": "evidence",
      "examples": [
        "확실한 증거가 있어",
        "근거를 확보했어",
        "내가 직접 확인했어",
        "분명한 정황이 나왔어",
        "증명할 자료가 충분해",
        "이제 단서가 나왔잖아",
        "입증할 수 있다고",
        "조사 결과를 찾았어",
        "확정적인 기록이 있어"
      ]
    },
    {
      "id": "UNCERTAIN",
      "kind": "statement",
      "topic": "confidence",
      "examples": [
        "모르겠다 누가 범인인지",
        "어느 쪽이 맞는지 헷갈려",
        "아직 확신할 수 없어",
        "마음이 갈팡질팡하네",
        "결론이 안 서",
        "애매한 상황이라 못 정하겠어",
        "솔직히 판단이 안 돼",
        "누가 수상한지 잘 모르겠음",
        "내 생각이 아직 정리가 안 됐어",
        "확실하다고 말할 수 없네",
        "판단하기 난감해"
      ]
    },
    {
      "id": "DEFER",
      "kind": "statement",
      "topic": "decision",
      "examples": [
        "잠깐 두고 보자",
        "나중에 결론내자",
        "추가 발언 듣고 결정하자",
        "우선 지켜볼래",
        "판단을 유보하겠어",
        "일단 결정을 미루자",
        "당장 결정하지 말자",
        "성급하게 투표하지 말자",
        "오늘은 신중하게 기다려보자",
        "좀 더 관찰한 다음 판단해",
        "새 증거 나올 때까지 보자",
        "결론을 서두르지 않는 게 좋겠어"
      ]
    },
    {
      "id": "VOTE_SKIP",
      "kind": "statement",
      "topic": "vote",
      "examples": [
        "이번 표는 기권하자",
        "아무도 찍지 말자",
        "이번엔 투표를 건너뛰자",
        "스킵하는 게 낫지",
        "그냥 패스할래",
        "이번엔 빈 표로 가자",
        "나 표 안 낼래",
        "오늘은 투표하지 않겠어",
        "차라리 투표 스킵하자",
        "아무도 퇴출시키지 말자",
        "한 명도 지목하지 말자",
        "이번 표결을 생략하자"
      ]
    },
    {
      "id": "VOTE_SKIP_DENY",
      "kind": "statement",
      "topic": "vote",
      "examples": [
        "나는 기권할 생각이 없어",
        "스킵은 하지 마",
        "표 던져야지 왜 패스해",
        "건너뛰지 않을 거야",
        "이번엔 꼭 표 행사할래",
        "스킵하는 건 반대야",
        "기권하는 건 싫어",
        "표결을 생략하면 안 돼",
        "나는 스킵 안 하겠다고"
      ]
    },
    {
      "id": "NIGHT_SKIP",
      "kind": "statement",
      "topic": "night",
      "examples": [
        "밤 단계는 생략하자",
        "야간 턴 넘어가자",
        "밤 진행 스킵하자",
        "오늘 밤 통째로 패스해",
        "밤은 그냥 건너뛰자",
        "야간 행동 없이 끝내자",
        "이번 밤을 지나치자",
        "밤 턴 안 해도 돼"
      ]
    },
    {
      "id": "VOTE_QUERY",
      "kind": "question",
      "topic": "vote",
      "examples": [
        "너 누구 찍을 생각이야",
        "누구한테 투표할 거야",
        "너는 표 어디로 줄래",
        "가장 유력한 퇴출 후보가 누구야",
        "누가 투표받을 것 같아",
        "오늘 누구 처형할래",
        "너 투표 대상 정했냐",
        "누구를 뽑아야 하지",
        "스킵할까 투표할까",
        "어느 쪽에 표를 행사할 건데",
        "이번 투표 어떻게 할 거야",
        "표를 어디에 던질 생각인지"
      ]
    },
    {
      "id": "VOTE_PROPOSE",
      "kind": "statement",
      "topic": "vote",
      "examples": [
        "4번을 찍자",
        "5번한테 표 주자",
        "이번엔 6번 처형하자",
        "나는 3번 투표할게",
        "저 사람 퇴출시키는 게 낫겠어",
        "다들 4번에게 표 몰자",
        "2번으로 투표하자",
        "7번을 지목하겠어",
        "5번한테 표 넣는 거 어때",
        "6번 찍고 가자"
      ]
    },
    {
      "id": "SUSPICION_QUERY",
      "kind": "question",
      "topic": "suspicion",
      "examples": [
        "누가 제일 수상해",
        "너는 누구 의심하니",
        "누가 마피아 같아",
        "범인으로 보는 사람 있어",
        "가장 의심가는 사람 누구",
        "너 생각엔 누가 범인이야",
        "누구를 믿기 어렵겠어",
        "내가 의심할 사람 누구",
        "의심 후보를 골라봐",
        "왜 5번을 의심해",
        "4번 수상한 거 아니냐",
        "네 의견을 구체적으로 말해봐",
        "누가 거짓말하는 거 같아"
      ]
    },
    {
      "id": "ACCUSE",
      "kind": "statement",
      "topic": "suspicion",
      "examples": [
        "4번은 아무래도 수상해",
        "저 사람 마피아 같다",
        "5번이 뭔가 숨기는 느낌이야",
        "그 사람 말이 이상해",
        "6번 거짓말하는 중인 듯",
        "2번이 범인일 가능성이 있어",
        "7번의 행적이 수상해",
        "내 생각엔 3번이 마피아 같아",
        "5번 말하는 게 앞뒤가 달라",
        "4번이 너무 의심돼"
      ]
    },
    {
      "id": "DEFEND",
      "kind": "statement",
      "topic": "suspicion",
      "examples": [
        "난 4번을 믿어",
        "3번은 범인이 아닌 것 같아",
        "5번 몰아가지 마",
        "근거 없이 그 사람 의심하지 마",
        "내가 마피아가 아니라는 건 알아",
        "난 시민팀이라고",
        "저 사람은 결백할 수도 있잖아",
        "4번 의심할 필요 없어",
        "5번은 믿을 만해",
        "나는 저 사람 편을 들겠어"
      ]
    },
    {
      "id": "COMPARE",
      "kind": "question",
      "topic": "suspicion",
      "examples": [
        "3번하고 4번 중 누가 더 수상해",
        "5번 대 6번 비교해봐",
        "둘 중 누구 의심할까",
        "4번과 7번 중 어느 쪽이 더 의심돼",
        "둘의 말을 나란히 비교해",
        "5번 6번 뭐가 다른지",
        "서로 같은 팀이라고 보니",
        "두 사람 의견 충돌해",
        "4번과 5번 누가 더 범인 같아"
      ]
    },
    {
      "id": "CONTRADICTION",
      "kind": "question",
      "topic": "memory",
      "examples": [
        "4번이 말을 바꿨잖아",
        "5번의 앞뒤 말이 맞아",
        "아까랑 지금 주장이 다르지",
        "저번엔 시민이라더니 지금은 경찰이래",
        "발언이 서로 모순되는 거 아니야",
        "누가 말 바꿨는지 알려줘",
        "앞에서 했던 주장이랑 달라",
        "3번 얘기 앞뒤가 다르잖아",
        "기억해봐 저 사람 말 달라졌어",
        "거짓말한 게 기록에 있나"
      ]
    },
    {
      "id": "CHAT_HISTORY",
      "kind": "question",
      "topic": "memory",
      "examples": [
        "4번이 아까 뭐라고 했어",
        "방금 누가 뭐라고 말했지",
        "3번 전에 한 말 다시 알려줘",
        "누가 경찰이라고 했었어",
        "5번 발언 기억나",
        "아까 6번 발언 내용 뭐야",
        "저 사람 이전에 했던 말 보여줘",
        "내가 무슨 말을 했었지",
        "방금 대화 무슨 내용이었어",
        "직전에 나온 말 다시 말해줘",
        "앞에 누가 무슨 주장 했어",
        "지난 대화 기억하니"
      ]
    },
    {
      "id": "CLARIFY",
      "kind": "question",
      "topic": "dialogue",
      "examples": [
        "무슨 뜻으로 한 말이야",
        "이해를 못했는데 다시 설명해",
        "무슨 소리하는 거야",
        "방금 말이 무슨 뜻이지",
        "조금 더 구체적으로 설명해줘",
        "네 말이 무슨 의미야",
        "헷갈려 다시 정리해봐",
        "설명 부탁해",
        "그 얘기를 풀어서 말해봐",
        "이유까지 상세히 설명해",
        "무엇을 말하려는 거야"
      ]
    },
    {
      "id": "REPEAT_REQUEST",
      "kind": "question",
      "topic": "dialogue",
      "examples": [
        "아까 질문에 대답해",
        "내가 물어본 거 다시 답해",
        "내 말 무시하지 마",
        "내 질문 기억 안 나",
        "같은 질문 또 해야 돼",
        "딴 얘기 말고 답변해",
        "방금 물었는데 왜 안 답해",
        "질문에 제대로 답해줘",
        "내가 한 질문으로 돌아가",
        "말 돌리지 말고 대답해"
      ]
    },
    {
      "id": "AGREE",
      "kind": "statement",
      "topic": "stance",
      "examples": [
        "나도 그렇게 생각해",
        "맞아 그 말이 맞아",
        "3번 의견에 동의해",
        "네 의견을 받아들일게",
        "그 주장에 찬성해",
        "그건 인정",
        "그 말에 공감해",
        "나 역시 같은 생각이야",
        "맞는 소리네",
        "나도 동감"
      ]
    },
    {
      "id": "DISAGREE",
      "kind": "statement",
      "topic": "stance",
      "examples": [
        "그 말에는 동의 못 해",
        "난 반대 의견이야",
        "4번 주장 틀렸다고 봐",
        "아니야 내 생각은 달라",
        "그건 납득 못 하겠는데",
        "그 판단을 받아들이기 어려워",
        "나랑 생각이 다르네",
        "그 주장에 반대야",
        "너 말은 아니라고 생각해"
      ]
    },
    {
      "id": "CORRECTION",
      "kind": "statement",
      "topic": "dialogue",
      "examples": [
        "내 말은 그게 아니야",
        "다시 말할게",
        "아까 표현을 정정하자면",
        "내가 잘못 말했어",
        "그게 아니라 이런 뜻이야",
        "네가 오해한 거야",
        "아까 말 취소할게",
        "그 말은 무슨 뜻이냐면",
        "좀 잘못 이해했네",
        "아니 내가 말한 건 다른 거야"
      ]
    },
    {
      "id": "DEESCALATE",
      "kind": "statement",
      "topic": "social",
      "examples": [
        "그만 좀 싸워",
        "서로 싸우지 말자",
        "욕하지 말고 차분히 얘기해",
        "다툼 그만해",
        "똑같은 말로 싸우지 말자",
        "의미 없는 논쟁 그만하자",
        "서로 몰아가기를 멈춰",
        "근거 없이 비난하지 마",
        "그만 다투자",
        "서로 공격하지 말고 사실부터 보자"
      ]
    },
    {
      "id": "LIVING_COUNT",
      "kind": "question",
      "topic": "state",
      "examples": [
        "현재 몇 명 살아있어",
        "생존자가 몇 명 남았어",
        "지금 사람 몇 명 남았지",
        "누가 아직 살아있냐",
        "남아 있는 참가자 수 알려줘",
        "생존자 명단 정리해봐",
        "탈락하지 않은 사람 누구",
        "지금 몇 대 몇이야",
        "살아있는 인원 알려줄래",
        "남은 사람들을 알려줘"
      ]
    },
    {
      "id": "PHASE_QUERY",
      "kind": "question",
      "topic": "state",
      "examples": [
        "지금 낮이야 밤이야",
        "현재 무슨 단계야",
        "지금 투표 단계인가",
        "다음에는 뭘 해",
        "언제 투표 시작해",
        "게임은 지금 어디까지 왔어",
        "몇 번째 밤이지",
        "지금 몇 번째 낮이야",
        "라운드 단계 알려줘",
        "아직 토론 중이야"
      ]
    },
    {
      "id": "RULE_QUERY",
      "kind": "question",
      "topic": "rules",
      "examples": [
        "경찰 능력이 뭐야",
        "의사는 무슨 능력 써",
        "스파이가 하는 일이 뭐야",
        "건달의 역할 설명해줘",
        "마피아 승리 조건이 뭐야",
        "투표는 어떻게 하는 거야",
        "스킵이랑 기권이 달라",
        "밤을 건너뛸 수 있어",
        "재투표 규칙 알려줘",
        "접선은 언제 가능해",
        "의사가 자기 자신 치료할 수 있어",
        "게임 규칙 좀 알려줘"
      ]
    },
    {
      "id": "DEATH_QUERY",
      "kind": "question",
      "topic": "state",
      "examples": [
        "지난밤에 누가 죽었어",
        "어제 밤 사망자 누구",
        "탈락자 나왔니",
        "누가 제거됐냐",
        "밤 결과 발표됐어",
        "죽은 사람 몇 번",
        "지금까지 누구 탈락했는지",
        "이번 밤 사망자 있어",
        "지난 밤에 무슨 일 있었어"
      ]
    },
    {
      "id": "GREETING",
      "kind": "statement",
      "topic": "social",
      "examples": [
        "안녕하세요",
        "다들 반가워",
        "하이",
        "ㅎㅇ",
        "시작하자",
        "다들 안녕",
        "반갑다",
        "좋은 게임 하자",
        "안녕들",
        "오늘도 잘해보자"
      ]
    },
    {
      "id": "THANKS",
      "kind": "statement",
      "topic": "social",
      "examples": [
        "고마워",
        "감사합니다",
        "정보 고맙다",
        "땡큐",
        "알려줘서 고맙네",
        "ㄱㅅ",
        "답변 고마워",
        "수고했어",
        "설명해줘서 고마워"
      ]
    },
    {
      "id": "SECRET_ATTACK",
      "kind": "statement",
      "topic": "attack",
      "examples": [
        "오늘은 4번부터 공격하자",
        "5번을 습격하는 게 좋겠어",
        "6번 먼저 처리하자",
        "이번 밤은 3번으로 가자",
        "4번을 공격 목표로 정하자",
        "7번을 노리는 건 어때",
        "5번을 잡는 쪽으로 가자",
        "오늘 2번을 제거하는 게 낫겠어",
        "4번을 죽일 후보로 보자",
        "5번이 타겟이야",
        "오늘 공격은 6번에게",
        "저 사람부터 공격하자",
        "4번부터 보내자",
        "5번 공격하려고",
        "오늘은 7번 살해하자"
      ],
      "private": true
    },
    {
      "id": "SECRET_AVOID",
      "kind": "statement",
      "topic": "attack",
      "examples": [
        "4번은 공격하지 말자",
        "5번은 건드리지 마",
        "6번은 살려두자",
        "3번을 이번 공격에서 제외하자",
        "7번은 공격 안 하는 게 좋아",
        "4번 습격 취소해",
        "5번은 죽이지 말자",
        "이번엔 4번 빼자",
        "3번은 놔두고",
        "6번 공격하는 건 반대",
        "이번에 7번은 노리지 말자",
        "5번은 건드리지 않는 게 나아"
      ],
      "private": true
    },
    {
      "id": "SECRET_SWITCH",
      "kind": "statement",
      "topic": "attack",
      "examples": [
        "4번 말고 5번을 공격하자",
        "4번 대신 6번으로 가자",
        "3번 말고 7번을 노리자",
        "5번이 아니고 2번",
        "4번에서 5번으로 대상 바꾸자",
        "6번은 제외하고 3번으로",
        "오늘은 5번 대신 7번",
        "3번 말고 4번으로 변경하자",
        "2번은 관두고 5번을 처리하자",
        "6번은 말고 4번",
        "공격 대상을 4번에서 5번으로 바꿔",
        "7번 말고 3번"
      ],
      "private": true
    },
    {
      "id": "SECRET_INFO",
      "kind": "question",
      "topic": "investigation",
      "examples": [
        "스파이 조사 결과를 알려줘",
        "어젯밤 누구 신원을 알아냈어",
        "네가 알아낸 직업 정보 뭐야",
        "확인한 사람 명단 알려줘",
        "어제 조사한 사람은 누구",
        "경찰이나 의사 알아낸 거 있어",
        "6번 실제 직업을 확인했어",
        "내게 수사 정보 공유해 줘",
        "조사한 실제 역할 뭔데",
        "어느 사람 정보를 확보했니",
        "5번이 무슨 직업인지 아냐",
        "수집한 정보 좀 정리해줘",
        "비밀 조사 내역 말해"
      ],
      "private": true
    },
    {
      "id": "SECRET_PLAN",
      "kind": "question",
      "topic": "attack",
      "examples": [
        "오늘 밤 공격 대상을 정했어",
        "누굴 먼저 공격할까",
        "공격할 사람 추천해줘",
        "오늘 살해 후보 누구",
        "우리 팀은 어떤 전략 쓸까",
        "오늘 밤 계획은 뭐야",
        "공격 목표를 어떻게 고르지",
        "네 생각에 공격 누구",
        "마피아가 누구를 노리는 게 좋아",
        "최종 공격 대상이 누구야",
        "오늘 목표 어떻게 정해",
        "우리가 먼저 죽일 사람 있을까"
      ],
      "private": true
    }
  ]
}
};
const utteranceModule={exports:{}};
(function(module,exports,require){
'use strict';
// Deterministic, offline Korean utterance understanding. The JSON bank is a
// set of INTENT EXAMPLES, not an answer lookup table. Grammar guards and
// context/polarity features decide whether a candidate is legal, then
// character similarity handles unseen synonyms/word order. Unknown input is
// returned as null rather than forcing a wrong label.
const {intents:INTENTS}=require('./utterance-corpus.json');
const {parse:discourse}=require('../discourse-frame');
const rx={
 ROLE:/(?:직업|역할|정체|신분|포지션|무슨\s*팀|누구\s*편)/,
 REVEAL:/(?:공개|밝히|말해|말하|얘기|이야기|설명|소개|공유|알려|까봐|까\s*줘|뭐야|뭔데|뭔\s*직업|무엇|무슨|어떤|궁금|알고\s*싶|누구\s*편|어느\s*팀)/,
 ROLE_NO:/(?:(?:얘기|이야기).{0,8}(?:멈추|그만|중단)|말하지\s*않|말하지\s*마|말하지\s*말|공개하지\s*마|밝히지\s*마|밝힐\s*필요\s*없|숨기|비밀|금지|이야기\s*그만|얘기\s*그만|공개하면\s*안)/,
 REQUEST:/(?:말해|설명|알려|답해|제시|보여|말하라|하라고|말해봐|말해줘|줄래|뭐야|누구|누가|누굴|뭔데|왜|어떻게|있니|있어|맞아|해봐|해줘|어떤|무슨|몇\s*번|몇\s*명|궁금|할까|할래|거야|할거|되니|되나|나요|하자|밝혀|찾아)/,
 POLICE:/(?:경찰|형사)/,
 INVESTIGATION:/(?:조사|수사|검사|탐문|확인해\s*봤|알아\s*봤)/,
 EVIDENCE:/(?:증거|근거|단서|정황|물증|입증|뒷받침|자료|확증|기록|그렇게\s*생각|그렇게\s*판단|이유)/,
 EVIDENCE_WEAK:/(?:없|부족|빈약|약해|모자|못\s*찾|불충분|뚜렷하지\s*않|확인하지\s*못|찾지\s*못|없잖|못\s*봤)/,
 CONFIDENT:/(?:있어|있다|충분|발견|나왔|확보|봤어|확인했|명백)/,
 UNCERTAIN:/(?:모르|헷갈|확신\s*안|확신\s*없|애매|불확실|난감|갈팡질팡|결론이\s*안|못\s*정하|판단이\s*안|확답\s*못)/,
 DEFER:/(?:(?:단정|판단|결론|투표|결정).{0,16}(?:이르|성급|아직\s*아니)|유보|보류|관망|지켜\s*보|두고\s*보|기다리|미루|서두르지|나중에|새\s*정보|추가\s*정보|성급|서두를|관찰한\s*다음)/,
 SKIP:/(?:스킵|패스|기권|건너\s*뛰|생략|아무도\s*찍지|한\s*명도\s*지목하지|빈\s*표|표\s*안\s*내|투표하지\s*않|퇴출시키지\s*말|표결\s*생략)/,
 SKIP_NO:/(?:스킵|패스|기권).{0,25}(?:못\s*받아들|안\s*받아들|거절)|(?:스킵|패스|기권|건너\s*뛰|생략).{0,20}(?:안\s*해|안\s*할|하지\s*않|하지\s*마|하지\s*말|생각이\s*없|반대|싫|하면\s*안|할\s*생각\s*없)|(?:스킵|기권|패스)\s*(?:안|못)/,
 NIGHT:/(?:밤|야간|나이트)/,
 VOTE:/(?:투표|표결|표\s*(?:던지|주|줄|줘|넣|행사|몰)|표를\s*몰아\s*주|지목|퇴출|처형|찍|뽑|표를|표는)/,
 DOUBT:/(?:의심|수상|마피아|범인|거짓말|구라|믿기\s*어렵|숨기|이상|찜찜)/,
 NEGATE_DOUBT:/(?:아니|아냐|아닌|아닐|의심하지\s*마|의심하지\s*않|의심할\s*필요\s*없|의심\s*안|못\s*믿|안\s*수상|수상하지\s*않|믿어|결백|무죄|몰아가지\s*마)/,
 COMPARE:/(?:\d+\s*번.{0,18}\d+\s*번.{0,10}(?:중|더)|비교|둘\s*중|누가\s*더|어느\s*쪽|대\s*\d+\s*번|차이|서로\s*같은\s*팀|서로\s*다른\s*팀|나란히)/,
 CHANGE:/(?:앞(?:에서)?\s*한\s*말.{0,20}(?:지금|현재).{0,20}(?:말|안\s*맞)|말(?:이랑|과).{0,16}안\s*맞|말\s*바꿨|말이\s*바뀌|말이\s*바뀐|앞뒤|모순|서로\s*다르|주장이\s*다르|거짓말|전에\s*했다|아까랑\s*지금|변경)/,
 HISTORY:/(?:아까|방금|전에|이전|직전|저번|앞에|지난\s*대화|기억|뭐라\s*했|뭐라고\s*했|발언\s*내용|누가\s*말|했던\s*말|지난\s*말)/,
 CLARIFY:/(?:쉽게\s*(?:설명|말)|풀어\s*(?:줘|주|설명)|이해할\s*수\s*있게|무슨\s*뜻|무슨\s*말|무슨\s*소리|뭔\s*뜻|뭔\s*소리|다시\s*설명|풀어\s*(?:설명|얘기)|풀어서\s*말|구체적|헷갈|이해를\s*못|의미)/,
 REPEAT:/(?:다시\s*답|답변해|대답해|질문에\s*답|물어본\s*거|안\s*답|말\s*돌리|내\s*말\s*무시|아까\s*질문|직전\s*질문|같은\s*질문)/,
 AGREE:/(?:동의|동감|찬성|같은\s*생각|공감|맞는\s*소리|그\s*말\s*맞|나도\s*그렇게\s*생각|받아들일게)/,
 DISAGREE:/(?:(?:못|안)\s*받아들|받아들이지\s*(?:못|않)|받아들일\s*수\s*없|반대|동의\s*못|동의하지\s*않|생각이\s*다르|의견이\s*달|틀렸|아니라고\s*생각|납득\s*못|인정\s*(?:못|안|하기\s*어렵)|받아들이기\s*어렵)/,
 CORRECTION:/(?:내(?:가\s*한)?\s*말.{0,20}(?:다르게|잘못).{0,16}(?:받아들|이해)|정정|다시\s*말|내\s*말은|내가\s*잘못\s*말|그게\s*아니|오해|말\s*취소|아니\s*내가)/,
 SOCIAL_FIGHT:/(?:싸우|다투|몰아가|비난|욕하지|논쟁\s*그만|시끄러)/,
 LIVE:/(?:살아|생존|남아\s*있|탈락하지\s*않|남은\s*(?:사람|인원|참가자)|생존자)/,
 COUNT:/(?:몇\s*명|몇\s*대\s*몇|숫자|명단|누구|인원|사람|참가자)/,
 PHASE:/(?:해야\s*하는\s*순서|진행\s*순서|현재\s*순서|단계|턴|차례|몇\s*번째|게임\s*진행|지금\s*낮|지금\s*밤|언제\s*투표|토론\s*중)/,
 RULE:/(?:규칙|능력|승리\s*조건|방법|어떻게\s*하|접선|재투표|자기\s*자신\s*치료|뭐\s*하|하는\s*일)/,
 DEAD:/(?:사망|죽었|죽은|제거|탈락|킬\s*당|밤\s*결과)/,
 GREET:/(?:안녕|하이|ㅎㅇ|반가|반갑|좋은\s*게임|잘해\s*보자)/,
 THANK:/(?:고마|고맙|감사|땡큐|ㄱㅅ|수고)/
};
const order=INTENTS.map(x=>x.id);
const byId=new Map(INTENTS.map(x=>[x.id,x]));
const mapSynonym=[
  [/(?:정체|신분|포지션|역할)/g,'직업'],
  [/(?:물증|확증|입증|뒷받침|자료|정황|단서|증거)/g,'근거'],
  [/(?:패스|기권|건너\s*뛰|생략)/g,'스킵'],
  [/(?:형사)/g,'경찰'],
  [/(?:수사|탐문|검사)/g,'조사'],
  [/(?:뭐라고\s*했|뭐라\s*했|무슨\s*말\s*했)/g,'발언'],
  [/(?:알려줘|말해줘|밝혀줘|공개해줘|말해봐|얘기해봐|설명해봐)/g,'공개해'],
  [/(?:범인|늑대)/g,'마피아'],
  [/(?:어제\s*밤|어젯밤|지난\s*밤)/g,'밤']
];
function canonical(s) {
  let t=String(s||'').normalize('NFC').toLowerCase().replace(/[\u200b-\u200d\ufeff]/g,'').replace(/[.,!?;:()[\]{}“”‘’~…]+/g,' ').replace(/\s+/g,' ').trim();
  for(const [re,v] of mapSynonym)t=t.replace(re,v);
  return t.replace(/\d+\s*(?:번|호)(?:님)?/g,'선수').replace(/\s+/g,'').trim();
}
function grams(s) {
  const g=new Set();
  for(let i=0;i<s.length-1;i++)g.add(s.slice(i,i+2));
  for(let i=0;i<s.length-2;i++)g.add(s.slice(i,i+3));
  return g;
}
const prepared=INTENTS.map(g=>({...g,ex:g.examples.map(s=>({s:canonical(s),g:grams(canonical(s))}))}));
const canonicalExamples=new Map();
for(const item of prepared)for(const ex of item.ex)canonicalExamples.set(ex.s,item.id);
function dice(a,b){let common=0;for(const x of a)if(b.has(x))common++;return 2*common/(a.size+b.size||1);}
function isQuestionForm(t){return /[?？]/.test(t)||/(?:무엇|누구|누가|누굴|왜|어떻게|무슨|뭐야|뭔데|어때|할래|할까|있어|있냐|알려|설명|밝혀|공개|말해|대답|몇\s*번|몇\s*명|어느|해줘|줄래|해봐|하라|하자|해라|해주|해주면|뭐지|뭐임|됨|돼\s*\?|가능|어딨)/.test(t);}
function isReport(t) {
  if(/(?:뭐라고|뭐라|무슨 말을)/.test(t))return false;
  return /^(?:\d+\s*(?:번|호)|그\s*사람|걔|쟤).{0,28}(?:하라고\s*했|하랬|하자고\s*했|해달랬|한다고\s*했|하던데|했다던데|했다고\s*했|라고\s*했)/.test(t);
}
function valid(id,t,frame,question,channel='PUBLIC'){
  const f=rx;
  if(id.startsWith('SECRET_') && channel!=='SECRET')return false;
  switch(id){
    case 'SECRET_ATTACK':return /(?:공격|습격|죽일|죽이|죽여|살해|처리|제거|노리|노려|잡자|타겟|목표|\d+\s*번.{0,12}(?:가자|보내자))/.test(t) && !/(?:하지\s*말|안\s*하|취소|제외|빼자|건드리지|놔두|살려두)/.test(t) && !/(?:말고|대신)/.test(t) && !question;
    case 'SECRET_AVOID':return /(?:공격|습격|죽일|죽이|죽여|살해|처리|제거|노리|건드리|살려두|제외|빼자|놔두)/.test(t)&&/(?:하지\s*말|안\s*하|취소|제외|빼자|건드리지|놔두|살려두|반대)/.test(t)&&!/(?:말고|대신)/.test(t);
    case 'SECRET_SWITCH':return /\d+\s*번/.test(t) && /(말고|대신|바꿔|변경|아니고|제외하고|관두고)/.test(t);
    case 'SECRET_INFO':return /(조사|정보|수사|신원|실제\s*직업|알아낸|확인한|내역|역할)/.test(t) && question;
    case 'SECRET_PLAN':return /(공격|살해|죽일|죽이|노리|목표|타겟|전략|계획)/.test(t) && question;
    case 'ROLE_SILENCE':return f.ROLE.test(t)&&f.ROLE_NO.test(t);
    case 'ROLE_REQUEST':return (f.ROLE.test(t)||/(?:경찰|의사|마피아|시민|건달|스파이).{0,12}(?:맞아|맞니|냐)/.test(t)) && !f.ROLE_NO.test(t) && question && !isReport(t);
    case 'WHO_POLICE':return f.POLICE.test(t)&&/(?:누구|누가|몇\s*번|자처|밝힌\s*사람|주장한\s*사람|나온\s*사람)/.test(t) && !isReport(t);
    case 'INVESTIGATION_QUERY':return f.INVESTIGATION.test(t) && question && !isReport(t);
    case 'EVIDENCE_QUERY':return f.EVIDENCE.test(t) && question && !/^(?:난|나는|내가).{0,20}(?:없|부족)/.test(t);
    case 'EVIDENCE_LACK':return frame.act==='LOW_EVIDENCE'||(f.EVIDENCE.test(t)&&f.EVIDENCE_WEAK.test(t)&&!question && !/없는\s*건\s*아니|없다는\s*뜻이\s*아니/.test(t));
    case 'EVIDENCE_HAS':return frame.act==='EVIDENCE_CLAIM'||(f.EVIDENCE.test(t)&&f.CONFIDENT.test(t)&&!f.EVIDENCE_WEAK.test(t)&&!question);
    case 'UNCERTAIN':return frame.act==='UNCERTAIN'||(f.UNCERTAIN.test(t)&&!question);
    case 'DEFER':return frame.act==='DEFER'||(f.DEFER.test(t)&&!question && !f.SKIP.test(t));
    case 'VOTE_SKIP':return frame.act==='VOTE_SKIP' && !frame.question || (f.SKIP.test(t)&&!f.SKIP_NO.test(t)&&!f.NIGHT.test(t)&&!question);
    case 'VOTE_SKIP_DENY':return frame.act==='REJECT_SKIP'||f.SKIP_NO.test(t);
    case 'NIGHT_SKIP':return frame.act==='NIGHT_SKIP'||(f.NIGHT.test(t)&&f.SKIP.test(t) && !f.SKIP_NO.test(t));
    case 'VOTE_QUERY':return f.VOTE.test(t)&&question&&!f.NIGHT.test(t)&&!f.SKIP_NO.test(t);
    case 'VOTE_PROPOSE':return f.VOTE.test(t)&&!question && !f.SKIP.test(t);
    case 'SUSPICION_QUERY':return f.DOUBT.test(t) && question && !f.EVIDENCE.test(t) && !f.COMPARE.test(t) && !isReport(t);
    case 'ACCUSE':return f.DOUBT.test(t)&&!question&&!f.NEGATE_DOUBT.test(t)&&!f.CHANGE.test(t);
    case 'DEFEND':return (f.NEGATE_DOUBT.test(t)||/(?:믿어|결백|무죄|시민팀)/.test(t))&&!question&&!f.CHANGE.test(t);
    case 'COMPARE':return f.COMPARE.test(t) && question;
    case 'CONTRADICTION':return f.CHANGE.test(t) && (f.HISTORY.test(t)||/(?:모순|말\s*바꿨|앞뒤|서로\s*다르)/.test(t)) && !isReport(t);
    case 'CHAT_HISTORY':return f.HISTORY.test(t) && (/(?:말|발언|기억|주장|대화|뭐라|뭐라고)/.test(t)) && question && !isReport(t);
    case 'CLARIFY':return f.CLARIFY.test(t) && question;
    case 'REPEAT_REQUEST':return f.REPEAT.test(t) && !isReport(t);
    case 'AGREE':return f.AGREE.test(t)&&!f.DISAGREE.test(t)&&!question;
    case 'DISAGREE':return f.DISAGREE.test(t)&&!question;
    case 'CORRECTION':return f.CORRECTION.test(t)&&!question;
    case 'DEESCALATE':return f.SOCIAL_FIGHT.test(t)&&!question;
    case 'LIVING_COUNT':return f.LIVE.test(t)&&f.COUNT.test(t)&&question;
    case 'PHASE_QUERY':return f.PHASE.test(t)&&question && !f.NIGHT.test(t) || f.PHASE.test(t)&&f.NIGHT.test(t)&&question && !f.SKIP.test(t);
    case 'RULE_QUERY':return f.RULE.test(t)&&question && !(f.ROLE.test(t) && !/(?:능력|규칙|하는\s*일|승리\s*조건|방법)/.test(t)) && !isReport(t);
    case 'DEATH_QUERY':return f.DEAD.test(t)&&question&&!f.VOTE.test(t);
    case 'GREETING':return f.GREET.test(t)&&t.length<=25;
    case 'THANKS':return f.THANK.test(t)&&t.length<=28;
    default:return false;
  }
}
function featureClassify(t,frame,channel='PUBLIC') {
  // Slot/act inference composes lexical concepts, grammatical polarity,
  // speaker attribution and question/imperative forms. This works on new
  // phrasings which never appeared in the example bank.
  const x=t.replace(/\s+/g,' ').trim();
  const ask=/(?:[?？]|(?:추천해|골라\s*줘|들려\s*줘|왜|누구|누가|누굴|무슨|뭐|뭔(?!가)|어떤|어떻게|어느|몇\s*명|몇\s*번|어딨|어딘|있냐|있니|있어\?|할까|할래|할거|보니|봤어|이야|인가|니|냐|지\?|가요|나요|할\s*수|될까|될지|그런지|궁금|알고\s*싶|알려|말해|설명|보여|보여줘|정리해|답해|찾아|공유해|공개해|밝혀|소개해|풀어줘|해봐|해줘|해주라|말\s*좀|좀\s*말|좀\s*설명|말하라|밝히라|설명하라|설명\s*좀|누구인지|어디로|왜\s*안|내용\s*돌려))/.test(x);
  const imperative=/(?:하자|말자|말해|밝혀|공개해|설명해|보여|알려|얘기해|찍자|보자|말라|그만|해라|해봐|해줘|해주|할래|하지\s*마|하지\s*말|바꾸자|대답해|답해)/.test(x);
  const aboutRoles=rx.ROLE.test(x)||/(?:시민|경찰|의사|마피아|건달|스파이).{0,10}(?:맞아|맞니|맞냐)/.test(x);
  const askRole=aboutRoles && !rx.ROLE_NO.test(x) &&
    (ask || imperative || /(?:포지션|직업|정체|역할).{0,14}(?:말|알|궁금|공개|밝|까|설명|소개|공유|뭔|무슨|어떤)/.test(x));
  const aboutGameRules=/(?:규칙|능력|승리\s*조건|재투표|동률|접선|자기\s*자신\s*치료|스킵과\s*기권|스킵이랑\s*기권)/.test(x)||
    /(?:경찰|의사|건달|마피아|스파이)(?:은|는|이|가|의)?\s*(?:밤마다|밤에|할\s*수|뭐\s*하|하는\s*일|역할\s*설명|어떻게\s*하|남도\s*살)/.test(x);
  const skip=rx.SKIP.test(x)||/(?:표\s*(?:행사|던지|주|넣).{0,13}(?:안\s*할|않을|못\s*하|싫)|아무(?:한테|에게)도\s*표\s*(?:안|못|없))/.test(x);
  const skipNo=rx.SKIP_NO.test(x)||
    /(?:스킵|패스|기권|건너\s*뛰|생략).{0,17}(?:마음\s*없|전혀\s*없|절대\s*반대|난\s*반대|안\s*돼|싫어|안\s*함|못\s*하|않을|하면\s*안|하지\s*마|하지\s*말)/.test(x)||
    /(?:반대|안\s*해|안\s*할|절대\s*싫).{0,14}(?:스킵|패스|기권)/.test(x)||
    /(?:표를?\s*(?:꼭|반드시)\s*(?:던지|주|행사)|기권할\s*마음\s*(?:전혀\s*)?없)/.test(x);
  const night=rx.NIGHT.test(x);
  const nightSkip=night && /(스킵|패스|생략|건너|넘어가|넘기|지나치|안\s*하|없이\s*끝내)/.test(x);
  const publicVote=rx.VOTE.test(x) || /(?:표\s*행사|표\s*주|표\s*넣|표\s*몰|퇴출|처형)/.test(x);
  const aboutSuspicion=rx.DOUBT.test(x)||/(?:누굴\s*믿|누굴\s*의심|범인|거짓말|누가\s*수상)/.test(x);
  const doubtNeg=rx.NEGATE_DOUBT.test(x)||/(?:무죄|결백|믿을\s*만|믿어주|범인\s*아닐|마피아\s*아닐)/.test(x);
  const evidenceQuestion=rx.EVIDENCE.test(x)&&ask ||
    /(?:왜|뭘\s*보고|무엇을\s*보고|어떤\s*이유).{0,30}(?:의심|수상|찍|생각|판단|마피아|범인|보는|보고)/.test(x);
  if(isReport(x))return null;
  if(frame.act==='LOW_EVIDENCE' && !/[?？]/.test(x))return 'EVIDENCE_LACK';
  if(channel==='SECRET'){
    const ids=[...x.matchAll(/(\d+)\s*번/g)];
    if(ids.length>=2 && /(?:말고|대신|아니고|바꾸|변경|옮기|전환)/.test(x))return 'SECRET_SWITCH';
    if(ids.length && /(?:공격|습격|죽이|죽일|노리|건드리|살려|제외|빼자)/.test(x) &&
      /(?:하지\s*마|하지\s*말|하지\s*않|안\s*해|취소|건드리지|살려두|제외|빼자|반대)/.test(x))return 'SECRET_AVOID';
    if(/(?:조사|신원|정보|알아낸|실제\s*직업|직업\s*정보)/.test(x) && ask && !/너\s*직업|네\s*직업/.test(x))return 'SECRET_INFO';
    if(/(?:공격|습격|살해|목표|타겟|전략|계획|누굴\s*먼저)/.test(x) && ask && !ids.length && !/(?:조사|결과|확인|의사|경찰|건달|시민팀|마피아팀)/.test(x))return 'SECRET_PLAN';
    if(ids.length && /(?:공격|습격|죽이|죽일|처리|제거|노리|노려|잡자|타겟|목표|먼저\s*보내)/.test(x)&&!ask)return 'SECRET_ATTACK';
  }
  // Denials and phase distinctions are higher-priority than topic similarity.
  if(aboutRoles && rx.ROLE_NO.test(x) && !/(?:공개하지\s*마\?|말하지\s*마\?)/.test(x))return 'ROLE_SILENCE';
  if(/(?:너|넌|네가|니가|당신).{0,12}(?:마피아|시민|경찰|의사|스파이|건달)(?:야|이야|냐|니|맞아|같아)[?？]?\s*$/.test(x))return 'ROLE_REQUEST';
  if(/(?:(?:너|넌|네가|니가|너는).{0,15}(?:거짓말|구라).{0,8}(?:했|하|맞|니|냐)|왜.{0,25}(?:거짓말|구라|속였))/.test(x)&&ask)return 'EVIDENCE_QUERY';

  if(skipNo || frame.act==='REJECT_SKIP') return 'VOTE_SKIP_DENY';
  if(/(?:아무(?:한테|에게)도.{0,18}(?:표|투표).{0,16}(?:안|않|못)|(?:이번|오늘|난|나는).{0,18}(?:표|투표).{0,14}(?:안\s*할래|안\s*할게|않을래|안\s*하겠))/.test(x))return 'VOTE_SKIP';
  if(nightSkip)return 'NIGHT_SKIP';
  if(aboutGameRules && (ask||imperative||/(?:역할\s*설명|스킵이랑\s*기권)/.test(x)))return 'RULE_QUERY';
  if(rx.POLICE.test(x)&&/(?:누구|누가|몇\s*번|자처|주장한|행세|나온\s*사람)/.test(x)
     && !/(?:조사|능력)/.test(x))return 'WHO_POLICE';
  if(askRole)return 'ROLE_REQUEST';
  if((rx.INVESTIGATION.test(x)||/(?:검사|탐문)/.test(x))&& (ask||/(?:내역|기록)\s*좀/.test(x))
     && !/(?:내가|나는|난).{0,10}(?:조사|확인)\s*(?:했|해봤)/.test(x))return 'INVESTIGATION_QUERY';
  if(/(?:생존|남은\s*인원|살아\s*있|살아\s*남|남아\s*있|탈락\s*안|탈락하지\s*않)/.test(x)&&
    (rx.COUNT.test(x)||/(?:몇|명단|세\s*줘)/.test(x)))return 'LIVING_COUNT';
  if(/(?:희생|사망|죽은|죽었|죽었니|탈락자|밤\s*결과)/.test(x) && (ask||/누구|몇\s*번|있니|나왔/.test(x)))return 'DEATH_QUERY';
  if((rx.PHASE.test(x)||/(?:무슨\s*차례|몇\s*번째\s*토론|몇\s*번째\s*밤|지금\s*낮|지금\s*밤|어디까지\s*왔)/.test(x))
     && (ask||/(?:무슨\s*차례|몇\s*번째|해야\s*하는\s*순서|진행\s*순서)/.test(x)) && !nightSkip)return 'PHASE_QUERY';
  if(/(?:직전|아까|앞선).{0,15}질문.{0,8}(?:뭘|무슨|뭐|했어|했지|기억)/.test(x))return 'CHAT_HISTORY';
  if(rx.REPEAT.test(x)||/(?:내\s*질문|내가\s*물|물은\s*데|질문에).{0,20}(?:답|대답|왜\s*안)/.test(x))return 'REPEAT_REQUEST';
  if(rx.CHANGE.test(x)||/(?:말이\s*달라|말\s*바뀐|발언이\s*달라|주장을\s*바꿨)/.test(x)){
    if(/(?:모순|앞뒤|말\s*바|말이\s*바뀌|말이\s*바뀐|말이\s*달|발언이\s*달|주장.*다르|앞(?:에서)?.{0,15}말.{0,20}지금|말이랑.{0,15}안\s*맞)/.test(x))return 'CONTRADICTION';
  }
  if((rx.HISTORY.test(x)||/(?:첫날|직전|전에|앞서)/.test(x)) &&
    /(?:발언|뭐라|뭐라고|말했|말한|했던\s*말|질문|기억|대화)/.test(x) && ask)return 'CHAT_HISTORY';
  if(rx.CLARIFY.test(x) && (ask||/(?:풀어\s*(?:줘|설명)|다시\s*설명|쉽게\s*풀어|이해할\s*수\s*있게)/.test(x)))return 'CLARIFY';
  if(evidenceQuestion && !/^(?:난|나는|내가).{0,16}(?:근거|증거|단서).{0,12}(?:없|부족)/.test(x))return 'EVIDENCE_QUERY';
  if(rx.EVIDENCE.test(x)&& (rx.EVIDENCE_WEAK.test(x)||/(?:입증이\s*어렵|확인하기\s*어렵|몰아갈\s*수\s*없|판단.*어렵)/.test(x))&&!ask)return 'EVIDENCE_LACK';
  if(/(?:말만\s*듣|느낌만|감만).{0,26}(?:몰아|확신|판단|단정|모르|찍|퇴출)/.test(x))return 'EVIDENCE_LACK';
  if(rx.EVIDENCE.test(x)&& rx.CONFIDENT.test(x) && !rx.EVIDENCE_WEAK.test(x)&&!ask ||
     /(?:내가\s*직접\s*확인|입증\s*가능|결정적인\s*자료)/.test(x) && !ask)return 'EVIDENCE_HAS';
  if(skip&&!skipNo&&!nightSkip && !ask)return 'VOTE_SKIP';
  if(skip&&!skipNo&&!nightSkip && ask)return 'VOTE_QUERY';
  if((rx.DEFER.test(x)||frame.act==='DEFER') && !skip ||/(?:결정\s*내릴\s*때.{0,13}아(?:닌|니)|좀\s*더\s*이야기\s*듣|조금만\s*더.{0,22}결론|결론.{0,10}(?:나중|뒤|말자))/.test(x))return 'DEFER';
  if(rx.UNCERTAIN.test(x)||/(?:감이\s*안|누구.{0,15}난감|판단\s*안\s*되|정리가\s*안\s*됐)/.test(x))return 'UNCERTAIN';
  if(rx.COMPARE.test(x)&&ask && /(?:\d+\s*번|둘|두\s*사람|서로)/.test(x))return 'COMPARE';
  if(aboutSuspicion && (ask || /(?:어떤\s*사람|누가|누굴|누구).{0,20}(?:마피아|범인|수상|의심)/.test(x)) && !doubtNeg && !evidenceQuestion)return 'SUSPICION_QUERY';
  if(doubtNeg && !ask && (aboutSuspicion||/(?:무죄|결백|시민팀|범인\s*아닐|마피아\s*아닐)/.test(x)) && !/(?:믿어주면\s*안|믿을\s*수\s*없|못\s*믿|안\s*믿)/.test(x))return 'DEFEND';
  if((aboutSuspicion || /(?:믿어주면\s*안|믿을\s*수\s*없|못\s*믿|안\s*믿)/.test(x)) && !ask && !rx.CORRECTION.test(x) && !/(?:말이\s*달라|말\s*바꿨|앞뒤|모순)/.test(x))return 'ACCUSE';
  if(publicVote && ask && !nightSkip)return 'VOTE_QUERY';
  if(publicVote && !ask && !skipNo && !skip && !rx.DEFER.test(x) && /(하자|하겠|할게|찍|몰자|몰아\s*주자|넣|표\s*행사|투표)/.test(x))return 'VOTE_PROPOSE';
  if(rx.CORRECTION.test(x)||/(?:아니\s*그런\s*말|바로잡|말한\s*적\s*없)/.test(x))return 'CORRECTION';
  if(rx.SOCIAL_FIGHT.test(x) && /(?:그만|중단|대신|말자|멈춰|하지\s*마)/.test(x))return 'DEESCALATE';
  if(rx.DISAGREE.test(x))return 'DISAGREE';
  if(rx.AGREE.test(x)||/(?:내가\s*보기에도\s*맞|그\s*말\s*맞|그건\s*인정)/.test(x))return 'AGREE';
  if(rx.GREET.test(x)&&x.length<32)return 'GREETING';
  if(rx.THANK.test(x)&&x.length<55)return 'THANKS';
  return null;
}
function classify(text,options={}) {
  const t=String(text||'').normalize('NFC').trim();
  if(!t||t.length>400)return null;
  const frame=discourse(t,{phase:options.phase||'DAY'});
  const question=isQuestionForm(t), canonicalText=canonical(t), fingerprint=grams(canonicalText);
  const report=isReport(t);
  // The corpus is labeled intent examples, NEVER complete answers. Exact
  // examples can resolve unusual grammar, while all other text uses the same
  // compositional guards + graded lexical similarity.
  const remembered=canonicalExamples.get(canonicalText);
  if(remembered && !report && (!remembered.startsWith('SECRET_') || options.channel==='SECRET')) {
    const type=byId.get(remembered);
    // Do not turn a negated disclosure into the positive intent, even if the
    // surface form contains a literal training phrase.
    if(!(remembered==='ROLE_REQUEST' && rx.ROLE_NO.test(t)))
      return {intent:remembered,kind:type.kind,confidence:1,topic:type.topic,
        group:/(?:다들|모두|각자|전원|여러분|한\s*명씩|차례로|너희|우리\s*모두)/.test(t),
        frame,numberMentions:[...t.matchAll(/(\d+)\s*(?:번|호)(?!\d)/g)].map(x=>Number(x[1]))};
  }
  // Unseen phrases use compositional grammar, polarity and context features.
  const feature=featureClassify(t,frame,options.channel||'PUBLIC');
  if(feature && (!report || feature==='CHAT_HISTORY')) {
    const g=byId.get(feature);
    return {intent:feature,kind:g.kind,confidence:0.88,topic:g.topic,
      group:/(?:다들|모두|각자|전원|여러분|한\s*명씩|차례로|너희|우리\s*모두|전체)/.test(t),
      frame,numberMentions:[...t.matchAll(/(\d+)\s*(?:번|호)(?!\d)/g)].map(x=>Number(x[1]))};
  }
  // Safety priorities: a negated request is not a request to reveal a role;
  // refusing to skip must never be recorded as the choice to skip.
  const priority=['ROLE_SILENCE','VOTE_SKIP_DENY','NIGHT_SKIP','WHO_POLICE','RULE_QUERY'];
  const winners=[];
  for(const item of prepared) {
    if(!valid(item.id,t,frame,question,options.channel||'PUBLIC'))continue;
    let best=0;
    for(const x of item.ex){const similarity=dice(fingerprint,x.g);if(similarity>best)best=similarity;}
    // Strong semantic anchors make the label meaningful even when no example
    // is especially close. Short/ambiguous utterances need a closer example.
    const anchored=(item.id.startsWith('SECRET_') || priority.includes(item.id) || ['ROLE_REQUEST','INVESTIGATION_QUERY','EVIDENCE_QUERY','EVIDENCE_LACK','DEFER','UNCERTAIN','VOTE_QUERY','VOTE_SKIP','LIVING_COUNT','CHAT_HISTORY','PHASE_QUERY','CONTRADICTION','DEATH_QUERY'].includes(item.id));
    const threshold=anchored?0.23:0.37;
    if(best<threshold)continue;
    let score=best + (anchored?0.055:0);
    if(item.id==='ROLE_REQUEST' && /(?:직업|역할|정체|신분|포지션)/.test(t))score+=0.09;
    if(item.id==='RULE_QUERY' && /(?:능력|규칙|승리\s*조건|재투표|접선)/.test(t))score+=0.12;
    if(item.id==='NIGHT_SKIP'&&frame.act==='NIGHT_SKIP')score+=0.3;
    if(item.id==='VOTE_SKIP'&&frame.act==='VOTE_SKIP')score+=0.24;
    if(item.id==='VOTE_SKIP_DENY'&&frame.act==='REJECT_SKIP')score+=0.3;
    winners.push({id:item.id,kind:item.kind,score,exampleSimilarity:best});
  }
  winners.sort((a,b)=>b.score-a.score || order.indexOf(a.id)-order.indexOf(b.id));
  const best=winners[0];if(!best)return null;
  const second=winners[1];
  // A lexically ambiguous pair is deliberately left unknown unless grammar
  // has already resolved polarity or the role disclosure/silence distinction.
  if(second && best.score-second.score<0.022 && best.score<0.48 && !priority.includes(best.id))return null;
  return {intent:best.id,kind:best.kind,confidence:Math.max(0,Math.min(1,best.score)),
    topic:byId.get(best.id).topic,group:/(?:다들|모두|각자|전원|여러분|한\s*명씩|차례로|너희|우리\s*모두)/.test(t),
    frame,numberMentions:[...t.matchAll(/(\d+)\s*(?:번|호)(?!\d)/g)].map(x=>Number(x[1]))};
}
module.exports={classify,canonical,INTENTS};

})(utteranceModule,utteranceModule.exports,(name)=>{
 if(name==='./utterance-corpus.json')return corpusModule.exports;
 if(name==='../discourse-frame')return discourseModule.exports;
 throw new Error('Unexpected utterance import '+name);
});
const botModule={exports:{}};
(function(module,exports,require){
'use strict';

// Offline-first social-deduction agents. Each bot reads only public statements and
// its own role/investigations/contact information. No remote text API or cheat access.
// Speech is assembled from a context-specific argument, an attitude, evidence,
// and a question or conclusion; it is not a list of full canned chat messages.
const DiscourseFrame = require('./discourse-frame');
const Utterance = require('./ai/utterance-parser');
const {AgentMemory} = require('./ai/memory');
const ROLE_WORDS = ['마피아', '스파이', '경찰', '의사', '건달', '시민'];
const PERSONAS = [
  { label:'신중', direct:0.25, talk:3, doubt:0.35, rhythm:['음','일단','잠깐'] },
  { label:'직설', direct:0.92, talk:5, doubt:0.62, rhythm:['잠깐만','솔직히'] },
  { label:'분석', direct:0.60, talk:4, doubt:0.75, rhythm:['정리하면','내 생각엔','일단 사실만 보면'] },
  { label:'감정', direct:0.82, talk:4, doubt:0.48, rhythm:['어','잠깐','이상한데'] },
  { label:'조용', direct:0.18, talk:2, doubt:0.27, rhythm:['음'] },
  { label:'설득', direct:0.60, talk:4, doubt:0.64, rhythm:['보니까','일단'] },
];

function choice(xs,rng) { return xs.length ? xs[Math.min(xs.length-1,Math.floor(rng()*xs.length))] : ''; }
function stamp(target) { return target ? `${target.number}번` : ''; }
function clamp(v,lo,hi) { return Math.min(hi,Math.max(lo,v)); }
function normalize(text) { return String(text||'').replace(/\s+/g,' ').trim(); }
function roleAsStatement(role) {
  const last=role.charCodeAt(role.length-1);
  const hasJong=last>=0xAC00 && last<=0xD7A3 && (last-0xAC00)%28!==0;
  return role+(hasJong?'이야':'야');
}
function roleAsQuote(role) {
  const last=role.charCodeAt(role.length-1);
  const hasJong=last>=0xAC00 && last<=0xD7A3 && (last-0xAC00)%28!==0;
  return role+(hasJong?'이라고':'라고');
}
function includesSelfClaim(text) {
  return /(?:나는|난|내가|제가|저는|전|나|내 직업|제 직업|저)\s*(?:(?:진짜|사실|원래|확실히)\s*)?(?:경찰|의사|시민|마피아|건달|스파이)/.test(text) ||
    /(?:경찰|의사|시민|마피아|건달|스파이)\s*(?:입니다|이에요|이야|인데|이니까)/.test(text) && !/(?:너|쟤|그 사람|\d번)\s*(?:경찰|의사|시민|마피아|건달|스파이)/.test(text);
}
function claimedRole(text) {
  const t=normalize(text);
  const original=t.match(/(?:^|[,.!?;，]\s*|(?:^|\s)(?:음|솔직히|사실|근데|저기|일단|참고로)\s+|^(?:너네|너희|다들|여러분)\s+)(?:나는|난|내가|제가|저는|전|나|내\s*직업(?:은|이)?|제\s*직업(?:은|이)?|저)\s*(?:(?:진짜|사실|원래|확실히)\s*)?(?:경찰|의사|시민|마피아|건달|스파이)/);
  const additional=t.match(new RegExp(`(?:^|\\s)(?:\\uB098\\uB3C4|\\uC800\\uB3C4)\\s*(${ROLE_WORDS.join('|')})`));
  const selected=original && additional ? (original.index<=additional.index?original:additional) : (original||additional);
  if(!selected)return null;
  const fragment=selected[0];
  const role=ROLE_WORDS.find(word=>fragment.endsWith(word));
  if(!role)return null;
  const rest=t.slice(selected.index+fragment.length);
  // A short question about one's own role is not a declaration; a completed
  // declaration followed by a separate question still counts.
  const firstPunctuation=rest.match(/[.!?\uFF1F]/)?.[0];
  if(firstPunctuation==='?' || firstPunctuation==='\uFF1F')return null;
  // Negative self-statements do not constitute a positive role claim.
  if(/^\s*(?:\uD300)?\s*(?:\uC774|\uAC00)?\s*\uC544\uB2C8/.test(rest))return null;
  return role;
}
// Negative first-person role declarations are public claims about what a speaker
// denies, never positive evidence of their role.
function deniedRole(text) {
  const t=normalize(text);
  if(isQuestion(t))return null;
  const m=t.match(/^(?:(?:너네|너희|다들|여러분|아까|아니|근데)\s+)?(?:나는|난|내가|저는|전|제가|저|나|내\s*직업(?:은|이)?)\s*(?:진짜\s*)?(경찰|의사|시민|마피아|건달|스파이)\s*(?:이|가|은|는)?\s*(?:아니(?:야|다|에요|라고|라고\s*했|라니까|라며)|아닌데|아닙니다|아니라고)/);
  return m?.[1]||null;
}
function orderedMentions(text,players) {
  const matches=[];
  for(const p of players){
    const num=new RegExp(`(?:^|[^0-9])(${p.number})\\s*(?:번|호)(?![0-9])`);
    const found=num.exec(text);
    if(found)matches.push({id:p.id,index:found.index+(found[0].length-found[0].trimStart().length)});
    else if(p.name && p.name.length>1){const i=text.indexOf(p.name);if(i!==-1)matches.push({id:p.id,index:i});}
  }
  return matches.sort((a,b)=>a.index-b.index).map(x=>x.id);
}
function topicSwitchTarget(text,view) {
  const t=normalize(text);
  const m=t.match(/(\d+)\s*번[^.!?]{0,28}?(?:말고|아니고|그만하고|됐고)\s*(\d+)\s*번/);
  if(!m)return null;
  return view.everyone.find(p=>p.number===Number(m[2]))?.id||null;
}
function isReportedSkipVote(text) {
  return /(?:\d+\s*번|그\s*사람|걔).{0,28}(?:스킵|건너뛰).{0,14}(?:한다고|한다던데|했는데|했다|했어|하겠다고|하자고)/.test(text);
}
function declaredStance(text,players) {
  const t=normalize(text);
  const frame=DiscourseFrame.parse(t);
  // Do not turn negated, reported, hypothetical or night-only SKIP language
  // into a promise to skip the public daytime vote.
  if(frame.reported || frame.act==='NIGHT_SKIP' ||
     /(?:스킵|기권|패스|건너\s*뛰).{0,14}(?:안\s*해|안\s*할|하지\s*않|하지\s*말|싫|아니)/.test(t))return null;
  if(/[?？]/.test(t) || /(?:왜|누구|어떻게)\s*(?:찍|투표|스킵|건너뛰)/.test(t))return null;
  // A decision to wait is NOT an irreversible vote decision.
  if(frame.act==='VOTE_SKIP' && !/(?:보류|유보)(?:하|할|했)/.test(t) &&
      !/^(?:\d+\s*번|그\s*사람|걔|쟤).{0,25}(?:스킵|기권|패스)/.test(t)) return 'SKIP';
  // Players cannot skip the night phase. Such a suggestion must not become
  // evidence that they promised to skip the *daytime vote*.
  if(/(?:밤|야간).{0,20}(?:스킵|건너\s*뛰|넘기)/.test(t) && !/(?:투표|표결)/.test(t))return null;
  // Reports of another player's stance are not the current speaker's own vote.
  if(isReportedSkipVote(t))return null;
  // Only *voluntary, stated* voting intentions are evidence, never inferred hidden votes.
  if(/(?:나는|난|내가|저는|전)\s*(?:이번엔|오늘|일단|지금은)?\s*(?:스킵|건너\s*뛰(?:기)?)/.test(t) ||
    /(?:스킵|건너\s*뛰(?:기)?)(?:\s*(?:하자|할게|할래|하고 싶어|하려고))/.test(t))return 'SKIP';
  const refs=mentions(t,players);
  const declares=/(?:찍을게|찍자|투표할게|투표하자|퇴출시키자|뽑을게|표\s*줄게)/.test(t);
  if(declares && refs.length)return refs[0];
  return null;
}
function mentions(text, players) {
  const found=[];
  for(const p of players) {
    const num = new RegExp(`(?:^|[^0-9])${p.number}\\s*(?:번|호|번님)(?![0-9])`);
    if (num.test(text) || (p.name && p.name.length>1 && text.includes(p.name))) found.push(p.id);
  }
  return found;
}
function mindFor(p,rng=Math.random) {
  if (!p.mind) p.mind = {
    persona: choice(PERSONAS,rng), suspicion:Object.create(null), trust:Object.create(null),
    claims:Object.create(null), observations:[], attacks:Object.create(null),
    accusations:[], seenPublic:[], seenSecret:[], spoken:[], turns:0,
    lastOpinion:null, lastRespondedId:null, visitedLast:[], watched:[],
    claimChanges:[], answerIds:[], publicStances:Object.create(null), stanceChanges:[], roleDenials:Object.create(null),
    agentMemory:new AgentMemory(p.number)
  };
  return p.mind;
}
function adjust(mind,id,score) {
  if (!id) return;
  mind.suspicion[id]=clamp((mind.suspicion[id]||0)+score,-7,9);
}
function legalView(room,p) {
  const view=room.botKnowledge(p);
  const everyone=room.players.map(q=>({id:q.id,number:q.number,name:q.name,alive:q.alive,bot:q.bot}));
  return { ...view, everyone, publicChat:room.publicChat, publicLog:room.publicLog,
    publicVote:room.voteOutcome && ['VOTE_RESULT','GAME_OVER'].includes(room.phase) ? room.voteOutcome : null,
    phaseStart:room.phaseStart,
    secretChat:view.partnerId ? room.secretChat : [] };
}
function findOwnResult(view,id) {return view.investigations.findLast(x=>x.targetId===id) || null;}
function readStatements(p,view,rng) {
  const mind=mindFor(p,rng);
  const roster=view.everyone;
  for(const entry of view.publicChat) {
    if(mind.seenPublic.includes(entry.id)) continue;
    mind.seenPublic.push(entry.id);
    if(entry.senderId===p.id) continue;
    const words=normalize(entry.text);
    const refs=mentions(words,roster);
    const speaker=roster.find(x=>x.id===entry.senderId);
    if(!speaker) continue;
    const claim=claimedRole(words);
    const denial=deniedRole(words);
    if(denial){
      if(mind.claims[speaker.id]?.role===denial){
        mind.claimChanges.push({speakerId:speaker.id,from:denial,to:'그 직업 부인',id:entry.id,at:entry.at});
        adjust(mind,speaker.id,1.2);
      }
      mind.roleDenials[speaker.id]={role:denial,at:entry.at,text:words};
      if(mind.claims[speaker.id]?.role===denial)delete mind.claims[speaker.id];
    }
    if (claim) {
      const previous=mind.claims[speaker.id];
      if(previous && previous.role!==claim) {
        adjust(mind,speaker.id,2.3);
        mind.claimChanges.push({speakerId:speaker.id,from:previous.role,to:claim,id:entry.id,at:entry.at});
      }
      mind.claims[speaker.id]={role:claim,at:entry.at,text:words};
      // A police bot knows no other player can simultaneously be the police.
      if(view.role==='POLICE' && claim==='경찰') adjust(mind,speaker.id,5);
      // A spy can compare an actual investigated role against a claimant.
      const verified=findOwnResult(view,speaker.id);
      if(view.role==='SPY' && verified?.actualRole && claim && verified.displayed!==claim) adjust(mind,speaker.id,2.4);
      if(view.role==='POLICE' && verified?.displayed==='마피아팀' && claim!=='마피아') adjust(mind,speaker.id,4);
      if(claim==='경찰' && !/(조사|결과|\d번)/.test(words)) adjust(mind,speaker.id,0.4);
    }

    const aggressive=/(\uC758\uC2EC|\uC218\uC0C1|\uB9C8\uD53C\uC544|\uAC70\uC9D3|\uAD6C\uB77C|\uB9D0 \uBC14\uAFD4)/.test(words);
    const negated=/(\uC544\uB2C8|\uC5C6|\uB2E8\uC815\uD558\uC9C0|\uBABB \uBBFF|\uD655\uC2E4\uD558\uC9C0)/.test(words);
    const affirmative=/(\uB9C8\uD53C\uC544(?:\uD300)?\s*(?:\uAC19\uC544|\uC774\uC57C|\uC57C|\uB2E4)|\uC758\uC2EC\uD574|\uC218\uC0C1\uD574|\uAC70\uC9D3\uB9D0|\uAD6C\uB77C)/.test(words);
    const actualAccusation=aggressive && affirmative && !isQuestion(words) && !negated;
    if(actualAccusation && refs.length) {
      for(const id of refs) if(id!==speaker.id) {
        mind.accusations.push({by:speaker.id,target:id,text:words,at:entry.at});
        // Human testimony is a weak conversational signal, not proof.
        // Bot accusations never amplify another bot's suspicion score.
        if(!speaker.bot)adjust(mind,id,0.08);
      }
    }
    // Being challenged by another bot is not a reason to retaliate.
    if(actualAccusation && refs.includes(p.id))
      mind.attacks[speaker.id]=(mind.attacks[speaker.id]||0)+1;
    // A false investigation contradicting the agent's *own* information.
    const claimedInvestigation=/(조사|확인|결과)/.test(words);
    if(claimedInvestigation && refs.length && /(마피아팀|마피아라고|마피아야)/.test(words)) {
      const accused=refs.find(id=>id!==speaker.id) || refs[0];
      const own=findOwnResult(view,accused);
      if(view.role==='POLICE' && own?.displayed==='시민팀') adjust(mind,speaker.id,1.8);
      if(view.role==='SPY' && own?.actualRole && own.actualRole!=='MAFIA') adjust(mind,speaker.id,2);
    }
    const statedVote=declaredStance(words,roster);
    if(statedVote!==null) {
      const before=mind.publicStances[speaker.id];
      if(before && before!==statedVote) {
        mind.stanceChanges.push({speakerId:speaker.id,from:before,to:statedVote,at:entry.at,id:entry.id});
        // A changed opinion can have an innocent explanation.
      }
      mind.publicStances[speaker.id]=statedVote;
    }

    mind.observations.push({kind:'message',speakerId:speaker.id,mentions:refs,text:words,at:entry.at,id:entry.id,claim});
  }
  if(mind.seenPublic.length>250) mind.seenPublic=mind.seenPublic.slice(-250);
  if(mind.observations.length>80) mind.observations=mind.observations.slice(-80);
  if(mind.accusations.length>50) mind.accusations=mind.accusations.slice(-50);
  if(mind.claimChanges.length>30) mind.claimChanges=mind.claimChanges.slice(-30);
  if(mind.stanceChanges.length>30)mind.stanceChanges=mind.stanceChanges.slice(-30);
  // Only a contacted Mafia/Spy may inspect the secret messages.
  for(const entry of view.secretChat) {
    if(mind.seenSecret.includes(entry.id)) continue;
    mind.seenSecret.push(entry.id);
    if(entry.senderId===p.id) continue;
    mind.observations.push({kind:'secret',speakerId:entry.senderId,text:entry.text,at:entry.at,id:entry.id});
  }
  if(mind.seenSecret.length>150) mind.seenSecret=mind.seenSecret.slice(-150);
  updateCognitiveMemory(p,view,mind);
  return mind;
}
function updateCognitiveMemory(p,view,mind) {
  const mem=mind.agentMemory;
  if(!mem)return;
  mem.observe({
    publicChat:view.publicChat.map(e=>({id:e.id,number:e.number,text:e.text})),
    secretChat:view.secretChat.map(e=>({id:e.id,number:e.number,text:e.text})),
    ownInvestigations:view.investigations,
    publicLog:view.publicLog
  });
  const visibleIds=new Set(view.alivePlayers.filter(x=>x.id!==p.id).map(x=>x.id));
  // A role-claim switch is an observable contradiction, not proof of Mafia.
  for (const change of mind.claimChanges) {
    mem.addInferredEvidence('claim:'+change.id,change.speakerId,1.2,
      '공개 직업 주장이 이전과 달라짐',[change.id],visibleIds);
  }
  // The agent may use ONLY its own confirmed investigation results.
  for (const result of view.investigations) {
    const id='inv:'+result.night+':'+result.targetId;
    if(p.role==='POLICE'){
      const delta=result.displayed==='마피아팀' ? 2 :
        result.displayed==='시민팀' ? -0.8 : 0;
      if(delta) mem.addInferredEvidence('police:'+id,result.targetId,delta,
        '내 경찰 조사에서 '+result.displayed+'으로 표시됨',[id],visibleIds);
    } else if(p.role==='SPY' && result.actualRole){
      // Spy sees the real role; this remains private until deliberately shared.
      if(result.actualRole==='MAFIA') mem.addInferredEvidence('spy:'+id,result.targetId,-2,
        '내 비공개 조사에서 마피아 본체로 확인함',[id],visibleIds);
    }
  }
  // A genuine police bot knows that another police claimant cannot be genuine.
  if(p.role==='POLICE'){
    for(const [id,claim] of Object.entries(mind.claims)){
      if(id===p.id || claim.role!=='경찰')continue;
      const e=view.publicChat.findLast(x=>x.senderId===id && x.text===claim.text);
      if(e)mem.addInferredEvidence('police-claim:'+e.id,id,1.8,
        '내가 경찰인데 다른 참가자가 경찰이라고 공개 주장함',[e.id],visibleIds);
    }
  }
}
// Keep all six memories current even when no bot has a speaking turn.
// No API, internet, or model is involved; each bot gets its own legal view.
function syncRoom(room) {
  for (const p of room.players) {
    if(!p.bot || !p.alive || !p.role)continue;
    try {readStatements(p,legalView(room,p),room.rng);}catch(_) {
      // A malformed chat may not interrupt the authoritative game engine.
    }
  }
}
function recordDecision(room,p,kind,targetId) {
  const view=legalView(room,p);
  const mind=readStatements(p,view,room.rng);
  const mem=mind.agentMemory;
  const belief=mem.beliefs.get(targetId);
  mem.recordDecision({kind,targetId,night:room.night,phase:room.phase,
    evidenceIds:belief?.reasons?.flatMap(x=>x.evidenceIds).slice(-5)||[],
    basis:belief?.reasons?.length ? '개인 관찰 근거 + 직업 목표 + 게임 규칙' :
      '직업 목표 + 제한된 공개 근거 + 전략적 선택'});
}
function chooseWeighted(items,rng) {
  const total=items.reduce((s,x)=>s+Math.max(0,x.w),0);
  let k=rng()*total;
  for(const entry of items) {k-=Math.max(0,entry.w);if(k<=0)return entry.item;}
  return items[items.length-1]?.item;
}
function candidates(p,view,validIds,excludeIds=[]) {
  const excluded=new Set([...excludeIds,p.id]);
  return view.alivePlayers.filter(q=>validIds.includes(q.id) && !excluded.has(q.id));
}
function suspicion(mind,view,id) {
  // Always-on independent evidence ledger changes even non-LLM choices.
  const v=(mind.suspicion[id]||0)+(mind.agentMemory?.beliefs.get(id)?.score||0)*0.65;
  const result=view.investigations.findLast(i=>i.targetId===id);
  if(view.role==='POLICE') return v+(result?.displayed==='마피아팀'?12:result?.displayed==='시민팀'?-2.4:0);
  return v;
}
function strongestSuspect(p,view,mind,validIds) {
  const vals=candidates(p,view,validIds,view.partnerId?[view.partnerId]:[]);
  vals.sort((a,b)=>suspicion(mind,view,b.id)-suspicion(mind,view,a.id));
  return vals[0] || null;
}
function chooseNight(room,p,rng) {
  const view=legalView(room,p), mind=readStatements(p,view,rng);
  const opts=room.validTargets(p);
  if(!opts.length) return null;
  const possible=candidates(p,view,opts);
  if(p.role==='DOCTOR') {
    const likelyThreat = strongestSuspect(p,view,mind,opts);
    const publicTarget = view.publicChat.slice(-6).flatMap(x=>mentions(x.text,view.alivePlayers)).find(x=>x!==p.id);
    if(publicTarget && opts.includes(publicTarget) && rng()<0.26) return publicTarget;
    if(rng()<0.50 || !likelyThreat) return p.id;
    return choice(possible,rng)?.id || p.id;
  }
  if(['POLICE','SPY'].includes(p.role)) {
    const seen=new Set(view.investigations.map(x=>x.targetId));
    const fresh=possible.filter(x=>!seen.has(x.id));
    if(p.role==='SPY' && !view.partnerId) {
      // The spy cannot know which uninvestigated player is actually Mafia.
      const scored=fresh.slice().sort((a,b)=>(mind.suspicion[b.id]||0)-(mind.suspicion[a.id]||0));
      return (rng()<0.63 ? scored[0] : choice(fresh,rng))?.id || choice(possible,rng).id;
    }
    const scored=fresh.slice().sort((a,b)=>suspicion(mind,view,b.id)-suspicion(mind,view,a.id));
    return (rng()<0.72 ? scored[0] : choice(fresh,rng))?.id || choice(possible,rng).id;
  }
  if(p.role==='GANGSTER') {
    const suspect=strongestSuspect(p,view,mind,opts);
    if(suspect && suspicion(mind,view,suspect.id)>0.9 && rng()<0.72) return suspect.id;
  }
  if(p.role==='MAFIA') {
    const avoid=new Set();
    if(view.contacted && view.partnerId) {
      // Newer advice takes priority; a later veto cancels an earlier proposal.
      for(const entry of view.secretChat.slice().reverse()) {
        if(entry.senderId!==view.partnerId || entry.at<room.phaseStart)continue;
        const veto=secretAvoidTarget(entry.text,view);
        if(veto)avoid.add(veto);
        const candidate=secretAttackTarget(entry.text,view);
        if(candidate && opts.includes(candidate) && candidate!==view.partnerId && !avoid.has(candidate))return candidate;
      }
    }
    const available=possible.filter(x=>!avoid.has(x.id));
    const pool=available.length?available:possible;
    const expectedTrust = pool.slice().sort((a,b)=>(mind.suspicion[a.id]||0)-(mind.suspicion[b.id]||0));
    return (rng()<0.60 ? choice(expectedTrust.slice(0,Math.min(3,expectedTrust.length)),rng) : choice(pool,rng))?.id;
  }
  return choice(possible,rng)?.id;
}
function chooseVote(room,p,rng) {
  const view=legalView(room,p),mind=readStatements(p,view,rng);
  const list=candidates(p,view,view.alivePlayers.map(q=>q.id),view.partnerId?[view.partnerId]:[]);
  if(!list.length) return 'SKIP';
  const winner=list.slice().sort((a,b)=>suspicion(mind,view,b.id)-suspicion(mind,view,a.id))[0];
  const score=suspicion(mind,view,winner.id);
  if(p.role==='POLICE' && score>8) return winner.id;
  if(p.team==='MAFIA') {
    // After contact, avoid voting out the known partner. Before contact, the spy is unknown.
    if(rng()<0.12 && score<0.4)return 'SKIP';
    return (score>0.25 || rng()<0.65) ? winner.id : choice(list,rng).id;
  }
  if(score>=1.4) return rng()<0.89?winner.id:'SKIP';
  if(view.night===1 && rng()<0.45) return 'SKIP';
  if(rng()<0.2) return 'SKIP';
  return rng()<0.63 ? winner.id : choice(list,rng).id;
}
// Public conversation analysis uses witnessed statements, not invented evidence.
// A question is handled as a request for an answer, never as an excuse to ask more questions.
function formatRef(view,id) {
  const q=view.everyone.find(x=>x.id===id);
  return q ? `${q.number}번` : '그 사람';
}
function makeSentence({preface,observation,argument,ask},rng) {
  const parts=[];
  if(preface && rng()<0.73)parts.push(preface);
  if(observation)parts.push(observation);
  if(argument)parts.push(argument);
  if(ask)parts.push(ask);
  return normalize(parts.join(' ')).slice(0,218);
}

// Commands about roles need an explicit intent, even without a question mark.
// A request to discuss or reveal roles is not a statement to acknowledge with
// "I will keep that in mind". This recognizer shares a path between day chat,
// contacted secret chat, the scheduler and the optional LLM relevance check.
function roleSilenceRequest(text) {
  const t=normalize(text);
  return /(?:직업|역할|정체|신분).{0,28}(?:말하지\s*마|말하지\s*말|공개하지\s*마|공개하지\s*말|밝히지\s*마|밝히지\s*말|얘기하지\s*마|이야기하지\s*마|말하면\s*안\s*돼|공개하면\s*안\s*돼|말할\s*필요\s*없)/.test(t) ||
    /(?:직업|역할|정체|신분).{0,26}(?:비밀로\s*해|숨기자|밝힐\s*필요\s*없|(?:얘기|이야기).{0,8}멈추)/.test(t);
}
function roleDisclosureRequest(text) {
  const t=normalize(text);
  const analyzed=Utterance.classify(t);
  if(!/(?:직업|역할|정체|신분|포지션|누구\s*편)/.test(t) || roleSilenceRequest(t))return null;
  // Avoid mistaking a record of somebody's past disclosure for an order.
  const ask=/(?:직업|역할|정체|신분).{0,29}(?:(?:말해|말하(?:자|라|라고|라고\s*했))|(?:알려|공개(?:해|하(?:자|라|라고))|밝혀|밝히(?:자|라|라고)|얘기(?:해|하(?:자|라|라고))|이야기(?:해|하(?:자|라|라고))|설명(?:해|하(?:자|라))|소개(?:해|하(?:자|라))|공유(?:해|하(?:자|라))|까(?:봐|줘|자)|뭐(?:야|지|냐|니|임|를)?|뭔데|어떤|무슨|궁금|말해\s*봐))/.test(t) ||
    /(?:직업|역할|정체|신분).{0,29}(?:얘기|이야기|설명|소개|공유|말|공개|정리).{0,9}(?:해|하자|하라|하라고|해봐|해줘|해보자|해라|해주라|해주시)/.test(t) ||
    /(?:말해|알려|밝혀|공개해|얘기해|이야기해|설명해|공유해|까봐).{0,23}(?:직업|역할|정체)/.test(t) ||
    /(?:무슨|어떤|뭐\s*하는)\s*(?:직업|역할|정체)/.test(t) ||
    /(?:직업|역할|정체)(?:은|는|이|가)?\s*(?:무엇|뭐)/.test(t) ||
    /^(?:자\s*)?(?:다들|모두|여러분|너희|각자|전원).{0,18}(?:직업|역할|정체)(?:\s*(?:부터|좀|한\s*명씩))?[.!?]*$/.test(t);
  if(!ask && analyzed?.intent!=='ROLE_REQUEST')return null;
  // Merely quoting another person's request is not a fresh order from the human.
  if(/^(?:\d+\s*번|그\s*사람|걔)(?:이|가|은|는).{0,24}(?:직업|역할|정체).{0,15}(?:말하|얘기하|밝히|공개하).{0,8}(?:라고\s*했|자고\s*했)/.test(t))return null;
  const group=/(?:다들|모두|전원|여러분|너희|각자|한\s*명씩|하나씩|차례로|서로|우리\s*모두)/.test(t);
  return {group:group || analyzed?.group || false};
}

// Player messages can be questions, statements, corrections and short follow-ups.
// Routing and answering must inspect the SAME utterance; never substitute a
// generic discussion topic for a player's non-question contribution.
function isQuestion(text) {
  const t=normalize(text).replace(/[.!~]+$/,'').trim();
  if(!t)return false;
  if(/[?？]/.test(t))return true;
  // A declarative game report ending in a period must never become a
  // question merely because it contains a word such as '누구' or '조사'.
  if(/[.。]\s*$/.test(normalize(text)) && !/(?:말해(?:\s*줘)?|알려(?:\s*줘)?|답해(?:\s*줘)?|설명해(?:\s*줘)?|해명해(?:\s*봐)?|대답해|밝혀(?:\s*줘)?|공개해|보여\s*줘|정리해(?:\s*줘)?|공유해|말해봐|얘기해|말하라)\s*$/.test(t))return false;
  if(Utterance.classify(t)?.kind==='question')return true;
  // Role requests without punctuation remain conversational questions.
  if(roleDisclosureRequest(t))return true;
  if(/^(?:나는|난|내가|저는|전|제가|저)\s*.{0,20}(?:시민|경찰|의사|마피아|스파이|건달)(?:이야|야|입니다|이에요|인데)$/.test(t))return false;
  if(/(?:말해\s*줘|답해\s*줘|알려\s*줘|설명해\s*줘|해명해\s*봐|대답해|알려줘|말해봐|답해봐)$/.test(t))return true;
  if(/(?:왜|누구|누가|누굴|뭐|무슨|어떻게|어느|몇\s*번|뭔데|뭐야)/.test(t) &&
    /(?:왜|누구|누가|누굴|뭐|무슨|어떻게|어느|몇\s*번|뭔데|뭐야|생각해|의심해|맞아|이야|냐|니|했어|할거야|할래|말해|찍어|찍을래|투표해|수상해|알아)/.test(t))return true;
  if(/(?:직업|역할).{0,12}(?:말해|알려|뭐|뭔데)|(?:마피아|경찰|시민|의사|스파이|건달).{0,6}(?:맞아|냐|니)$/.test(t))return true;
  if(/(?:너|넌|네가|니가).{0,35}(?:의심해|믿어|동의해|수상해|같아|생각해|찍을래|투표할래)$/.test(t))return true;
  if(/^(?:너|넌|네가|니가|당신)\s*.{0,18}(?:마피아|경찰|의사|시민|건달|스파이)(?:야|냐|니|맞아)$/.test(t))return true;
  return false;
}
function intentOf(text) {
  const t=normalize(text);
  if(!isQuestion(t))return null;
  const semantic=Utterance.classify(t);
  if(semantic){
    const mapped={ROLE_REQUEST:'role',WHO_POLICE:'who_police',INVESTIGATION_QUERY:'investigation',
      EVIDENCE_QUERY:'evidence',SUSPICION_QUERY:'opinion',COMPARE:'compare',
      VOTE_QUERY:'vote',DEATH_QUERY:'death',CLARIFY:'clarify',
      LIVING_COUNT:'alive_count',PHASE_QUERY:'phase',RULE_QUERY:'game_rules',
      CHAT_HISTORY:'chat_history',CONTRADICTION:'contradiction',REPEAT_REQUEST:'repeat_request'};
    if(mapped[semantic.intent])return mapped[semantic.intent];
  }
  if(/(?:뭔\s*소리|무슨\s*말|무슨\s*뜻|이해.*?안\s*돼|다시\s*설명|방금.*?(?:말|뜻)|아까.*?무슨\s*말|그게\s*뭐)/.test(t))return 'clarify';
  if(/(?:밤|야간).{0,18}(?:스킵|건너\s*뛰(?:기)?|넘기)/.test(t))return 'night-skip';
  if(/(?:왜.*?(?:싸우|싸워|다투|다퉈)|그만.*?(?:싸우|싸워|다투)|싸우는\s*이유)/.test(t))return 'deescalate';
  if(/(?:\d+\s*번.{0,20}(?:스킵|건너뛰).{0,20}(?:했|한다|하겠).{0,20}(?:왜|투표)|왜.{0,20}(?:투표|찍).{0,20}(?:스킵|건너뛰))/.test(t))return 'vote_contradiction';
  if(/(?:경찰(?:이|은|은\s*대체)?\s*(?:대체\s*)?누구|누가\s*(?:진짜\s*)?경찰|누구(?:가|야|지)?\s*경찰|경찰\s*몇\s*번)/.test(t))return 'who_police';
  if(/(?:\d+\s*번.*?\d+\s*번).{0,30}(?:중에|둘\s*중|누가\s*더|어느\s*쪽|비교|더\s*수상)|(?:중에|둘\s*중).{0,40}(?:누가\s*더|수상|의심|마피아)/.test(t))return 'compare';
  if(/(?:누가\s*(?:죽|사망)|(?:지난밤|어젯밤).*?(?:죽|사망)|사망자.*누구)/.test(t))return 'death';
  if(/(?:조사.*?(?:누구|몇\s*번|결과|했어|했니|했냐|했냐고|알려|말해)|(?:누구|몇\s*번|\d+번).*?조사|조사\s*기록|(?:시민팀|마피아팀).*?(?:나왔|맞아))/.test(t))return 'investigation';
  if(/(?:왜.*?(?:의심|수상|찍|못\s*믿|마피아|거짓말)|(?:의심|수상).*?이유|근거|증거|해명|왜.*?그렇게|무슨\s*이유)/.test(t))return 'evidence';
  if(/(?:투표|스킵|건너뛰|누구\s*찍|누굴\s*찍|표를\s*줄|누구\s*뽑)/.test(t))return 'vote';
  if(/(?:너|넌|네가|니가|너는|당신)\s*(?:은|는)?\s*(?:마피아|경찰|의사|시민|건달|스파이)(?:야|이야|니|냐|맞아)/.test(t))return 'role';
  if(roleSilenceRequest(t))return 'role_silence';
  if(roleDisclosureRequest(t))return 'role';
  if(/(?:직업|역할|(?:너|넌|네가|니가|당신).*?(?:경찰|의사|시민|스파이|마피아|건달)|(?:경찰|의사|시민|스파이|건달).*?(?:맞아|이야|인가|냐|니))/.test(t))return 'role';
  if(/(?:누가\s*마피아|누굴\s*의심|누구.*?의심|누구.*?수상|어떻게\s*생각|생각은|믿어|동의해|(?:말|주장).{0,10}(?:동의|맞아|어때|믿어)|마피아.*?누구|(?:\d+\s*번|그\s*사람|걔).*?(?:마피아|시민|의심|수상|거짓말))/.test(t))return 'opinion';
  return 'general';
}
function directAddressee(text,view) {
  const t=normalize(text).replace(/^(?:(?:그럼|그러면|근데|그런데|혹시|저기|잠깐|일단|그래서|자|야)[,，:：\s]+){1,2}/, '');
  const m=t.match(/^(\d+)\s*번(?:님)?(?=\s|[,，:：!?]|(?:아|야|너|넌|네가|니가))/);
  if(!m)return null;
  const after=t.slice(m[0].length);
  // “4번은 마피아 같다” is ABOUT 4, not addressed TO 4.
  if(/^(?:은|는|이|가|을|를|의|이랑|하고|한테|에게|부터|도)/.test(after))return null;
  if(/^\s*(?:[,，:：!?]|아|야|너|넌|네가|니가|네\s*(?:직업|역할|말|가|생각)|니\s*(?:직업|역할|생각)|본인\s*(?:직업|생각)|직업|역할|정체|신분|공개|밝혀|말해|답해|왜|넌\s*누구|마피아|경찰|시민|의사|스파이|건달|\d+번)/.test(after))
    return view.everyone.find(q=>q.number===Number(m[1]))?.id || null;
  return null;
}
function previousDialogue(view,entry,p) {
  const i=view.publicChat.findIndex(x=>x.id===entry.id);
  if(i<=0)return null;
  const prior=view.publicChat.slice(Math.max(0,i-12),i).reverse().filter(x=>x.at>=view.phaseStart);
  const latestFromBot=prior.find(x=>x.senderId===p.id);
  const latestOverall=prior[0];
  return {latestFromBot,latestOverall,prior};
}
function contextualSubject(entry,p,view,mind) {
  const from=entry.senderId||entry.speakerId;
  const addressed=directAddressee(entry.text,view);
  const switched=topicSwitchTarget(entry.text,view);
  if(switched)return switched;
  const explicit=orderedMentions(entry.text,view.everyone).filter(id=>id!==addressed && id!==p.id);
  if(explicit.length)return explicit[0];
  // '5번 왜 거짓말했어?' addresses 5 directly. The subject is 5, not missing.
  if(addressed===p.id && /(?:왜|네\s*직업|니\s*직업|너\s*마피아|너\s*거짓말|네가\s*한|본인)/.test(entry.text))return p.id;
  if(/(?:왜\s*(?:나|날|내)|나를\s*(?:왜|의심)|내가\s*수상|날\s*의심)/.test(entry.text))return from;
  const ctx=previousDialogue(view,entry,p);
  if(/(?:그\s*사람|걔|그\s*애|그\s*말|그거|아까|방금|그게|맞아|아니|동의|네\s*말)/.test(entry.text)){
    const priorFromSpeaker=ctx?.prior?.find(x=>x.senderId===from && mentions(x.text,view.everyone).some(id=>id!==p.id));
    if(priorFromSpeaker){const refs=mentions(priorFromSpeaker.text,view.everyone).filter(id=>id!==p.id);if(refs.length)return refs[0];}
    const priorBot=ctx?.latestFromBot || ctx?.latestOverall;
    if(priorBot){const refs=mentions(priorBot.text,view.everyone).filter(id=>id!==p.id);if(refs.length)return refs[0];}
  }
  if(mind.lastOpinion?.targetId && /(?:그\s*사람|걔|그\s*말|그거)/.test(entry.text))return mind.lastOpinion.targetId;
  if(/(?:너|넌|네가|니가|너는|네\s*직업)/.test(entry.text))return p.id;
  return null;
}
function statementKind(text) {
  const t=normalize(text);
  // Explicit agreement with a named speaker must quote that person's actual
  // public statement; a generic 'I agree' response would lose the evidence.
  if(/(?:\d+\s*번).{0,15}(?:말에|의견에|주장에|말은|말이).{0,14}(?:동의|맞는\s*것|맞아|옳아|틀려|동의\s*안|동의하지)/.test(t))
    return /(?:동의\s*안|동의하지|틀려)/.test(t)?'disagree':'agree-ref';
  const semantic=Utterance.classify(t);
  const semanticKinds={ROLE_SILENCE:'role-silence',EVIDENCE_LACK:'uncertainty',
    UNCERTAIN:'uncertainty',DEFER:'uncertainty',VOTE_SKIP:'skip',
    NIGHT_SKIP:'night-skip',VOTE_PROPOSE:'vote',ACCUSE:'accusation',
    DEFEND:'defense',AGREE:'agree',DISAGREE:'disagree',
    CORRECTION:'correction',DEESCALATE:'deescalate',GREETING:'greeting',THANKS:'thanks'};
  // Respect explicit grammar for negative SKIP, role denials and prior
  // claims rather than reinterpreting them as superficial topic keywords.
  if(semantic?.kind==='statement'&&semanticKinds[semantic.intent])
    return semanticKinds[semantic.intent];
  // A night cannot be skipped in NOIR / SEVEN; it is not a vote-_SKIP_.
  if(/(?:밤|야간).{0,18}(?:스킵|건너\s*뛰(?:기)?|넘기)/.test(t))return 'night-skip';
  if(/(?:그만\s*싸|싸우지\s*마|말싸움\s*그만|서로\s*싸|논쟁\s*그만|시끄러|그만\s*다퉈|근거\s*없이.{0,24}(?:마피아|의심|수상|몰아).{0,12}(?:하지\s*마|몰아가지\s*마)|근거\s*없(?:이|는).{0,22}(?:단정|몰아가|비난)|증거\s*없이.{0,22}(?:단정|의심)|근거 없는 의심 그만)/.test(t))return 'deescalate';
  if(/\d+\s*번[^.!?]{0,28}(?:말고|아니고|됐고)\s*\d+\s*번/.test(t))return 'topic-switch';
  if(/(?:\d+\s*번).{0,15}(?:말에|의견에|주장에|말은|말이).{0,14}(?:동의|맞는\s*것|맞아|옳아|틀려|동의\s*안|동의하지)/.test(t))return /(?:동의\s*안|동의하지|틀려)/.test(t)?'disagree':'agree-ref';
  if(roleSilenceRequest(t))return 'role-silence';
  if(deniedRole(t))return 'role-denial';
  if(/\d+\s*번[^.!?]{0,24}\d+\s*번.{0,16}(?:같은\s*팀|한\s*팀|같은\s*편)/.test(t))return 'team-theory';
  if(/(?:내\s*말(?:\s*좀)?\s*들|말\s*좀\s*들어|내\s*말\s*무시|내가\s*말\s*하잖|사람\s*말\s*좀)/.test(t))return 'listen';
  if(/^(?:아니|아니\s*그게|그게\s*아니|정정할게|다시\s*말하면|내\s*말은)/.test(t))return 'correction';
  if(/(?:안녕|하이|ㅎㅇ|반가워)/.test(t) && t.length<17)return 'greeting';
  if(/^(?:응|ㅇㅇ|그래|맞아|맞지|동의|인정|좋아|오케이|ㅇㅋ|그렇지)/.test(t))return 'agree';
  if(claimedRole(t))return 'claim';
  if(/(?:내가|나는|난|전|제가|저는).{0,18}(?:조사했|조사해봤|조사\s*결과)/.test(t))return 'investigation';
  if(/(?:나는|난|내가|저는|전).{0,22}(?:스킵|건너\s*뛰(?:기)?)/.test(t) || /(?:스킵|건너\s*뛰(?:기)?)(?:\s*(?:할게|하자|할래|하려고|하고\s*싶))/.test(t))return 'skip';
  if(/(?:투표할게|찍을게|표\s*줄게|퇴출시키자|투표하자)/.test(t))return 'vote';
  if(/(?:의심\s*(?:안|하지\s*않|하지\s*말)|수상하지\s*않|마피아\s*(?:아니|같지\s*않)|마피아가\s*아니|믿어|결백|무죄)/.test(t))return 'defense';
  if(/(?:의심|수상|마피아\s*(?:같|인\s*것|야|다)|거짓말|구라|말\s*바꿨|수상해)/.test(t))return 'accusation';
  // These are statements of uncertainty, not proof requests. They are very
  // common in short day discussions and should receive direct acknowledgements.
  if(/(?:보류|판단\s*(?:못|안|보류)|아직\s*모르겠|잘\s*모르겠|누군지\s*모르겠|누구인지\s*모르겠|확신\s*(?:없|안\s*서)|(?:확실|명확|뚜렷)(?:한)?\s*(?:증거|근거|단서).{0,10}(?:없|부족)|(?:증거|근거|단서).{0,12}(?:없|부족|안\s*보)|(?:결정|단정)(?:하긴|하기엔)\s*(?:어렵|이르))/.test(t))return 'uncertainty';
  if(/(?:나는|난|내가|저는|전).{0,12}(?:마피아가?\s*아니|스파이가?\s*아니)/.test(t))return 'denial';
  return 'other';
}
function isReactiveMessage(text) {return normalize(text).length>=2;}

function askedForBot(obs,p,view,chat,forced=false) {
  if(!obs || (obs.senderId||obs.speakerId)===p.id || !intentOf(obs.text)) return false;
  if(forced)return true;
  const addressee=directAddressee(obs.text,view);
  if(addressee)return addressee===p.id;
  if(obs.mentions.includes(p.id) && /(?:너|네가|니가|넌|너는)/.test(obs.text))return true;
  // '너' after a bot's own statement is an implicit direct address.
  const idx=chat.findIndex(x=>x.id===obs.id);
  const prior=idx>0?chat[idx-1]:null;
  if(prior?.senderId===p.id && /(?:너|네가|니가|넌|너는|넌데)/.test(obs.text))return true;
  if(obs.mentions.length && !/다들|모두|여러분|누구든/.test(obs.text))return false;
  return /(?:다들|모두|여러분|누구|의견|어떻게|왜)/.test(obs.text);
}

function discussionLedger(room,phaseStart) {
  if(!room.aiDiscussionLedger || room.aiDiscussionLedger.phaseStart!==phaseStart)
    room.aiDiscussionLedger={phaseStart,answered:new Set(),topics:new Set(),genericCount:0};
  return room.aiDiscussionLedger;
}
function reserveTopic(room,phaseStart,key,generic=false) {
  const ledger=discussionLedger(room,phaseStart);
  if(ledger.topics.has(key) || (generic && ledger.genericCount>=6))return false;
  ledger.topics.add(key);
  if(generic)ledger.genericCount++;
  return true;
}

function pickQuestion(room,p,view,mind,replyToId) {
  const chat=view.publicChat;
  const answered=discussionLedger(room,view.phaseStart).answered;
  if(replyToId) {
    const chosen=chat.find(x=>x.id===replyToId);
    if(chosen && chosen.senderId!==p.id && (!answered.has(chosen.id) || roleDisclosureRequest(chosen.text)?.group) && !mind.answerIds.includes(chosen.id) &&
      (!chosen.bot || askedForBot({...chosen,mentions:mentions(chosen.text,view.everyone)},p,view,chat,true)))
      return {...chosen,mentions:mentions(chosen.text,view.everyone)};
  }
  const recent=chat.slice(-14).filter(x=>x.at>=view.phaseStart && x.senderId!==p.id &&
     !mind.answerIds.includes(x.id) && (!answered.has(x.id) || roleDisclosureRequest(x.text)?.group))
    .map(x=>({...x,mentions:mentions(x.text,view.everyone)}));
  return recent.filter(x=>askedForBot(x,p,view,chat)).sort((a,b)=>{
    const da=Number(directAddressee(a.text,view)===p.id);
    const db=Number(directAddressee(b.text,view)===p.id);
    return (db-da)*100 + (chat.findIndex(x=>x.id===b.id)-chat.findIndex(x=>x.id===a.id));
  })[0]||null;
}
function finishInteraction(room,p,view,mind,entry,response) {
  discussionLedger(room,view.phaseStart).answered.add(entry.id);
  mind.answerIds.push(entry.id);
  if(mind.answerIds.length>100)mind.answerIds=mind.answerIds.slice(-100);
  return normalize(`${formatRef(view,entry.senderId||entry.speakerId)}, ${response}`).slice(0,218);
}
function findRecentWords(view,senderId,entryId) {
  const idx=view.publicChat.findIndex(x=>x.id===entryId);
  return view.publicChat.slice(0,idx<0?undefined:idx).reverse().find(x=>x.senderId===senderId && x.at>=view.phaseStart)?.text||'';
}
function factFor(p,view,mind,id,channel='PUBLIC') {
  if(!id)return null;
  const ref=formatRef(view,id);
  const own=findOwnResult(view,id);
  if(view.role==='POLICE' && own) return {strong:own.displayed==='마피아팀',targetId:id,
    text:`${own.night}번째 밤에 ${ref}을 조사했어. 결과는 ${own.displayed}이었어.${own.displayed==='시민팀'?' 다만 스파이도 시민팀으로 표시돼.':''}`,
    kind:'police-result'};
  if(channel==='SECRET' && view.role==='SPY' && own?.actualRole) return {strong:true,targetId:id,
    text:`접선 전에 ${ref}을 조사했고 실제 직업은 ${own.displayed}이었어.`,kind:'spy-result'};
  const shift=mind.claimChanges.findLast(x=>x.speakerId===id);
  if(shift) return {strong:true,targetId:id,
    text:shift.to==='그 직업 부인'?
      `${ref}은 처음엔 ${roleAsQuote(shift.from)} 했다가 나중엔 그 직업이 아니라고 말했어. 공개 발언이 바뀐 건 확인되지만 이유는 알 수 없어.`:
      `${ref}은 처음엔 ${roleAsQuote(shift.from)} 했다가 나중엔 ${roleAsQuote(shift.to)} 했어. 직업 주장이 바뀐 건 채팅에서 직접 확인했어.`,kind:'role-change'};
  if(view.role==='POLICE' && id!==p.id && mind.claims[id]?.role==='경찰') return {strong:true,targetId:id,
    text:`${ref}이 경찰이라고 주장했는데 나도 경찰이야. 경찰은 한 명뿐이니 둘 다 진짜일 수는 없어.`,kind:'counterclaim'};
  const changed=mind.stanceChanges.findLast(x=>x.speakerId===id);
  if(changed) {
    const phrase=value=>value==='SKIP'?'투표 건너뛰기':`${formatRef(view,value)} 투표`;
    return {strong:false,targetId:id,text:`${ref}은 아까 ${phrase(changed.from)}를 이야기했다가 ${phrase(changed.to)}로 입장을 바꿨어. 다만 입장이 바뀐 것만으로 마피아라고 단정할 수는 없어.`,kind:'changed-vote-intent'};
  }
  const claim=mind.claims[id];
  if(claim)return {strong:false,targetId:id,
    text:`${ref}은 자신이 ${roleAsQuote(claim.role)} 주장했어. 하지만 직업을 말했다고 실제로 증명된 건 아니야.`,kind:'unverified-claim'};
  // An accusation is evidence that the ACCUSATION was spoken, not proof of the target's team.
  const discussed=mind.accusations.findLast(x=>x.target===id && x.by!==p.id);
  if(discussed)return {strong:false,targetId:id,
    text:`${formatRef(view,discussed.by)}이 ${ref}을 의심한다고 말했어. 그 말만으로 ${ref}이 마피아라는 증거는 아니야.`,kind:'second-hand'};
  return null;
}
function evidenceAnswer(p,view,mind,id,{direct=false}={}) {
  const ref=formatRef(view,id);
  const evidence=factFor(p,view,mind,id);
  if(!evidence)return direct ?
    `${ref}을 의심할 만한 확인된 근거는 아직 없어. 내가 먼저 의심했다면 성급했어. 지금은 단정하지 않겠어.` :
    `${ref}에 대해 확인된 단서가 없어서 마피아라고 말할 수 없어.`;
  if(evidence.strong)return `${direct?'내가 그렇게 판단한 근거는 이거야. ':''}${evidence.text}`;
  return `${evidence.text} 그래서 지금은 의심만으로 몰아가면 안 된다고 봐.`;
}
function summarizeVisibleFact(p,view,mind,id) {
  if(!id)return '그 사람이 누구인지 특정할 수 없어.';
  const f=factFor(p,view,mind,id);
  if(f?.strong)return f.text;
  if(f && f.kind!=='second-hand')return f.text;
  return `${formatRef(view,id)}의 실제 직업은 알 수 없어. 정체를 입증할 공개 증거는 아직 없어.`;
}
/* v2.8.9: replies are composed from independently inferred discourse features
 * plus real game evidence; there is no per-quote/screenshot answer table.
 * The parser's epistemic stance does not create evidence or reveal secrets.
 */
function groundedForFrame(p,view,mind,targetId) {
  if(targetId) {
    const ref=formatRef(view,targetId),f=factFor(p,view,mind,targetId);
    if(f?.strong)return `다만 ${f.text}`;
    if(f && f.kind!=='second-hand')return `${f.text}`;
    return `${ref}에 대해 확인된 결정적 근거는 아직 없어. 그래서 단정하지 않겠어.`;
  }
  // Only reveal facts the *speaking* AI actually witnessed or investigated.
  const known=view.alivePlayers.filter(x=>x.id!==p.id && x.id!==view.partnerId)
    .map(x=>factFor(p,view,mind,x.id)).filter(f=>f?.strong);
  if(known.length)return `그렇지만 확인할 수 있는 단서는 있어. ${known[0].text}`;
  const latest=view.publicLog.findLast(x=>/지난밤.*(?:사망|죽)|사망자는 없습니다/.test(x.text));
  if(latest)return `공개된 밤 결과는 “${normalize(latest.text).slice(0,55)}”이지만 범인의 신원은 확정되지 않았어.`;
  return '현재 공개 기록만으로 특정인의 정체를 확정할 수는 없어.';
}
function framePhrase(p,mind,variants,rng) {
  // Distribute contextual wording across personalities and turns. This is
  // presentation variation, never a random inference or fabricated fact.
  const i=(p.number + mind.turns + Math.floor(rng()*variants.length))%variants.length;
  return variants[i];
}
function replyFromDiscourseFrame(room,p,view,mind,entry,rng) {
  const frame=DiscourseFrame.parse(entry.text,{phase:room.phase});
  if(frame.reported) {
    if(!/(?:스킵|기권|패스|근거|증거|단서|확신|보류|유보)/.test(entry.text))return null;
    const source=orderedMentions(entry.text,view.everyone)[0];
    const ref=source?formatRef(view,source):'다른 참가자';
    const observed=source?view.publicChat.findLast(x=>x.senderId===source && x.id!==entry.id &&
      /(?:스킵|기권|패스|근거|증거|단서|확신|보류|유보)/.test(x.text)):null;
    return observed?`${ref}이 실제로 “${normalize(observed.text).slice(0,67)}”라고 말한 기록은 있어. 그 주장 자체가 증거는 아니야.`:
      `${ref}이 그렇게 말했다는 네 전언이구나. 공개된 채팅에 같은 발언이 있는지는 아직 확인되지 않았어.`;
  }
  if(!frame.act)return null;
  const id=contextualSubject(entry,p,view,mind);
  const ref=id?formatRef(view,id):null;
  const detail=groundedForFrame(p,view,mind,id);
  const t=normalize(entry.text);
  if(/(?:마피아라고|몰아가|의심|비난|단정).{0,18}(?:하지\s*마|하지\s*말|그만)|(?:근거|증거)\s*없이.{0,20}(?:마피아|몰아가|의심|비난)/.test(t) && !frame.question)
    return '그래. 확인된 근거 없이 누군가를 마피아라고 몰아가지 않겠어. 실제 발언과 조사 결과를 구분하자.';
  const first=framePhrase.bind(null,p,mind);
  const previous=previousDialogue(view,entry,p)?.latestFromBot;
  let opening='';
  if(frame.act==='DENY_ABSENCE') {
    const refPart=ref?`${ref}에 대해서 `:'';
    return `${refPart}증거나 확신이 전혀 없다고 말한 건 아니라는 뜻이구나. 그렇다고 아직 검증되지 않은 사실을 증명된 것으로 취급하진 않을게. ${detail}`;
  }
  if(frame.act==='REJECT_SKIP') {
    return `투표를 스킵하지 않겠다는 입장이구나. 누구에게 표를 줄지는 별도의 선택이고, 아직 실제 투표가 제출된 것은 아니야.`;
  }
  if(frame.act==='NIGHT_SKIP') {
    // The NIGHT stage is mandatory; only a daytime vote has a SKIP ballot.
    return '밤 단계 자체를 건너뛰는 건 규칙상 불가능해. 투표에서 사람을 고르지 않는 선택과는 구분해야 해.';
  }
  if(frame.act==='ASK_EVIDENCE') {
    opening=ref?`${ref}을 의심할 만한 확인된 근거를 묻는 거지.`:
      first(['어떤 근거가 있는지 묻는 거네.','소문이 아니라 실제 증거를 요구하는 말이지.','지금 가진 근거와 증거가 무엇인지 확인하자는 거지.'],rng);
    return `${opening} ${detail}`;
  }
  if(frame.act==='EVIDENCE_CLAIM') {
    opening=ref?`${ref}에 관한 근거가 있다고 말하는 거구나.`:
      '확인할 만한 정보가 있다고 말하는 거지.';
    return `${opening} ${detail} 주장과 검증된 사실은 나눠서 보자.`;
  }
  if(frame.act==='VOTE_SKIP') {
    const abstention=frame.question?
      first(['투표를 건너뛸지 고민하는 거구나.','지금 표를 행사하지 않아도 될지 묻는 거지.'],rng):
      first(['이번 투표를 건너뛰자는 의견이네.','지금은 아무도 퇴출시키지 말자는 제안으로 이해했어.','표를 던지지 않고 넘어가자는 쪽이구나.'],rng);
    if(id && /(?:\d+\s*번|그\s*사람)/.test(t) && !/(?:아무도|누구도)/.test(t)) {
      return `${abstention} ${ref}을 언급했지만 그 사람에게 투표한다는 뜻으로 해석하지 않을게. ${detail}`;
    }
    const known=view.alivePlayers.filter(x=>x.id!==p.id).map(x=>factFor(p,view,mind,x.id)).find(f=>f?.strong);
    if(known)return `${abstention} 다만 ${known.text} 이 단서도 판단에 포함해야 해.`;
    return `${abstention} 확인된 강한 근거가 없다면 고려할 수 있지만, 실제 투표 화면에서 '건너뛰기'를 선택해야 적용돼.`;
  }
  if(frame.act==='DEFER') {
    opening=first(['판단을 조금 더 미루자는 뜻이구나.','아직 결론부터 내리지 말자는 의견이지.','새 정보가 나올 때까지 상황을 보자는 쪽이네.'],rng);
    if(/(?:나도|저도|나\s*역시|그\s*말)/.test(t) && previous && /(?:스킵|보류|판단|기다리)/.test(previous.text))
      opening='방금 나온 판단 보류 의견에 동의한다는 거구나.';
    return `${opening} ${detail}`;
  }
  if(frame.act==='LOW_EVIDENCE') {
    opening=ref?`${ref}에 관해서는 아직 근거가 충분하지 않다고 보는 거지.`:
      first(['지금 증거만으로 누군가를 단정하기 어렵다는 뜻이네.','마피아를 지목할 객관적인 근거가 부족하다는 이야기지.','근거 없는 추측만으로 결론을 내리지 말자는 의견이구나.'],rng);
    return `${opening} ${detail}`;
  }
  if(frame.act==='UNCERTAIN') {
    opening=ref?`${ref}에 대해 아직 확신이 서지 않는 거지.`:
      first(['아직 누구를 의심할지 판단하기 어렵다는 뜻이지.','지금 판단이 애매하다는 건 이해했어.','확신 없이 몰아가고 싶지 않다는 말이네.'],rng);
    return `${opening} ${detail}`;
  }
  return null;
}

function replyToStatement(room,p,view,mind,entry,rng) {
  const common=replyFromDiscourseFrame(room,p,view,mind,entry,rng);
  if(common)return finishInteraction(room,p,view,mind,entry,common);
  const t=normalize(entry.text), kind=statementKind(t), from=entry.senderId||entry.speakerId;
  const addressed=directAddressee(t,view), subject=contextualSubject(entry,p,view,mind);
  const named=mentions(t,view.everyone).filter(x=>x!==addressed && x!==p.id);
  const ref=subject?formatRef(view,subject):null;
  const prev=findRecentWords(view,from,entry.id);
  let response='';
  if(kind==='role-silence') {
    response='알겠어. 지금은 내 직업을 공개하지 않을게. 하지만 다른 사람이 이미 한 직업 주장은 공개 발언으로 기억할게.';
  } else if(kind==='topic-switch') {
    response=subject?`알겠어. ${formatRef(view,subject)}에 관한 이야기로 바꾸자. ${summarizeVisibleFact(p,view,mind,subject)}`:
      '알겠어. 앞서 말한 대상 대신 새로 언급한 사람의 발언을 확인하자.';
  } else if(kind==='agree-ref' || kind==='disagree') {
    const source=orderedMentions(t,view.everyone)[0];
    const stated=view.publicChat.slice(0,view.publicChat.findIndex(x=>x.id===entry.id))
      .findLast(x=>x.senderId===source);
    if(source && stated){
      const quote=normalize(stated.text).slice(0,65);
      response=kind==='agree-ref'?`${formatRef(view,source)}이 “${quote}”라고 말했지. 네가 그 의견에 동의한다는 뜻으로 이해했어. 사실 여부는 별도로 확인하자.`:
        `${formatRef(view,source)}이 “${quote}”라고 말했지. 네가 그 의견에 동의하지 않는다는 뜻이구나. 반박 이유가 공개 기록에 있는지 보자.`;
    } else if(!source) response=kind==='agree-ref'?'앞에서 나온 의견에 동의하는 거지. 어떤 주장을 말하는지 기록과 비교해 볼게.':
      '그 판단에 반대한다는 뜻이지. 어떤 근거에 동의하지 않는지 말해주면 공개 기록과 대조해 볼게.';
    else response=kind==='agree-ref'?`${formatRef(view,source)}의 의견에 동의한다는 뜻이구나. 그 사람이 실제로 무엇을 말했는지는 지금 공개 기록에서 확인되지 않아.`:
      `${formatRef(view,source)}의 의견에 동의하지 않는다는 뜻이구나. 실제 발언 기록을 보고 판단하자.`;
  } else if(kind==='role-denial') {
    response=`네가 ${deniedRole(t)}은 아니라고 분명히 말한 건 들었어. 그 말을 반대로 해석하거나 그 직업이라고 몰아가진 않을게. 하지만 실제 직업은 아직 확인되지 않았어.`;
  } else if(kind==='team-theory') {
    const refs=orderedMentions(t,view.everyone);
    response=`${formatRef(view,refs[0])}과 ${formatRef(view,refs[1])}이 같은 팀이라는 추측이구나. 팀 관계는 공개된 발언만으로 확인할 수 없어. 실제로 일치하는 행동이나 조사 결과가 있는지 살펴봐야 해.`;
  } else if(kind==='deescalate') {
    response='알겠어. 근거 없는 의심과 마피아 단정을 반복하지 않을게. 확인된 사실과 추측을 구분해서 이야기하자.';
  } else if(kind==='listen') {
    const id=subject||(prev?mentions(prev,view.everyone).filter(x=>x!==p.id)[0]:null);
    if(id)response=`네 말 듣고 있어. 아까 ${formatRef(view,id)}에 대해 이야기한 것도 기억해. ${summarizeVisibleFact(p,view,mind,id)}`;
    else response='네 말 듣고 있어. 내 추측부터 꺼내지 말고 네가 제시한 내용에 맞춰 답할게.';
  } else if(kind==='greeting') {
    response='안녕. 지금 나온 공개 정보만 근거로 이야기할게.';
  } else if(kind==='correction') {
    const denial=/(?:안\s*의심|의심\s*안|의심하지\s*않|마피아\s*아니|마피아\s*같지\s*않)/.test(t);
    if(subject && denial)response=`내가 잘못 알아들었어. ${ref}을 의심하지 않는다는 뜻이지. ${summarizeVisibleFact(p,view,mind,subject)}`;
    else if(subject)response=`알겠어, ${ref}에 대한 말을 정정한 거구나. ${summarizeVisibleFact(p,view,mind,subject)}`;
    else response='내가 네 말을 다르게 이해했어. 앞의 추측을 일단 빼고 방금 정정한 내용으로 보겠어.';
  } else if(kind==='agree') {
    const recent=previousDialogue(view,entry,p)?.latestFromBot || previousDialogue(view,entry,p)?.latestOverall;
    if(recent && /스킵|건너뛰/.test(recent.text))response='응, 근거가 모자라면 스킵하는 쪽에 동의한다는 거지. 그건 무리하게 사람을 몰아가는 것보다 신중한 선택이야.';
    else if(recent && /(?:의심|수상|마피아|거짓말)/.test(recent.text))response=`내가 방금 한 말에 동의한다는 거지. 그래도 실제 증거와 추측은 따로 보자.`;
    else response='응, 네 의견은 들었어. 확인되지 않은 사실은 그대로 단정하지 않겠어.';
  } else if(kind==='claim') {
    const role=claimedRole(t);
    if(role==='경찰' && view.role==='POLICE')response='네가 경찰이라고 주장했지. 하지만 나도 경찰이야. 경찰은 한 명뿐이니 서로 주장이 충돌해. 조사 결과로 비교해 보자.';
    else response=`네가 ${roleAsQuote(role)} 주장한 건 들었어. 아직 검증된 정보는 아니니까, 뒤에 나오는 발언이나 조사 결과와 함께 판단할게.`;
    if(subject && subject!==from && subject!==p.id && /(?:조사|마피아팀|시민팀)/.test(t))
      response+=` ${ref}에 관한 말도 네 주장으로 기억해 둘게.`;
  } else if(kind==='investigation') {
    const claimedTeam=/(?:마피아팀|시민팀)/.exec(t)?.[0];
    response=subject ? `네가 ${ref}을 조사했다고 말한 거지${claimedTeam?' 결과가 '+claimedTeam+'이라는 주장도 들었어':''}. 그건 네가 발표한 정보이고, 내가 직접 검증한 결과라고 단정할 수는 없어.` :
      '네가 조사했다고 한 건 알겠어. 누구를 조사한 건지 번호가 있어야 그 발언을 다른 정보와 비교할 수 있어.';
  } else if(kind==='night-skip') {
    response='밤 단계 자체를 건너뛰는 기능은 없어. 이번 투표를 스킵하자는 뜻이면 투표 화면에서 건너뛰기를 선택하면 돼.';
  } else if(kind==='skip') {
    response='이번 투표를 스킵하자는 거지. 나도 확인된 단서가 부족하면 무리하게 누군가를 퇴출시키진 않겠어.';
  } else if(kind==='uncertainty') {
    const prior=previousDialogue(view,entry,p)?.latestFromBot;
    if(/보류|판단/.test(t)) {
      response=prior && /(?:스킵|건너뛰)/.test(prior.text) ?
        '판단을 보류하겠다는 거지. 나도 증거가 없다면 투표를 스킵하는 쪽을 고려할게.':
        '응, 아직 결론을 내리기 어렵다는 거지. 나도 새 단서가 나오기 전에는 누군가를 단정하지 않을게.';
    } else if(/(?:증거|근거|단서|확실)/.test(t)) {
      response='맞아. 확실한 근거가 없으면 누군가를 마피아라고 단정할 수 없어. 다음 발언과 조사 결과를 더 살펴보자.';
    } else {
      response='아직 판단하기 어렵다는 뜻으로 이해했어. 지금 나온 사실만으로 결론을 서두르지 말자.';
    }
  } else if(kind==='vote') {
    response=subject?`${ref}에게 투표하겠다는 뜻이구나. ${summarizeVisibleFact(p,view,mind,subject)} 그걸 감안해 각자 판단하자.`:
      '투표하자는 뜻은 알겠어. 다만 누구에게 표를 줄 건지와 그 근거는 구분해서 이야기하자.';
  } else if(kind==='defense' || kind==='denial') {
    if(subject && subject!==p.id)response=`${ref}을 섣불리 의심하지 말자는 거지. ${summarizeVisibleFact(p,view,mind,subject)} 근거가 없으면 퇴출을 밀어붙이지 않겠어.`;
    else response='네가 마피아가 아니라고 밝힌 건 들었어. 그 자체가 증명은 아니지만, 근거 없이 너를 몰아가지는 않겠어.';
  } else if(kind==='accusation') {
    if(subject && named.length>1 && /(?:랑|과|와|둘|서로|다르|비교)/.test(t))response=`${formatRef(view,named[0])}과 ${formatRef(view,named[1])}의 말을 비교하자는 거구나. 둘의 발언이 실제로 어긋나는지 채팅 내용을 보고 판단해야 해.`;
    else if(subject)response=`${ref}이 수상하다는 의견은 들었어. ${summarizeVisibleFact(p,view,mind,subject)} 이 내용만으로 단정하지는 않을게.`;
    else response='누군가 수상하다는 말은 들었어. 다만 대상이 특정되지 않아서 누구의 발언을 검토해야 할지 모르겠어.';
  } else if(named.length>=2 && /(?:랑|과|와|서로|비교|다르)/.test(t)) {
    response=`${formatRef(view,named[0])}과 ${formatRef(view,named[1])}을 비교하자는 이야기지. 실제로 어떤 주장에 차이가 있는지 확인해 보자.`;
  } else if(subject && subject!==p.id) {
    response=`${ref}에 대해 이야기하는 거지. ${summarizeVisibleFact(p,view,mind,subject)}`;
  } else if(/(?:고마워|ㄱㅅ|감사)/.test(t)) {
    response='응. 새 정보가 나오면 같이 따져 보자.';
  } else if(/(?:이해가\s*안|뭔\s*소리|말이\s*안\s*돼)/.test(t)) {
    response='내 설명이 엉뚱했구나. 내가 말한 사실과 추측을 구분해서 다시 말할게. 지금 확인된 단서는 많지 않아.';
  } else {
    // A terse, honest acknowledgement is better than a long generic speech
    // that every AI repeats when the player's sentence has no known intent.
    response='의견은 들었어. 지금은 확인된 사실을 중심으로 판단할게.';
  }
  return finishInteraction(room,p,view,mind,entry,response);
}
function topicOf(question,p,view,mind) {
  return contextualSubject(question,p,view,mind);
}
function rulesAnswer(q) {
  if(/경찰/.test(q)&&/(?:능력|역할|하는|뭐|설명)/.test(q))
    return '경찰은 밤마다 한 명을 조사해 시민팀인지 마피아팀인지 확인해. 다만 스파이는 조사 결과에 시민팀으로 표시돼.';
  if(/의사/.test(q))return '의사는 밤에 한 명을 치료할 수 있고 자기 자신도 치료할 수 있어. 치료 대상 선택은 밤 단계에서만 가능해.';
  if(/건달/.test(q))return '건달은 밤에 한 명을 지목해 그 사람의 다음 날 투표권을 제한하는 능력이 있어.';
  if(/스파이/.test(q)&&/(?:접선|능력|역할|하는)/.test(q))return '스파이는 마피아팀이야. 접선이 성공한 뒤 정해진 다음 날 밤부터 비밀 채팅을 사용할 수 있어.';
  if(/마피아/.test(q)&&/(?:능력|역할|승리|조건|하는)/.test(q))return '마피아는 밤에 공격 대상을 선택해. 시민팀 전원이 제거되면 마피아팀이 승리하고, 마피아가 제거되면 시민팀이 이겨.';
  if(/(?:스킵|기권|투표|표결)/.test(q))return '낮 투표에서는 사람을 지목하거나 스킵할 수 있어. 투표하지 않는 것과 스킵 표를 내는 것은 달라. 동률이면 45초 추가 토론 뒤 한 번 재투표해.';
  if(/(?:밤|야간)/.test(q)&&/(?:건너|스킵|패스|생략)/.test(q))return '밤 단계는 생략할 수 없어. 각자의 직업별 능력은 정해진 제한 시간과 대상 규칙을 따라야 해.';
  if(/접선/.test(q))return '마피아와 스파이는 접선에 성공해야 서로를 확인하고, 그다음 날 밤부터 비밀 채팅을 사용할 수 있어.';
  if(/(?:재투표|동률)/.test(q))return '1차 투표에서 동률이면 45초 추가 토론과 30초 재투표를 진행해. 세 번째 투표는 없어.';
  if(/(?:토론|시간|초)/.test(q))return '기본 낮 토론은 60초, 1차 투표는 30초야. 동률이면 45초 추가 토론 후 30초 재투표해. 밤 행동 제한 시간은 60초야.';
  return '공개 규칙을 설명할게. 참가자 7명은 마피아 1, 스파이 1, 경찰 1, 의사 1, 건달 1, 시민 2명이야. 구체적인 직업이나 투표 규칙을 말해줘.';
}
function corpusSpecialAnswer(room,p,view,mind,entry,channel='PUBLIC') {
  const parsed=Utterance.classify(entry.text,{phase:room.phase,channel});
  if(!parsed)return null;
  const t=normalize(entry.text);
  const from=entry.senderId||entry.speakerId;
  if(parsed.intent==='LIVING_COUNT'){
    const alive=view.everyone.filter(x=>x.alive);
    return `현재 생존자는 ${alive.length}명이야. ${alive.map(x=>`${x.number}번`).join(', ')}이 살아 있어. 실제 직업은 공개된 정보만으로 알 수 없어.`;
  }
  if(parsed.intent==='PHASE_QUERY'){
    const names={LOBBY:'대기실',BOXES:'직업 선택 준비',NIGHT:'밤 행동',NIGHT_RESULT:'밤 결과',DAY:'낮 토론',VOTE1:'1차 투표',EXTRA_DISCUSSION:'추가 토론',VOTE2:'재투표',VOTE_RESULT:'투표 결과',GAME_OVER:'게임 종료',ABORTED:'게임 중단'};
    return `지금은 ${view.night}번째 밤 기준 ${names[room.phase]||room.phase} 단계야. 밤·낮·투표는 정해진 순서에 따라 진행돼.`;
  }
  if(parsed.intent==='RULE_QUERY')return rulesAnswer(t);
  if(parsed.intent==='CHAT_HISTORY'){
    const messages=(channel==='SECRET'?view.secretChat:view.publicChat).filter(x=>x.id!==entry.id);
    const explicit=orderedMentions(t,view.everyone);
    const aboutMe=/(?:내가|나는|난|제가|저는|내\s*말)/.test(t);
    const id=aboutMe?from:explicit[0]||null;
    const found=messages.slice().reverse().find(x=>!id||x.senderId===id);
    if(!found)return id?`${formatRef(view,id)}의 앞선 발언을 이 채팅에서 찾을 수 없어.`:'앞선 발언이 이 채팅에 보이지 않아.';
    const label=formatRef(view,found.senderId);
    return `${label}이 앞에서 “${normalize(found.text).slice(0,95)}”라고 말한 기록이 있어. 다만 그 말이 사실이라는 증거는 별개야.`;
  }
  if(parsed.intent==='CONTRADICTION'){
    const id=contextualSubject(entry,p,view,mind);
    const name=id?formatRef(view,id):'특정 참가자';
    const changes=[...mind.claimChanges,...mind.stanceChanges].filter(x=>!id||x.speakerId===id);
    const last=changes.at(-1);
    if(last&&last.to==='그 직업 부인')return `${name}은 앞에서 ${roleAsQuote(last.from)} 했다가 뒤에는 그 직업이 아니라고 말했어. 공개 기록상 발언이 달라진 건 맞아.`;
    if(last&&mind.claimChanges.includes(last))return `${name}이 ${roleAsQuote(last.from)} 했다가 ${roleAsQuote(last.to)} 했어. 공개된 직업 주장이 바뀐 건 확인돼.`;
    if(last)return `${name}이 공개적으로 밝힌 투표 입장을 바꾼 기록이 있어. 그렇다고 마피아로 확정되는 것은 아니야.`;
    return `${name}의 발언이 모순된다는 주장은 들었어. 하지만 현재 확인된 직업·투표 입장 변경 기록은 없어. 어떤 두 발언인지 알려줘.`;
  }
  return null;
}
function answerQuestion(room,p,view,mind,question,rng) {
  const common=replyFromDiscourseFrame(room,p,view,mind,question,rng);
  if(common)return finishInteraction(room,p,view,mind,question,common);
  const intent=intentOf(question.text);
  const fromId=question.senderId||question.speakerId;
  const id=topicOf(question,p,view,mind);
  const ref=id?formatRef(view,id):null;
  const q=normalize(question.text);
  const prior=previousDialogue(view,question,p);
  const special=corpusSpecialAnswer(room,p,view,mind,question);
  if(special)return finishInteraction(room,p,view,mind,question,special);
  if(intent==='repeat_request') {
    const original=prior?.prior?.find(x=>x.senderId===fromId &&
      x.id!==question.id && intentOf(x.text) && intentOf(x.text)!=='repeat_request');
    if(original){
      const reply=answerQuestion(room,p,view,mind,original,rng);
      const prefix=formatRef(view,fromId)+', ';
      return finishInteraction(room,p,view,mind,question,
        `아까 “${normalize(original.text).slice(0,45)}”라고 물었지. ${reply.startsWith(prefix)?reply.slice(prefix.length):reply}`);
    }
    return finishInteraction(room,p,view,mind,question,
      '대답을 다시 요청한 건 알겠어. 앞서 했던 질문이 현재 대화에서 보이지 않아. 무엇을 물었는지 한 번 더 말해줘.');
  }
  let response='';
  if(intent==='night-skip') {
    response='밤 단계는 건너뛸 수 없어. 지금 투표를 건너뛰자는 뜻이라면 투표 화면에서 스킵을 선택하면 돼.';
  } else if(intent==='who_police') {
    const declared=Object.entries(mind.claims).filter(([id,c])=>c.role==='경찰').map(([id])=>formatRef(view,id));
    if(view.role==='POLICE') response=declared.length?
      `나는 경찰이야. 공개적으로 경찰이라고 주장한 사람은 ${declared.join(', ')}이지만, 다른 사람의 주장까지 진짜라는 뜻은 아니야.`:
      '나는 경찰이야. 내 조사 결과와 다른 사람들의 발언을 비교해서 판단해 줘.';
    else response=declared.length?
      `경찰이라고 공개적으로 주장한 사람은 ${declared.join(', ')}이야. 다만 누가 진짜 경찰인지는 확인되지 않았어.`:
      '아직 공개적으로 경찰이라고 밝힌 사람은 확인하지 못했어. 비공개 직업은 임의로 추측해서 알려줄 수 없어.';
  } else if(intent==='compare') {
    const pair=orderedMentions(q,view.everyone).filter(x=>x!==p.id || !directAddressee(q,view)).slice(0,2);
    if(pair.length<2)response='비교할 두 사람의 번호를 알려줘. 기록에 없는 단서는 만들지 않을게.';
    else {
      const [a,b]=pair,fa=factFor(p,view,mind,a),fb=factFor(p,view,mind,b);
      const aa=formatRef(view,a),bb=formatRef(view,b);
      if(fa?.strong && !fb?.strong)response=`${aa}과 ${bb}을 비교하면 ${aa}에게 더 분명한 단서가 있어. ${fa.text} ${bb}에 관해선 확인된 강한 단서가 없어.`;
      else if(fb?.strong && !fa?.strong)response=`${aa}과 ${bb}을 비교하면 ${bb}에게 더 분명한 단서가 있어. ${fb.text} ${aa}에 관해선 확인된 강한 단서가 없어.`;
      else if(fa?.strong && fb?.strong)response=`${aa}과 ${bb} 모두 따져볼 단서가 있어. ${fa.text} ${fb.text}`;
      else response=`${aa}과 ${bb} 모두 확인된 결정적인 근거가 부족해. 지금은 둘 중 누가 더 수상하다고 단정할 수 없어.`;
    }
  } else if(intent==='vote_contradiction') {
    const source=orderedMentions(q,view.everyone)[0];
    const publicStance=source?mind.publicStances[source]:null;
    const line=source?view.publicChat.findLast(x=>x.senderId===source&&/(?:스킵|건너뛰)/.test(x.text)&&x.id!==question.id):null;
    if(source && (publicStance==='SKIP'||line))response=`${formatRef(view,source)}이 스킵하겠다고 말한 기록이 있어. 그건 ${formatRef(view,source)}에게 투표하라는 뜻이 아니야. 실제 투표는 별개이고, 누가 투표를 요구했는지는 기록을 봐야 해.`;
    else if(source)response=`${formatRef(view,source)}이 스킵한다고 했다는 네 말은 들었어. 다만 공개 기록에서 확인되지 않으니 사실로 단정하진 않을게. 스킵과 특정인 투표는 다른 선택이야.`;
    else response='스킵하겠다는 말과 누군가에게 투표하자는 말은 달라. 누가 어떤 입장을 밝혔는지 공개 발언을 확인해 보자.';
  } else if(intent==='clarify') {
    const last=prior?.latestFromBot||prior?.latestOverall;
    if(last) {
      const content=normalize(last.text).slice(0,95);
      if(/(?:주장|진짜|증명|확인되지|확정)/.test(content))
        response=`아까 내가 말한 건 “${content}”이야. 누군가 그렇게 말했다는 사실과 그 말이 진짜라는 건 다르다는 뜻이야.`;
      else response=`내가 방금 “${content}”라고 했지. 확인된 정보와 아직 추측인 부분을 구분해서 보자는 뜻이야.`;
    } else response='내가 바로 앞에서 한 말이 보이지 않아. 어떤 발언을 말하는지 번호나 내용을 짚어주면 정확히 설명할게.';
  } else if(intent==='deescalate') {
    response='서로 같은 의심을 반복하기보다 근거를 보자는 뜻이야. 나도 확인되지 않은 말을 사실처럼 되풀이하지 않을게.';
  } else if(intent==='death') {
    const line=view.publicLog.filter(x=>/지난밤 .*사망|지난밤 사망자는 없습니다/.test(x.text)).at(-1);
    response=line?`${line.text} 그게 지금 공개된 결과야. 누가 공격했는지는 공개되지 않았어.`:'아직 밤 사망 결과가 발표되지 않았어.';
  } else if(intent==='investigation') {
    if(view.role==='POLICE') {
      const specified=id && id!==p.id && id!==fromId?findOwnResult(view,id):null;
      if(specified)response=`${ref}은 ${specified.night}번째 밤에 조사했어. 결과는 ${specified.displayed}이야.${specified.displayed==='시민팀'?' 다만 스파이는 시민팀으로 나올 수 있어.':''}`;
      else if(id && id!==p.id && id!==fromId && /(?:조사했|조사\s*결과)/.test(q))response=`${ref}은 아직 조사한 기록이 없어. 결과를 지어내지 않을게.`;
      else response=view.investigations.length?`내가 직접 조사한 기록은 ${view.investigations.slice(-3).map(x=>`${formatRef(view,x.targetId)}: ${x.displayed}`).join(', ')}야. 시민팀 결과에 스파이가 포함될 수 있어.`:'나는 경찰이지만 아직 공개할 조사 결과가 없어.';
    } else if(view.role==='SPY' || view.role==='MAFIA') {
      response='내가 가진 비공개 정보를 여기서 확인해 주지는 않을게. 공개된 조사 주장은 따로 검증해야 해.';
    } else {
      response='난 경찰 조사 결과를 갖고 있지 않아. 다른 사람이 공개한 조사 주장은 들을 수 있지만 내가 조사했다고 말할 순 없어.';
    }
  } else if(intent==='vote') {
    if(id && id!==p.id && id!==fromId && /(?:\d+번|그\s*사람|걔)/.test(q)) {
      const evidence=factFor(p,view,mind,id);
      response=evidence?.strong?`${ref}을 투표 대상으로 생각할 만한 단서는 있어. ${evidence.text}`:`${ref}에게 투표하자는 말이지. 하지만 지금 ${ref}을 퇴출시킬 충분한 근거는 없어. 나는 스킵도 고려하고 있어.`;
    } else {
      const eligible=view.alivePlayers.filter(x=>x.id!==p.id && x.id!==view.partnerId);
      const top=strongestSuspect(p,view,mind,eligible.map(x=>x.id));
      const evidence=top?factFor(p,view,mind,top.id):null;
      response=top && evidence?.strong && suspicion(mind,view,top.id)>0.8?`지금은 ${formatRef(view,top.id)}에게 투표할 생각이야. ${evidence.text}`:
        '확인된 근거가 부족하니 이번엔 스킵을 고려 중이야. 새 증거가 나오면 판단을 바꿀게.';
    }
  } else if(intent==='role_silence') {
    response='알겠어. 지금은 직업을 공개하지 않을게. 이미 누군가 말한 직업 주장과 실제 직업은 구분할게.';
  } else if(intent==='role') {
    const aboutOther=id && id!==p.id && id!==fromId;
    if(aboutOther) {
      response=summarizeVisibleFact(p,view,mind,id);
    } else if(/(?:너|넌|네가|니가|당신).*?마피아/.test(q)) {
      response=view.team==='MAFIA'?'나는 마피아가 아니야. 하지만 내 말만 믿지 말고 공개된 행동으로 판단해.':'아니, 나는 마피아팀이 아니야. 내 주장도 다른 정보와 대조해서 판단해 줘.';
    } else if(view.role==='POLICE') {
      response=view.investigations.length?`나는 경찰이야. 내가 직접 조사한 결과는 ${view.investigations.map(x=>`${formatRef(view,x.targetId)} ${x.displayed}`).join(', ')}야.`:'나는 경찰이야. 조사 결과는 아직 없어.';
    } else if(view.team==='MAFIA') {
      response='내 직업은 지금 밝히지 않을게. 내가 무슨 직업이라고 말하든 그 주장만으로 확인되진 않으니까.';
    } else {
      // Keep a consistent disclosure decision across repeated questions in
      // this round: changing between an identity claim and secrecy randomly
      // on every prompt makes a bot appear to contradict its own memory.
      if(!mind.roleDisclosure) mind.roleDisclosure=rng()<0.60?'REVEAL':'WITHHOLD';
      response=mind.roleDisclosure==='REVEAL'?`내 직업은 ${roleAsStatement(({CITIZEN:'시민',GANGSTER:'건달',DOCTOR:'의사',POLICE:'경찰'})[view.role])}. 이 말만으로 확정하지는 마.`:'직업은 아직 공개하지 않을게. 대신 확인 가능한 발언을 기준으로 이야기하자.';
    }
  } else if(intent==='evidence') {
    if(!id)response='어느 사람에 대한 근거를 묻는지 정확하지 않아. 번호로 말해 주면 그 사람의 공개된 발언을 확인할게.';
    else if(id===p.id && directAddressee(q,view)===p.id && /(?:거짓말|구라|말\s*바꿨)/.test(q)) {
      const priorOwn=view.publicChat.filter(x=>x.senderId===p.id && x.id!==question.id).slice(-3);
      response=priorOwn.length?`${formatRef(view,p.id)}인 내가 한 말이 서로 모순된다는 뜻으로 들었어. 공개된 내 발언 기록을 기준으로 확인해야 해. 추측을 사실이라고 말하진 않을게.`:`${formatRef(view,p.id)}인 내가 거짓말했다는 근거는 지금 공개 기록에 없어. 확인할 만한 내 발언이 나오면 그걸 기준으로 판단하자.`;
    } else if(id===fromId && /(?:왜.*?(?:나|날|내)|나를.*?의심)/.test(q)) {
      const hadAccused=view.publicChat.some(x=>x.senderId===p.id && mentions(x.text,view.everyone).includes(fromId) &&
        /(?:의심|수상|마피아|거짓말)/.test(x.text));
      response=hadAccused?evidenceAnswer(p,view,mind,fromId,{direct:true}):'나는 너를 마피아라고 단정해서 지목한 적은 없어. 의심할 근거는 아직 없어. 네 발언을 확인하고 판단하려는 거야.';
    } else response=evidenceAnswer(p,view,mind,id,{direct:true});
  } else if(intent==='opinion') {
    if(/(?:내\s*말|내가\s*한\s*말|나를|날).{0,18}(?:믿|동의)/.test(q)) {
      const recent=findRecentWords(view,fromId,question.id);
      if(recent && claimedRole(recent))response=`네가 아까 ${roleAsQuote(claimedRole(recent))} 말한 건 기억해. 다만 그 발언만으로 진짜인지 확인할 수는 없어.`;
      else response='네 말을 무시한 건 아니야. 다만 믿는 것과 사실로 확인하는 건 구분해서 판단하려고 해.';
    } else {
    const broad=/(?:누가|누굴|누구).{0,20}(?:마피아|의심|수상)|(?:마피아|의심).{0,15}누구/.test(q);
    if(id && id!==p.id && !broad) {
      const recent=view.publicChat.findLast(x=>x.senderId===id && x.id!==question.id);
      if(/(?:말에\s*동의|말\s*믿|그\s*말\s*맞|뭐라고\s*했)/.test(q) && recent)response=`${ref}이 “${normalize(recent.text).slice(0,70)}”라고 말한 건 들었어. 그렇지만 그 말이 사실인지는 다른 단서와 비교해야 해.`;
      else response=summarizeVisibleFact(p,view,mind,id);
    } else {
      const eligible=view.alivePlayers.filter(x=>x.id!==p.id && x.id!==view.partnerId);
      const strong=eligible.map(x=>({x,fact:factFor(p,view,mind,x.id)})).filter(x=>x.fact?.strong);
      response=strong.length?`${formatRef(view,strong[0].x.id)}을 살펴볼 이유가 있어. ${strong[0].fact.text}`:
        '현재 누가 마피아인지 확실한 단서가 없어. 말투가 아니라 조사 결과와 실제 발언을 기준으로 보려고 해.';
    }
    }
  } else {
    if(/(?:맞지|맞아|동의해)/.test(q))response='네 말이 어떤 주장인지는 들었어. 다만 직업이나 마피아 여부는 검증 없이 맞다고 확정할 수 없어.';
    else if(id && id!==p.id)response=`${ref}에 관해 묻는 거지. ${summarizeVisibleFact(p,view,mind,id)}`;
    else response='질문을 정확히 이해하지 못했어. 알아듣지 못한 부분을 임의로 추리하지 않을게. 대상이나 행동을 구체적으로 말해줘.';
  }
  return finishInteraction(room,p,view,mind,question,response);
}
// PRIVATE TEAM DISCUSSION: used only once Mafia and Spy have truly contacted.
// This cannot call the public reply functions: those assume a public transcript
// and deliberately refuse to share investigations. Each answer is anchored in
// the partner's actual message, the speaker's own knowledge and public evidence.
function secretAttackTarget(text,view) {
  const t=normalize(text);
  const attack=/(?:공격|살해|죽일|죽이|죽여|잡자|노리|노려|처리하|킬|\d+\s*번(?:으로|로)\s*(?:가자|하자|바꾸자|정하자|선택하자)|\d+\s*번\s*(?:선택|타겟|목표))/.test(t) && !/(?:투표|스킵|퇴출)/.test(t);
  if(!attack)return null;
  const ids=orderedMentions(t,view.everyone);
  if(!ids.length)return null;
  const ban=!!secretAvoidTarget(t,view);
  const switched=/(?:말고|대신|바꿔|변경|옮기|전환)/.test(t) && ids.length>=2;
  if(ban && !switched)return null;
  const candidate=switched?ids[ids.length-1]:ids[0];
  if(!view.alivePlayers.some(x=>x.id===candidate))return null;
  return candidate;
}
function secretAvoidTarget(text,view) {
  const t=normalize(text);
  const ids=orderedMentions(t,view.everyone);
  if(!ids.length)return null;
  if(/(?:말고|대신)/.test(t) && ids.length>1 && /(?:공격|죽이|죽일|죽여|살해|노리|처리)/.test(t))return ids[0];
  if(/(?:공격|살해|죽이|죽일|죽여|노리|처리).{0,12}(?:하지\s*마|하지\s*말|말자|안\s*돼|취소|반대)|(?:죽이지|죽이면|공격하면|공격하는\s*건).{0,8}(?:마|말|안\s*돼)|(?:공격|죽이|죽일|살해)\s*안\s*해/.test(t))return ids[0];
  return null;
}
function secretRecentPartnerMessage(room,p,view,mind,replyToId) {
  const partner=view.partnerId;
  if(!view.contacted || !partner)return null;
  if(!mind.secretAnswerIds)mind.secretAnswerIds=[];
  const entry=replyToId?view.secretChat.find(x=>x.id===replyToId):
    view.secretChat.slice().reverse().find(x=>x.senderId===partner && !mind.secretAnswerIds.includes(x.id));
  if(!entry || entry.senderId!==partner || mind.secretAnswerIds.includes(entry.id))return null;
  return entry;
}
function secretEvidence(p,view,mind,id) {
  const ref=formatRef(view,id);
  const own=findOwnResult(view,id);
  if(p.role==='SPY' && own?.actualRole)
    return `${ref}은 내가 ${own.night}번째 밤에 직접 조사했고 실제 직업은 ${own.displayed}로 확인됐어.`;
  const claim=mind.claims[id];
  if(claim)return `${ref}이 낮에 ${roleAsQuote(claim.role)} 주장한 건 봤어. 하지만 조사로 확인된 건 아니야.`;
  const line=view.publicChat.findLast(x=>x.senderId===id);
  if(line)return `${ref}이 낮에 한 마지막 말은 “${normalize(line.text).slice(0,48)}”였어. 그 말만으론 실제 직업을 알 수 없어.`;
  return `${ref}에 관한 확인된 단서는 아직 없어.`;
}
function secretSharedIntel(view,requestedId=null) {
  // Report what the partner told us, not a privileged read of the other role.
  const reports=[];
  for(const entry of view.secretChat.slice().reverse()) {
    if(entry.senderId!==view.partnerId)continue;
    const text=normalize(entry.text);
    const ids=orderedMentions(text,view.everyone);
    if(!ids.length || !/(?:조사|확인|알아봤|직업은)/.test(text))continue;
    const role=text.match(/(?:경찰|의사|건달|시민|마피아|스파이)/)?.[0];
    if(!role)continue;
    if(requestedId && !ids.includes(requestedId))continue;
    const id=ids[0];
    if(reports.some(x=>x.id===id))continue;
    reports.push({id,role});
  }
  return reports;
}
function secretInvestigations(p,view,requestedId=null) {
  if(p.role!=='SPY') {
    const received=secretSharedIntel(view,requestedId);
    if(received.length)return `네가 비밀 채팅에서 ${received.map(x=>`${formatRef(view,x.id)}은 ${x.role}`).join(', ')}라고 조사 결과를 알려줬지. 나는 직접 확인할 수 없어서 네가 공유한 정보로만 기억하고 있어.`;
    return requestedId?`${formatRef(view,requestedId)}에 대해 네가 공유한 조사 결과는 아직 없어. 내가 직접 조사한 기록도 없어.`:
      '나는 직접 조사할 수 없어. 네가 조사한 기록을 공유해 주면 그 내용에 맞춰 함께 논의할게.';
  }
  const found=requestedId ? view.investigations.findLast(x=>x.targetId===requestedId) : null;
  if(requestedId && !found)return `${formatRef(view,requestedId)}은 내가 조사한 기록이 없어. 결과를 지어내지 않을게.`;
  const list=(requestedId?[found]:view.investigations).filter(x=>x?.actualRole);
  return list.length?`내가 직접 조사한 기록은 ${list.map(x=>`${formatRef(view,x.targetId)} ${x.displayed}(${x.night}번째 밤)`).join(', ')}야. 다른 사람의 직업은 추측일 뿐이야.`:
    '아직 공유할 직접 조사 기록이 없어. 확인하지 않은 사람의 직업은 모른다고 할게.';
}
function secretTargetFromLastMessage(view,entry) {
  const switched=topicSwitchTarget(entry.text,view);
  if(switched)return switched;
  const ids=orderedMentions(entry.text,view.everyone);
  return ids.find(x=>x!==view.partnerId && x!==view.selfId) || ids[0] || null;
}
function answerSecret(room,p,view,mind,entry) {
  const t=normalize(entry.text);
  const semantic=Utterance.classify(t,{phase:room.phase,channel:'SECRET'});
  const special=corpusSpecialAnswer(room,p,view,mind,entry,'SECRET');
  const partner=view.partnerId;
  const refId=secretTargetFromLastMessage(view,entry);
  const refs=orderedMentions(t,view.everyone);
  const target=secretAttackTarget(t,view)||
    (semantic && ['SECRET_ATTACK','SECRET_SWITCH'].includes(semantic.intent)?refs.at(-1):null);
  const valid=target && target!==p.id && target!==partner;
  const attackWord=(/(?:공격|살해|죽|킬|노리|처리|습격|제거|\d+\s*번(?:으로|로)\s*(?:가자|하자|바꾸자|정하자|선택)|타겟|목표)/.test(t) && !/(?:투표|스킵|퇴출)/.test(t)) ||
    !!(semantic && ['SECRET_ATTACK','SECRET_AVOID','SECRET_SWITCH'].includes(semantic.intent));
  const requestInfo=/(?:조사|정보|결과|직업).{0,26}(?:누구|몇\s*번|뭐|알려|말해|공유|했|확인)|(?:누구|몇\s*번).{0,20}(?:조사|알아)/.test(t);
  const rolePrompt=roleDisclosureRequest(t);
  const ownAction=p.role==='MAFIA'?room.actions.get(p.id):null;
  const confirmed=ownAction?.confirmed;
  const ownTarget=ownAction?.target||ownAction?.selected;
  let reply=special||'';
  if(special) {
    // Do not turn a direct rule/memory answer into idle strategy narration.
  } else if(semantic?.intent==='SECRET_AVOID') {
    const exclude=refs[0];
    reply=exclude?`${formatRef(view,exclude)}을 공격하지 말자는 뜻이지. ${confirmed?'이미 확정된 공격은 이 밤에 바꿀 수 없어.':'확정 전이라면 다른 후보를 고를게.'}`:
      '공격을 피하자는 의견은 들었어. 확정 전이라면 공격 대상을 다시 검토할게.';
  } else if(semantic?.intent==='SECRET_PLAN' && !refs.length && !/(?:조사|확인|결과|직업|의사|경찰|건달|시민팀|마피아팀)/.test(t)) {
    if(confirmed)reply=`나는 이미 ${formatRef(view,ownTarget)} 공격을 확정했어. 이번 밤에는 바꿀 수 없어.`;
    else if(ownTarget)reply=`현재 ${formatRef(view,ownTarget)}을 공격 후보로 선택했지만 확정 전이야. 실제 확인된 정보를 보고 다시 판단할 수 있어.`;
    else reply=p.role==='MAFIA'?'아직 공격 대상을 확정하지 않았어. 공개 발언과 네 조사 정보를 보고 살아 있는 시민팀 후보를 고를게.':'조사 결과를 비교해서 공격 후보를 제안할게. 최종 공격 대상은 마피아가 정해.';
  } else if(semantic?.intent==='SECRET_INFO') {
    reply=secretInvestigations(p,view,refId&&refId!==p.id&&refId!==partner?refId:null);
  } else if(/(?:아니\s*그게|그게\s*아니|정정|말고|대신|바꿔|변경|옮기|전환)/.test(t) && target) {
    if(!valid)reply='그 사람은 우리 팀이거나 나 자신이어서 공격 대상으로 정할 수 없어. 다른 살아 있는 사람을 골라야 해.';
    else if(confirmed)reply=`${formatRef(view,target)}으로 바꾸자는 뜻이지. 하지만 난 이미 ${formatRef(view,ownTarget)} 공격을 확정해서 이번 밤엔 변경할 수 없어.`;
    else reply=`알겠어. 이전 후보 대신 ${formatRef(view,target)}을 공격 후보로 바꾸자는 뜻이지. ${secretEvidence(p,view,mind,target)} ${p.role==='MAFIA'?'확정 전이라면 그 제안을 반영할게.':'최종 공격 선택은 네가 해.'}`;
  } else if(/(?:왜\s*내\s*말\s*무시|대답\s*해|내\s*말\s*들|말\s*좀\s*들|헛소리|엉뚱|그\s*얘기\s*말고)/.test(t)) {
    reply=`네 말을 무시한 건 아니야. 방금 한 말에 맞춰 답할게. ${refId?`${formatRef(view,refId)} 얘기부터 보자. ${secretEvidence(p,view,mind,refId)}`:'공격 대상이나 조사 정보 중 무엇을 확인할지 말해줘.'}`;
  } else if(/(?:무슨\s*말|뭔\s*뜻|다시\s*설명|아까\s*말|방금\s*말)/.test(t)) {
    const old=view.secretChat.slice(0,view.secretChat.findIndex(x=>x.id===entry.id)).reverse().find(x=>x.senderId===p.id);
    reply=old?`내가 아까 “${normalize(old.text).slice(0,72)}”라고 했어. 그건 내가 가진 정보나 후보를 설명한 것이지, 실제 공격이 확정됐다는 뜻은 아니야.`:'지금 내가 바로 앞에서 한 말을 찾을 수 없어. 어떤 부분인지 다시 말해주면 설명할게.';
  } else if(roleSilenceRequest(t)) {
    reply='알겠어. 공개 채팅에서는 접선한 우리 팀의 직업과 관계를 말하지 않을게.';
  } else if(rolePrompt || /(?:너|넌|네가|니가|너희|우린|우리).{0,20}(?:직업|스파이|마피아|같은\s*팀|한\s*팀)|(?:직업|역할)\s*(?:뭐|뭔데|알려)/.test(t)) {
    if(refId && refId!==partner && refId!==p.id && rolePrompt)
      reply=secretInvestigations(p,view,refId);
    else reply=`난 ${p.role==='SPY'?'스파이':'마피아'}야. 우리는 접선한 같은 팀이야. 비밀 채팅에선 서로 정체를 숨길 필요가 없어.`;
  } else if(p.role==='MAFIA' && refId && /(?:조사|확인|알아봤)/.test(t) &&
      /(?:경찰|의사|건달|시민|마피아|스파이)/.test(t) &&
      !/(?:뭐|누구|어때|알려|말해|맞아|맞니|맞지)/.test(t)) {
    const role=t.match(/(?:경찰|의사|건달|시민|마피아|스파이)/)?.[0];
    reply=`${formatRef(view,refId)}이 ${role}라는 조사 정보를 공유하는 거지. 네가 직접 확인한 결과로 기억할게. 나는 조사할 수 없으니 그 외의 사람 역할은 단정하지 않겠어.`;
  } else if(requestInfo || /(?:누구|누굴).{0,12}(?:조사|확인)/.test(t)) {
    reply=secretInvestigations(p,view,refId && refId!==p.id && refId!==partner?refId:null);
  } else if(attackWord && secretAvoidTarget(t,view) && !/(?:말고|대신)/.test(t)) {
    reply=refId?`${formatRef(view,refId)}을 공격하지 말자는 뜻이지. ${confirmed?'이미 확정한 공격은 바꿀 수 없어.':'확정 전이라면 다른 대상을 고려할게.'}`:'공격을 보류하자는 뜻이지. 지금은 확정된 행동을 임의로 바꾸지 않겠어.';
  } else if(attackWord && target) {
    if(!valid)reply=`${formatRef(view,target)}은 우리 편이거나 나 자신이야. 공격 대상이 될 수 없으니 다른 사람을 골라야 해.`;
    else if(confirmed)reply=`${formatRef(view,target)} 공격 제안은 들었어. 하지만 이미 ${formatRef(view,ownTarget)} 공격을 확정했으니 이번 밤엔 바꿀 수 없어.`;
    else reply=`${formatRef(view,target)}을 공격하자는 제안이구나. ${secretEvidence(p,view,mind,target)} ${p.role==='MAFIA'?'아직 행동을 확정하지 않았다면 이 후보를 고려할게.':'공격 결정은 마피아인 네가 해야 해. 나는 정보를 공유할게.'}`;
  } else if(/(?:누구|누굴|몇\s*번|어디).{0,16}(?:공격|죽|살해|노리)|(?:공격|살해|죽일).{0,18}(?:누구|누굴|할까|할래|어때|생각)/.test(t)) {
    if(p.role==='MAFIA' && confirmed)reply=`나는 이미 ${formatRef(view,ownTarget)} 공격을 확정했어. 이번 밤에는 변경할 수 없어.`;
    else if(p.role==='MAFIA' && ownTarget)reply=`현재 ${formatRef(view,ownTarget)}을 임시 선택했어. 최종 확정 전까지 다른 후보도 논의할 수 있어.`;
    else reply='아직 공격 대상을 확정하지 않았어. 낮에 확인한 발언이나 스파이의 실제 조사 기록을 근거로 후보를 정하자.';
  } else if(/(?:\d+\s*번|그\s*사람|걔).{0,20}(?:경찰|의사|시민|마피아|스파이|수상|믿|의심|어때|맞아|확실|누구)/.test(t) && refId && !/(?:스킵|투표|찍을|퇴출)/.test(t)) {
    if(refId===partner || refId===p.id)reply=`${formatRef(view,refId)}은 접선한 우리 마피아팀이야. 밖에서는 그 사실을 숨겨야 해.`;
    else reply=`${formatRef(view,refId)}에 대해 묻는 거지. ${secretEvidence(p,view,mind,refId)} 아는 사실과 추측을 구분해 판단하자.`;
  } else if(/(?:스킵|투표|찍을|퇴출)/.test(t)) {
    reply=refId?`낮에 ${formatRef(view,refId)}에게 투표하자는 얘기구나. 실제 투표와 밤 공격은 다른 선택이야. 공개된 근거와 우리 팀의 생존을 같이 고려하자.`:'낮 투표는 밤 공격과 별개야. 근거가 부족하면 스킵도 가능하지만, 승패 조건을 고려해 전략을 정하자.';
  } else if(/(?:고마워|ㄱㅅ|감사)/.test(t)) {
    reply='응. 네가 알려준 내용도 기억하고 다음 판단에 참고할게.';
  } else if(/^(?:응|ㅇㅇ|그래|맞아|동의|좋아|오케이|ㅇㅋ|알겠)/.test(t)) {
    reply='좋아. 방금 논의한 후보와 조사 정보를 계속 염두에 둘게. 최종 행동이 확정되면 바꿀 수 없다는 점도 기억하자.';
  } else if(/(?:안녕|하이|ㅎㅇ|반가워)/.test(t) && t.length<20) {
    reply='안녕. 접선했으니 이제 이 채팅에서 공격 대상과 조사 정보를 함께 논의할 수 있어.';
  } else if(/(?:보류|기다려|잠깐|아직\s*하지)/.test(t)) {
    reply=confirmed?'이미 공격 행동을 확정했다면 되돌릴 수는 없어.':'알겠어. 후보를 더 살펴보고 확정 전까지 논의하자.';
  } else if(refId) {
    reply=`${formatRef(view,refId)} 이야기로 이해했어. ${secretEvidence(p,view,mind,refId)} 그 사람에게 관해 확인하고 싶은 게 있으면 더 말해줘.`;
  } else {
    const echo=t.slice(0,55);
    reply=`“${echo}”라고 말한 건 들었어. 이 내용이 공격 대상 제안인지, 조사 결과를 묻는 건지 확실하지 않아. 이해하지 못한 부분은 지어내지 않을게.`;
  }
  mind.secretAnswerIds ||= [];
  mind.secretAnswerIds.push(entry.id);
  if(mind.secretAnswerIds.length>120)mind.secretAnswerIds=mind.secretAnswerIds.slice(-90);
  return normalize(`${formatRef(view,partner)}, ${reply}`).slice(0,218);
}
function decideSpeech(room,p,channel,rng,options={}) {
  const view=legalView(room,p),mind=readStatements(p,view,rng),profile=mind.persona;
  mind.turns++;
  const opener=choice(profile.rhythm,rng);
  if(channel==='SECRET') {
    const partnerEntry=secretRecentPartnerMessage(room,p,view,mind,options.replyToId);
    if(partnerEntry) return answerSecret(room,p,view,mind,partnerEntry);
    if(options.replyToId) return null; // Old/answered message: never produce unrelated filler.
    const fresh=view.investigations.filter(x=>x.actualRole && x.actualRole!=='MAFIA' && view.alivePlayers.some(y=>y.id===x.targetId))
      .find(x=>!mind.spoken.includes('spy:'+x.targetId));
    if(p.role==='SPY' && fresh) {
      mind.spoken.push('spy:'+fresh.targetId);
      return `${formatRef(view,fresh.targetId)}을 조사했고 실제 직업은 ${fresh.displayed}이었어. 이건 내가 직접 알아낸 정보야. 살해 대상을 정할 때 참고해.`;
    }
    // A single unsolicited strategy opener per night. Follow-up turns must
    // respond to the partner instead of repeating the same monologue.
    const idleKey='secret-opener:'+view.night;
    if(mind.spoken.includes(idleKey))return null;
    mind.spoken.push(idleKey);
    const focus=strongestSuspect(p,view,mind,view.alivePlayers.map(x=>x.id));
    return p.role==='MAFIA' ? `오늘 공격 대상은 내가 정할게. ${focus?formatRef(view,focus.id)+'은 공개 채팅에서 언급됐지만':'공개된 정보가 부족하니'} 이유 없이 단정하지 말고 판단하자.` :
      `지금까지 얻은 조사 정보와 낮 채팅을 함께 보자. 최종 공격 대상은 네가 정해.`;
  }
  const asked=pickQuestion(room,p,view,mind,options.replyToId);
  if(asked) return intentOf(asked.text) ? answerQuestion(room,p,view,mind,asked,rng) : replyToStatement(room,p,view,mind,asked,rng);
  const mafiaResult=view.role==='POLICE' && view.investigations.findLast(x=>x.displayed==='마피아팀' && view.alivePlayers.some(y=>y.id===x.targetId));
  if(mafiaResult && !mind.spoken.includes('police:'+mafiaResult.targetId) && reserveTopic(room,view.phaseStart,'police-result:'+p.id+':'+mafiaResult.targetId)) {
    mind.spoken.push('police:'+mafiaResult.targetId);
    return `내가 경찰이고 ${mafiaResult.night}번째 밤에 ${formatRef(view,mafiaResult.targetId)}을 조사했어. 결과는 마피아팀이야. 그 사람이 왜 의심받는지 설명할 수 있는 실제 조사 결과야.`;
  }
  const counter=Object.entries(mind.claims).find(([id,c])=>id!==p.id && c.role==='경찰' && view.role==='POLICE');
  if(counter && !mind.spoken.includes('counter:'+counter[0]) && reserveTopic(room,view.phaseStart,'counterclaim:'+p.id+':'+counter[0])) {
    mind.spoken.push('counter:'+counter[0]);
    return `${formatRef(view,counter[0])}은 경찰이라고 주장했지. 나도 경찰이야. 경찰은 한 명뿐이니까 둘 다 진짜일 수는 없어. 이게 내 의심의 이유야.`;
  }
  const shift=mind.claimChanges.findLast(x=>!mind.spoken.includes('changed:'+x.id) && !discussionLedger(room,view.phaseStart).topics.has('role-change:'+x.id));
  if(shift) {
    reserveTopic(room,view.phaseStart,'role-change:'+shift.id);
    mind.spoken.push('changed:'+shift.id);
    mind.lastOpinion={targetId:shift.speakerId,reason:'role-change'};
    return shift.to==='그 직업 부인'?
      `${formatRef(view,shift.speakerId)}은 앞에선 ${shift.from}이라고 했다가 지금은 그 직업이 아니라고 말했어. 바뀐 이유는 아직 모르니까 확인해 보자.`:
      `${formatRef(view,shift.speakerId)}은 앞에서 ${shift.from}, 뒤에는 ${roleAsQuote(shift.to)} 했어. 직업 주장이 바뀐 건 실제 채팅에 남아 있으니 그 이유를 확인하고 판단하자.`;
  }
  const voteShift=mind.stanceChanges.findLast(x=>!mind.spoken.includes('vote-shift:'+x.id) && !discussionLedger(room,view.phaseStart).topics.has('vote-shift:'+x.id));
  if(voteShift) {
    reserveTopic(room,view.phaseStart,'vote-shift:'+voteShift.id);
    mind.spoken.push('vote-shift:'+voteShift.id);
    const phrase=value=>value==='SKIP'?'건너뛰기':formatRef(view,value)+' 투표';
    return `${formatRef(view,voteShift.speakerId)}은 처음엔 ${phrase(voteShift.from)}, 지금은 ${phrase(voteShift.to)}라고 했어. 생각이 바뀔 순 있지만 이유는 아직 확인되지 않았어.`;
  }
  const lastClaim=Object.entries(mind.claims).find(([id,c])=>!mind.spoken.includes('claim:'+id+':'+c.role) && !discussionLedger(room,view.phaseStart).topics.has('claim:'+id+':'+c.role) && !mind.claimChanges.some(x=>x.speakerId===id) && id!==p.id);
  if(lastClaim) {
    reserveTopic(room,view.phaseStart,'claim:'+lastClaim[0]+':'+lastClaim[1].role);
    mind.spoken.push('claim:'+lastClaim[0]+':'+lastClaim[1].role);
    return `${formatRef(view,lastClaim[0])}이 ${roleAsQuote(lastClaim[1].role)} 주장했어. 말 자체는 확인됐지만 진짜 그 직업인지는 아직 증명되지 않았어. 말과 조사 결과는 구분해야 해.`;
  }
  const list=view.alivePlayers.filter(x=>x.id!==p.id);
  const strong=list.map(x=>({q:x,fact:factFor(p,view,mind,x.id)}))
    .filter(x=>x.fact?.strong).sort((a,b)=>suspicion(mind,view,b.q.id)-suspicion(mind,view,a.q.id));
  const topicForFact=entry=>{
    if(entry.fact.kind==='role-change') {
      const shift=mind.claimChanges.findLast(x=>x.speakerId===entry.q.id);
      return shift?'role-change:'+shift.id:null;
    }
    if(entry.fact.kind==='police-result')return 'police-result:'+p.id+':'+entry.q.id;
    if(entry.fact.kind==='counterclaim')return 'counterclaim:'+p.id+':'+entry.q.id;
    return 'fact:'+entry.q.id+':'+entry.fact.kind;
  };
  if(strong.length) {
    const entry=strong.find(x=>topicForFact(x) && !discussionLedger(room,view.phaseStart).topics.has(topicForFact(x)));
    if(entry) {
      reserveTopic(room,view.phaseStart,topicForFact(entry));
      mind.spoken.push('fact:'+entry.q.id+':'+entry.fact.kind);
      mind.lastOpinion={targetId:entry.q.id,reason:entry.fact.kind};
      return `${opener}, ${entry.fact.text} 이건 막연한 느낌이 아니라 확인 가능한 단서야.`;
    }
  }
  const publicResult=view.publicLog.findLast(x=>/지난밤 .*사망|지난밤 사망자는 없습니다/.test(x.text));
  const topics=[
    `현재 공개된 사실은 ${publicResult?.text || '아직 밤 사망 결과가 없다는 점'}이야. 그 이유가 누구 때문인지는 알려지지 않았어.`,
    `나는 아직 누가 마피아인지 확신할 증거가 없어. 말투만으로 누군가를 퇴출시키는 건 위험해.`,
    `누가 다른 사람을 의심한다는 사실과 실제로 마피아라는 증거는 달라. 두 가지를 구분해서 판단하자.`,
    `자기 직업을 주장하는 건 누구나 할 수 있어. 조사 내용이나 앞서 했던 말과 맞는지 확인해야 해.`,
    `확실한 근거가 없으면 이번 투표를 건너뛰고 다음 밤 정보를 기다리는 것도 합리적이야.`,
    `나는 지금은 판단을 보류할게. 새 단서가 나오기 전까지 같은 의심을 반복하지는 않겠어.`
  ];
  const offset=(p.number + Math.floor(view.night||1)*2 + mind.turns-1)%topics.length;
  const index=Array.from({length:topics.length},(_,i)=>(offset+i)%topics.length)
    .find(i=>reserveTopic(room,view.phaseStart,'topic:'+i,true));
  if(index===undefined)return null;
  mind.spoken.push('topic:'+index);
  if(mind.spoken.length>160)mind.spoken=mind.spoken.slice(-120);
  return `${opener}, ${topics[index]}`;
}

module.exports={ mindFor, legalView, readStatements, decideSpeech, chooseNight, chooseVote, syncRoom, recordDecision, claimedRole, mentions, isQuestion, directAddressee, isReactiveMessage, roleDisclosureRequest, parseDiscourse:DiscourseFrame.parse, parseUtterance:Utterance.classify };

})(botModule,botModule.exports,(name)=>{
 if(name==='./discourse-frame')return discourseModule.exports;
 if(name==='./ai/memory')return memoryModule.exports;
 if(name==='./ai/utterance-parser')return utteranceModule.exports;
 throw new Error('Unexpected bot import '+name);
});
const engineModule={exports:{}};
(function(module,exports,require){
'use strict';

const crypto = require('node:crypto');
const BotMind = require('./bot-mind');
const ROLES = ['MAFIA', 'SPY', 'POLICE', 'DOCTOR', 'GANGSTER', 'CITIZEN', 'CITIZEN'];
const ROLE_KO = {
  MAFIA: '마피아', SPY: '스파이', POLICE: '경찰', DOCTOR: '의사',
  GANGSTER: '건달', CITIZEN: '시민'
};
const TEAM = { MAFIA: 'MAFIA', SPY: 'MAFIA', POLICE: 'CITIZEN',
  DOCTOR: 'CITIZEN', GANGSTER: 'CITIZEN', CITIZEN: 'CITIZEN' };
const DEFAULT_DURATIONS = {
  NIGHT: 60000, NIGHT_RESULT: 4500, DAY: 60000,
  VOTE1: 30000, EXTRA_DISCUSSION: 45000, VOTE2: 30000,
  VOTE_RESULT: 4500
};
const MAX_CHAT_LENGTH = 220;
const BOT_NAMES = ['도윤', '서아', '민준', '하린', '지호', '수빈', '유진'];

function rule(condition, message) { if (!condition) throw new Error(message); }
function shuffled(items, rng) {
  const out = items.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}
function pick(items, rng) { return items.length ? items[Math.floor(rng() * items.length)] : null; }
function sanitizeName(value) {
  return String(value || '').replace(/[\r\n<>]/g, '').trim().slice(0, 18) || '익명';
}
function sanitizeChat(value) {
  return String(value || '').replace(/[\u0000-\u001F\u007F]/g, '').trim().slice(0, MAX_CHAT_LENGTH);
}
function publicActor(p) {
  return { id: p.id, number: p.number, name: p.name, bot: p.bot, alive: p.alive,
    boxPicked: p.boxIndex !== null, roleReady: p.roleReady };
}

class MafiaRoom {
  constructor(code, options = {}) {
    this.code = code;
    this.now = options.now || Date.now;
    this.rng = options.rng || Math.random;
    this.durations = { ...DEFAULT_DURATIONS, ...options.durations };
    this.onChange = options.onChange || (() => {});
    this.botController = options.botController || null;
    this.players = [];
    this.hostId = null;
    this.phase = 'LOBBY';
    this.phaseStart = this.now();
    this.deadline = null;
    this.night = 0;
    this.boxAssignments = null;
    this.boxOwners = null;
    this.actions = new Map();
    this.votes = new Map();
    this.contact = null;
    this.stunnedId = null;
    this.pendingNight = null;
    this.voteOutcome = null;
    this.publicLog = [];
    this.publicChat = [];
    this.secretChat = [];
    this.winningTeam = null;
    this.abortReason = null;
    this.botPlans = [];
    this.updatedAt = this.now();
  }

  update() { this.updatedAt = this.now(); this.onChange(this); }
  getPlayer(id) { return this.players.find(p => p.id === id); }
  hasActiveMatch() { return !['LOBBY', 'ABORTED', 'GAME_OVER'].includes(this.phase); }
  isHost(p) { return !!p && p.id === this.hostId; }
  ensureHost(p) { rule(this.isHost(p), '방장만 사용할 수 있습니다.'); }
  ensurePhase(...phases) { rule(phases.includes(this.phase), '현재 단계에서는 사용할 수 없습니다.'); }
  nextNumber() {
    for (let n = 1; n <= 7; n++) if (!this.players.some(p => p.number === n)) return n;
    return null;
  }

  createPlayer(name, bot = false) {
    this.ensurePhase('LOBBY');
    rule(this.players.length < 7, '방 인원이 가득 찼습니다.');
    const id = crypto.randomUUID();
    const p = {
      id, number: this.nextNumber(), name: sanitizeName(name), bot,
      token: bot ? null : crypto.randomBytes(24).toString('hex'),
      connected: false, connection: null, role: null, team: null, alive: true,
      boxIndex: null, roleReady: false, notices: [], investigations: [],
      lastChatAt: -Infinity
    };
    this.players.push(p);
    if (!this.hostId && !bot) this.hostId = id;
    this.log(`${p.number}번 ${p.name}님이 입장했습니다.${bot ? ' (AI)' : ''}`);
    this.update();
    return p;
  }

  addBots(actor, count = 1) {
    this.ensureHost(actor);
    this.ensurePhase('LOBBY');
    rule(Number.isInteger(count) && count >= 1 && count <= 6, 'AI 추가 인원이 올바르지 않습니다.');
    rule(this.players.length + count <= 7, '참가 인원은 7명까지입니다.');
    for (let i = 0; i < count; i++) {
      const used = new Set(this.players.map(p => p.name));
      const name = BOT_NAMES.find(n => !used.has(n)) || `AI ${i + 1}`;
      this.createPlayer(name, true);
    }
  }
  removeBots(actor) {
    this.ensureHost(actor);
    this.ensurePhase('LOBBY');
    this.players = this.players.filter(p => !p.bot);
    this.log('AI 플레이어를 제거했습니다.');
    this.update();
  }
  removeHuman(p, reason = '접속 종료') {
    if (!this.players.includes(p)) return;
    const mustAbort = this.hasActiveMatch();
    this.players = this.players.filter(x => x.id !== p.id);
    if (this.hostId === p.id) this.hostId = this.players.find(x => !x.bot)?.id || null;
    if (mustAbort) this.abort(`${p.number}번 ${p.name}: ${reason}`);
    else { this.log(`${p.number}번 ${p.name}님이 나갔습니다.`); this.update(); }
  }

  log(text) {
    this.publicLog.push({ at: this.now(), text });
    if (this.publicLog.length > 50) this.publicLog.shift();
  }
  notice(p, text, type = 'info') {
    if (!p) return;
    p.notices.push({ id: crypto.randomUUID(), at: this.now(), text, type });
    if (p.notices.length > 20) p.notices.shift();
  }
  phaseTo(phase, duration = null) {
    this.phase = phase;
    this.phaseStart = this.now();
    this.deadline = duration === null ? null : this.phaseStart + duration;
    this.botPlans = [];
    this.scheduleBots();
    this.syncBotMemories();
    this.update();
  }

  syncBotMemories() {
    BotMind.syncRoom(this);
  }

  startDraft(actor) {
    this.ensureHost(actor);
    this.ensurePhase('LOBBY');
    rule(this.players.length === 7, '게임을 시작하려면 7명이 필요합니다.');
    rule(this.players.filter(p => !p.bot).every(p => p.connected), '모든 실제 플레이어가 연결되어야 합니다.');
    this.clearRoundState();
    this.boxAssignments = shuffled(ROLES, this.rng);
    this.boxOwners = Array(7).fill(null);
    this.log('직업 상자 7개가 준비되었습니다. 각자 한 개를 선택하세요.');
    this.phaseTo('BOXES');
  }
  clearRoundState() {
    this.botController?.resetRoom?.(this);
    this.night = 0;
    this.contact = null;
    this.stunnedId = null;
    this.pendingNight = null;
    this.voteOutcome = null;
    this.winningTeam = null;
    this.abortReason = null;
    this.publicChat = [];
    this.secretChat = [];
    this.publicLog = [];
    this.actions.clear();
    this.votes.clear();
    for (const p of this.players) {
      p.role = null; p.team = null; p.alive = true; p.boxIndex = null;
      p.roleReady = false; p.notices = []; p.investigations = []; p.mind = null;
    }
  }
  chooseBox(p, index) {
    this.ensurePhase('BOXES');
    rule(p && this.players.includes(p), '참가자만 상자를 선택할 수 있습니다.');
    rule(!p.bot, 'AI의 상자는 서버가 배정합니다.');
    rule(Number.isInteger(index) && index >= 0 && index < 7, '올바르지 않은 상자입니다.');
    rule(p.boxIndex === null, '이미 상자를 선택했습니다.');
    rule(this.boxOwners[index] === null, '이미 선택된 상자입니다.');
    this.assignBox(p, index);
    this.completeBotBoxesIfReady();
    this.update();
  }
  assignBox(p, index) {
    this.boxOwners[index] = p.id;
    p.boxIndex = index;
    p.role = this.boxAssignments[index];
    p.team = TEAM[p.role];
    this.notice(p, `당신의 직업은 ${ROLE_KO[p.role]}입니다.`, 'role');
  }
  completeBotBoxesIfReady() {
    if (!this.players.filter(p => !p.bot).every(p => p.boxIndex !== null)) return;
    for (const p of this.players.filter(p => p.bot)) {
      const open = this.boxOwners.map((owner, i) => owner === null ? i : -1).filter(i => i !== -1);
      this.assignBox(p, pick(open, this.rng));
      p.roleReady = true;
    }
    this.maybeBeginAfterDraft();
  }
  confirmRole(p) {
    this.ensurePhase('BOXES');
    rule(p && p.boxIndex !== null, '먼저 직업 상자를 선택하세요.');
    p.roleReady = true;
    this.maybeBeginAfterDraft();
    this.update();
  }
  maybeBeginAfterDraft() {
    if (this.players.length === 7 && this.players.every(p => p.boxIndex !== null && p.roleReady)) this.startNight();
  }

  usable(p) {
    if (!p || !p.alive) return false;
    if (p.role === 'CITIZEN') return false;
    if (p.role === 'SPY' && this.contact && this.night > this.contact.night) return false;
    return true;
  }
  validTargets(p) {
    if (!this.usable(p)) return [];
    return this.players.filter(q => q.alive && (
      p.role === 'DOCTOR' || q.id !== p.id
    ) && !(
      p.role === 'MAFIA' && this.contact && this.night > this.contact.night && q.role === 'SPY'
    )).map(q => q.id);
  }
  startNight() {
    this.night += 1;
    this.pendingNight = null;
    this.stunnedId = null;
    this.actions.clear();
    this.voteOutcome = null;
    for (const p of this.players) if (this.usable(p)) {
      this.actions.set(p.id, { selected: null, confirmed: false, target: null,
        auto: false, fromLastSelection: false, confirmedAt: null });
    }
    this.log(`${this.night}번째 밤이 시작되었습니다.`);
    this.phaseTo('NIGHT', this.durations.NIGHT);
  }
  selectAbility(p, targetId) {
    this.ensurePhase('NIGHT');
    rule(this.usable(p), '야간 능력을 사용할 수 없습니다.');
    const action = this.actions.get(p.id);
    rule(action && !action.confirmed, '이미 행동을 확정하여 변경할 수 없습니다.');
    rule(this.validTargets(p).includes(targetId), '해당 플레이어는 선택할 수 없습니다.');
    action.selected = targetId;
    this.update();
  }
  confirmAbility(p, targetId) {
    this.ensurePhase('NIGHT');
    const action = this.actions.get(p?.id);
    rule(action && !action.confirmed, '행동을 확정할 수 없습니다.');
    rule(action.selected !== null && action.selected === targetId, '먼저 대상을 임시 선택하세요.');
    rule(this.validTargets(p).includes(targetId), '유효하지 않은 대상입니다.');
    action.confirmed = true;
    action.target = targetId;
    action.confirmedAt = this.now();
    this.notice(p, '능력 사용 대상이 확정되었습니다. 더 이상 변경할 수 없습니다.');
    if (this.allActionsConfirmed()) this.resolveNight();
    else this.update();
  }
  allActionsConfirmed() {
    return Array.from(this.actions.values()).every(a => a.confirmed);
  }
  finalizeNightActions() {
    for (const [id, action] of this.actions) {
      if (action.confirmed) continue;
      const p = this.getPlayer(id);
      if (action.selected !== null && this.validTargets(p).includes(action.selected)) {
        action.target = action.selected;
        action.fromLastSelection = true;
        this.notice(p, '제한 시간이 종료되어 마지막으로 선택한 대상이 확정되었습니다.');
      } else if (p.role === 'DOCTOR') {
        action.target = p.id;
        action.auto = true;
        this.notice(p, '대상을 선택하지 않아 자신을 자동 치료합니다.');
      } else {
        action.target = pick(this.validTargets(p), this.rng);
        action.auto = true;
        this.notice(p, '제한 시간이 종료되어 대상이 자동 선택되었습니다.');
      }
      action.confirmed = true;
      action.confirmedAt = this.now();
    }
  }
  playerByRole(role) { return this.players.find(p => p.role === role); }
  actionTarget(role) {
    const p = this.playerByRole(role);
    return p && this.actions.get(p.id)?.target || null;
  }
  resolveNight() {
    if (this.phase !== 'NIGHT') return;
    this.finalizeNightActions();
    const mafia = this.playerByRole('MAFIA');
    const spy = this.playerByRole('SPY');
    const police = this.playerByRole('POLICE');
    const doctor = this.playerByRole('DOCTOR');
    const gangster = this.playerByRole('GANGSTER');
    const mafiaTarget = this.actionTarget('MAFIA');
    const spyTarget = this.actionTarget('SPY');
    const policeTarget = this.actionTarget('POLICE');
    const doctorTarget = this.actionTarget('DOCTOR');
    const gangsterTarget = this.actionTarget('GANGSTER');

    // Investigations are simultaneous, irrespective of the order in which clients submitted.
    if (spyTarget && spy?.alive && this.actions.has(spy.id)) {
      const target = this.getPlayer(spyTarget);
      spy.investigations.push({ night: this.night, targetId: target.id,
        actualRole: target.role, displayed: ROLE_KO[target.role] });
      this.notice(spy, `${target.number}번 ${target.name}의 실제 직업: ${ROLE_KO[target.role]}`, 'investigation');
    }
    if (policeTarget && police?.alive) {
      const target = this.getPlayer(policeTarget);
      const displayed = target.role === 'MAFIA' ? '마피아팀' : '시민팀';
      police.investigations.push({ night: this.night, targetId: target.id, displayed });
      this.notice(police, `${target.number}번 ${target.name}의 소속 조사 결과: ${displayed}`, 'investigation');
    }

    const beforeContact = !this.contact;
    const contactA = beforeContact && spy?.alive && spyTarget === mafia?.id;
    const contactB = beforeContact && spy?.alive && mafiaTarget === spy.id;
    if (contactA || contactB) {
      this.contact = { night: this.night, type: contactA ? 'A' : 'B' };
      this.notice(mafia, '스파이와 접선했습니다. 다음 날 밤부터 비밀 채팅을 사용할 수 있습니다.', 'contact');
      this.notice(spy, '마피아와 접선했습니다. 다음 날 밤부터 비밀 채팅을 사용할 수 있으며 조사 능력은 종료됩니다.', 'contact');
    }
    const attackCanceled = !!(spy?.alive && mafiaTarget === spy.id);
    if (attackCanceled && mafia) {
      this.notice(mafia, '스파이 대상 공격이 취소되었습니다. 이번 밤에는 추가 공격할 수 없습니다.', 'contact');
    }
    const effectiveAttack = attackCanceled ? null : mafiaTarget;
    const saved = !!(effectiveAttack && doctor?.alive && doctorTarget === effectiveAttack);
    const deathId = effectiveAttack && !saved ? effectiveAttack : null;
    if (doctor?.alive && doctorTarget) {
      this.notice(doctor, saved ? '당신이 선택한 플레이어를 살렸습니다.' :
        '당신이 선택한 플레이어는 공격받지 않았습니다.', saved ? 'success' : 'info');
    }
    this.pendingNight = { deathId, stunId: gangster?.alive ? gangsterTarget : null,
      attackTargetId: mafiaTarget, effectiveAttack, saved, contactType: contactA ? 'A' : contactB ? 'B' : null };
    this.phaseTo('NIGHT_RESULT', this.durations.NIGHT_RESULT);
  }
  publishMorning() {
    if (this.phase !== 'NIGHT_RESULT') return;
    const result = this.pendingNight || {};
    const victim = result.deathId ? this.getPlayer(result.deathId) : null;
    if (victim) victim.alive = false;
    const stunned = result.stunId ? this.getPlayer(result.stunId) : null;
    this.stunnedId = stunned?.alive ? stunned.id : null;
    if (stunned?.alive) this.notice(stunned, '당신은 오늘 투표에 참여할 수 없습니다.', 'warning');
    if (victim) this.log(`지난밤 ${victim.number}번 ${victim.name}이(가) 사망했습니다.`);
    else this.log('지난밤 사망자는 없습니다.');
    if (this.checkVictory()) return;
    this.log('날이 밝았습니다. 1분 동안 토론을 진행해 주세요.');
    this.phaseTo('DAY', this.durations.DAY);
  }

  canChat(p, channel = 'PUBLIC') {
    if (!p || !p.alive || !this.players.includes(p)) return false;
    if (channel === 'PUBLIC') return ['DAY', 'EXTRA_DISCUSSION'].includes(this.phase);
    if (channel === 'SECRET') return this.phase === 'NIGHT' &&
      !!this.contact && this.night > this.contact.night &&
      ['MAFIA', 'SPY'].includes(p.role) &&
      this.playerByRole('MAFIA')?.alive && this.playerByRole('SPY')?.alive;
    return false;
  }
  sendChat(p, channel, input) {
    rule(this.canChat(p, channel), '현재 채팅을 사용할 수 없습니다.');
    const text = sanitizeChat(input);
    rule(text.length > 0, '채팅 메시지를 입력하세요.');
    rule(this.now() - p.lastChatAt >= 650, '메시지를 너무 빠르게 보내고 있습니다.');
    // Minimal abuse filter, not a game mechanic. Messages are always rendered as text, never HTML.
    rule(!/(?:시발|씨발|병신|개새끼)/i.test(text), '부적절한 표현은 전송할 수 없습니다.');
    p.lastChatAt = this.now();
    const entry = { id: crypto.randomUUID(), at: this.now(), senderId: p.id,
      number: p.number, name: p.name, bot: p.bot, text, channel };
    const arr = channel === 'SECRET' ? this.secretChat : this.publicChat;
    arr.push(entry);
    if (arr.length > 100) arr.shift();
    // Independent memories update as events happen; do not wait for LLM calls.
    if(p.bot)BotMind.mindFor(p,this.rng).agentMemory.recordSpeech(text);
    this.syncBotMemories();
    this.update();
    if (channel === 'PUBLIC') this.scheduleReactions(p, text, entry);
    if (channel === 'SECRET' && !p.bot) this.scheduleSecretReaction(p, entry);
  }

  startVote(number) {
    this.votes.clear();
    this.voteOutcome = null;
    this.log(number === 1 ? '1차 투표가 시작되었습니다.' : '재투표가 시작되었습니다.');
    this.phaseTo(number === 1 ? 'VOTE1' : 'VOTE2', this.durations[number === 1 ? 'VOTE1' : 'VOTE2']);
  }
  canVote(p) {
    return !!p && p.alive && this.stunnedId !== p.id &&
      ['VOTE1', 'VOTE2'].includes(this.phase);
  }
  submitVote(p, targetId) {
    rule(this.canVote(p), '투표할 수 없습니다.');
    rule(!this.votes.has(p.id), '이미 투표를 제출했습니다.');
    rule(targetId === 'SKIP' || (targetId !== p.id &&
      this.players.some(q => q.id === targetId && q.alive)), '유효하지 않은 투표 대상입니다.');
    this.votes.set(p.id, { targetId, at: this.now() });
    this.notice(p, targetId === 'SKIP' ? '투표 건너뛰기를 제출했습니다.' : '투표를 제출했습니다.');
    this.update();
  }
  tallyVote() {
    const counts = new Map();
    for (const entry of this.votes.values()) {
      counts.set(entry.targetId, (counts.get(entry.targetId) || 0) + 1);
    }
    if (!this.votes.size) return { kind: 'EMPTY', counts: [], valid: 0 };
    const max = Math.max(...counts.values());
    const winners = Array.from(counts.entries()).filter(([, n]) => n === max).map(([id]) => id);
    const list = Array.from(counts.entries()).map(([targetId, count]) => ({ targetId, count }));
    return { kind: winners.length > 1 ? 'TIE' : winners[0] === 'SKIP' ? 'SKIP' : 'EXPEL',
      targetId: winners.length === 1 ? winners[0] : null,
      tiedIds: winners.length > 1 ? winners : [], counts: list, valid: this.votes.size };
  }
  resolveVote() {
    if (!['VOTE1', 'VOTE2'].includes(this.phase)) return;
    const isFirst = this.phase === 'VOTE1';
    const outcome = this.tallyVote();
    this.voteOutcome = { ...outcome, round: isFirst ? 1 : 2 };
    if (outcome.kind === 'TIE' && isFirst) {
      this.log('최다 득표 동률이 발생했습니다. 45초 동안 추가 토론합니다.');
      this.phaseTo('EXTRA_DISCUSSION', this.durations.EXTRA_DISCUSSION);
      return;
    }
    if (outcome.kind === 'EXPEL') {
      const eliminated = this.getPlayer(outcome.targetId);
      eliminated.alive = false;
      this.log(`투표 결과 ${eliminated.number}번 ${eliminated.name}이(가) 퇴출되었습니다.`);
      if (this.checkVictory()) return;
    } else if (outcome.kind === 'SKIP') {
      this.log('투표 건너뛰기가 단독 최다 득표했습니다. 퇴출자는 없습니다.');
    } else if (outcome.kind === 'EMPTY') {
      this.log('유효표가 없습니다. 투표 무효, 퇴출자는 없습니다.');
    } else {
      this.log('재투표에서도 동률이 발생했습니다. 퇴출자는 없습니다.');
    }
    this.phaseTo('VOTE_RESULT', this.durations.VOTE_RESULT);
  }
  checkVictory() {
    const mafia = this.playerByRole('MAFIA');
    if (!mafia?.alive) { this.finishGame('CITIZEN'); return true; }
    if (!this.players.some(p => p.alive && p.team === 'CITIZEN')) {
      this.finishGame('MAFIA'); return true;
    }
    return false;
  }
  finishGame(team) {
    this.winningTeam = team;
    this.log(team === 'CITIZEN' ? '마피아가 제거되었습니다. 시민팀이 승리했습니다!' :
      '시민팀 전원이 제거되었습니다. 마피아팀이 승리했습니다!');
    this.phaseTo('GAME_OVER');
  }
  abort(reason) {
    if (['ABORTED', 'GAME_OVER', 'LOBBY'].includes(this.phase)) return;
    this.abortReason = reason || '연결 문제';
    this.winningTeam = null;
    this.pendingNight = null;
    this.actions.clear(); this.votes.clear();
    this.log(`게임 연결 문제로 판이 중단되었습니다. ${this.abortReason}`);
    this.phaseTo('ABORTED');
  }
  resetLobby(actor) {
    this.ensureHost(actor);
    this.ensurePhase('GAME_OVER', 'ABORTED');
    if (this.phase === 'ABORTED') this.players = this.players.filter(p => !p.bot);
    this.clearRoundState();
    this.boxOwners = null; this.boxAssignments = null;
    this.log('새 게임을 위한 인원 모집을 시작합니다.');
    this.phaseTo('LOBBY');
  }

  // The bot only sees its own role, its own investigation history, public data,
  // and a contact partner once contact has genuinely happened.
  botKnowledge(p) {
    const partner = this.contact ?
      this.players.find(q => q.id !== p.id && ['MAFIA', 'SPY'].includes(q.role)) : null;
    return { role: p.role, team: p.team, selfId: p.id, playerNumber: p.number,
      alivePlayers: this.players.filter(q => q.alive).map(q => ({ id: q.id, number: q.number, name: q.name })),
      investigations: p.investigations.map(i => ({ ...i })),
      partnerId: ['MAFIA', 'SPY'].includes(p.role) && this.contact ? partner?.id : null,
      contacted: ['MAFIA','SPY'].includes(p.role) && !!this.contact, night: this.night };
  }
  botNightTarget(p) {
    const target=BotMind.chooseNight(this,p,this.rng);
    BotMind.recordDecision(this,p,'ABILITY',target);
    return target;
  }
  botVoteTarget(p) {
    const target=BotMind.chooseVote(this,p,this.rng);
    BotMind.recordDecision(this,p,'VOTE',target);
    return target;
  }
  botChatText(p, channel, replyToId = null) {
    const mind=BotMind.mindFor(p,this.rng);
    if(!mind.recentLines) mind.recentLines=[];
    let line=BotMind.decideSpeech(this,p,channel,this.rng,replyToId?{replyToId}:{});
    // Do not replace a direct answer with a generic line merely for duplicate avoidance.
    if(!line)return null;
    if(!replyToId && mind.recentLines.includes(line))
      line=BotMind.decideSpeech(this,p,channel,this.rng);
    if(!line)return null;
    mind.recentLines.push(line);
    if(mind.recentLines.length>12)mind.recentLines.shift();
    return line;
  }
  scheduleReactions(sender,text,entry) {
    if (!['DAY','EXTRA_DISCUSSION'].includes(this.phase) || !entry) return;
    const now=this.now();
    if(!sender.bot && !this.players.includes(sender))return;
    if(this.deadline-now<1150)return;
    const isQuestion=BotMind.isQuestion(text);
    const view={everyone:this.players};
    const directId=BotMind.directAddressee(text,view);
    const addressed=this.players.filter(x=>x.bot && x.alive && x.id!==sender.id &&
      (directId ? x.id===directId : x.name.length>1 &&
        new RegExp('^'+x.name+'(?:[,:：，\\s]|님|아|야)').test(text)));
    // Bot-to-bot spontaneous reactions create feedback loops; permit only an
    // explicitly addressed question. Human statements are meaningful turns too.
    if(sender.bot && (!isQuestion || !/[?？]/.test(text) || !addressed.length))return;
    if(!sender.bot && !BotMind.isReactiveMessage(text))return;
    const candidates=this.players.filter(x=>x.bot && x.alive && x.id!==sender.id);
    if(!candidates.length)return;
    const roleRequest=BotMind.roleDisclosureRequest(text);
    if(!sender.bot && roleRequest?.group && !directId) {
      // The player addressed everybody. Each AI must independently answer
      // the same role-discussion request; stagger messages for readability.
      const ordered=candidates.slice().sort((a,b)=>a.number-b.number);
      let i=0;
      for(const respondent of ordered) {
        const at=Math.max(now+900+i*860,respondent.lastChatAt+780);
        if(at>=this.deadline-140)break;
        const scheduled=this.botPlans.find(plan=>!plan.done && plan.kind==='PUBLIC_CHAT' && plan.id===respondent.id && !plan.replyToId);
        if(scheduled){scheduled.replyToId=entry.id;scheduled.at=Math.min(scheduled.at,at);}
        else this.botPlans.push({id:respondent.id,kind:'PUBLIC_CHAT',at,done:false,replyToId:entry.id});
        i++;
      }
      return;
    }
    let bot=addressed[0] || null;
    const prior=this.publicChat.length>=2?this.publicChat[this.publicChat.length-2]:null;
    const referBack=/(?:뭔\s*소리|무슨\s*말|무슨\s*뜻|방금|그게\s*무슨|설명해|응|맞아|그래|동의|아니\s*그게|그건\s*아니|(?:직업|역할|정체).{0,12}(?:하라니까|말하라고|공개하라고|밝히라고))/.test(text);
    if(!bot && !sender.bot && referBack && prior?.bot)
      bot=candidates.find(x=>x.id===prior.senderId)||null;
    if(!bot && !sender.bot && /(?:너|넌|네가|니가|너는|네\s*말)/.test(text) && prior?.bot)
      bot=candidates.find(x=>x.id===prior.senderId)||null;
    if(!bot && !sender.bot && isQuestion && /(?:왜.*?(?:나|날|내)|나를.*?의심)/.test(text))
      bot=candidates.findLast(x=>x.mind?.lastOpinion?.targetId===sender.id)||null;
    if(!bot && !sender.bot) {
      const subjects=BotMind.mentions(text,this.players);
      // An accusation ABOUT a bot should be assessed by another participant,
      // unless the player addresses that bot directly.
      bot=pick(candidates.filter(x=>!subjects.includes(x.id)),this.rng)||pick(candidates,this.rng);
    }
    if(!bot)return;
    // Prevent flood when a human types numerous fragments. Direct questions
    // still take priority, up to the ordinary discussion deadline.
    const queued=this.botPlans.filter(x=>!x.done && x.kind==='PUBLIC_CHAT' && x.replyToId).length;
    if(queued>=12 && !isQuestion)return;
    const at=Math.min(Math.max(now+900,bot.lastChatAt+780),this.deadline-140);
    if(at<=now)return;
    const pending=this.botPlans.find(plan=>!plan.done && plan.id===bot.id && plan.kind==='PUBLIC_CHAT');
    if(pending) {
      if(pending.replyToId && pending.replyToId!==entry.id) {
        const followUpAt=Math.min(Math.max(at,pending.at+900),this.deadline-140);
        if(followUpAt>now)this.botPlans.push({id:bot.id,kind:'PUBLIC_CHAT',at:followUpAt,done:false,replyToId:entry.id});
      } else {
        pending.at=Math.min(pending.at,at);
        pending.replyToId=entry.id;
      }
      return;
    }
    this.botPlans.push({id:bot.id,kind:'PUBLIC_CHAT',at,done:false,replyToId:entry.id});
  }
  scheduleSecretReaction(sender, entry) {
    // Only the *contacted* teammate can reply. Never broadcast or let another bot read it.
    if (!entry || entry.channel !== 'SECRET' || sender.bot || !this.canChat(sender, 'SECRET')) return;
    const partner=this.players.find(p => p.bot && p.alive && p.id!==sender.id &&
      ['MAFIA','SPY'].includes(p.role) && this.canChat(p,'SECRET'));
    if (!partner || this.deadline-this.now()<1250) return;
    const pendingReplies=this.botPlans.filter(plan => !plan.done && plan.kind==='SECRET_CHAT' && plan.replyToId && plan.id===partner.id);
    if (pendingReplies.some(plan => plan.replyToId===entry.id) || pendingReplies.length>=15) return;
    const now=this.now();
    // Keep the existing question queued and append a follow-up. Do not overwrite a
    // player's earlier question just because they sent a second sentence.
    const previous=pendingReplies.reduce((mx,x)=>Math.max(mx,x.at),now);
    const at=Math.max(now+850,partner.lastChatAt+710,previous+(pendingReplies.length?740:0));
    if(at>=this.deadline-180)return;
    const unused=this.botPlans.find(plan => !plan.done && plan.id===partner.id && plan.kind==='SECRET_CHAT' && !plan.replyToId);
    if(unused && !pendingReplies.length) {
      unused.replyToId=entry.id;
      unused.at=at;
    } else {
      this.botPlans.push({id:partner.id,kind:'SECRET_CHAT',at,done:false,replyToId:entry.id});
    }
  }
  scheduleBots() {
    const duration = this.deadline !== null ? this.deadline - this.phaseStart : 0;
    const schedule = (p, kind, minFraction, maxFraction) => {
      const at = this.phaseStart + Math.max(80, duration * (minFraction + this.rng() * (maxFraction - minFraction)));
      this.botPlans.push({ id: p.id, kind, at, done: false });
    };
    if (this.phase === 'NIGHT') {
      for (const p of this.players.filter(x => x.bot && x.alive)) {
        if (this.usable(p)) {
          // Once partners can talk, let an AI Mafia consult the human Spy
          // before locking in an irreversible attack selection.
          if (p.role==='MAFIA' && this.canChat(p,'SECRET')) schedule(p,'ABILITY',0.73,0.83);
          else schedule(p,'ABILITY',0.05,0.22);
        }
        if (this.canChat(p, 'SECRET')) {
          schedule(p, 'SECRET_CHAT', 0.015, 0.12);
          if (this.rng() < 0.68) schedule(p, 'SECRET_CHAT', 0.26, 0.65);
        }
      }
    }
    if (['DAY', 'EXTRA_DISCUSSION'].includes(this.phase)) {
      const speakers=this.players.filter(x => x.bot && x.alive);
      const offset=speakers.length?Math.floor(this.rng()*speakers.length):0;
      for(let i=0;i<speakers.length;i++) {
        const p=speakers[(i+offset)%speakers.length];
        BotMind.mindFor(p,this.rng);
        // Space out contributions over the discussion instead of making every
        // bot interrupt at once in the first ten seconds.
        const fraction=0.055+(i+this.rng()*0.45)*0.78/speakers.length;
        this.botPlans.push({id:p.id,kind:'PUBLIC_CHAT',at:this.phaseStart+Math.max(80,duration*fraction),done:false});
        if(this.rng()<0.30)schedule(p,'PUBLIC_CHAT',0.72,0.92);
      }
    }
    if (['VOTE1', 'VOTE2'].includes(this.phase)) {
      for (const p of this.players.filter(x => x.bot && x.alive && this.stunnedId !== x.id)) {
        schedule(p, 'VOTE', 0.10, 0.60);
      }
    }
  }
  actBot(plan) {
    try {
      if (this.botController?.handlePlan?.(this,plan)) return;
    } catch (error) { /* Misconfigured optional LLM must not break game rules. */ }
    this.actBotLegacy(plan);
  }
  actBotLegacy(plan) {
    const p = this.getPlayer(plan.id);
    if (!p?.alive) return;
    try {
      if (plan.kind === 'ABILITY' && this.phase === 'NIGHT' && this.usable(p)) {
        const t = this.botNightTarget(p);
        if (t) {
          this.selectAbility(p, t);
          this.confirmAbility(p, t);
        }
      } else if (plan.kind === 'SECRET_CHAT' && this.canChat(p, 'SECRET')) {
        // Answer human turns before unsolicited strategizing. Preserve chat
        // cooldown without silently dropping a pending direct reply.
        if(!plan.replyToId && this.botPlans.some(q=>!q.done && q.id===p.id && q.kind==='SECRET_CHAT' && q.replyToId))return;
        if(this.now()-p.lastChatAt<660) {
          const at=p.lastChatAt+710;
          if(at<this.deadline-100)this.botPlans.push({...plan,at,done:false});
          return;
        }
        const line=this.botChatText(p,'SECRET',plan.replyToId);
        if(line)this.sendChat(p,'SECRET',line);
      } else if (plan.kind === 'PUBLIC_CHAT' && this.canChat(p, 'PUBLIC')) {
        // A direct reply should not be lost to the chat anti-spam cooldown.
        if(this.now()-p.lastChatAt<660) {
          const when=p.lastChatAt+690;
          if(when<this.deadline) this.botPlans.push({...plan,at:when,done:false});
          return;
        }
        const line=this.botChatText(p, 'PUBLIC', plan.replyToId);
        if(line)this.sendChat(p, 'PUBLIC', line);
      } else if (plan.kind === 'VOTE' && this.canVote(p) && !this.votes.has(p.id)) {
        this.submitVote(p, this.botVoteTarget(p));
      }
    } catch (e) { /* A bot missing a turn is subject to the ordinary automatic rules. */ }
  }
  tick() {
    if (this.deadline === null) return;
    const now = this.now();
    // Copy because actions can change the phase while iterating.
    for (const plan of this.botPlans.slice()) {
      if (plan.done || plan.at > now) continue;
      plan.done = true;
      const expected = this.phase;
      this.actBot(plan);
      if (this.phase !== expected) break;
    }
    if (this.deadline === null || now < this.deadline) return;
    switch (this.phase) {
      case 'NIGHT': this.resolveNight(); break;
      case 'NIGHT_RESULT': this.publishMorning(); break;
      case 'DAY': this.startVote(1); break;
      case 'VOTE1': case 'VOTE2': this.resolveVote(); break;
      case 'EXTRA_DISCUSSION': this.startVote(2); break;
      case 'VOTE_RESULT': this.startNight(); break;
      default: break;
    }
  }

  snapshotFor(p) {
    const finished = this.phase === 'GAME_OVER';
    const privateAction = this.actions.get(p?.id);
    const canSeeSecret = p && ['MAFIA', 'SPY'].includes(p.role) &&
      !!this.contact && this.night > this.contact.night;
    const seesPartner = !!p && ['MAFIA', 'SPY'].includes(p.role) && !!this.contact;
    const partner = seesPartner ? this.players.find(q => q.id !== p.id && ['MAFIA', 'SPY'].includes(q.role)) : null;
    return {
      code: this.code, phase: this.phase, phaseStart: this.phaseStart,
      deadline: this.deadline, serverNow: this.now(), night: this.night,
      players: this.players.map(x => ({ ...publicActor(x),
        ...(finished ? { role: x.role, team: x.team } : {}) })),
      hostId: this.hostId,
      seatsMax: 7,
      boxes: this.boxOwners ? this.boxOwners.map((id, index) => ({ index, chosen: id !== null,
        pickerId: id })) : [],
      me: p ? { id: p.id, number: p.number, name: p.name, role: p.role,
        roleKo: p.role ? ROLE_KO[p.role] : null, team: p.team, alive: p.alive,
        connected: p.connected, boxIndex: p.boxIndex, roleReady: p.roleReady,
        isHost: this.isHost(p), canAct: this.phase === 'NIGHT' && this.usable(p),
        validTargets: this.phase === 'NIGHT' ? this.validTargets(p) : [],
        action: privateAction ? { selected: privateAction.selected, confirmed: privateAction.confirmed,
          target: privateAction.target, auto: privateAction.auto } : null,
        teamAction: p.role === 'SPY' && this.phase === 'NIGHT' && this.contact &&
          this.night > this.contact.night && this.playerByRole('MAFIA')?.alive ? (() => {
            const a = this.actions.get(this.playerByRole('MAFIA').id);
            return a ? { selected:a.selected, confirmed:a.confirmed, target:a.target } : null;
          })() : null,
        canVote: this.canVote(p), voted: this.votes.has(p.id),
        stunned: this.stunnedId === p.id,
        canPublicChat: this.canChat(p, 'PUBLIC'), canSecretChat: this.canChat(p, 'SECRET'),
        notices: p.notices.slice(-12), investigations: p.investigations.slice(),
        contact: seesPartner ? { night: this.contact.night, type: this.contact.type,
          partnerId: partner?.id, partnerNumber: partner?.number, partnerName: partner?.name } : null } : null,
      publicLog: this.publicLog.slice(-18), publicChat: this.publicChat.slice(-80),
      secretChat: canSeeSecret ? this.secretChat.slice(-80) : [],
      voteOutcome: ['VOTE_RESULT', 'GAME_OVER'].includes(this.phase) ? this.voteOutcome : null,
      winningTeam: finished ? this.winningTeam : null,
      abortReason: this.phase === 'ABORTED' ? this.abortReason : null
    };
  }
}

module.exports = { MafiaRoom, ROLES, ROLE_KO, TEAM, DEFAULT_DURATIONS,
  shuffled, sanitizeChat, sanitizeName };

})(engineModule,engineModule.exports,(name)=>{
 if(name==='node:crypto')return cryptoShim;
 if(name==='./bot-mind')return botModule.exports;
 throw new Error('Offline engine cannot import '+name);
});
globalThis.NOIR_OFFLINE_ENGINE=engineModule.exports;
})();
