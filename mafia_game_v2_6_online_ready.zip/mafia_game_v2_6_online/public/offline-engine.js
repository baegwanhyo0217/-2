(function(){
'use strict';
const cryptoShim={
 randomUUID(){
  const a=new Uint8Array(16);
  if(globalThis.crypto?.getRandomValues)globalThis.crypto.getRandomValues(a);
  else for(let i=0;i<16;i++)a[i]=Math.floor(Math.random()*256);
  a[6]=(a[6]&15)|64;a[8]=(a[8]&63)|128;
  const h=Array.from(a,n=>n.toString(16).padStart(2,'0'));
  return h.slice(0,4).join('')+'-'+h.slice(4,6).join('')+'-'+h.slice(6,8).join('')+'-'+h.slice(8,10).join('')+'-'+h.slice(10).join('');
 },
 randomBytes(n){const a=new Uint8Array(n);if(globalThis.crypto?.getRandomValues)globalThis.crypto.getRandomValues(a);else for(let i=0;i<n;i++)a[i]=Math.floor(Math.random()*256);return {toString:()=>Array.from(a,b=>b.toString(16).padStart(2,'0')).join('')};}
};
const botModule={exports:{}};
(function(module,exports){
'use strict';

// Offline-first social-deduction agents. Each bot reads only public statements and
// its own role/investigations/contact information. No remote text API or cheat access.
// Speech is assembled from a context-specific argument, an attitude, evidence,
// and a question or conclusion; it is not a list of full canned chat messages.
const ROLE_WORDS = ['마피아', '스파이', '경찰', '의사', '건달', '시민'];
const PERSONAS = [
  { label:'신중', direct:0.25, talk:3, doubt:0.35, rhythm:['음','일단','잠깐'] },
  { label:'직설', direct:0.92, talk:5, doubt:0.62, rhythm:['잠깐만','솔직히'] },
  { label:'분석', direct:0.60, talk:4, doubt:0.75, rhythm:['정리하면','내 생각엔','일단 사실만 보면'] },
  { label:'감정', direct:0.82, talk:4, doubt:0.48, rhythm:['어','잠깐','이상한데'] },
  { label:'조용', direct:0.18, talk:2, doubt:0.27, rhythm:['음'] },
  { label:'설득', direct:0.60, talk:4, doubt:0.64, rhythm:['보니까','일단'] },
];

function choice(xs,rng) { return xs.length ? xs[Math.min(xs.length-1,Math.floor(rng()*xs.length))] : ''; }
function stamp(target) { return target ? `${target.number}번` : ''; }
function clamp(v,lo,hi) { return Math.min(hi,Math.max(lo,v)); }
function normalize(text) { return String(text||'').replace(/\s+/g,' ').trim(); }
function includesSelfClaim(text) {
  return /(?:나는|난|내가|제가|저는|전|나|내 직업|제 직업|저)\s*(?:(?:진짜|사실|원래|확실히)\s*)?(?:경찰|의사|시민|마피아|건달|스파이)/.test(text) ||
    /(?:경찰|의사|시민|마피아|건달|스파이)\s*(?:입니다|이에요|이야|인데|이니까)/.test(text) && !/(?:너|쟤|그 사람|\d번)\s*(?:경찰|의사|시민|마피아|건달|스파이)/.test(text);
}
function claimedRole(text) {
  const t=normalize(text);
  const original=t.match(/(?:나는|난|내가|제가|저는|전|나|내 직업|제 직업|저)\s*(?:(?:진짜|사실|원래|확실히)\s*)?(?:경찰|의사|시민|마피아|건달|스파이)/);
  const additional=t.match(new RegExp(`(?:^|\\s)(?:\\uB098\\uB3C4|\\uC800\\uB3C4)\\s*(${ROLE_WORDS.join('|')})`));
  const selected=original && additional ? (original.index<=additional.index?original:additional) : (original||additional);
  if(!selected)return null;
  const fragment=selected[0];
  const role=ROLE_WORDS.find(word=>fragment.endsWith(word));
  if(!role)return null;
  const rest=t.slice(selected.index+fragment.length);
  // A short question about one's own role is not a declaration; a completed
  // declaration followed by a separate question still counts.
  const firstPunctuation=rest.match(/[.!?\uFF1F]/)?.[0];
  if(firstPunctuation==='?' || firstPunctuation==='\uFF1F')return null;
  // Negative self-statements do not constitute a positive role claim.
  if(/^\s*(?:\uD300)?\s*(?:\uC774|\uAC00)?\s*\uC544\uB2C8/.test(rest))return null;
  return role;
}
function declaredStance(text,players) {
  const t=normalize(text);
  if(/[?？]/.test(t) || /(?:왜|누구|어떻게)\s*(?:찍|투표|스킵|건너뛰)/.test(t))return null;
  // Only *voluntary, stated* voting intentions are evidence, never inferred hidden votes.
  if(/(?:나는|난|내가|저는|전)\s*(?:이번엔|오늘|일단|지금은)?\s*(?:스킵|건너뛰)/.test(t) ||
    /(?:스킵|건너뛰)(?:하자|할게|할래|하고 싶어)/.test(t))return 'SKIP';
  const refs=mentions(t,players);
  const declares=/(?:찍을게|찍자|투표할게|투표하자|퇴출시키자|뽑을게|표\s*줄게)/.test(t);
  if(declares && refs.length)return refs[0];
  return null;
}
function mentions(text, players) {
  const found=[];
  for(const p of players) {
    const num = new RegExp(`(?:^|[^0-9])${p.number}\\s*(?:번|호|번님)(?![0-9])`);
    if (num.test(text) || (p.name && p.name.length>1 && text.includes(p.name))) found.push(p.id);
  }
  return found;
}
function mindFor(p,rng=Math.random) {
  if (!p.mind) p.mind = {
    persona: choice(PERSONAS,rng), suspicion:Object.create(null), trust:Object.create(null),
    claims:Object.create(null), observations:[], attacks:Object.create(null),
    accusations:[], seenPublic:[], seenSecret:[], spoken:[], turns:0,
    lastOpinion:null, lastRespondedId:null, visitedLast:[], watched:[],
    claimChanges:[], answerIds:[], publicStances:Object.create(null), stanceChanges:[]
  };
  return p.mind;
}
function adjust(mind,id,score) {
  if (!id) return;
  mind.suspicion[id]=clamp((mind.suspicion[id]||0)+score,-7,9);
}
function legalView(room,p) {
  const view=room.botKnowledge(p);
  const everyone=room.players.map(q=>({id:q.id,number:q.number,name:q.name,alive:q.alive,bot:q.bot}));
  return { ...view, everyone, publicChat:room.publicChat, publicLog:room.publicLog,
    publicVote:room.voteOutcome && ['VOTE_RESULT','GAME_OVER'].includes(room.phase) ? room.voteOutcome : null,
    phaseStart:room.phaseStart,
    secretChat:view.partnerId ? room.secretChat : [] };
}
function findOwnResult(view,id) {return view.investigations.findLast(x=>x.targetId===id) || null;}
function readStatements(p,view,rng) {
  const mind=mindFor(p,rng);
  const roster=view.everyone;
  for(const entry of view.publicChat) {
    if(mind.seenPublic.includes(entry.id)) continue;
    mind.seenPublic.push(entry.id);
    if(entry.senderId===p.id) continue;
    const words=normalize(entry.text);
    const refs=mentions(words,roster);
    const speaker=roster.find(x=>x.id===entry.senderId);
    if(!speaker) continue;
    const claim=claimedRole(words);
    if (claim) {
      const previous=mind.claims[speaker.id];
      if(previous && previous.role!==claim) {
        adjust(mind,speaker.id,2.3);
        mind.claimChanges.push({speakerId:speaker.id,from:previous.role,to:claim,id:entry.id,at:entry.at});
      }
      mind.claims[speaker.id]={role:claim,at:entry.at,text:words};
      // A police bot knows no other player can simultaneously be the police.
      if(view.role==='POLICE' && claim==='경찰') adjust(mind,speaker.id,5);
      // A spy can compare an actual investigated role against a claimant.
      const verified=findOwnResult(view,speaker.id);
      if(view.role==='SPY' && verified?.actualRole && claim && verified.displayed!==claim) adjust(mind,speaker.id,2.4);
      if(view.role==='POLICE' && verified?.displayed==='마피아팀' && claim!=='마피아') adjust(mind,speaker.id,4);
      if(claim==='경찰' && !/(조사|결과|\d번)/.test(words)) adjust(mind,speaker.id,0.4);
    }

    const aggressive=/(\uC758\uC2EC|\uC218\uC0C1|\uB9C8\uD53C\uC544|\uAC70\uC9D3|\uAD6C\uB77C|\uB9D0 \uBC14\uAFD4)/.test(words);
    const negated=/(\uC544\uB2C8|\uC5C6|\uB2E8\uC815\uD558\uC9C0|\uBABB \uBBFF|\uD655\uC2E4\uD558\uC9C0)/.test(words);
    const affirmative=/(\uB9C8\uD53C\uC544(?:\uD300)?\s*(?:\uAC19\uC544|\uC774\uC57C|\uC57C|\uB2E4)|\uC758\uC2EC\uD574|\uC218\uC0C1\uD574|\uAC70\uC9D3\uB9D0|\uAD6C\uB77C)/.test(words);
    const actualAccusation=aggressive && affirmative && !isQuestion(words) && !negated;
    if(actualAccusation && refs.length) {
      for(const id of refs) if(id!==speaker.id) {
        mind.accusations.push({by:speaker.id,target:id,text:words,at:entry.at});
        // Human testimony is a weak conversational signal, not proof.
        // Bot accusations never amplify another bot's suspicion score.
        if(!speaker.bot)adjust(mind,id,0.08);
      }
    }
    // Being challenged by another bot is not a reason to retaliate.
    if(actualAccusation && refs.includes(p.id))
      mind.attacks[speaker.id]=(mind.attacks[speaker.id]||0)+1;
    // A false investigation contradicting the agent's *own* information.
    const claimedInvestigation=/(조사|확인|결과)/.test(words);
    if(claimedInvestigation && refs.length && /(마피아팀|마피아라고|마피아야)/.test(words)) {
      const accused=refs.find(id=>id!==speaker.id) || refs[0];
      const own=findOwnResult(view,accused);
      if(view.role==='POLICE' && own?.displayed==='시민팀') adjust(mind,speaker.id,1.8);
      if(view.role==='SPY' && own?.actualRole && own.actualRole!=='MAFIA') adjust(mind,speaker.id,2);
    }
    const statedVote=declaredStance(words,roster);
    if(statedVote!==null) {
      const before=mind.publicStances[speaker.id];
      if(before && before!==statedVote) {
        mind.stanceChanges.push({speakerId:speaker.id,from:before,to:statedVote,at:entry.at,id:entry.id});
        // A changed opinion can have an innocent explanation.
      }
      mind.publicStances[speaker.id]=statedVote;
    }

    mind.observations.push({kind:'message',speakerId:speaker.id,mentions:refs,text:words,at:entry.at,id:entry.id,claim});
  }
  if(mind.seenPublic.length>250) mind.seenPublic=mind.seenPublic.slice(-250);
  if(mind.observations.length>80) mind.observations=mind.observations.slice(-80);
  if(mind.accusations.length>50) mind.accusations=mind.accusations.slice(-50);
  if(mind.claimChanges.length>30) mind.claimChanges=mind.claimChanges.slice(-30);
  if(mind.stanceChanges.length>30)mind.stanceChanges=mind.stanceChanges.slice(-30);
  // Only a contacted Mafia/Spy may inspect the secret messages.
  for(const entry of view.secretChat) {
    if(mind.seenSecret.includes(entry.id)) continue;
    mind.seenSecret.push(entry.id);
    if(entry.senderId===p.id) continue;
    mind.observations.push({kind:'secret',speakerId:entry.senderId,text:entry.text,at:entry.at,id:entry.id});
  }
  if(mind.seenSecret.length>150) mind.seenSecret=mind.seenSecret.slice(-150);
  return mind;
}
function chooseWeighted(items,rng) {
  const total=items.reduce((s,x)=>s+Math.max(0,x.w),0);
  let k=rng()*total;
  for(const entry of items) {k-=Math.max(0,entry.w);if(k<=0)return entry.item;}
  return items[items.length-1]?.item;
}
function candidates(p,view,validIds,excludeIds=[]) {
  const excluded=new Set([...excludeIds,p.id]);
  return view.alivePlayers.filter(q=>validIds.includes(q.id) && !excluded.has(q.id));
}
function suspicion(mind,view,id) {
  const v=mind.suspicion[id]||0;
  const result=view.investigations.findLast(i=>i.targetId===id);
  if(view.role==='POLICE') return v+(result?.displayed==='마피아팀'?12:result?.displayed==='시민팀'?-2.4:0);
  return v;
}
function strongestSuspect(p,view,mind,validIds) {
  const vals=candidates(p,view,validIds,view.partnerId?[view.partnerId]:[]);
  vals.sort((a,b)=>suspicion(mind,view,b.id)-suspicion(mind,view,a.id));
  return vals[0] || null;
}
function chooseNight(room,p,rng) {
  const view=legalView(room,p), mind=readStatements(p,view,rng);
  const opts=room.validTargets(p);
  if(!opts.length) return null;
  const possible=candidates(p,view,opts);
  if(p.role==='DOCTOR') {
    const likelyThreat = strongestSuspect(p,view,mind,opts);
    const publicTarget = view.publicChat.slice(-6).flatMap(x=>mentions(x.text,view.alivePlayers)).find(x=>x!==p.id);
    if(publicTarget && opts.includes(publicTarget) && rng()<0.26) return publicTarget;
    if(rng()<0.50 || !likelyThreat) return p.id;
    return choice(possible,rng)?.id || p.id;
  }
  if(['POLICE','SPY'].includes(p.role)) {
    const seen=new Set(view.investigations.map(x=>x.targetId));
    const fresh=possible.filter(x=>!seen.has(x.id));
    if(p.role==='SPY' && !view.partnerId) {
      // The spy cannot know which uninvestigated player is actually Mafia.
      const scored=fresh.slice().sort((a,b)=>(mind.suspicion[b.id]||0)-(mind.suspicion[a.id]||0));
      return (rng()<0.63 ? scored[0] : choice(fresh,rng))?.id || choice(possible,rng).id;
    }
    const scored=fresh.slice().sort((a,b)=>suspicion(mind,view,b.id)-suspicion(mind,view,a.id));
    return (rng()<0.72 ? scored[0] : choice(fresh,rng))?.id || choice(possible,rng).id;
  }
  if(p.role==='GANGSTER') {
    const suspect=strongestSuspect(p,view,mind,opts);
    if(suspect && suspicion(mind,view,suspect.id)>0.9 && rng()<0.72) return suspect.id;
  }
  if(p.role==='MAFIA') {
    const expectedTrust = possible.slice().sort((a,b)=>(mind.suspicion[a.id]||0)-(mind.suspicion[b.id]||0));
    return (rng()<0.60 ? choice(expectedTrust.slice(0,Math.min(3,expectedTrust.length)),rng) : choice(possible,rng))?.id;
  }
  return choice(possible,rng)?.id;
}
function chooseVote(room,p,rng) {
  const view=legalView(room,p),mind=readStatements(p,view,rng);
  const list=candidates(p,view,view.alivePlayers.map(q=>q.id),view.partnerId?[view.partnerId]:[]);
  if(!list.length) return 'SKIP';
  const winner=list.slice().sort((a,b)=>suspicion(mind,view,b.id)-suspicion(mind,view,a.id))[0];
  const score=suspicion(mind,view,winner.id);
  if(p.role==='POLICE' && score>8) return winner.id;
  if(p.team==='MAFIA') {
    // After contact, avoid voting out the known partner. Before contact, the spy is unknown.
    if(rng()<0.12 && score<0.4)return 'SKIP';
    return (score>0.25 || rng()<0.65) ? winner.id : choice(list,rng).id;
  }
  if(score>=1.4) return rng()<0.89?winner.id:'SKIP';
  if(view.night===1 && rng()<0.45) return 'SKIP';
  if(rng()<0.2) return 'SKIP';
  return rng()<0.63 ? winner.id : choice(list,rng).id;
}
// Public conversation analysis uses witnessed statements, not invented evidence.
// A question is handled as a request for an answer, never as an excuse to ask more questions.
function formatRef(view,id) {
  const q=view.everyone.find(x=>x.id===id);
  return q ? `${q.number}번` : '그 사람';
}
function makeSentence({preface,observation,argument,ask},rng) {
  const parts=[];
  if(preface && rng()<0.73)parts.push(preface);
  if(observation)parts.push(observation);
  if(argument)parts.push(argument);
  if(ask)parts.push(ask);
  return normalize(parts.join(' ')).slice(0,218);
}

function isQuestion(text) {
  const t=normalize(text).replace(/[.!~]+$/,'').trim();
  if(!t)return false;
  if(/[?\uFF1F]/.test(t))return true;
  // Natural requests without a question mark: explain, tell me, answer me.
  if(/(?:\uB9D0\uD574|\uB2F5\uD574|\uC54C\uB824|\uC124\uBA85\uD574|\uD574\uBA85\uD574)\s*(?:\uC918|\uBD10|\uC8FC\uC138\uC694)?$/.test(t))return true;
  // Common brief Korean questions where the player omitted punctuation.
  if(/(?:\uB204\uAD6C|\uB204\uAC00|\uC65C|\uC5B4\uB5BB\uAC8C|\uBB34\uC2A8|\uBB50)[^.!?]{0,70}(?:\uC57C|\uB0D0|\uB2C8|\uAC70\uC57C|\uAC70\uB2C8|\uAC8C|\uC0DD\uAC01\uD574|\uC758\uC2EC\uD574|\uAC19\uC544|\uD588\uC5B4|\uBBFF\uC5B4|\uCC0D\uC5B4)$/.test(t))return true;
  return /(?:\uB108|\uB10C|\uB124\uAC00|\uB2C8\uAC00|\uB2F9\uC2E0).*?(?:\uB9C8\uD53C\uC544|\uACBD\uCC30|\uC758\uC0AC|\uC2DC\uBBFC|\uC2A4\uD30C\uC774|\uAC74\uB2EC)(?:\uC57C|\uB2C8|\uB0D0|\uB9DE\uC544)$/.test(t);
}

function intentOf(text) {
  const t=normalize(text);
  if(!isQuestion(t))return null;
  if(/누가\s*(?:죽|사망)|(?:지난밤|어젯밤).*?(?:죽|사망)|사망자.*누구/.test(t))return 'death';
  if(/(?:조사.*?(?:누구|몇\s*번|결과|했어|했니|했냐|알려|말해)|(?:누구|몇\s*번).*?조사|조사\s*기록)/.test(t))return 'investigation';
  if(/(?:왜.*?(?:의심|수상|찍|마피아|못\s*믿)|(?:의심|수상).*?이유|근거|증거|해명|왜.*?그렇게|무슨\s*이유)/.test(t))return 'evidence';
  if(/(?:투표|스킵|건너뛰|누구\s*찍|누굴\s*찍|표를\s*줄)/.test(t))return 'vote';
  if(/(?:직업|(?:너|넌|네가|니가|당신).*?(?:경찰|의사|시민|스파이|마피아)|(?:경찰|의사|시민|스파이).*?(?:맞아|이야|인가|냐|니))/.test(t))return 'role';
  if(/(?:누가\s*마피아|누굴\s*의심|누구.*?의심|누구.*?수상|어떻게\s*생각|생각은|믿어|마피아.*?누구|\d+\s*번.*?(?:마피아|시민|의심|수상))/.test(t))return 'opinion';
  if(/[?？]|(?:말해|답해|알려|설명해)/.test(t))return 'general';
  return null;
}
function directAddressee(text,view) {
  const t=normalize(text);
  const match=t.match(/^(\d+)\s*번\s*(?:[,，:：]|님|너|넌|니가|네가|왜\s*(?:나|날|내))/);
  if(match) return view.everyone.find(q=>q.number===Number(match[1]))?.id || null;
  return null;
}
function askedForBot(obs,p,view,chat,forced=false) {
  if(!obs || (obs.senderId||obs.speakerId)===p.id || !intentOf(obs.text)) return false;
  if(forced)return true;
  const addressee=directAddressee(obs.text,view);
  if(addressee)return addressee===p.id;
  if(obs.mentions.includes(p.id) && /(?:너|네가|니가|넌|너는)/.test(obs.text))return true;
  // '너' after a bot's own statement is an implicit direct address.
  const idx=chat.findIndex(x=>x.id===obs.id);
  const prior=idx>0?chat[idx-1]:null;
  if(prior?.senderId===p.id && /(?:너|네가|니가|넌|너는|넌데)/.test(obs.text))return true;
  if(obs.mentions.length && !/다들|모두|여러분|누구든/.test(obs.text))return false;
  return /(?:다들|모두|여러분|누구|의견|어떻게|왜)/.test(obs.text);
}

function discussionLedger(room,phaseStart) {
  if(!room.aiDiscussionLedger || room.aiDiscussionLedger.phaseStart!==phaseStart)
    room.aiDiscussionLedger={phaseStart,answered:new Set(),topics:new Set(),genericCount:0};
  return room.aiDiscussionLedger;
}
function reserveTopic(room,phaseStart,key,generic=false) {
  const ledger=discussionLedger(room,phaseStart);
  if(ledger.topics.has(key) || (generic && ledger.genericCount>=6))return false;
  ledger.topics.add(key);
  if(generic)ledger.genericCount++;
  return true;
}

function pickQuestion(room,p,view,mind,replyToId) {
  const chat=view.publicChat;
  const answered=discussionLedger(room,view.phaseStart).answered;
  if(replyToId) {
    const chosen=chat.find(x=>x.id===replyToId);
    if(chosen && !answered.has(chosen.id) && !mind.answerIds.includes(chosen.id) && askedForBot({...chosen,mentions:mentions(chosen.text,view.everyone)},p,view,chat,true))return {...chosen,mentions:mentions(chosen.text,view.everyone)};
  }
  // Reply to a fresh question directed at this bot, otherwise respond to one open question.
  const recent=chat.slice(-14).filter(x=>x.at>=view.phaseStart && x.senderId!==p.id && !mind.answerIds.includes(x.id) && !answered.has(x.id))
    .map(x=>({...x,mentions:mentions(x.text,view.everyone)}));
  return recent.filter(x=>askedForBot(x,p,view,chat)).sort((a,b)=>{
    const da=Number(a.mentions.includes(p.id)),db=Number(b.mentions.includes(p.id));
    return (db-da)*100 + (chat.findIndex(x=>x.id===b.id)-chat.findIndex(x=>x.id===a.id));
  })[0]||null;
}
function factFor(p,view,mind,id,channel='PUBLIC') {
  if(!id)return null;
  const ref=formatRef(view,id);
  const own=findOwnResult(view,id);
  if(view.role==='POLICE' && own) return {strong:own.displayed==='마피아팀',targetId:id,
    text:`${own.night}번째 밤에 ${ref}을 조사했어. 결과는 ${own.displayed}이었어.${own.displayed==='시민팀'?' 다만 스파이도 시민팀으로 표시돼.':''}`,
    kind:'police-result'};
  if(channel==='SECRET' && view.role==='SPY' && own?.actualRole) return {strong:true,targetId:id,
    text:`접선 전에 ${ref}을 조사했고 실제 직업은 ${own.displayed}이었어.`,kind:'spy-result'};
  const shift=mind.claimChanges.findLast(x=>x.speakerId===id);
  if(shift) return {strong:true,targetId:id,
    text:`${ref}은 처음엔 ${shift.from}이라고 했다가 나중엔 ${shift.to}이라고 했어. 직업 주장이 바뀐 건 채팅에서 직접 확인했어.`,kind:'role-change'};
  if(view.role==='POLICE' && id!==p.id && mind.claims[id]?.role==='경찰') return {strong:true,targetId:id,
    text:`${ref}이 경찰이라고 주장했는데 나도 경찰이야. 경찰은 한 명뿐이니 둘 다 진짜일 수는 없어.`,kind:'counterclaim'};
  const changed=mind.stanceChanges.findLast(x=>x.speakerId===id);
  if(changed) {
    const phrase=value=>value==='SKIP'?'투표 건너뛰기':`${formatRef(view,value)} 투표`;
    return {strong:false,targetId:id,text:`${ref}은 아까 ${phrase(changed.from)}를 이야기했다가 ${phrase(changed.to)}로 입장을 바꿨어. 다만 입장이 바뀐 것만으로 마피아라고 단정할 수는 없어.`,kind:'changed-vote-intent'};
  }
  const claim=mind.claims[id];
  if(claim)return {strong:false,targetId:id,
    text:`${ref}은 자신이 ${claim.role}이라고 주장했어. 하지만 직업을 말했다고 실제로 증명된 건 아니야.`,kind:'unverified-claim'};
  // An accusation is evidence that the ACCUSATION was spoken, not proof of the target's team.
  const discussed=mind.accusations.findLast(x=>x.target===id && x.by!==p.id);
  if(discussed)return {strong:false,targetId:id,
    text:`${formatRef(view,discussed.by)}이 ${ref}을 의심한다고 말했어. 그 말만으로 ${ref}이 마피아라는 증거는 아니야.`,kind:'second-hand'};
  return null;
}
function evidenceAnswer(p,view,mind,id,{direct=false}={}) {
  const ref=formatRef(view,id);
  const evidence=factFor(p,view,mind,id);
  if(!evidence)return direct ?
    `${ref}을 의심할 만한 확인된 근거는 아직 없어. 내가 먼저 의심했다면 성급했어. 지금은 단정하지 않겠어.` :
    `${ref}에 대해 확인된 단서가 없어서 마피아라고 말할 수 없어.`;
  if(evidence.strong)return `${direct?'내가 그렇게 판단한 근거는 이거야. ':''}${evidence.text}`;
  return `${evidence.text} 그래서 지금은 의심만으로 몰아가면 안 된다고 봐.`;
}
function topicOf(question,p,view,mind) {
  const named=question.mentions.filter(x=>x!==p.id);
  if(named.length)return named[0];
  if(/(?:나를|날|내가|내\s*말|나는|난)\s*(?:왜|의심|찍)|왜\s*(?:나|날|내)/.test(question.text))return question.senderId||question.speakerId;
  if(mind.lastOpinion?.targetId && view.everyone.some(x=>x.id===mind.lastOpinion.targetId))return mind.lastOpinion.targetId;
  return question.senderId||question.speakerId;
}
function answerQuestion(room,p,view,mind,question,rng) {
  const intent=intentOf(question.text);
  const fromId=question.senderId||question.speakerId;
  const to=formatRef(view,fromId);
  const id=topicOf(question,p,view,mind),ref=formatRef(view,id);
  let response='';
  if(intent==='death') {
    const line=view.publicLog.filter(x=>/지난밤 .*사망|지난밤 사망자는 없습니다/.test(x.text)).at(-1);
    response=line ? `${line.text} 그게 지금 공개된 결과야. 사망 이유나 범인은 공개되지 않았어.` :
      `아직 공개된 사망 발표가 없어. 확인할 수 있는 정보만 가지고 이야기하자.`;
  } else if(intent==='investigation') {
    if(view.role==='POLICE') {
      const results=view.investigations.slice(-3);
      response=results.length ? `경찰 조사 결과는 ${results.map(x=>`${x.night}번째 밤 ${formatRef(view,x.targetId)}: ${x.displayed}`).join(', ')}야. 시민팀으로 나왔더라도 스파이일 가능성은 남아.` :
        `나는 경찰이지만 아직 공개할 조사 결과가 없어. 확인하지 않은 사람의 결과를 지어내지는 않을게.`;
    } else if(view.role==='SPY' || view.role==='MAFIA') {
      response=`조사 결과를 공개할 생각은 없어. 남들이 말하는 조사 주장도 검증 전에는 사실로 받아들이지 말자.`;
    } else {
      response=`나는 경찰 조사 결과를 갖고 있지 않아. 누구를 조사했다고 거짓으로 말할 수는 없어.`;
    }
  } else if(intent==='role') {
    if(/(?:너|넌|네가|니가|당신).*?마피아/.test(question.text)) {
      response=view.team==='MAFIA' ? `나는 마피아가 아니야. 다만 내 말을 믿으라는 주장만으로 판단하지는 마.` :
        `아니, 나는 마피아팀이 아니야. 물론 내 말도 공개된 행동과 대조해서 판단해 줘.`;
    } else if(id && id!==p.id && id!==fromId && !/(?:너|넌|네\s*직업|니\s*직업)/.test(question.text)) {
      const fact=factFor(p,view,mind,id);
      response=fact?fact.text:`${ref}의 실제 직업은 알 수 없어. 직접 확인한 결과 없이 단정하면 안 돼.`;
    } else if(view.role==='POLICE' && view.investigations.length) response=`나는 경찰이야. 내가 직접 확인한 결과는 ${view.investigations.map(x=>`${formatRef(view,x.targetId)} ${x.displayed}`).join(', ')}야.`;
    else if(view.team==='MAFIA')response=`지금 내 직업은 공개하지 않을게. 직업 주장만 듣고 믿기보다는 실제 발언을 비교해 보자.`;
    else response=rng()<0.60 ? `내 직업은 ${view.role==='CITIZEN'?'시민':view.role==='GANGSTER'?'건달':view.role==='DOCTOR'?'의사':'경찰'}이야. 이 말만으로 믿으라는 건 아니야.` :
      `직업은 아직 공개하지 않을게. 확실히 모르는 걸 아는 척하지는 않을 거야.`;
  } else if(intent==='vote') {
    const eligible=view.alivePlayers.filter(x=>x.id!==p.id && x.id!==view.partnerId);
    const top=strongestSuspect(p,view,mind,eligible.map(x=>x.id));
    const fact=top?factFor(p,view,mind,top.id):null;
    if(top && fact?.strong && suspicion(mind,view,top.id)>0.8)response=`현재는 ${formatRef(view,top.id)}에게 투표할 생각이야. ${fact.text}`;
    else response=`지금은 단독으로 퇴출시킬 만큼 확실한 근거가 없어서 건너뛰기를 고려하고 있어. 새 증거가 나오면 판단을 바꿀 거야.`;
  } else if(intent==='evidence' || intent==='opinion') {
    const direct=intent==='evidence';
    if(intent==='opinion' && /(?:누가|누구).*?(?:마피아|의심|수상)|(?:마피아|의심).*?누구/.test(question.text) && !question.mentions.length){
      const eligible=view.alivePlayers.filter(x=>x.id!==p.id && x.id!==view.partnerId);
      const withProof=eligible.map(x=>({x,fact:factFor(p,view,mind,x.id)})).filter(x=>x.fact?.strong);
      response=withProof.length ? `${formatRef(view,withProof[0].x.id)}을 우선 살펴봐야겠어. ${withProof[0].fact.text}` :
        `아직 누가 마피아인지 알 만한 확실한 단서가 없어. 누군가를 찍어서 말하지는 않겠어.`;
    } else response=evidenceAnswer(p,view,mind,id,{direct});
    if(direct && /(?:왜\s*(?:나|날|내)|나를.*의심)/.test(question.text) && id===p.id)response=evidenceAnswer(p,view,mind,fromId,{direct:true});
  } else {
    // Broad questions still receive a conclusion grounded in the visible discussion.
    const latest=mind.claimChanges.at(-1);
    if(latest)response=`지금 가장 확인할 만한 건 ${formatRef(view,latest.speakerId)}의 직업 주장이 바뀌었다는 점이야. 처음엔 ${latest.from}, 나중엔 ${latest.to}라고 했어.`;
    else response=`현재 확실한 정보는 낮에 공개된 발언과 밤 사망 발표뿐이야. 확인되지 않은 직업이나 공격 대상을 사실처럼 말하지 않겠어.`;
  }
  discussionLedger(room,view.phaseStart).answered.add(question.id);
  mind.answerIds.push(question.id);
  if(mind.answerIds.length>100)mind.answerIds=mind.answerIds.slice(-100);
  return normalize(`${to}, ${response}`).slice(0,218);
}
function decideSpeech(room,p,channel,rng,options={}) {
  const view=legalView(room,p),mind=readStatements(p,view,rng),profile=mind.persona;
  mind.turns++;
  const opener=choice(profile.rhythm,rng);
  if(channel==='SECRET') {
    const fresh=view.investigations.filter(x=>x.actualRole && x.actualRole!=='MAFIA' && view.alivePlayers.some(y=>y.id===x.targetId))
      .find(x=>!mind.spoken.includes('spy:'+x.targetId));
    if(p.role==='SPY' && fresh) {
      mind.spoken.push('spy:'+fresh.targetId);
      return `${formatRef(view,fresh.targetId)}을 조사했고 실제 직업은 ${fresh.displayed}이었어. 이건 내가 직접 알아낸 정보야. 살해 대상을 정할 때 참고해.`;
    }
    const focus=strongestSuspect(p,view,mind,view.alivePlayers.map(x=>x.id));
    return p.role==='MAFIA' ? `오늘 공격 대상은 내가 정할게. ${focus?formatRef(view,focus.id)+'은 공개 채팅에서 언급됐지만':'공개된 정보가 부족하니'} 이유 없이 단정하지 말고 판단하자.` :
      `지금까지 얻은 조사 정보와 낮 채팅을 함께 보자. 최종 공격 대상은 네가 정해.`;
  }
  const asked=pickQuestion(room,p,view,mind,options.replyToId);
  if(asked) return answerQuestion(room,p,view,mind,asked,rng);
  const mafiaResult=view.role==='POLICE' && view.investigations.findLast(x=>x.displayed==='마피아팀' && view.alivePlayers.some(y=>y.id===x.targetId));
  if(mafiaResult && !mind.spoken.includes('police:'+mafiaResult.targetId) && reserveTopic(room,view.phaseStart,'police-result:'+p.id+':'+mafiaResult.targetId)) {
    mind.spoken.push('police:'+mafiaResult.targetId);
    return `내가 경찰이고 ${mafiaResult.night}번째 밤에 ${formatRef(view,mafiaResult.targetId)}을 조사했어. 결과는 마피아팀이야. 그 사람이 왜 의심받는지 설명할 수 있는 실제 조사 결과야.`;
  }
  const counter=Object.entries(mind.claims).find(([id,c])=>id!==p.id && c.role==='경찰' && view.role==='POLICE');
  if(counter && !mind.spoken.includes('counter:'+counter[0]) && reserveTopic(room,view.phaseStart,'counterclaim:'+p.id+':'+counter[0])) {
    mind.spoken.push('counter:'+counter[0]);
    return `${formatRef(view,counter[0])}은 경찰이라고 주장했지. 나도 경찰이야. 경찰은 한 명뿐이니까 둘 다 진짜일 수는 없어. 이게 내 의심의 이유야.`;
  }
  const shift=mind.claimChanges.findLast(x=>!mind.spoken.includes('changed:'+x.id) && !discussionLedger(room,view.phaseStart).topics.has('role-change:'+x.id));
  if(shift) {
    reserveTopic(room,view.phaseStart,'role-change:'+shift.id);
    mind.spoken.push('changed:'+shift.id);
    mind.lastOpinion={targetId:shift.speakerId,reason:'role-change'};
    return `${formatRef(view,shift.speakerId)}은 앞에서 ${shift.from}, 뒤에는 ${shift.to}이라고 했어. 직업 주장이 바뀐 건 실제 채팅에 남아 있으니 그 이유를 확인하고 판단하자.`;
  }
  const voteShift=mind.stanceChanges.findLast(x=>!mind.spoken.includes('vote-shift:'+x.id) && !discussionLedger(room,view.phaseStart).topics.has('vote-shift:'+x.id));
  if(voteShift) {
    reserveTopic(room,view.phaseStart,'vote-shift:'+voteShift.id);
    mind.spoken.push('vote-shift:'+voteShift.id);
    const phrase=value=>value==='SKIP'?'건너뛰기':formatRef(view,value)+' 투표';
    return `${formatRef(view,voteShift.speakerId)}은 처음엔 ${phrase(voteShift.from)}, 지금은 ${phrase(voteShift.to)}라고 했어. 생각이 바뀔 순 있지만 이유는 아직 확인되지 않았어.`;
  }
  const lastClaim=Object.entries(mind.claims).find(([id,c])=>!mind.spoken.includes('claim:'+id+':'+c.role) && !discussionLedger(room,view.phaseStart).topics.has('claim:'+id+':'+c.role) && !mind.claimChanges.some(x=>x.speakerId===id) && id!==p.id);
  if(lastClaim) {
    reserveTopic(room,view.phaseStart,'claim:'+lastClaim[0]+':'+lastClaim[1].role);
    mind.spoken.push('claim:'+lastClaim[0]+':'+lastClaim[1].role);
    return `${formatRef(view,lastClaim[0])}이 ${lastClaim[1].role}이라고 주장했어. 말 자체는 확인됐지만 진짜 그 직업인지는 아직 증명되지 않았어. 말과 조사 결과는 구분해야 해.`;
  }
  const list=view.alivePlayers.filter(x=>x.id!==p.id);
  const strong=list.map(x=>({q:x,fact:factFor(p,view,mind,x.id)}))
    .filter(x=>x.fact?.strong).sort((a,b)=>suspicion(mind,view,b.q.id)-suspicion(mind,view,a.q.id));
  const topicForFact=entry=>{
    if(entry.fact.kind==='role-change') {
      const shift=mind.claimChanges.findLast(x=>x.speakerId===entry.q.id);
      return shift?'role-change:'+shift.id:null;
    }
    if(entry.fact.kind==='police-result')return 'police-result:'+p.id+':'+entry.q.id;
    if(entry.fact.kind==='counterclaim')return 'counterclaim:'+p.id+':'+entry.q.id;
    return 'fact:'+entry.q.id+':'+entry.fact.kind;
  };
  if(strong.length) {
    const entry=strong.find(x=>topicForFact(x) && !discussionLedger(room,view.phaseStart).topics.has(topicForFact(x)));
    if(entry) {
      reserveTopic(room,view.phaseStart,topicForFact(entry));
      mind.spoken.push('fact:'+entry.q.id+':'+entry.fact.kind);
      mind.lastOpinion={targetId:entry.q.id,reason:entry.fact.kind};
      return `${opener}, ${entry.fact.text} 이건 막연한 느낌이 아니라 확인 가능한 단서야.`;
    }
  }
  const publicResult=view.publicLog.findLast(x=>/지난밤 .*사망|지난밤 사망자는 없습니다/.test(x.text));
  const topics=[
    `현재 공개된 사실은 ${publicResult?.text || '아직 밤 사망 결과가 없다는 점'}이야. 그 이유가 누구 때문인지는 알려지지 않았어.`,
    `나는 아직 누가 마피아인지 확신할 증거가 없어. 말투만으로 누군가를 퇴출시키는 건 위험해.`,
    `누가 다른 사람을 의심한다는 사실과 실제로 마피아라는 증거는 달라. 두 가지를 구분해서 판단하자.`,
    `자기 직업을 주장하는 건 누구나 할 수 있어. 조사 내용이나 앞서 했던 말과 맞는지 확인해야 해.`,
    `확실한 근거가 없으면 이번 투표를 건너뛰고 다음 밤 정보를 기다리는 것도 합리적이야.`,
    `나는 지금은 판단을 보류할게. 새 단서가 나오기 전까지 같은 의심을 반복하지는 않겠어.`
  ];
  const offset=(p.number + Math.floor(view.night||1)*2 + mind.turns-1)%topics.length;
  const index=Array.from({length:topics.length},(_,i)=>(offset+i)%topics.length)
    .find(i=>reserveTopic(room,view.phaseStart,'topic:'+i,true));
  if(index===undefined)return null;
  mind.spoken.push('topic:'+index);
  if(mind.spoken.length>160)mind.spoken=mind.spoken.slice(-120);
  return `${opener}, ${topics[index]}`;
}

module.exports={ mindFor, legalView, readStatements, decideSpeech, chooseNight, chooseVote, claimedRole, mentions, isQuestion };

})(botModule,botModule.exports);
const engineModule={exports:{}};
(function(module,exports,require){
'use strict';

const crypto = require('node:crypto');
const BotMind = require('./bot-mind');
const ROLES = ['MAFIA', 'SPY', 'POLICE', 'DOCTOR', 'GANGSTER', 'CITIZEN', 'CITIZEN'];
const ROLE_KO = {
  MAFIA: '마피아', SPY: '스파이', POLICE: '경찰', DOCTOR: '의사',
  GANGSTER: '건달', CITIZEN: '시민'
};
const TEAM = { MAFIA: 'MAFIA', SPY: 'MAFIA', POLICE: 'CITIZEN',
  DOCTOR: 'CITIZEN', GANGSTER: 'CITIZEN', CITIZEN: 'CITIZEN' };
const DEFAULT_DURATIONS = {
  NIGHT: 60000, NIGHT_RESULT: 4500, DAY: 60000,
  VOTE1: 30000, EXTRA_DISCUSSION: 45000, VOTE2: 30000,
  VOTE_RESULT: 4500
};
const MAX_CHAT_LENGTH = 220;
const BOT_NAMES = ['도윤', '서아', '민준', '하린', '지호', '수빈', '유진'];

function rule(condition, message) { if (!condition) throw new Error(message); }
function shuffled(items, rng) {
  const out = items.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}
function pick(items, rng) { return items.length ? items[Math.floor(rng() * items.length)] : null; }
function sanitizeName(value) {
  return String(value || '').replace(/[\r\n<>]/g, '').trim().slice(0, 18) || '익명';
}
function sanitizeChat(value) {
  return String(value || '').replace(/[\u0000-\u001F\u007F]/g, '').trim().slice(0, MAX_CHAT_LENGTH);
}
function publicActor(p) {
  return { id: p.id, number: p.number, name: p.name, bot: p.bot, alive: p.alive,
    boxPicked: p.boxIndex !== null, roleReady: p.roleReady };
}

class MafiaRoom {
  constructor(code, options = {}) {
    this.code = code;
    this.now = options.now || Date.now;
    this.rng = options.rng || Math.random;
    this.durations = { ...DEFAULT_DURATIONS, ...options.durations };
    this.onChange = options.onChange || (() => {});
    this.players = [];
    this.hostId = null;
    this.phase = 'LOBBY';
    this.phaseStart = this.now();
    this.deadline = null;
    this.night = 0;
    this.boxAssignments = null;
    this.boxOwners = null;
    this.actions = new Map();
    this.votes = new Map();
    this.contact = null;
    this.stunnedId = null;
    this.pendingNight = null;
    this.voteOutcome = null;
    this.publicLog = [];
    this.publicChat = [];
    this.secretChat = [];
    this.winningTeam = null;
    this.abortReason = null;
    this.botPlans = [];
    this.updatedAt = this.now();
  }

  update() { this.updatedAt = this.now(); this.onChange(this); }
  getPlayer(id) { return this.players.find(p => p.id === id); }
  hasActiveMatch() { return !['LOBBY', 'ABORTED', 'GAME_OVER'].includes(this.phase); }
  isHost(p) { return !!p && p.id === this.hostId; }
  ensureHost(p) { rule(this.isHost(p), '방장만 사용할 수 있습니다.'); }
  ensurePhase(...phases) { rule(phases.includes(this.phase), '현재 단계에서는 사용할 수 없습니다.'); }
  nextNumber() {
    for (let n = 1; n <= 7; n++) if (!this.players.some(p => p.number === n)) return n;
    return null;
  }

  createPlayer(name, bot = false) {
    this.ensurePhase('LOBBY');
    rule(this.players.length < 7, '방 인원이 가득 찼습니다.');
    const id = crypto.randomUUID();
    const p = {
      id, number: this.nextNumber(), name: sanitizeName(name), bot,
      token: bot ? null : crypto.randomBytes(24).toString('hex'),
      connected: false, connection: null, role: null, team: null, alive: true,
      boxIndex: null, roleReady: false, notices: [], investigations: [],
      lastChatAt: -Infinity
    };
    this.players.push(p);
    if (!this.hostId && !bot) this.hostId = id;
    this.log(`${p.number}번 ${p.name}님이 입장했습니다.${bot ? ' (AI)' : ''}`);
    this.update();
    return p;
  }

  addBots(actor, count = 1) {
    this.ensureHost(actor);
    this.ensurePhase('LOBBY');
    rule(Number.isInteger(count) && count >= 1 && count <= 6, 'AI 추가 인원이 올바르지 않습니다.');
    rule(this.players.length + count <= 7, '참가 인원은 7명까지입니다.');
    for (let i = 0; i < count; i++) {
      const used = new Set(this.players.map(p => p.name));
      const name = BOT_NAMES.find(n => !used.has(n)) || `AI ${i + 1}`;
      this.createPlayer(name, true);
    }
  }
  removeBots(actor) {
    this.ensureHost(actor);
    this.ensurePhase('LOBBY');
    this.players = this.players.filter(p => !p.bot);
    this.log('AI 플레이어를 제거했습니다.');
    this.update();
  }
  removeHuman(p, reason = '접속 종료') {
    if (!this.players.includes(p)) return;
    const mustAbort = this.hasActiveMatch();
    this.players = this.players.filter(x => x.id !== p.id);
    if (this.hostId === p.id) this.hostId = this.players.find(x => !x.bot)?.id || null;
    if (mustAbort) this.abort(`${p.number}번 ${p.name}: ${reason}`);
    else { this.log(`${p.number}번 ${p.name}님이 나갔습니다.`); this.update(); }
  }

  log(text) {
    this.publicLog.push({ at: this.now(), text });
    if (this.publicLog.length > 50) this.publicLog.shift();
  }
  notice(p, text, type = 'info') {
    if (!p) return;
    p.notices.push({ id: crypto.randomUUID(), at: this.now(), text, type });
    if (p.notices.length > 20) p.notices.shift();
  }
  phaseTo(phase, duration = null) {
    this.phase = phase;
    this.phaseStart = this.now();
    this.deadline = duration === null ? null : this.phaseStart + duration;
    this.botPlans = [];
    this.scheduleBots();
    this.update();
  }

  startDraft(actor) {
    this.ensureHost(actor);
    this.ensurePhase('LOBBY');
    rule(this.players.length === 7, '게임을 시작하려면 7명이 필요합니다.');
    rule(this.players.filter(p => !p.bot).every(p => p.connected), '모든 실제 플레이어가 연결되어야 합니다.');
    this.clearRoundState();
    this.boxAssignments = shuffled(ROLES, this.rng);
    this.boxOwners = Array(7).fill(null);
    this.log('직업 상자 7개가 준비되었습니다. 각자 한 개를 선택하세요.');
    this.phaseTo('BOXES');
  }
  clearRoundState() {
    this.night = 0;
    this.contact = null;
    this.stunnedId = null;
    this.pendingNight = null;
    this.voteOutcome = null;
    this.winningTeam = null;
    this.abortReason = null;
    this.publicChat = [];
    this.secretChat = [];
    this.actions.clear();
    this.votes.clear();
    for (const p of this.players) {
      p.role = null; p.team = null; p.alive = true; p.boxIndex = null;
      p.roleReady = false; p.notices = []; p.investigations = []; p.mind = null;
    }
  }
  chooseBox(p, index) {
    this.ensurePhase('BOXES');
    rule(p && this.players.includes(p), '참가자만 상자를 선택할 수 있습니다.');
    rule(!p.bot, 'AI의 상자는 서버가 배정합니다.');
    rule(Number.isInteger(index) && index >= 0 && index < 7, '올바르지 않은 상자입니다.');
    rule(p.boxIndex === null, '이미 상자를 선택했습니다.');
    rule(this.boxOwners[index] === null, '이미 선택된 상자입니다.');
    this.assignBox(p, index);
    this.completeBotBoxesIfReady();
    this.update();
  }
  assignBox(p, index) {
    this.boxOwners[index] = p.id;
    p.boxIndex = index;
    p.role = this.boxAssignments[index];
    p.team = TEAM[p.role];
    this.notice(p, `당신의 직업은 ${ROLE_KO[p.role]}입니다.`, 'role');
  }
  completeBotBoxesIfReady() {
    if (!this.players.filter(p => !p.bot).every(p => p.boxIndex !== null)) return;
    for (const p of this.players.filter(p => p.bot)) {
      const open = this.boxOwners.map((owner, i) => owner === null ? i : -1).filter(i => i !== -1);
      this.assignBox(p, pick(open, this.rng));
      p.roleReady = true;
    }
    this.maybeBeginAfterDraft();
  }
  confirmRole(p) {
    this.ensurePhase('BOXES');
    rule(p && p.boxIndex !== null, '먼저 직업 상자를 선택하세요.');
    p.roleReady = true;
    this.maybeBeginAfterDraft();
    this.update();
  }
  maybeBeginAfterDraft() {
    if (this.players.length === 7 && this.players.every(p => p.boxIndex !== null && p.roleReady)) this.startNight();
  }

  usable(p) {
    if (!p || !p.alive) return false;
    if (p.role === 'CITIZEN') return false;
    if (p.role === 'SPY' && this.contact && this.night > this.contact.night) return false;
    return true;
  }
  validTargets(p) {
    if (!this.usable(p)) return [];
    return this.players.filter(q => q.alive && (
      p.role === 'DOCTOR' || q.id !== p.id
    ) && !(
      p.role === 'MAFIA' && this.contact && this.night > this.contact.night && q.role === 'SPY'
    )).map(q => q.id);
  }
  startNight() {
    this.night += 1;
    this.pendingNight = null;
    this.stunnedId = null;
    this.actions.clear();
    this.voteOutcome = null;
    for (const p of this.players) if (this.usable(p)) {
      this.actions.set(p.id, { selected: null, confirmed: false, target: null,
        auto: false, fromLastSelection: false, confirmedAt: null });
    }
    this.log(`${this.night}번째 밤이 시작되었습니다.`);
    this.phaseTo('NIGHT', this.durations.NIGHT);
  }
  selectAbility(p, targetId) {
    this.ensurePhase('NIGHT');
    rule(this.usable(p), '야간 능력을 사용할 수 없습니다.');
    const action = this.actions.get(p.id);
    rule(action && !action.confirmed, '이미 행동을 확정하여 변경할 수 없습니다.');
    rule(this.validTargets(p).includes(targetId), '해당 플레이어는 선택할 수 없습니다.');
    action.selected = targetId;
    this.update();
  }
  confirmAbility(p, targetId) {
    this.ensurePhase('NIGHT');
    const action = this.actions.get(p?.id);
    rule(action && !action.confirmed, '행동을 확정할 수 없습니다.');
    rule(action.selected !== null && action.selected === targetId, '먼저 대상을 임시 선택하세요.');
    rule(this.validTargets(p).includes(targetId), '유효하지 않은 대상입니다.');
    action.confirmed = true;
    action.target = targetId;
    action.confirmedAt = this.now();
    this.notice(p, '능력 사용 대상이 확정되었습니다. 더 이상 변경할 수 없습니다.');
    if (this.allActionsConfirmed()) this.resolveNight();
    else this.update();
  }
  allActionsConfirmed() {
    return Array.from(this.actions.values()).every(a => a.confirmed);
  }
  finalizeNightActions() {
    for (const [id, action] of this.actions) {
      if (action.confirmed) continue;
      const p = this.getPlayer(id);
      if (action.selected !== null && this.validTargets(p).includes(action.selected)) {
        action.target = action.selected;
        action.fromLastSelection = true;
        this.notice(p, '제한 시간이 종료되어 마지막으로 선택한 대상이 확정되었습니다.');
      } else if (p.role === 'DOCTOR') {
        action.target = p.id;
        action.auto = true;
        this.notice(p, '대상을 선택하지 않아 자신을 자동 치료합니다.');
      } else {
        action.target = pick(this.validTargets(p), this.rng);
        action.auto = true;
        this.notice(p, '제한 시간이 종료되어 대상이 자동 선택되었습니다.');
      }
      action.confirmed = true;
      action.confirmedAt = this.now();
    }
  }
  playerByRole(role) { return this.players.find(p => p.role === role); }
  actionTarget(role) {
    const p = this.playerByRole(role);
    return p && this.actions.get(p.id)?.target || null;
  }
  resolveNight() {
    if (this.phase !== 'NIGHT') return;
    this.finalizeNightActions();
    const mafia = this.playerByRole('MAFIA');
    const spy = this.playerByRole('SPY');
    const police = this.playerByRole('POLICE');
    const doctor = this.playerByRole('DOCTOR');
    const gangster = this.playerByRole('GANGSTER');
    const mafiaTarget = this.actionTarget('MAFIA');
    const spyTarget = this.actionTarget('SPY');
    const policeTarget = this.actionTarget('POLICE');
    const doctorTarget = this.actionTarget('DOCTOR');
    const gangsterTarget = this.actionTarget('GANGSTER');

    // Investigations are simultaneous, irrespective of the order in which clients submitted.
    if (spyTarget && spy?.alive && this.actions.has(spy.id)) {
      const target = this.getPlayer(spyTarget);
      spy.investigations.push({ night: this.night, targetId: target.id,
        actualRole: target.role, displayed: ROLE_KO[target.role] });
      this.notice(spy, `${target.number}번 ${target.name}의 실제 직업: ${ROLE_KO[target.role]}`, 'investigation');
    }
    if (policeTarget && police?.alive) {
      const target = this.getPlayer(policeTarget);
      const displayed = target.role === 'MAFIA' ? '마피아팀' : '시민팀';
      police.investigations.push({ night: this.night, targetId: target.id, displayed });
      this.notice(police, `${target.number}번 ${target.name}의 소속 조사 결과: ${displayed}`, 'investigation');
    }

    const beforeContact = !this.contact;
    const contactA = beforeContact && spy?.alive && spyTarget === mafia?.id;
    const contactB = beforeContact && spy?.alive && mafiaTarget === spy.id;
    if (contactA || contactB) {
      this.contact = { night: this.night, type: contactA ? 'A' : 'B' };
      this.notice(mafia, '스파이와 접선했습니다. 다음 날 밤부터 비밀 채팅을 사용할 수 있습니다.', 'contact');
      this.notice(spy, '마피아와 접선했습니다. 다음 날 밤부터 비밀 채팅을 사용할 수 있으며 조사 능력은 종료됩니다.', 'contact');
    }
    const attackCanceled = !!(spy?.alive && mafiaTarget === spy.id);
    if (attackCanceled && mafia) {
      this.notice(mafia, '스파이 대상 공격이 취소되었습니다. 이번 밤에는 추가 공격할 수 없습니다.', 'contact');
    }
    const effectiveAttack = attackCanceled ? null : mafiaTarget;
    const saved = !!(effectiveAttack && doctor?.alive && doctorTarget === effectiveAttack);
    const deathId = effectiveAttack && !saved ? effectiveAttack : null;
    if (doctor?.alive && doctorTarget) {
      this.notice(doctor, saved ? '당신이 선택한 플레이어를 살렸습니다.' :
        '당신이 선택한 플레이어는 공격받지 않았습니다.', saved ? 'success' : 'info');
    }
    this.pendingNight = { deathId, stunId: gangster?.alive ? gangsterTarget : null,
      attackTargetId: mafiaTarget, effectiveAttack, saved, contactType: contactA ? 'A' : contactB ? 'B' : null };
    this.phaseTo('NIGHT_RESULT', this.durations.NIGHT_RESULT);
  }
  publishMorning() {
    if (this.phase !== 'NIGHT_RESULT') return;
    const result = this.pendingNight || {};
    const victim = result.deathId ? this.getPlayer(result.deathId) : null;
    if (victim) victim.alive = false;
    const stunned = result.stunId ? this.getPlayer(result.stunId) : null;
    this.stunnedId = stunned?.alive ? stunned.id : null;
    if (stunned?.alive) this.notice(stunned, '당신은 오늘 투표에 참여할 수 없습니다.', 'warning');
    if (victim) this.log(`지난밤 ${victim.number}번 ${victim.name}이(가) 사망했습니다.`);
    else this.log('지난밤 사망자는 없습니다.');
    if (this.checkVictory()) return;
    this.log('날이 밝았습니다. 1분 동안 토론을 진행해 주세요.');
    this.phaseTo('DAY', this.durations.DAY);
  }

  canChat(p, channel = 'PUBLIC') {
    if (!p || !p.alive || !this.players.includes(p)) return false;
    if (channel === 'PUBLIC') return ['DAY', 'EXTRA_DISCUSSION'].includes(this.phase);
    if (channel === 'SECRET') return this.phase === 'NIGHT' &&
      !!this.contact && this.night > this.contact.night &&
      ['MAFIA', 'SPY'].includes(p.role) &&
      this.playerByRole('MAFIA')?.alive && this.playerByRole('SPY')?.alive;
    return false;
  }
  sendChat(p, channel, input) {
    rule(this.canChat(p, channel), '현재 채팅을 사용할 수 없습니다.');
    const text = sanitizeChat(input);
    rule(text.length > 0, '채팅 메시지를 입력하세요.');
    rule(this.now() - p.lastChatAt >= 650, '메시지를 너무 빠르게 보내고 있습니다.');
    // Minimal abuse filter, not a game mechanic. Messages are always rendered as text, never HTML.
    rule(!/(?:시발|씨발|병신|개새끼)/i.test(text), '부적절한 표현은 전송할 수 없습니다.');
    p.lastChatAt = this.now();
    const entry = { id: crypto.randomUUID(), at: this.now(), senderId: p.id,
      number: p.number, name: p.name, bot: p.bot, text, channel };
    const arr = channel === 'SECRET' ? this.secretChat : this.publicChat;
    arr.push(entry);
    if (arr.length > 100) arr.shift();
    this.update();
    if (channel === 'PUBLIC') this.scheduleReactions(p, text, entry);
  }

  startVote(number) {
    this.votes.clear();
    this.voteOutcome = null;
    this.log(number === 1 ? '1차 투표가 시작되었습니다.' : '재투표가 시작되었습니다.');
    this.phaseTo(number === 1 ? 'VOTE1' : 'VOTE2', this.durations[number === 1 ? 'VOTE1' : 'VOTE2']);
  }
  canVote(p) {
    return !!p && p.alive && this.stunnedId !== p.id &&
      ['VOTE1', 'VOTE2'].includes(this.phase);
  }
  submitVote(p, targetId) {
    rule(this.canVote(p), '투표할 수 없습니다.');
    rule(!this.votes.has(p.id), '이미 투표를 제출했습니다.');
    rule(targetId === 'SKIP' || (targetId !== p.id &&
      this.players.some(q => q.id === targetId && q.alive)), '유효하지 않은 투표 대상입니다.');
    this.votes.set(p.id, { targetId, at: this.now() });
    this.notice(p, targetId === 'SKIP' ? '투표 건너뛰기를 제출했습니다.' : '투표를 제출했습니다.');
    this.update();
  }
  tallyVote() {
    const counts = new Map();
    for (const entry of this.votes.values()) {
      counts.set(entry.targetId, (counts.get(entry.targetId) || 0) + 1);
    }
    if (!this.votes.size) return { kind: 'EMPTY', counts: [], valid: 0 };
    const max = Math.max(...counts.values());
    const winners = Array.from(counts.entries()).filter(([, n]) => n === max).map(([id]) => id);
    const list = Array.from(counts.entries()).map(([targetId, count]) => ({ targetId, count }));
    return { kind: winners.length > 1 ? 'TIE' : winners[0] === 'SKIP' ? 'SKIP' : 'EXPEL',
      targetId: winners.length === 1 ? winners[0] : null,
      tiedIds: winners.length > 1 ? winners : [], counts: list, valid: this.votes.size };
  }
  resolveVote() {
    if (!['VOTE1', 'VOTE2'].includes(this.phase)) return;
    const isFirst = this.phase === 'VOTE1';
    const outcome = this.tallyVote();
    this.voteOutcome = { ...outcome, round: isFirst ? 1 : 2 };
    if (outcome.kind === 'TIE' && isFirst) {
      this.log('최다 득표 동률이 발생했습니다. 45초 동안 추가 토론합니다.');
      this.phaseTo('EXTRA_DISCUSSION', this.durations.EXTRA_DISCUSSION);
      return;
    }
    if (outcome.kind === 'EXPEL') {
      const eliminated = this.getPlayer(outcome.targetId);
      eliminated.alive = false;
      this.log(`투표 결과 ${eliminated.number}번 ${eliminated.name}이(가) 퇴출되었습니다.`);
      if (this.checkVictory()) return;
    } else if (outcome.kind === 'SKIP') {
      this.log('투표 건너뛰기가 단독 최다 득표했습니다. 퇴출자는 없습니다.');
    } else if (outcome.kind === 'EMPTY') {
      this.log('유효표가 없습니다. 투표 무효, 퇴출자는 없습니다.');
    } else {
      this.log('재투표에서도 동률이 발생했습니다. 퇴출자는 없습니다.');
    }
    this.phaseTo('VOTE_RESULT', this.durations.VOTE_RESULT);
  }
  checkVictory() {
    const mafia = this.playerByRole('MAFIA');
    if (!mafia?.alive) { this.finishGame('CITIZEN'); return true; }
    if (!this.players.some(p => p.alive && p.team === 'CITIZEN')) {
      this.finishGame('MAFIA'); return true;
    }
    return false;
  }
  finishGame(team) {
    this.winningTeam = team;
    this.log(team === 'CITIZEN' ? '마피아가 제거되었습니다. 시민팀이 승리했습니다!' :
      '시민팀 전원이 제거되었습니다. 마피아팀이 승리했습니다!');
    this.phaseTo('GAME_OVER');
  }
  abort(reason) {
    if (['ABORTED', 'GAME_OVER', 'LOBBY'].includes(this.phase)) return;
    this.abortReason = reason || '연결 문제';
    this.winningTeam = null;
    this.pendingNight = null;
    this.actions.clear(); this.votes.clear();
    this.log(`게임 연결 문제로 판이 중단되었습니다. ${this.abortReason}`);
    this.phaseTo('ABORTED');
  }
  resetLobby(actor) {
    this.ensureHost(actor);
    this.ensurePhase('GAME_OVER', 'ABORTED');
    if (this.phase === 'ABORTED') this.players = this.players.filter(p => !p.bot);
    this.clearRoundState();
    this.boxOwners = null; this.boxAssignments = null;
    this.log('새 게임을 위한 인원 모집을 시작합니다.');
    this.phaseTo('LOBBY');
  }

  // The bot only sees its own role, its own investigation history, public data,
  // and a contact partner once contact has genuinely happened.
  botKnowledge(p) {
    const partner = this.contact ?
      this.players.find(q => q.id !== p.id && ['MAFIA', 'SPY'].includes(q.role)) : null;
    return { role: p.role, team: p.team, selfId: p.id, playerNumber: p.number,
      alivePlayers: this.players.filter(q => q.alive).map(q => ({ id: q.id, number: q.number, name: q.name })),
      investigations: p.investigations.map(i => ({ ...i })),
      partnerId: ['MAFIA', 'SPY'].includes(p.role) && this.contact ? partner?.id : null,
      contacted: ['MAFIA','SPY'].includes(p.role) && !!this.contact, night: this.night };
  }
  botNightTarget(p) {
    return BotMind.chooseNight(this,p,this.rng);
  }
  botVoteTarget(p) {
    return BotMind.chooseVote(this,p,this.rng);
  }
  botChatText(p, channel, replyToId = null) {
    const mind=BotMind.mindFor(p,this.rng);
    if(!mind.recentLines) mind.recentLines=[];
    let line=BotMind.decideSpeech(this,p,channel,this.rng,replyToId?{replyToId}:{});
    // Do not replace a direct answer with a generic line merely for duplicate avoidance.
    if(!line)return null;
    if(!replyToId && mind.recentLines.includes(line))
      line=BotMind.decideSpeech(this,p,channel,this.rng);
    if(!line)return null;
    mind.recentLines.push(line);
    if(mind.recentLines.length>12)mind.recentLines.shift();
    return line;
  }
  scheduleReactions(sender,text,entry) {
    if (!['DAY','EXTRA_DISCUSSION'].includes(this.phase) || !entry) return;
    const now=this.now();
    if(!sender.bot && !this.players.includes(sender))return;
    if(!sender.bot && this.deadline-now<1100)return;
    const isQuestion=BotMind.isQuestion(text);
    // AI responses to other AI are only queued when a specific participant is named.
    const direct=text.match(/^\s*(\d+)\s*번\s*(?:[,，:：]|님|너|넌|네가|니가|왜\s*(?:나|날|내))/);
    const directId=direct?this.players.find(x=>x.number===Number(direct[1]))?.id:null;
    const addressed=this.players.filter(x=>x.bot && x.alive && x.id!==sender.id &&
      (directId ? x.id===directId : x.name.length>1 && text.startsWith(x.name+',')));
    if(sender.bot && (!isQuestion || addressed.length===0))return;
    const candidates=this.players.filter(x=>x.bot && x.alive && x.id!==sender.id);
    if(!candidates.length)return;
    let bot=addressed.length?pick(addressed,this.rng):null;
    if(!bot && !sender.bot && isQuestion && /(?:너|넌|네가|니가|너는)/.test(text)) {
      const previous=this.publicChat.length>=2?this.publicChat[this.publicChat.length-2]:null;
      bot=candidates.find(x=>x.id===previous?.senderId) || null;
    }
    if(!bot && !sender.bot && isQuestion && /(?:왜.*?(?:나|날|내)|나를.*?의심)/.test(text)) {
      bot=candidates.findLast(x=>x.mind?.lastOpinion?.targetId===sender.id) || null;
    }
    if(!bot && !sender.bot){
      const subjects=BotMind.mentions(text,this.players);
      bot=pick(candidates.filter(x=>!subjects.includes(x.id)),this.rng) || pick(candidates,this.rng);
    }
    if(!bot)return;
    const at=Math.min(Math.max(now+900,bot.lastChatAt+780),this.deadline-140);
    if(at<=now)return;
    const pending=this.botPlans.find(plan=>!plan.done && plan.id===bot.id && plan.kind==='PUBLIC_CHAT');
    if(pending) {
      if(isQuestion && pending.replyToId && pending.replyToId!==entry.id) {
        // Do not overwrite an unanswered question with a newer question.
        const followUpAt=Math.min(Math.max(at,pending.at+900),this.deadline-140);
        if(followUpAt>now)this.botPlans.push({id:bot.id,kind:'PUBLIC_CHAT',at:followUpAt,done:false,replyToId:entry.id});
      } else {
        pending.at=Math.min(pending.at,at);
        if(isQuestion)pending.replyToId=entry.id;
      }
      return;
    }
    this.botPlans.push({id:bot.id,kind:'PUBLIC_CHAT',at,done:false,replyToId:isQuestion?entry.id:null});
  }
  scheduleBots() {
    const duration = this.deadline !== null ? this.deadline - this.phaseStart : 0;
    const schedule = (p, kind, minFraction, maxFraction) => {
      const at = this.phaseStart + Math.max(80, duration * (minFraction + this.rng() * (maxFraction - minFraction)));
      this.botPlans.push({ id: p.id, kind, at, done: false });
    };
    if (this.phase === 'NIGHT') {
      for (const p of this.players.filter(x => x.bot && x.alive)) {
        if (this.usable(p)) schedule(p, 'ABILITY', 0.05, 0.22);
        if (this.canChat(p, 'SECRET')) {
          schedule(p, 'SECRET_CHAT', 0.015, 0.12);
          if (this.rng() < 0.68) schedule(p, 'SECRET_CHAT', 0.26, 0.65);
        }
      }
    }
    if (['DAY', 'EXTRA_DISCUSSION'].includes(this.phase)) {
      const speakers=this.players.filter(x => x.bot && x.alive);
      const offset=speakers.length?Math.floor(this.rng()*speakers.length):0;
      for(let i=0;i<speakers.length;i++) {
        const p=speakers[(i+offset)%speakers.length];
        BotMind.mindFor(p,this.rng);
        // Space out contributions over the discussion instead of making every
        // bot interrupt at once in the first ten seconds.
        const fraction=0.055+(i+this.rng()*0.45)*0.78/speakers.length;
        this.botPlans.push({id:p.id,kind:'PUBLIC_CHAT',at:this.phaseStart+Math.max(80,duration*fraction),done:false});
        if(this.rng()<0.30)schedule(p,'PUBLIC_CHAT',0.72,0.92);
      }
    }
    if (['VOTE1', 'VOTE2'].includes(this.phase)) {
      for (const p of this.players.filter(x => x.bot && x.alive && this.stunnedId !== x.id)) {
        schedule(p, 'VOTE', 0.10, 0.60);
      }
    }
  }
  actBot(plan) {
    const p = this.getPlayer(plan.id);
    if (!p?.alive) return;
    try {
      if (plan.kind === 'ABILITY' && this.phase === 'NIGHT' && this.usable(p)) {
        const t = this.botNightTarget(p);
        if (t) {
          this.selectAbility(p, t);
          this.confirmAbility(p, t);
        }
      } else if (plan.kind === 'SECRET_CHAT' && this.canChat(p, 'SECRET')) {
        this.sendChat(p, 'SECRET', this.botChatText(p, 'SECRET'));
      } else if (plan.kind === 'PUBLIC_CHAT' && this.canChat(p, 'PUBLIC')) {
        // A direct reply should not be lost to the chat anti-spam cooldown.
        if(this.now()-p.lastChatAt<660) {
          const when=p.lastChatAt+690;
          if(when<this.deadline) this.botPlans.push({...plan,at:when,done:false});
          return;
        }
        const line=this.botChatText(p, 'PUBLIC', plan.replyToId);
        if(line)this.sendChat(p, 'PUBLIC', line);
      } else if (plan.kind === 'VOTE' && this.canVote(p) && !this.votes.has(p.id)) {
        this.submitVote(p, this.botVoteTarget(p));
      }
    } catch (e) { /* A bot missing a turn is subject to the ordinary automatic rules. */ }
  }
  tick() {
    if (this.deadline === null) return;
    const now = this.now();
    // Copy because actions can change the phase while iterating.
    for (const plan of this.botPlans.slice()) {
      if (plan.done || plan.at > now) continue;
      plan.done = true;
      const expected = this.phase;
      this.actBot(plan);
      if (this.phase !== expected) break;
    }
    if (this.deadline === null || now < this.deadline) return;
    switch (this.phase) {
      case 'NIGHT': this.resolveNight(); break;
      case 'NIGHT_RESULT': this.publishMorning(); break;
      case 'DAY': this.startVote(1); break;
      case 'VOTE1': case 'VOTE2': this.resolveVote(); break;
      case 'EXTRA_DISCUSSION': this.startVote(2); break;
      case 'VOTE_RESULT': this.startNight(); break;
      default: break;
    }
  }

  snapshotFor(p) {
    const finished = this.phase === 'GAME_OVER';
    const privateAction = this.actions.get(p?.id);
    const canSeeSecret = p && ['MAFIA', 'SPY'].includes(p.role) &&
      !!this.contact && this.night > this.contact.night;
    const seesPartner = !!p && ['MAFIA', 'SPY'].includes(p.role) && !!this.contact;
    const partner = seesPartner ? this.players.find(q => q.id !== p.id && ['MAFIA', 'SPY'].includes(q.role)) : null;
    return {
      code: this.code, phase: this.phase, phaseStart: this.phaseStart,
      deadline: this.deadline, serverNow: this.now(), night: this.night,
      players: this.players.map(x => ({ ...publicActor(x),
        ...(finished ? { role: x.role, team: x.team } : {}) })),
      hostId: this.hostId,
      seatsMax: 7,
      boxes: this.boxOwners ? this.boxOwners.map((id, index) => ({ index, chosen: id !== null,
        pickerId: id })) : [],
      me: p ? { id: p.id, number: p.number, name: p.name, role: p.role,
        roleKo: p.role ? ROLE_KO[p.role] : null, team: p.team, alive: p.alive,
        connected: p.connected, boxIndex: p.boxIndex, roleReady: p.roleReady,
        isHost: this.isHost(p), canAct: this.phase === 'NIGHT' && this.usable(p),
        validTargets: this.phase === 'NIGHT' ? this.validTargets(p) : [],
        action: privateAction ? { selected: privateAction.selected, confirmed: privateAction.confirmed,
          target: privateAction.target, auto: privateAction.auto } : null,
        teamAction: p.role === 'SPY' && this.phase === 'NIGHT' && this.contact &&
          this.night > this.contact.night && this.playerByRole('MAFIA')?.alive ? (() => {
            const a = this.actions.get(this.playerByRole('MAFIA').id);
            return a ? { selected:a.selected, confirmed:a.confirmed, target:a.target } : null;
          })() : null,
        canVote: this.canVote(p), voted: this.votes.has(p.id),
        stunned: this.stunnedId === p.id,
        canPublicChat: this.canChat(p, 'PUBLIC'), canSecretChat: this.canChat(p, 'SECRET'),
        notices: p.notices.slice(-12), investigations: p.investigations.slice(),
        contact: seesPartner ? { night: this.contact.night, type: this.contact.type,
          partnerId: partner?.id, partnerNumber: partner?.number, partnerName: partner?.name } : null } : null,
      publicLog: this.publicLog.slice(-18), publicChat: this.publicChat.slice(-80),
      secretChat: canSeeSecret ? this.secretChat.slice(-80) : [],
      voteOutcome: ['VOTE_RESULT', 'GAME_OVER'].includes(this.phase) ? this.voteOutcome : null,
      winningTeam: finished ? this.winningTeam : null,
      abortReason: this.phase === 'ABORTED' ? this.abortReason : null
    };
  }
}

module.exports = { MafiaRoom, ROLES, ROLE_KO, TEAM, DEFAULT_DURATIONS,
  shuffled, sanitizeChat, sanitizeName };

})(engineModule,engineModule.exports,(name)=>{
 if(name==='node:crypto')return cryptoShim;
 if(name==='./bot-mind')return botModule.exports;
 throw new Error('Offline engine cannot import '+name);
});
globalThis.NOIR_OFFLINE_ENGINE=engineModule.exports;
})();
