/* NOIR / SEVEN v2.8: offline local session authority.
 * Host executes MafiaRoom, never forwards its private game state; guests receive
 * only room.snapshotFor(their own player). Transport is replaceable: BroadcastChannel
 * supports same-browser development, while a native BLE bridge is needed for devices.
 */
(() => {
  'use strict';
  const makeId=()=>{
    if(globalThis.crypto?.randomUUID)return crypto.randomUUID();
    return String(Date.now())+Math.random().toString(36).slice(2);
  };
  const randomCode=()=>Array.from({length:6},()=> 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[Math.floor(Math.random()*32)]).join('');
  const API_VERSION=1;
  const native=!!window.NOIR_BLE_NATIVE;
  const peerId=makeId();
  const channel = native ? null : new BroadcastChannel('NOIR-SEVEN-LOCAL-V2.8');
  const pending=new Map();
  const received=new Map();
  const peers=new Map();
  const listeners=new Set();
  let hostRoom=null,hostPlayer=null,hostCode=null,hostPeer=null,localPlayer=null,localToken=null,tickTimer=null;
  let lastHostBeat=Date.now();
  let lastPublish=0;
  let lastHostAdvertisement=0;
  let lastSnapshot=null;
  let isActive=false;

  function emitState(snapshot){lastSnapshot=snapshot;for(const listener of listeners)listener(snapshot);}
  function emitError(text){window.dispatchEvent(new CustomEvent('noir-local-error',{detail:text}));}
  function deliver(target,kind,body={}) {
    const packet={v:API_VERSION,from:peerId,to:target||'*',kind,...body};
    if(native){window.NOIR_BLE_NATIVE.send(JSON.stringify(packet),target||'*');}
    else channel.postMessage(packet);
  }
  function snapshotFor(player){return hostRoom.snapshotFor(player);}
  function publish(force=false){
    if(!hostRoom)return;
    if(!force && Date.now()-lastPublish<30)return;
    lastPublish=Date.now();
    if(hostPlayer) emitState(snapshotFor(hostPlayer));
    for(const [remote,record] of peers) {
      const player=hostRoom.getPlayer(record.playerId);
      if(player)deliver(remote,'state',{snapshot:snapshotFor(player)});
    }
  }
  function loseHost(reason){
    if(!hostPeer || !isActive)return;
    // Never invent a winner when the transport disappears: retain only the last
    // per-player projection and mark the interrupted match as aborted.
    if(lastSnapshot)emitState({...lastSnapshot,phase:'ABORTED',
      abortReason:reason,winningTeam:null,deadline:null});
    emitError(reason);
    stopTicker();hostPeer=null;localToken=null;isActive=false;
    if(native)window.NOIR_BLE_NATIVE.stop().catch(()=>{});
  }
  function actionAs(player,type,data){
    switch(type){
      case 'heartbeat':player.lastHeartbeatAt=Date.now();return;
      case 'addBots':return hostRoom.addBots(player,Number(data.count));
      case 'removeBots':return hostRoom.removeBots(player);
      case 'start':return hostRoom.startDraft(player);
      case 'chooseBox':return hostRoom.chooseBox(player,Number(data.index));
      case 'confirmRole':return hostRoom.confirmRole(player);
      case 'selectAbility':return hostRoom.selectAbility(player,String(data.targetId||''));
      case 'confirmAbility':return hostRoom.confirmAbility(player,String(data.targetId||''));
      case 'chat':return hostRoom.sendChat(player,data.channel,data.text);
      case 'vote':return hostRoom.submitVote(player,String(data.targetId||''));
      case 'resetLobby':return hostRoom.resetLobby(player);
      case 'leave':{
        if(player===hostPlayer){
          // Host ending a room aborts the active round for every other peer.
          for(const id of peers.keys())deliver(id,'hostLeft',{reason:'방장이 방을 종료했습니다.'});
          hostRoom=null;hostPlayer=null;peers.clear();
          stopTicker();isActive=false;
          return;
        }
        hostRoom.removeHuman(player,'근거리 연결 종료');return;
      }
      default:throw new Error('지원하지 않는 행동입니다.');
    }
  }
  function accept(packet){
    if(!packet || packet.v!==API_VERSION || packet.from===peerId || !packet.kind)return;
    if(packet.to!==peerId && packet.to!=='*')return;
    if(hostRoom && packet.kind==='join' && packet.to==='*') {
      if(packet.code!==hostCode)return;
      let entry=peers.get(packet.from);
      try{
        if(!entry){
          const p=hostRoom.createPlayer(packet.name);
          p.connected=true;p.lastHeartbeatAt=Date.now();
          entry={playerId:p.id,seenAt:Date.now()};peers.set(packet.from,entry);
        }else entry.seenAt=Date.now();
        const p=hostRoom.getPlayer(entry.playerId);
        if(!p)throw new Error('참가자 정보가 없습니다.');
        deliver(packet.from,'joined',{replyTo:packet.requestId,token:p.token,code:hostCode,snapshot:snapshotFor(p)});
        publish(true);
      }catch(e){deliver(packet.from,'failure',{replyTo:packet.requestId,error:e.message});}
      return;
    }
    if(hostRoom && packet.kind==='command' && packet.to===peerId) {
      const entry=peers.get(packet.from);
      if(!entry){deliver(packet.from,'failure',{replyTo:packet.requestId,error:'참가자로 확인되지 않았습니다.'});return;}
      entry.seenAt=Date.now();
      const p=hostRoom.getPlayer(entry.playerId);
      // Keep-alive is transport metadata, not a game action. Never retransmit a
      // full private snapshot for each guest's one-second heartbeat.
      if(packet.type==='heartbeat'){
        if(p)p.lastHeartbeatAt=Date.now();
        return;
      }
      try{
        if(!p)throw new Error('참가자가 게임에 없습니다.');
        const seenId=packet.requestId;
        if(seenId && received.has(packet.from+':'+seenId)){
          deliver(packet.from,'ack',{replyTo:seenId});return;
        }
        actionAs(p,packet.type,packet.data||{});
        if(seenId){received.set(packet.from+':'+seenId,Date.now());if(received.size>300){for(const key of [...received.keys()].slice(0,100))received.delete(key);}}
        deliver(packet.from,'ack',{replyTo:seenId});publish(true);
      }catch(e){deliver(packet.from,'failure',{replyTo:packet.requestId,error:e.message});}
      return;
    }
    if(hostRoom && packet.kind==='getState' && packet.to===peerId){
      const p=hostRoom.getPlayer(peers.get(packet.from)?.playerId);
      if(p)deliver(packet.from,'stateReply',{replyTo:packet.requestId,snapshot:snapshotFor(p)});
      return;
    }
    if(packet.replyTo && pending.has(packet.replyTo)){
      const job=pending.get(packet.replyTo);
      if(job.host && packet.from!==job.host)return;
      clearTimeout(job.timeout);pending.delete(packet.replyTo);
      if(packet.kind==='failure')job.reject(new Error(packet.error||'근거리 통신 실패'));
      else job.resolve(packet);
    }
    if(packet.kind==='state' && hostPeer===packet.from){lastHostBeat=Date.now();emitState(packet.snapshot);}
    if(packet.kind==='hostBeat' && hostPeer===packet.from)lastHostBeat=Date.now();
    if(packet.kind==='hostLeft' && hostPeer===packet.from)
      loseHost(packet.reason||'방장과의 연결이 종료되었습니다.');
  }
  if(channel)channel.onmessage=e=>accept(e.data);
  if(native){
    window.addEventListener('noir-ble-packet',e=>{
      try{accept(typeof e.detail==='string'?JSON.parse(e.detail):e.detail)}catch{}
    });
    window.addEventListener('noir-ble-disconnect',e=>{
      const lost=String(e.detail||'');
      if(hostRoom){
        const record=peers.get(lost);
        if(!record)return;
        peers.delete(lost);
        const player=hostRoom.getPlayer(record.playerId);
        if(player)hostRoom.removeHuman(player,'Bluetooth 연결 종료');
        publish(true);
      }else if(hostPeer&&isActive)loseHost('방장 기기와 Bluetooth 연결이 종료되었습니다.');
    });
  }
  function stopTicker(){if(tickTimer)clearInterval(tickTimer);tickTimer=null;}
  function startTicker(){
    stopTicker();tickTimer=setInterval(()=>{
      if(hostRoom){
        const t=Date.now();
        for(const [remote,record] of peers){
          // There is a short detection window to avoid false disconnects.
          if(t-record.seenAt>9000){
            const player=hostRoom.getPlayer(record.playerId);
            peers.delete(remote);
            if(player)hostRoom.removeHuman(player,'근거리 통신 응답 없음');
          }
        }
        hostRoom.tick(); // onChange publishes only changed game state
        if(t-lastHostAdvertisement>=3000){
          lastHostAdvertisement=t;
          for(const remote of peers.keys())deliver(remote,'hostBeat');
        }
      }else if(hostPeer && isActive){
        if(Date.now()-lastHostBeat>11000){
          loseHost('방장 기기에서 11초 동안 응답이 없어 판이 중단되었습니다.');
          return;
        }
        deliver(hostPeer,'command',{requestId:makeId(),type:'heartbeat',data:{}});
      }
    },1000);
  }
  function rpc(target,kind,body,timeoutMs=6500){
    const requestId=makeId();
    return new Promise((resolve,reject)=>{
      const timeout=setTimeout(()=>{pending.delete(requestId);reject(new Error('근거리 통신 응답이 없습니다. 블루투스 연결을 확인해 주세요.'));},timeoutMs);
      pending.set(requestId,{resolve,reject,timeout,host:target||null});
      deliver(target||'*',kind,{...body,requestId});
    });
  }
  async function create(name){
    if(native)await window.NOIR_BLE_NATIVE.host();
    stopTicker();
    const {MafiaRoom}=window.NOIR_OFFLINE_ENGINE||{};
    if(!MafiaRoom)throw new Error('게임 엔진을 불러오지 못했습니다.');
    hostCode=randomCode();hostRoom=new MafiaRoom(hostCode,{onChange:()=>publish(true)});
    hostPlayer=hostRoom.createPlayer(name);
    hostPlayer.connected=true;hostPlayer.lastHeartbeatAt=Date.now();
    localPlayer=hostPlayer;hostPeer=peerId;localToken=hostPlayer.token;
    isActive=true;startTicker();publish(true);
    return {ok:true,code:hostCode,token:localToken};
  }
  async function join(name,code){
    code=String(code||'').trim().toUpperCase();
    if(!/^[A-HJ-NP-Z2-9]{6}$/.test(code))throw new Error('방 코드는 영문·숫자 6자리입니다.');
    if(native)await window.NOIR_BLE_NATIVE.join(code);
    const result=await rpc(null,'join',{name,code},14000);
    hostPeer=result.from;localToken=result.token;lastHostBeat=Date.now();isActive=true;
    startTicker();emitState(result.snapshot);
    return {ok:true,code:result.code,token:localToken};
  }
  async function request(url,data={}){
    if(url==='/api/create')return create(data.name);
    if(url==='/api/join')return join(data.name,data.code);
    if(!localToken)throw new Error('근거리 게임에 연결되지 않았습니다.');
    if(hostRoom && hostPlayer){
      if(url==='/api/state')return {ok:true,state:snapshotFor(hostPlayer)};
      if(url==='/api/action'){
        actionAs(hostPlayer,data.type,data);publish(true);return {ok:true};
      }
    }
    if(!hostPeer)throw new Error('방장과 연결되지 않았습니다.');
    if(url==='/api/state'){
      const res=await rpc(hostPeer,'getState',{},7500);
      lastHostBeat=Date.now();return {ok:true,state:res.snapshot};
    }
    if(url==='/api/action'){
      const res=await rpc(hostPeer,'command',{type:data.type,data},7500);
      lastHostBeat=Date.now();return {ok:true};
    }
    throw new Error('지원하지 않는 API 요청입니다.');
  }
  function disconnect(){
    stopTicker();
    if(hostRoom&&hostPlayer){
      for(const id of peers.keys())deliver(id,'hostLeft',{reason:'방장이 나갔습니다.'});
      hostRoom=null;hostPlayer=null;peers.clear();
    }else if(hostPeer)deliver(hostPeer,'command',{requestId:makeId(),type:'leave',data:{}});
    hostPeer=null;localPlayer=null;localToken=null;isActive=false;
    if(native)window.NOIR_BLE_NATIVE.stop();
  }
  window.NOIR_LOCAL={
    request,onState:fn=>{listeners.add(fn);return ()=>listeners.delete(fn)},
    disconnect,debug:()=>({native,code:hostCode,host:!!hostRoom,peers:peers.size,
      players:hostRoom?.players.length,phase:hostRoom?.phase})
  };
})();
