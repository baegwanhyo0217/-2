'use strict';
// Only the presentation shell is cached. Game state and secret API responses are never cached.
const CACHE='noir-seven-offline-2.8.5';
const SHELL=['/','/index.html','/style.css','/app.js','/offline.html','/offline-engine.js','/manifest.webmanifest','/icons/icon-192.png','/icons/icon-512.png'];
self.addEventListener('install',event=>{
  event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(SHELL)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',event=>{
  event.waitUntil(Promise.all([
    caches.keys().then(keys=>Promise.all(keys.filter(key=>key!==CACHE).map(key=>caches.delete(key)))),
    self.clients.claim()
  ]));
});
self.addEventListener('fetch',event=>{
  const req=event.request;
  if (req.method!=='GET' || new URL(req.url).origin!==self.location.origin ||
      req.url.includes('/api/')) return;
  const url=new URL(req.url);
  if (!SHELL.includes(url.pathname)) return;
  event.respondWith(fetch(req).then(res=>{
    if (res.ok) {
      const copy=res.clone();
      caches.open(CACHE).then(cache=>cache.put(req,copy)).catch(()=>{});
    }
    return res;
  }).catch(()=>caches.match(req).then(response=>response||Response.error())));
});
