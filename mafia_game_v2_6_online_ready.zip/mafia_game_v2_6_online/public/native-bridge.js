/* Native WebView bridge. Android and iOS both implement one postMessage(json)
 * surface; this module never starts a network request or transmits internet data.
 * Expected native callbacks:
 *   window.NOIR_NATIVE_REPLY(id, result, errorString);
 *   window.NOIR_NATIVE_RX(packetString);
 */
(function(){
 'use strict';
 const android=window.NoirBridgeNative;
 const ios=window.webkit?.messageHandlers?.noir;
 if(!android&&!ios)return;
 let serial=0;const pending=new Map();
 function send(obj){
  if(android)android.postMessage(JSON.stringify(obj));
  else ios.postMessage(obj);
 }
 function rpc(kind,args={}){
  const id='n'+(++serial);
  return new Promise((resolve,reject)=>{
   const timer=setTimeout(()=>{pending.delete(id);reject(new Error('블루투스 작업 시간이 초과되었습니다.'));},25000);
   pending.set(id,{resolve,reject,timer});
   send({id,kind,...args});
  });
 }
 window.NOIR_NATIVE_REPLY=function(id,result,error){
  const p=pending.get(id);if(!p)return;
  clearTimeout(p.timer);pending.delete(id);
  error?p.reject(new Error(String(error))):p.resolve(result);
 };
 window.NOIR_NATIVE_DISCONNECT=function(peer){
  window.dispatchEvent(new CustomEvent('noir-ble-disconnect',{detail:String(peer)}));
 };
 window.NOIR_NATIVE_RX=function(packetString){
  try{const packet=JSON.parse(packetString);
   window.dispatchEvent(new CustomEvent('noir-ble-packet',{detail:packet}));
  }catch(e){console.warn('Invalid BLE packet',e)}
 };
 window.NOIR_BLE_NATIVE={
  host:()=>rpc('host'),
  join:(code)=>rpc('join',{code:String(code)}),
  send:(packet,target)=>send({kind:'send',packet:String(packet),target:String(target||'*')}),
  stop:()=>rpc('stop')
 };
})();
