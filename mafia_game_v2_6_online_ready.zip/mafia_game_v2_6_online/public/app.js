'use strict';

const OFFLINE_MODE = !!window.NOIR_OFFLINE || /(?:^|\/)offline\.html$/.test(location.pathname);
const LOCAL_MODE = !!window.NOIR_LOCAL && (!!window.NOIR_FORCE_LOCAL || /(?:^|\/)local\.html$/.test(location.pathname));
const root = document.getElementById('root');
const overlay = document.getElementById('overlay');
const toastBox = document.getElementById('toast');
const phaseNames = {
  LOBBY:'대기실', BOXES:'직업 배정', NIGHT:'밤', NIGHT_RESULT:'야간 결과',
  DAY:'낮 토론', VOTE1:'1차 투표', EXTRA_DISCUSSION:'추가 토론',
  VOTE2:'재투표', VOTE_RESULT:'투표 결과', GAME_OVER:'게임 종료', ABORTED:'연결 중단'
};
const phaseDescriptions = {
  LOBBY:'7명을 모아 게임을 시작합니다. AI 플레이어를 추가하여 혼자서도 베타 테스트할 수 있습니다.',
  BOXES:'상자를 하나 선택하면 본인에게만 직업이 공개됩니다. 모두 확인하면 첫 번째 밤이 시작됩니다.',
  NIGHT:'모든 직업이 동시에 행동합니다. 대상은 두 번 터치하여 최종 확정하세요.',
  NIGHT_RESULT:'서버가 야간 행동을 처리했습니다. 비공개 결과를 확인해 주세요.',
  DAY:'생존자들과 대화를 나누고 의심스러운 플레이어를 추리하세요.',
  VOTE1:'퇴출할 플레이어 또는 건너뛰기를 선택하세요. 자기 자신에게는 투표할 수 없습니다.',
  EXTRA_DISCUSSION:'최다 득표 동률이 발생했습니다. 한 번 더 토론해 주세요.',
  VOTE2:'모든 생존자와 건너뛰기 중 선택하여 다시 투표합니다.',
  VOTE_RESULT:'표가 집계되었습니다. 결과를 확인해 주세요.',
  GAME_OVER:'모든 플레이어의 직업과 소속팀이 공개되었습니다.',
  ABORTED:'접속 종료 또는 네트워크 문제로 해당 판이 취소되었습니다. 승패는 기록되지 않습니다.'
};
const roleInfo = {
  MAFIA:{ name:'마피아', verb:'살해', hint:'오늘 밤 공격할 플레이어를 선택하세요. 접선 전에는 스파이를 공격하면 접선이 발생합니다.' },
  SPY:{ name:'스파이', verb:'조사', hint:'다른 플레이어를 조사하여 실제 직업을 확인합니다. 마피아를 조사하면 접선합니다.' },
  POLICE:{ name:'경찰', verb:'조사', hint:'다른 플레이어의 소속팀을 조사합니다. 스파이는 시민팀으로 표시됩니다.' },
  DOCTOR:{ name:'의사', verb:'치료', hint:'자신을 포함한 플레이어 한 명을 공격으로부터 보호합니다. 미선택 시 자기 자신을 치료합니다.' },
  GANGSTER:{ name:'건달', verb:'스턴', hint:'다음 날 투표권을 잃게 할 플레이어를 선택합니다. 해당 플레이어는 토론에 참여할 수 있습니다.' },
  CITIZEN:{ name:'시민', verb:'', hint:'밤에는 능력이 없습니다. 낮의 토론과 투표로 마피아를 찾으세요.' }
};
let token = OFFLINE_MODE ? '' : (()=>{try{return sessionStorage.getItem('noir_token') || '';}catch{return '';}})();
let offlineRoom=null;
let offlinePlayer=null;
let offlineTicker=null;
let current = null;
let stream = null;
let chatDraft = '';
let chatTab = 'PUBLIC';
let clockOffset = 0;
let toastTimer = null;
let confirmTarget = null;
let connecting = false;
let mobileView = 'ACTION';
let renderedChatChannel = null;
const slotCache = new Map();
const invitationCode = (() => {
  const code = new URLSearchParams(location.search).get('room')?.trim().toUpperCase() || '';
  return /^[A-HJ-NP-Z2-9]{6}$/.test(code) ? code : '';
})();
const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, ch =>
  ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const $ = (sel, parent=document) => parent.querySelector(sel);
function toast(message) {
  toastBox.textContent = message;
  toastBox.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastBox.classList.add('hidden'), 4000);
}
async function request(url, data) {
  if (OFFLINE_MODE) return offlineRequest(url, data);
  if (LOCAL_MODE) return window.NOIR_LOCAL.request(url, data);
  const res = await fetch(url, {
    method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(data)
  });
  const json = await res.json();
  if (!res.ok || !json.ok) throw new Error(json.error || '서버 요청이 실패했습니다.');
  return json;
}
function offlineRequest(url,data) {
  const { MafiaRoom }=window.NOIR_OFFLINE_ENGINE || {};
  if (!MafiaRoom) throw new Error('오프라인 게임 엔진을 불러오지 못했습니다.');
  if (url==='/api/create') {
    if (offlineTicker) {clearInterval(offlineTicker);offlineTicker=null;}
    const room=new MafiaRoom('SOLO07',{onChange:r=>{
      if(offlineRoom===r && offlinePlayer && token) acceptState(r.snapshotFor(offlinePlayer));
    }});
    offlineRoom=room;
    offlinePlayer=room.createPlayer(data.name);
    offlinePlayer.connected=true;
    offlinePlayer.lastHeartbeatAt=Date.now();
    room.addBots(offlinePlayer,6);
    return {ok:true,token:'offline-local',code:room.code};
  }
  if(url==='/api/join')throw new Error('오프라인 모드는 친구와 연결할 수 없습니다.');
  if (!offlineRoom || !offlinePlayer || data?.token!=='offline-local')
    throw new Error('오프라인 판이 종료되었습니다. 새 게임을 시작해 주세요.');
  if(url==='/api/state')return {ok:true,state:offlineRoom.snapshotFor(offlinePlayer)};
  if(url==='/api/action') {
    switch(data.type) {
      case 'heartbeat': break;
      case 'start': offlineRoom.startDraft(offlinePlayer);break;
      case 'chooseBox': offlineRoom.chooseBox(offlinePlayer,Number(data.index));break;
      case 'confirmRole': offlineRoom.confirmRole(offlinePlayer);break;
      case 'selectAbility': offlineRoom.selectAbility(offlinePlayer,String(data.targetId||''));break;
      case 'confirmAbility': offlineRoom.confirmAbility(offlinePlayer,String(data.targetId||''));break;
      case 'chat': offlineRoom.sendChat(offlinePlayer,data.channel,data.text);break;
      case 'vote': offlineRoom.submitVote(offlinePlayer,String(data.targetId||''));break;
      case 'resetLobby': offlineRoom.resetLobby(offlinePlayer);break;
      case 'leave': offlineRoom=null;offlinePlayer=null;break;
      case 'addBots': case 'removeBots': throw new Error('오프라인에서는 AI 6명이 자동 참가합니다.');
      default: throw new Error('지원하지 않는 행동입니다.');
    }
    return {ok:true};
  }
  throw new Error('지원하지 않는 오프라인 기능입니다.');
}
function resetToStart(message) {
  if (stream) { const old=stream; stream=null; old.close(); }
  token = '';
  if(!OFFLINE_MODE&&!LOCAL_MODE){try{sessionStorage.removeItem('noir_token');}catch{}}
  if(LOCAL_MODE)window.NOIR_LOCAL.disconnect();
  if(OFFLINE_MODE){offlineRoom=null;offlinePlayer=null;if(offlineTicker){clearInterval(offlineTicker);offlineTicker=null;}}
  current = null;
  chatTab = 'PUBLIC';
  chatDraft = '';
  mobileView = 'ACTION';
  renderedChatChannel = null;
  slotCache.clear();
  renderLanding();
  if (message) toast(message);
}
async function createOrJoin(mode) {
  const name = ($('#name-input')?.value || '').trim();
  const code = ($('#join-code')?.value || '').trim().toUpperCase();
  if (!name) return toast('닉네임을 입력해 주세요.');
  if (OFFLINE_MODE && mode==='join') return toast('오프라인은 AI 6명과 하는 1인 게임입니다.');
  if (mode === 'join' && code.length !== 6) return toast('6자리 방 코드를 입력해 주세요.');
  if (connecting) return;
  connecting=true;
  try {
    const response = await request(mode === 'create' ? '/api/create' : '/api/join',
      mode === 'create' ? { name } : { name, code });
    token = response.token;
    if(!OFFLINE_MODE&&!LOCAL_MODE){try{sessionStorage.setItem('noir_token', token);}catch{}}
    chatDraft=''; chatTab='PUBLIC';
    await connect();
  } catch (e) { toast(e.message); }
  finally { connecting=false; }
}
async function connect() {
  if (!token) return resetToStart();
  if(OFFLINE_MODE) {
    if (!offlineRoom || !offlinePlayer) return resetToStart();
    acceptState(offlineRoom.snapshotFor(offlinePlayer));
    if(offlineTicker)clearInterval(offlineTicker);
    offlineTicker=setInterval(()=>offlineRoom?.tick(),180);
    return;
  }
  if(LOCAL_MODE){
    try{const res=await window.NOIR_LOCAL.request('/api/state',{token});acceptState(res.state);
      if(!window.__NOIR_LOCAL_SUBSCRIBED){window.__NOIR_LOCAL_SUBSCRIBED=true;window.NOIR_LOCAL.onState(state=>{if(token)acceptState(state)})}
    }catch(e){return resetToStart(e.message)}
    return;
  }
  try {
    const res = await fetch('/api/state?token=' + encodeURIComponent(token));
    const data = await res.json();
    if (!res.ok || !data.ok) throw new Error(data.error || '접속할 수 없습니다.');
    acceptState(data.state);
  } catch (e) { return resetToStart(e.message); }
  if (stream) stream.close();
  stream = new EventSource('/api/stream?token=' + encodeURIComponent(token));
  stream.addEventListener('state', event => {
    try { acceptState(JSON.parse(event.data)); } catch { toast('상태 데이터 처리에 실패했습니다.'); }
  });
  stream.onerror = () => {
    if (!stream || !current) return;
    // A lost connection aborts the active match server-side, per v2.6.
    $('.connect-banner')?.classList.remove('hidden');
  };
}
function acceptState(state) {
  const prev = current;
  current = state;
  if (prev?.phase !== state.phase) {
    // On mobile, put active discussion in front; for other phases show the action.
    mobileView = (['DAY','EXTRA_DISCUSSION'].includes(state.phase) && state.me.alive) ? 'CHAT' : 'ACTION';
  }

  clockOffset = state.serverNow - Date.now();
  if (confirmTarget && (state.phase !== 'NIGHT' || state.me.action?.confirmed ||
    state.me.action?.selected !== confirmTarget)) closeConfirm();
  if (state.phase === 'ABORTED' && prev?.phase !== 'ABORTED') toast('연결 문제로 해당 판이 승패 없이 중단되었습니다.');
  if (state.phase === 'GAME_OVER' && prev?.phase !== 'GAME_OVER') {
    toast(state.winningTeam === 'CITIZEN' ? '시민팀이 승리했습니다.' : '마피아팀이 승리했습니다.');
  }
  renderGame();
}
async function action(type, fields={}) {
  if (!token) return;
  try { await request('/api/action', { token, type, ...fields }); }
  catch(e) { toast(e.message); }
}
async function leave() {
  if (token) { try { await request('/api/action',{token,type:'leave'}); } catch {} }
  resetToStart();
}
function renderLanding() {
  root.innerHTML = `
    <div class="landing">
      <section class="hero">
        <div class="eyebrow">7 PLAYERS · ONE HIDDEN ENEMY</div>
        <div class="hero-rule"></div>
        <h1 class="hero-wordmark" aria-label="NOIR SEVEN"><span>NOIR</span><em aria-hidden="true">·</em><br><span>SEVEN</span></h1>
        <h2 class="hero-tagline"><span>모두가 용의자다.</span><span>진실은 단 한 명만 알고 있다.</span></h2>
        <p>일곱 명, 여섯 가지 직업, 한 번의 선택.<br>
          <strong>밤에는 정체를 숨기고, 낮에는 서로를 의심하세요.</strong><br>
          ${OFFLINE_MODE?'인터넷에 연결하지 않고 나와 AI 6명이 한 판을 플레이합니다.':LOCAL_MODE?'한 기기가 진행을 관리하고, 다른 친구들은 근거리 연결로 참가합니다.':'실제 친구들과 온라인으로 플레이하거나 지능형 AI와 토론할 수 있습니다.'}</p>
        <div class="hero-data">
          <div class="datum"><strong>07</strong><span>PLAYERS</span></div>
          <div class="datum"><strong>06</strong><span>ROLES</span></div>
          <div class="datum"><strong>02</strong><span>TEAMS</span></div>
        </div>
      </section>
      <section class="entry-card">
        <div class="entry-inner">
          <div class="eyebrow">ENTER THE GAME</div>
          <h2 class="entry-title">당신의 자리는 준비되어 있습니다.</h2>
          <div class="entry-desc">${OFFLINE_MODE?'오프라인에서는 AI 6명이 자동 참가합니다. 모든 계산과 대화가 이 기기에서 처리됩니다.':LOCAL_MODE?'인터넷 서버 없이 방장이 게임을 관리합니다. 방을 만들거나 6자리 방 코드로 참가하세요.':'닉네임을 정하고 새 게임을 만들거나, 친구의 방에 참가하세요.'}<br>휴대폰에서는 하단 탭으로 게임과 채팅을 오갈 수 있습니다.</div>
          <div class="field-wrap"><label class="form-label" for="name-input">플레이어 닉네임</label>
            <input class="field" id="name-input" maxlength="18" autocomplete="nickname" placeholder="닉네임을 입력하세요"></div>
          <button class="btn btn-primary btn-wide" data-cmd="create">${OFFLINE_MODE?'인터넷 없이 게임 시작':LOCAL_MODE?'근거리 방 만들기':'새로운 게임 만들기'} <span aria-hidden="true">→</span></button>
          ${OFFLINE_MODE ? '<div class="info-strip" style="margin-top:14px">오프라인 솔로 · AI 6명 자동 입장 · 실제 게임 규칙 동일</div>' : `<div class="or-divider">OR JOIN A ROOM</div>
          <label class="form-label" for="join-code">친구의 방 코드</label>
          <div class="join-row"><input class="field" id="join-code" maxlength="6" autocapitalize="characters" autocomplete="off" inputmode="text" placeholder="6자리 코드" value="${invitationCode}">
            <button class="btn btn-outline" data-cmd="join">참가하기</button></div>`}
          <div class="entry-bottom">${OFFLINE_MODE?'인터넷이나 서버에 연결하지 않습니다. 시작 후 AI들이 서로 질문하고 반박하며 토론합니다.':LOCAL_MODE?'모바일 브라우저 시뮬레이터는 같은 브라우저의 탭끼리 연결됩니다. 서로 다른 기기는 블루투스 기능을 갖춘 네이티브 앱이 필요합니다.':'AI 베타에서는 AI 6명을 추가해 테스트할 수 있습니다.'}<br>기본 게임 시간과 직업 규칙은 v2.6을 유지합니다.${OFFLINE_MODE?'':'<br><a class="offline-link" href="/offline.html">인터넷 없이 AI와 플레이 →</a>'}${!OFFLINE_MODE&&!LOCAL_MODE?'<br><a class="offline-link" href="/local.html">근거리 방 연결 시뮬레이터 (같은 브라우저 탭 전용) →</a>':''}</div>
        </div>
      </section>
    </div>`;
}
function roster(s) {
  const players = s.players;
  const html = Array.from({length:7}, (_,index) => {
    const p = players.find(x => x.number === index+1);
    if (!p) return `<div class="seat seat-slot-empty"><span class="seat-avatar">${index+1}</span>
      <span class="seat-text"><strong>빈자리</strong><small>참가 대기 중</small></span><span class="seat-status empty">—</span></div>`;
    const me = p.id === s.me.id;
    const text = p.alive ? (p.bot ? '추리 AI' : OFFLINE_MODE?'나':LOCAL_MODE?'근거리 플레이어':'온라인 플레이어') : '탈락';
    const status = ['LOBBY','ABORTED'].includes(s.phase) ? (p.bot ? 'AI' : '참여') :
      s.phase === 'BOXES' ? (p.roleReady ? '준비 완료' : p.boxPicked ? '확인 대기' : '선택 중') :
      p.alive ? '생존' : '탈락';
    return `<div class="seat ${me ? 'is-self' : ''}"><span class="seat-avatar ${p.alive ? '' : 'dead'}">${p.number}</span>
      <span class="seat-text"><strong>${escapeHTML(p.name)}${me?' (나)':''}</strong><small>${escapeHTML(text)}</small></span>
      <span class="seat-status ${p.alive ? '' : 'dead'}">${escapeHTML(status)}</span></div>`;
  }).join('');
  const role = s.me.role;
  return `<div class="panel"><div class="panel-head"><h3>참가 플레이어</h3><small>${players.length} / 7</small></div>
    <div class="roster">${html}</div>
    <div class="self-card"><div class="small-label">MY IDENTITY</div><div class="self-role"><span class="${s.me.team ? 'team-'+s.me.team : ''}">${role ? escapeHTML(s.me.roleKo) : '???'}</span>
    ${role ? `<span class="role-indicator team-${s.me.team}">${s.me.team==='MAFIA'?'마피아팀':'시민팀'}</span>` : '<span class="role-indicator">비공개</span>'}</div></div></div>`;
}
function phaseLiner(s) {
  if (s.deadline !== null) return `<div class="countdown"><div class="clock-icon">◷</div><div class="timer"><strong id="timer-value">--:--</strong><span>TIME REMAINING</span></div></div>`;
  return `<span class="round-mini">${s.phase === 'BOXES'?'상자 선택 중':s.phase==='LOBBY'?'참가자 모집 중':'게임 대기'}</span>`;
}
function gameHeading(s) {
  const round = s.night ? `${s.night}번째 밤` : '게임 준비';
  const playerNo = s.me.number;
  return `<div class="room-meta"><div class="room-code-caption">${OFFLINE_MODE?'OFFLINE SOLO':LOCAL_MODE?'NEARBY ROOM':'ROOM CODE'}
    <strong class="room-code-value">${escapeHTML(s.code)}</strong>
    ${OFFLINE_MODE?'':`<button class="room-code-btn" data-cmd="copy">코드 복사</button><button class="room-code-btn" data-cmd="share">초대 링크</button>`}</div>
    <div class="room-meta-right"><span class="phase-mini">PLAYER ${String(playerNo).padStart(2,'0')}</span><span class="round-mini">${round}</span></div></div>
  <div class="game-heading"><div><div class="eyebrow">${escapeHTML(s.phase)} / NOIR 07</div>
    <h1>${escapeHTML(phaseNames[s.phase])}</h1><p>${escapeHTML(phaseDescriptions[s.phase])}</p></div>
    ${phaseLiner(s)}</div>
  ${s.deadline !== null?'<div class="timer-track"><div class="timer-fill" id="timer-fill"></div></div>':''}`;
}
function renderLobby(s) {
  const available = 7-s.players.length;
  const bots = s.players.filter(p => p.bot).length;
  const all = s.players.length === 7;
  return `<div class="section-kicker">WAITING ROOM</div><h2 class="stage-title">모든 플레이어를 모아주세요.</h2>
    <p class="stage-description">7명이 참가해야 직업 상자를 배정할 수 있습니다. 친구에게 방 코드를 공유하거나 AI로 빈자리를 채우세요.</p>
    <div class="lobby-accent"><strong><span class="capacity">${String(s.players.length).padStart(2,'0')} / 07</span> &nbsp; 참가 완료</strong>
      <p>${all?'정원이 채워졌습니다. 직업 상자 배정을 시작할 수 있습니다.':`남은 자리 ${available}명. AI를 추가하면 혼자서도 테스트할 수 있습니다.`}</p></div>
    ${s.me.isHost ? `<div class="section-kicker">AI BETA TEST</div><div class="lobby-controls">
        <button class="btn btn-ghost" data-cmd="bots" data-count="1" ${available<1?'disabled':''}>+ AI 1명</button>
        <button class="btn btn-ghost" data-cmd="bots" data-count="3" ${available<3?'disabled':''}>+ AI 3명</button>
        <button class="btn btn-gold" data-cmd="fill" ${available===0?'disabled':''}>AI로 빈자리 채우기</button>
        ${bots?'<button class="btn btn-danger" data-cmd="removeBots">AI 제거</button>':''}
      </div><button class="btn btn-primary btn-wide" data-cmd="start" ${!all?'disabled':''}>직업 상자 배정 시작 →</button>` :
      '<div class="info-strip">방장이 참가자를 모집하고 게임을 시작할 때까지 기다려 주세요.</div>'}
    <div class="stage-description" style="margin-top:21px;font-size:11px">AI 플레이어도 실제 플레이어와 동일하게 행동하고 비공개 정보 제한을 받습니다.</div>`;
}
function renderBoxes(s) {
  const me = s.me;
  const myBox = me.boxIndex;
  if (myBox !== null) {
    return `<div class="section-kicker">IDENTITY REVEALED</div>
      <h2 class="stage-title">당신의 직업이 결정되었습니다.</h2>
      <div class="role-reveal"><div class="reveal-kicker">YOUR SECRET ROLE</div>
        <div class="reveal-role ${me.team?'team-'+me.team:''}">${escapeHTML(me.roleKo)}</div>
        <p>${escapeHTML(roleInfo[me.role]?.hint || '')}</p></div>
      ${me.roleReady?'<div class="action-complete"><div class="checkmark">✓</div><strong>직업 확인 완료</strong><p>다른 플레이어들이 직업을 확인하면 첫 번째 밤이 시작됩니다.</p></div>':
      '<button class="btn btn-primary btn-wide" data-cmd="confirmRole">직업 확인 완료 →</button>'}
      <div class="info-strip" style="margin-top:19px">직업과 소속팀은 게임이 끝날 때까지 다른 플레이어에게 공개되지 않습니다.</div>`;
  }
  const boxes = s.boxes.map(b => {
    return `<button class="mystery-box ${b.chosen?'taken':''}" data-cmd="box" data-index="${b.index}" ${b.chosen?'disabled':''}>
      <span class="box-shape"></span><span class="box-number">BOX ${String(b.index+1).padStart(2,'0')}</span></button>`;
  }).join('');
  return `<div class="section-kicker">CHOOSE YOUR FATE</div><h2 class="stage-title">운명을 결정할 상자를 고르세요.</h2>
    <p class="stage-description">총 7개의 상자가 있습니다. 선택한 상자는 다른 플레이어가 선택할 수 없습니다.
      다른 사람의 직업은 보이지 않습니다.</p>
    <div class="box-grid">${boxes}</div>
    <div class="info-strip">마피아 1 · 스파이 1 · 경찰 1 · 의사 1 · 건달 1 · 시민 2</div>`;
}
function renderTargets(s, mode) {
  const me=s.me;
  const selected = mode === 'ABILITY' ? me.action?.selected : null;
  const players = s.players.filter(p=>p.alive);
  const cards = players.map(p => {
    const valid = mode === 'ABILITY' ? me.validTargets.includes(p.id) : p.id !== me.id;
    return `<button class="target-card ${selected===p.id?'selected':''}" data-cmd="${mode==='ABILITY'?'target':'vote'}"
      data-id="${escapeHTML(p.id)}" ${!valid?'disabled':''}>
      <span class="target-num">${String(p.number).padStart(2,'0')}</span>
      <span><strong>${escapeHTML(p.name)}${p.id===me.id?' (나)':''}</strong>
      <small>${!valid?(p.id===me.id?'선택 불가':'대상 제외'):(selected===p.id?'다시 누르면 확정':'선택 가능')}</small></span></button>`;
  }).join('');
  if (mode === 'VOTE') return `<div class="target-grid">${cards}
    <button class="target-card skip-card" data-cmd="vote" data-id="SKIP"><span class="target-num">↷</span>
    <span><strong>투표 건너뛰기</strong><small>퇴출 반대 / 유효표</small></span></button></div>`;
  return `<div class="target-grid">${cards}</div>`;
}
function renderNight(s) {
  const me=s.me;
  const ruleInfo = roleInfo[me.role] || roleInfo.CITIZEN;
  let result;
  if (!me.alive) result = `<div class="circle-stage"><div class="ritual-circle"><span>†</span></div></div>
    <h2 class="stage-title">당신은 탈락했습니다.</h2><p class="stage-description">게임이 끝날 때까지 관전할 수 있지만 행동, 토론, 투표에는 참여할 수 없습니다.</p>`;
  else if (!me.canAct) result = `<div class="section-kicker">THE SILENT NIGHT</div>
    <div class="circle-stage"><div class="ritual-circle"><span>07</span></div></div>
    <h2 class="stage-title">당신의 차례를 기다릴 필요는 없습니다.</h2>
    <p class="stage-description">${me.role==='CITIZEN'?'시민은 밤에 능력이 없습니다. 다른 플레이어들의 행동을 기다려 주세요.':'접선 이후 스파이는 더 이상 조사를 하지 않습니다. 마피아와 비밀 채팅에 참여할 수 있습니다.'}</p>`;
  else if (me.action?.confirmed) result = `<div class="section-kicker">ACTION CONFIRMED</div>
    <div class="action-complete"><div class="checkmark">✓</div>
      <strong>${ruleInfo.verb} 대상 확정 완료</strong>
      <p>최종 확정 후에는 대상을 변경할 수 없습니다.<br>모든 능력 보유자가 확정하면 밤이 즉시 종료됩니다.</p></div>`;
  else result = `<div class="section-kicker">${escapeHTML(me.role)} / NIGHT ACTION</div>
    <h2 class="stage-title">${escapeHTML(ruleInfo.verb)} 대상을 선택하세요.</h2>
    <p class="stage-description">${escapeHTML(ruleInfo.hint)}<br>
      <strong style="color:var(--cream)">한 번 터치: 임시 선택 · 같은 대상 다시 터치: 최종 확정</strong></p>
      ${renderTargets(s,'ABILITY')}
      <div class="info-strip">60초 종료 시 마지막 임시 선택이 자동 확정됩니다. 대상을 선택하지 않으면 직업별 자동 행동을 수행합니다.</div>`;
  if (me.contact && s.night===me.contact.night) result += `<div class="game-alert">
    접선 성공 · ${me.contact.partnerNumber}번 ${escapeHTML(me.contact.partnerName)}님과 접선했습니다.
    비밀 채팅과 공동 논의는 다음 밤부터 가능합니다.</div>`;
  if (me.contact && s.night>me.contact.night && me.alive) result += `<div class="info-strip">
    접선 완료 · ${me.contact.partnerNumber}번 ${escapeHTML(me.contact.partnerName)}님과 같은 마피아팀입니다.
    ${me.role==='MAFIA'?'살해 대상의 최종 결정권은 당신에게 있습니다.':'최종 살해 대상은 마피아가 결정합니다.'}</div>`;
  if (me.role==='SPY' && me.teamAction && s.night>me.contact?.night) {
    const mafiaChoice=s.players.find(p=>p.id===(me.teamAction.target||me.teamAction.selected));
    result += `<div class="info-strip">마피아의 살해 대상: ${mafiaChoice ? `${mafiaChoice.number}번 ${escapeHTML(mafiaChoice.name)}` : '아직 선택하지 않음'}
      ${me.teamAction.confirmed?'(최종 확정)':'(임시 선택)'}</div>`;
  }
  return result;
}
function renderNightResult(s) {
  const notices=s.me.notices.filter(n=>n.at>=s.phaseStart-1800).slice(-6);
  return `<div class="section-kicker">NIGHT RESOLUTION</div>
    <h2 class="stage-title">밤의 결과가 결정되었습니다.</h2>
    <p class="stage-description">모든 직업의 능력은 동시에 판정되었습니다. 다음 날 아침에 사망자가 공개됩니다.</p>
    ${notices.length?notices.map(n=>`<div class="notice ${escapeHTML(n.type)}">${escapeHTML(n.text)}</div>`).join(''):
    '<div class="info-strip">당신에게 전달된 새로운 비공개 결과는 없습니다.</div>'}
    <div class="circle-stage"><div class="ritual-circle"><span>☾</span></div></div>`;
}
function renderDay(s) {
  const extra = s.phase === 'EXTRA_DISCUSSION';
  const event = s.publicLog.slice(-5).filter(e=>e.text.startsWith('지난밤') || e.text.includes('동률')).at(-1);
  return `<div class="section-kicker">${extra?'SECOND CHANCE':'THE DAYLIGHT'}</div>
    <h2 class="stage-title">${extra?'한 번 더 이야기하세요.':'오늘은 누가 거짓말을 하고 있을까요?'}</h2>
    <p class="stage-description">${extra?'1차 투표에서 동률이 발생했습니다. 60초의 추가 토론 후 30초 동안 재투표합니다.':
      '2분 동안 생존자들과 자유롭게 토론할 수 있습니다. 거짓 직업 주장과 심리전도 가능합니다.'}</p>
    ${event?`<div class="info-strip">${escapeHTML(event.text)}</div>`:''}
    ${s.me.alive?'<div class="lobby-accent"><strong>전체 채팅이 활성화되었습니다.</strong><p>오른쪽 채팅창에서 주장과 의심을 공유하세요. 누군가의 말이 반드시 사실인 것은 아닙니다.</p></div>':
    '<div class="game-alert">탈락한 플레이어는 생존자 채팅에 참여할 수 없습니다.</div>'}
    <div class="circle-stage"><div class="ritual-circle"><span>✦</span></div></div>`;
}
function renderVote(s) {
  const me=s.me;
  if (!me.alive) return `<div class="section-kicker">SPECTATOR</div>
    <h2 class="stage-title">투표를 지켜보고 있습니다.</h2><p class="stage-description">탈락한 플레이어는 투표에 참여할 수 없습니다.</p>`;
  if (me.stunned) return `<div class="section-kicker">VOTING LOCKED</div>
    <h2 class="stage-title">당신은 투표권을 잃었습니다.</h2><div class="game-alert">
      건달에게 스턴당했습니다. 이번 낮의 1차 투표와 재투표에는 참여할 수 없습니다.</div>`;
  if (me.voted) return `<div class="section-kicker">VOTE SUBMITTED</div>
    <div class="action-complete"><div class="checkmark">✓</div><strong>투표 제출 완료</strong>
      <p>투표 마감 후 결과가 공개됩니다. 다른 사람의 투표 대상은 지금 볼 수 없습니다.</p></div>`;
  return `<div class="section-kicker">${s.phase==='VOTE1'?'VOTE / FIRST ROUND':'VOTE / FINAL ROUND'}</div>
    <h2 class="stage-title">퇴출할 플레이어를 선택하세요.</h2>
    <p class="stage-description">자기 자신은 선택할 수 없습니다. 건너뛰기는 유효표이며,
      아무것도 제출하지 않으면 무효표가 됩니다. ${s.phase==='VOTE2'?'재투표에서도 모든 생존자를 선택할 수 있습니다.':''}</p>
    ${renderTargets(s,'VOTE')}`;
}
function renderVoteResult(s) {
  const o=s.voteOutcome;
  const last = s.publicLog.at(-1);
  const votes = o?.counts?.map(v=>{
    const p=s.players.find(p=>p.id===v.targetId);
    return `<span class="tally-pill">${v.targetId==='SKIP'?'건너뛰기':`${p?.number||'?'}번`} ${v.count}표</span>`;
  }).join('') || '';
  return `<div class="section-kicker">VOTE RESOLUTION</div>
    <h2 class="stage-title">투표가 종료되었습니다.</h2>
    <div class="outcome-result"><strong>${escapeHTML(last?.text || '투표 결과를 확인하고 있습니다.')}</strong>
    <div class="tally-list">${votes}</div></div>
    <p class="stage-description">퇴출자의 직업은 게임 종료 전까지 공개되지 않습니다. 다음 밤이 시작됩니다.</p>`;
}
function renderGameOver(s) {
  const citizen=s.winningTeam==='CITIZEN';
  return `<div class="winner-banner ${citizen?'citizen':''}"><div class="final-emblem">${citizen?'✦':'♠'}</div>
    <div class="section-kicker" style="justify-content:center">GAME COMPLETE</div>
    <h2 class="team-${s.winningTeam}">${citizen?'시민팀 승리':'마피아팀 승리'}</h2>
    <p>${citizen?'마피아가 제거되었습니다.':'모든 시민팀 플레이어가 제거되었습니다.'}<br>이제 모든 직업과 소속팀을 확인할 수 있습니다.</p></div>
    <div class="section-kicker">IDENTITY REVEAL</div>
    <div class="reveal-grid">${s.players.map(p=>`<div class="reveal-entry"><span>${p.number}번 ${escapeHTML(p.name)}</span>
      <strong class="team-${p.team}">${escapeHTML(roleInfo[p.role]?.name || p.role)}</strong></div>`).join('')}</div>
    ${s.me.isHost?'<button class="btn btn-primary btn-wide" data-cmd="resetLobby">새 게임 준비하기 →</button>':
      '<div class="info-strip">방장이 새 게임을 준비할 때까지 기다려 주세요.</div>'}`;
}
function renderAborted(s) {
  return `<div class="section-kicker">MATCH CANCELLED</div>
    <div class="winner-banner"><div class="final-emblem">!</div>
      <h2>이번 판이 중단되었습니다.</h2>
      <p>플레이어의 접속 종료 또는 네트워크 장애가 발생했습니다.<br>
      <strong>승리팀은 판정하지 않습니다.</strong></p></div>
    <div class="game-alert">중단 사유: ${escapeHTML(s.abortReason || '연결 종료')}<br>
      기존 직업 배정과 행동 기록은 새로운 판에 이어지지 않습니다.</div>
    ${s.me.isHost?'<button class="btn btn-primary btn-wide" data-cmd="resetLobby">인원 다시 모집하기 →</button>':
      '<div class="info-strip">방장이 인원을 다시 모집하면 새로운 판을 시작할 수 있습니다.</div>'}`;
}
function renderMain(s) {
  switch(s.phase){
    case 'LOBBY':return renderLobby(s);
    case 'BOXES':return renderBoxes(s);
    case 'NIGHT':return renderNight(s);
    case 'NIGHT_RESULT':return renderNightResult(s);
    case 'DAY':case 'EXTRA_DISCUSSION':return renderDay(s);
    case 'VOTE1':case 'VOTE2':return renderVote(s);
    case 'VOTE_RESULT':return renderVoteResult(s);
    case 'GAME_OVER':return renderGameOver(s);
    case 'ABORTED':return renderAborted(s);
    default:return '';
  }
}
function renderNotices(s) {
  const notices=s.me.notices.slice(-6).reverse();
  return `<div class="panel log-panel"><div class="panel-head"><h3>개인 알림</h3><small>PRIVATE</small></div>
    <div class="notice-list">${notices.length?notices.map(n=>
      `<div class="notice ${escapeHTML(n.type)}">${escapeHTML(n.text)}</div>`).join(''):
      '<div class="notice">개인 알림이 없습니다.</div>'}</div></div>`;
}
function renderChat(s) {
  const canSecret = (s.phase === 'NIGHT' && s.me.contact && s.night > s.me.contact.night && s.me.alive);
  if (!canSecret) chatTab='PUBLIC';
  const channel=canSecret && chatTab==='SECRET'?'SECRET':'PUBLIC';
  const messages=channel==='SECRET'?s.secretChat:s.publicChat;
  const allowed=channel==='SECRET'?s.me.canSecretChat:s.me.canPublicChat;
  const html=messages.slice(-45).map(m=>`<div class="chat-line"><strong class="${m.bot?'bot':''}">${m.number}번 ${escapeHTML(m.name)}</strong>
    <time>${new Date(m.at).toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit'})}</time>
    <p>${escapeHTML(m.text)}</p></div>`).join('');
  return `<div class="panel"><div class="chat-head"><strong>텍스트 채팅</strong>
    <span class="tiny">${allowed?'● 사용 가능':'○ 비활성화'}</span></div>
    <div class="chat-tabs"><button class="chat-tab ${channel==='PUBLIC'?'active':''}" data-cmd="chatTab" data-tab="PUBLIC">전체 채팅</button>
      ${canSecret?`<button class="chat-tab ${channel==='SECRET'?'active':''}" data-cmd="chatTab" data-tab="SECRET">마피아 비밀 채팅</button>`:''}</div>
    <div class="chat-scroll" id="chat-scroll">${html||'<div class="chat-empty">아직 대화가 없습니다.<br>첫 메시지를 남겨 보세요.</div>'}</div>
    ${allowed?`<form class="chat-composer" id="chat-form"><input id="chat-input" maxlength="220" autocomplete="off" placeholder="메시지 입력..." value="${escapeHTML(chatDraft)}">
    <button type="submit">전송</button></form>`:
    `<div class="chat-locked">${s.me.alive?'지금은 채팅을 사용할 수 없습니다.':'탈락자는 채팅에 참여할 수 없습니다.'}</div>`}</div>`;
}
function renderPublicLog(s) {
  return `<div class="panel log-panel"><div class="panel-head"><h3>게임 기록</h3><small>PUBLIC LOG</small></div>
    <div class="event-list">${s.publicLog.slice(-8).reverse().map(m=>`<div class="log-entry">${escapeHTML(m.text)}</div>`).join('')||
      '<div class="log-entry">아직 게임 기록이 없습니다.</div>'}</div></div>`;
}
// Patch individual areas instead of replacing the whole page when a new SSE
// snapshot arrives. The chat input must remain mounted while mobile keyboards
// are open, or typing becomes unreliable and the keyboard can close mid-sentence.
function patchSlot(id, html) {
  const el = document.getElementById(id);
  if (!el || slotCache.get(id) === html) return;
  el.innerHTML = html;
  slotCache.set(id, html);
}
function mobileStatus(s) {
  const round = s.night ? `${s.night}번째 밤` : '준비 중';
  return `<div class="mobile-status-left"><span class="mobile-phase">${escapeHTML(phaseNames[s.phase])}</span>
    <small>${round} · ${s.players.length}/7명 · ${escapeHTML(s.code)}</small></div>
    <div class="mobile-status-right">${s.deadline!==null?'<strong class="mobile-timer" id="timer-value-mobile">--:--</strong>':''}
    ${OFFLINE_MODE?'<span class="offline-status">오프라인</span>':'<button class="mobile-invite" data-cmd="share" aria-label="방 초대 링크 공유">초대 <span aria-hidden="true">↗</span></button>'}</div>`;
}
function mobileNavigation(s) {
  const views=[
    ['ACTION','진행','◈'],['CHAT','채팅','▤'],['PLAYERS','참가자','♙'],['INFO','알림','☷']
  ];
  return views.map(([v,label,symbol]) => `<button type="button" class="mobile-nav-button ${mobileView===v?'active':''}"
    data-cmd="mobileView" data-view="${v}" aria-label="${label} 화면" aria-pressed="${mobileView===v}">
    <span class="mobile-nav-symbol" aria-hidden="true">${symbol}</span>
    <span>${label}</span></button>`).join('');
}
function patchChat(s) {
  const existingInput = $('#chat-input');
  if (existingInput) chatDraft=existingInput.value;
  const wasFocused=existingInput && document.activeElement===existingInput;
  const canSecret = s.phase==='NIGHT' && !!s.me.contact && s.night>s.me.contact.night && s.me.alive;
  const nextChannel = canSecret && chatTab==='SECRET' ? 'SECRET' : 'PUBLIC';
  const nextHTML = renderChat(s);
  if (!nextHTML.includes('id="chat-input"')) $('.game-shell')?.classList.remove('is-typing');
  const sameChannel=renderedChatChannel===nextChannel;
  if (existingInput && sameChannel && nextHTML.includes('id="chat-input"')) {
    // Message updates must not replace the input that owns the soft keyboard.
    const template=document.createElement('template');
    template.innerHTML=nextHTML;
    const newScroll=template.content.querySelector('#chat-scroll');
    const oldScroll=$('#chat-scroll');
    if (oldScroll && newScroll && oldScroll.innerHTML!==newScroll.innerHTML) {
      const nearBottom=oldScroll.scrollHeight-oldScroll.scrollTop-oldScroll.clientHeight<100;
      const oldTop=oldScroll.scrollTop;
      oldScroll.innerHTML=newScroll.innerHTML;
      oldScroll.scrollTop=nearBottom?oldScroll.scrollHeight:oldTop;
    }
    const status=$('.chat-head .tiny');
    const newStatus=template.content.querySelector('.chat-head .tiny');
    if(status && newStatus) status.textContent=newStatus.textContent;
    slotCache.delete('chat-slot'); // next unfocused update may fully refresh
  } else {
    const wasAtBottom = (() => {
      const scroll=$('#chat-scroll');
      return !scroll || scroll.scrollHeight-scroll.scrollTop-scroll.clientHeight<90;
    })();
    patchSlot('chat-slot',nextHTML);
    const scroll=$('#chat-scroll');
    if(scroll && wasAtBottom) scroll.scrollTop=scroll.scrollHeight;
  }
  renderedChatChannel=nextChannel;
}
function renderGame() {
  const s=current;
  if (!s || !s.me) return renderLanding();
  let shell=$('.game-shell');
  if (!shell || shell.dataset.room!==s.code) {
    slotCache.clear();
    renderedChatChannel=null;
    root.innerHTML=`<div class="game-shell" data-room="${escapeHTML(s.code)}" data-mobile-view="${mobileView}">
      <div class="connect-banner game-alert hidden" role="alert" style="margin:0">연결이 불안정합니다. 진행 중인 판은 서버에서 중단될 수 있습니다.
        <button class="btn btn-ghost" data-cmd="goHome" style="margin-left:10px">처음 화면</button></div>
      <div class="mobile-status" id="mobile-status"></div>
      <div id="game-header"></div>
      <div class="board-grid">
        <aside class="seat-column" id="seat-column"><div id="roster-slot"></div>
          <div class="lobby-controls"><button class="btn btn-ghost btn-wide" data-cmd="leave">방에서 나가기</button></div></aside>
        <section class="panel main-panel"><div class="main-content" id="main-slot"></div></section>
        <aside class="side-column"><div id="chat-slot"></div><div id="notice-slot"></div><div id="log-slot"></div></aside>
      </div>
      <nav class="mobile-nav" id="mobile-nav" aria-label="모바일 게임 메뉴"></nav>
    </div>`;
    shell=$('.game-shell');
  }
  shell.dataset.mobileView=mobileView;
  patchSlot('mobile-status',mobileStatus(s));
  patchSlot('game-header',gameHeading(s));
  patchSlot('roster-slot',roster(s));
  patchSlot('main-slot',renderMain(s));
  patchSlot('notice-slot',renderNotices(s));
  patchSlot('log-slot',renderPublicLog(s));
  patchChat(s);
  patchSlot('mobile-nav',mobileNavigation(s));
  updateTimer();
}

function updateTimer() {
  if (!current || current.deadline===null) return;
  const remaining=Math.max(0,current.deadline-(Date.now()+clockOffset));
  const secs=Math.ceil(remaining/1000);
  const minutes=Math.floor(secs/60);
  const seconds=secs%60;
  for (const timer of [$('#timer-value'),$('#timer-value-mobile')]) if (timer) timer.textContent=`${String(minutes).padStart(2,'0')}:${String(seconds).padStart(2,'0')}`;
  const fill=$('#timer-fill');
  if (fill) {
    const total=Math.max(1,current.deadline-current.phaseStart);
    fill.style.width=Math.min(100,100*remaining/total)+'%';
  }
}
function openConfirm(targetId) {
  if (!current) return;
  const p=current.players.find(x=>x.id===targetId);
  if (!p) return;
  confirmTarget=targetId;
  overlay.classList.remove('hidden');
  overlay.innerHTML=`<div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">
    <div class="modal-kicker">FINAL CONFIRMATION</div>
    <h3 id="modal-title">${p.number}번 ${escapeHTML(p.name)} 플레이어를 확정하시겠습니까?</h3>
    <p>최종 확정된 야간 능력은 다시 변경할 수 없습니다. 모든 능력 보유자의 행동이 확정되면 밤이 바로 종료됩니다.</p>
    <div class="modal-actions"><button class="btn btn-ghost" data-cmd="decline">아니요</button>
      <button class="btn btn-primary" data-cmd="accept">예, 확정합니다</button></div></div>`;
}
function closeConfirm() {
  confirmTarget=null;
  overlay.classList.add('hidden');
  overlay.innerHTML='';
}
async function tapTarget(targetId) {
  if (!current || !current.me.canAct || current.me.action?.confirmed) return;
  if (!current.me.validTargets.includes(targetId)) return;
  if (current.me.action?.selected===targetId) return openConfirm(targetId);
  await action('selectAbility',{targetId});
}
async function copyText(value) {
  try { if (navigator.clipboard?.writeText) { await navigator.clipboard.writeText(value); return true; } }
  catch {}
  const t=document.createElement('textarea');
  t.value=value;
  t.style.cssText='position:fixed;left:0;top:0;opacity:0;z-index:-1';
  t.setAttribute('readonly','');
  document.body.appendChild(t);
  t.select();
  let copied=false;
  try { copied=document.execCommand('copy'); } catch {}
  t.remove();
  return copied;
}
async function shareRoom() {
  if (!current) return;
  if (OFFLINE_MODE) return toast('오프라인 게임은 AI 6명과 플레이합니다.');
  if (LOCAL_MODE) return toast('친구에게 6자리 방 코드를 알려주세요. 근거리 기기 연결이 필요합니다.');
  const url=new URL('/',location.href);
  url.searchParams.set('room',current.code);
  if (navigator.share) {
    try {
      await navigator.share({title:'NOIR / SEVEN 마피아 게임',text:`${current.code} 방에 참가하세요.`,url:url.href});
      return;
    } catch(e) { if(e?.name==='AbortError') return; }
  }
  const copied=await copyText(url.href);
  if (copied) toast('초대 링크를 복사했습니다. 같은 서버에 접속하는 친구에게 보내세요.');
  else window.prompt('다음 초대 링크를 복사해 주세요.',url.href);
}
root.addEventListener('click',async e=>{
  const btn=e.target.closest('button[data-cmd]');
  if (!btn || btn.disabled) return;
  const cmd=btn.dataset.cmd;
  try {
    if (cmd==='create') return createOrJoin('create');
    if (cmd==='join') return createOrJoin('join');
    if (cmd==='copy') {
      const copied=await copyText(current.code);
      return toast(copied?'방 코드를 복사했습니다.':'방 코드: '+current.code);
    }
    if (cmd==='share') return shareRoom();
    if (cmd==='mobileView') {
      mobileView=btn.dataset.view;
      renderGame();
      window.scrollTo(0,0);
      return;
    }
    if (cmd==='bots') return action('addBots',{count:Number(btn.dataset.count)});
    if (cmd==='fill') return action('addBots',{count:7-current.players.length});
    if (cmd==='removeBots') return action('removeBots');
    if (cmd==='start') return action('start');
    if (cmd==='box') return action('chooseBox',{index:Number(btn.dataset.index)});
    if (cmd==='confirmRole') return action('confirmRole');
    if (cmd==='target') return tapTarget(btn.dataset.id);
    if (cmd==='vote') return action('vote',{targetId:btn.dataset.id});
    if (cmd==='resetLobby') return action('resetLobby');
    if (cmd==='chatTab') {chatTab=btn.dataset.tab; chatDraft=''; const input=$('#chat-input'); if(input) input.value=''; return renderGame();}
    if (cmd==='leave') return leave();
    if (cmd==='goHome') return resetToStart('연결을 새로 설정해 주세요.');
  } catch(err){ toast(err.message); }
});
overlay.addEventListener('click',async e=>{
  if(e.target===overlay) return closeConfirm();
  const btn=e.target.closest('button[data-cmd]');
  if (!btn) return;
  if(btn.dataset.cmd==='decline') return closeConfirm();
  if(btn.dataset.cmd==='accept') {
    const id=confirmTarget;
    closeConfirm();
    if(id) await action('confirmAbility',{targetId:id});
  }
});
root.addEventListener('focusin',e=>{
  if (e.target.id==='chat-input') $('.game-shell')?.classList.add('is-typing');
});
root.addEventListener('focusout',e=>{
  if (e.target.id==='chat-input') $('.game-shell')?.classList.remove('is-typing');
});
root.addEventListener('input',e=>{
  if(e.target.id==='chat-input') chatDraft=e.target.value;
  if(e.target.id==='join-code') e.target.value=e.target.value.toUpperCase().replace(/[^A-Z2-9]/g,'');
});
root.addEventListener('submit',async e=>{
  if(e.target.id!=='chat-form') return;
  e.preventDefault();
  const input=$('#chat-input');
  const value=input?.value.trim()||'';
  if(!value)return;
  const channel=chatTab==='SECRET'?'SECRET':'PUBLIC';
  chatDraft='';
  if(input) input.value='';
  await action('chat',{channel,text:value});
});
root.addEventListener('keydown',e=>{
  if(e.key==='Enter' && e.target.id==='join-code') {
    e.preventDefault();createOrJoin('join');
  }
});
setInterval(updateTimer,200);
setInterval(() => {
  if (!OFFLINE_MODE && !LOCAL_MODE && token && stream && stream.readyState === EventSource.OPEN) {
    request('/api/action',{ token, type:'heartbeat' }).catch(() => {});
  }
},2500);
if ('serviceWorker' in navigator && (location.protocol==='https:' || location.hostname==='localhost' || location.hostname==='127.0.0.1')) {
  window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
}
if(token && !OFFLINE_MODE && !LOCAL_MODE) connect();
else renderLanding();
