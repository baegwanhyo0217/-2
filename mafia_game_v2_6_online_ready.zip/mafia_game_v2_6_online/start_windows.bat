@echo off
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo Node.js 20 or higher is required. https://nodejs.org/
  pause
  exit /b 1
)
start "Browser" cmd /c "timeout /t 2 /nobreak >nul && start http://localhost:3000"
node server.js
pause
