'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const { server }=require('../server');

async function withServer(fn){
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  try { await fn(`http://127.0.0.1:${server.address().port}`); }
  finally { await new Promise(resolve=>server.close(resolve)); }
}
test('mobile PWA manifest, icons, service worker and UI are served with correct types', async()=>{
  await withServer(async base=>{
    for(const [url,type] of [
      ['/','text/html'], ['/style.css','text/css'], ['/app.js','application/javascript'],
      ['/manifest.webmanifest','application/manifest+json'], ['/sw.js','application/javascript'],
      ['/icons/icon-192.png','image/png'], ['/icons/icon-512.png','image/png']
    ]){
      const response=await fetch(base+url);
      assert.equal(response.status,200,url);
      assert.ok((response.headers.get('content-type')||'').startsWith(type),url);
      assert.ok((await response.arrayBuffer()).byteLength>100,url);
    }
  });
});
test('mobile join URL reaches game HTML, and private APIs are not part of cache shell', async()=>{
  await withServer(async base=>{
    const html=await (await fetch(base+'/?room=ABC234')).text();
    assert.match(html,/viewport-fit=cover/);
    assert.match(html,/manifest\.webmanifest/);
    const sw=await (await fetch(base+'/sw.js')).text();
    assert.match(sw,/req\.url\.includes\('\/api\/'\)/);
    const css=await (await fetch(base+'/style.css')).text();
    assert.match(css,/data-mobile-view="CHAT"/);
    const js=await (await fetch(base+'/app.js')).text();
    assert.match(js,/invitationCode/);
    assert.match(js,/mobileNavigation/);
  });
});
