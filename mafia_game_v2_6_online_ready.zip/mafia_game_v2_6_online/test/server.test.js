'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const http=require('node:http');
const {once}=require('node:events');
const {server}=require('../server');
let port;
async function post(path, obj) {
  const response=await fetch(`http://127.0.0.1:${port}${path}`, {method:'POST',
    headers:{'Content-Type':'application/json'},body:JSON.stringify(obj)});
  return {status:response.status, data:await response.json()};
}
async function state(token) {
  const response=await fetch(`http://127.0.0.1:${port}/api/state?token=${token}`);
  return {status:response.status, data:await response.json()};
}
function stream(token) {
  return new Promise((resolve,reject)=>{
    const req=http.get(`http://127.0.0.1:${port}/api/stream?token=${token}`,
      res=>{ if(res.statusCode!==200) return reject(new Error('SSE status '+res.statusCode));
        res.on('data',()=>{});resolve({req,res});});
    req.on('error',reject);
  });
}
async function waitFor(fn, timeout=1500) {
  const begin=Date.now();
  while(Date.now()-begin<timeout) {
    const val=await fn();if(val)return val;
    await new Promise(ok=>setTimeout(ok,25));
  }
  throw new Error('Timed out waiting for condition');
}
test.before(async()=>{
  server.listen(0,'127.0.0.1');await once(server,'listening');port=server.address().port;
});
test.after(async()=>{await new Promise(ok=>server.close(ok));});

test('HTTP API: two humans, five AI, role boxes, network interruption',async()=>{
  const a=await post('/api/create',{name:'호스트'});
  assert.equal(a.status,200);
  assert.equal(a.data.code.length,6);
  const b=await post('/api/join',{name:'게스트',code:a.data.code});
  assert.equal(b.status,200);
  const A=await stream(a.data.token);
  const B=await stream(b.data.token);
  try {
    const before=await state(a.data.token);
    assert.equal(before.data.state.phase,'LOBBY');
    assert.equal(before.data.state.players.length,2);
    assert.equal(before.data.state.me.connected,true);
    assert.equal((await post('/api/action',{type:'addBots',token:a.data.token,count:5})).status,200);
    assert.equal((await post('/api/action',{type:'start',token:a.data.token})).status,200);
    const game=await state(a.data.token);
    assert.equal(game.data.state.phase,'BOXES');
    assert.equal(game.data.state.players.length,7);
    const bad=await post('/api/action',{type:'start',token:b.data.token});
    assert.equal(bad.status,400);
    assert.equal((await post('/api/action',{type:'chooseBox',token:a.data.token,index:0})).status,200);
    assert.equal((await post('/api/action',{type:'chooseBox',token:b.data.token,index:1})).status,200);
    assert.equal((await post('/api/action',{type:'confirmRole',token:a.data.token})).status,200);
    assert.equal((await post('/api/action',{type:'confirmRole',token:b.data.token})).status,200);
    const aNight=await state(a.data.token);
    const bNight=await state(b.data.token);
    assert.equal(aNight.data.state.phase,'NIGHT');
    assert.equal(aNight.data.state.players.some(p=>('role' in p)),false);
    assert.equal(bNight.data.state.me.role!==null,true);
    assert.equal(aNight.data.state.players.filter(p=>p.bot).length,5);
    const illegal=await post('/api/action',{type:'vote',token:b.data.token,targetId:bNight.data.state.me.id});
    assert.equal(illegal.status,400);
    B.res.destroy();
    await waitFor(async()=>{
      const v=await state(a.data.token);
      return v.data.state.phase==='ABORTED' ? v.data.state : null;
    });
    const abort=await state(a.data.token);
    assert.equal(abort.data.state.winningTeam,null);
    assert.match(abort.data.state.abortReason,/접속 종료/);
    assert.equal((await post('/api/action',{type:'resetLobby',token:a.data.token})).status,200);
    assert.equal((await state(a.data.token)).data.state.players.length,1);
    assert.equal((await state(a.data.token)).data.state.phase,'LOBBY');
    assert.equal((await state(b.data.token)).status,400);
  } finally {A.res.destroy();B.res.destroy();}
});

test('HTTP API rejects unauthorized actions and unknown room codes',async()=>{
  const missing=await post('/api/join',{code:'ZZZZZZ',name:'A'});
  assert.equal(missing.status,400);
  const invalid=await post('/api/action',{token:'unauthorized',type:'start'});
  assert.equal(invalid.status,400);
});
