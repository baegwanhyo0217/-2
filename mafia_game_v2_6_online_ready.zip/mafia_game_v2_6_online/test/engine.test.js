'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { MafiaRoom, ROLES, ROLE_KO } = require('../src/engine');

function fixture(options={}) {
  let currentTime=options.initialTime??1000;
  let rv=0;
  const rng=options.rng || (()=> {rv=(rv+0.3761)%1;return rv;});
  const room=new MafiaRoom('ABC123', { now:()=>currentTime,rng,
    durations:{NIGHT:60000,NIGHT_RESULT:4000,DAY:120000,VOTE1:30000,
      EXTRA_DISCUSSION:60000,VOTE2:30000,VOTE_RESULT:4000} });
  const people=[];
  const humans=options.humans??7;
  for(let i=0;i<humans;i++) {
    const p=room.createPlayer(`Player ${i+1}`);
    p.connected=true;people.push(p);
  }
  if(humans<7) room.addBots(people[0],7-humans);
  room.startDraft(people[0]);
  if(humans===7) {
    for(let i=0;i<7;i++) {
      const b=room.boxAssignments.indexOf(ROLES[i]);
      let idx=b;
      if(ROLES[i]==='CITIZEN' && room.boxOwners[idx]) idx=room.boxAssignments.findIndex((r,j)=>r==='CITIZEN' && !room.boxOwners[j]);
      room.chooseBox(people[i],idx);
    }
  } else {
    for(let i=0;i<humans;i++) room.chooseBox(people[i],
      room.boxOwners.findIndex(x=>x===null));
  }
  for(const p of people) room.confirmRole(p);
  assert.equal(room.phase,'NIGHT');
  return {
    room, people,
    byRole:role=>room.players.find(p=>p.role===role),
    allRole:role=>room.players.filter(p=>p.role===role),
    advance:(ms)=>{currentTime+=ms;room.tick();},
    moveToDeadline:()=>{currentTime=room.deadline+1;room.tick();},
    get now(){return currentTime;}
  };
}
function choose(room,p,target) {room.selectAbility(p,target.id);room.confirmAbility(p,target.id);}
function checkDay(f) {
  if(f.room.phase==='NIGHT') f.moveToDeadline();
  assert.equal(f.room.phase,'NIGHT_RESULT');
  f.moveToDeadline();
  assert.equal(f.room.phase,'DAY');
}
function nextNight(f) {
  if(f.room.phase==='NIGHT') checkDay(f);
  if(f.room.phase==='DAY') f.moveToDeadline();
  assert.equal(f.room.phase,'VOTE1');
  f.moveToDeadline();
  if(f.room.phase==='EXTRA_DISCUSSION') {f.moveToDeadline();f.moveToDeadline();}
  assert.equal(f.room.phase,'VOTE_RESULT');
  f.moveToDeadline();
  assert.equal(f.room.phase,'NIGHT');
}

// Box assignment, privacy, phase timing, simultaneous ability finalization.
test('7-player composition and roles are exact, citizen duplicated only',()=>{
  const f=fixture();
  const roles=f.room.players.map(p=>p.role).sort();
  assert.deepEqual(roles,ROLES.slice().sort());
  assert.equal(f.room.players.filter(p=>p.team==='CITIZEN').length,5);
  assert.equal(f.room.players.filter(p=>p.team==='MAFIA').length,2);
});
test('box choice cannot overlap and only reveals role privately',()=>{
  const r=new MafiaRoom('T1');
  const a=r.createPlayer('A');a.connected=true;
  for(let i=1;i<7;i++){ const p=r.createPlayer('P');p.connected=true; }
  r.startDraft(a);
  r.chooseBox(a,0);
  assert.throws(()=>r.chooseBox(r.players[1],0),/선택된/);
  assert.throws(()=>r.chooseBox(a,1),/이미 상자/);
  assert.equal(r.snapshotFor(r.players[1]).me.role,null);
  assert.equal(r.snapshotFor(r.players[1]).players.find(p=>p.id===a.id).role,undefined);
  assert.equal(typeof r.snapshotFor(a).me.role,'string');
});
test('box draft awaits every human confirmation',()=>{
  const r=new MafiaRoom('T2',{rng:()=>0.3});
  const ps=Array.from({length:7},()=>{const p=r.createPlayer('X');p.connected=true;return p;});
  r.startDraft(ps[0]);
  ps.forEach((p,i)=>r.chooseBox(p,i));
  ps.slice(0,6).forEach(p=>r.confirmRole(p));
  assert.equal(r.phase,'BOXES');
  r.confirmRole(ps[6]);assert.equal(r.phase,'NIGHT');
});
test('night has exactly five active roles before contact',()=>{
  const f=fixture();
  assert.equal(f.room.actions.size,5);
  assert.equal(f.room.deadline-f.room.phaseStart,60000);
  assert.equal(f.room.validTargets(f.byRole('DOCTOR')).length,7);
  for(const role of ['MAFIA','POLICE','SPY','GANGSTER'])
    assert.equal(f.room.validTargets(f.byRole(role)).length,6);
});
test('self targeting restricted for four roles but doctor can self-heal',()=>{
  const f=fixture();
  for(const role of ['MAFIA','POLICE','SPY','GANGSTER']) {
    const p=f.byRole(role);
    assert.throws(()=>f.room.selectAbility(p,p.id),/선택할 수 없습니다/);
    assert.ok(!f.room.validTargets(p).includes(p.id));
  }
  const d=f.byRole('DOCTOR');
  choose(f.room,d,d);
  assert.equal(f.room.actions.get(d.id).target,d.id);
});
test('first tap only selects, switching target before confirmation works',()=>{
  const f=fixture();const p=f.byRole('POLICE');
  const others=f.room.players.filter(x=>x!==p);
  f.room.selectAbility(p,others[0].id);
  assert.equal(f.room.actions.get(p.id).confirmed,false);
  f.room.selectAbility(p,others[1].id);
  assert.equal(f.room.actions.get(p.id).selected,others[1].id);
  f.room.confirmAbility(p,others[1].id);
  assert.equal(f.room.actions.get(p.id).confirmed,true);
  assert.throws(()=>f.room.selectAbility(p,others[0].id),/변경/);
  assert.throws(()=>f.room.confirmAbility(p,others[0].id),/확정할 수/);
});
test('confirm requires the last temporary target, not arbitrary target',()=>{
  const f=fixture(),p=f.byRole('POLICE'),others=f.room.players.filter(x=>x!==p);
  f.room.selectAbility(p,others[0].id);
  assert.throws(()=>f.room.confirmAbility(p,others[1].id),/임시 선택/);
  assert.equal(f.room.actions.get(p.id).confirmed,false);
});
test('temporary target is final on timeout; doctor defaults to self',()=>{
  const f=fixture(),cop=f.byRole('POLICE'),doctor=f.byRole('DOCTOR');
  const others=f.room.players.filter(x=>x!==cop);
  f.room.selectAbility(cop,others[0].id);
  f.room.selectAbility(cop,others[1].id);
  f.moveToDeadline();
  assert.equal(f.room.actions.get(cop.id).target,others[1].id);
  assert.equal(f.room.actions.get(cop.id).fromLastSelection,true);
  assert.equal(f.room.actions.get(doctor.id).target,doctor.id);
  assert.equal(f.room.actions.get(doctor.id).auto,true);
  for(const role of ['MAFIA','POLICE','SPY','GANGSTER']) {
    const p=f.byRole(role),a=f.room.actions.get(p.id);
    assert.notEqual(a.target,p.id);
  }
});
test('all active participants confirm -> night ends early',()=>{
  const f=fixture();
  const t0=f.now;
  for(const p of f.room.players.filter(x=>x.role!=='CITIZEN')) {
    const target=f.room.players.find(x=>x.id!==p.id);
    choose(f.room,p,target);
  }
  assert.equal(f.room.phase,'NIGHT_RESULT');
  assert.equal(f.now,t0);
});
test('pending night murder hidden from public until morning',()=>{
  const f=fixture(),mafia=f.byRole('MAFIA'),doctor=f.byRole('DOCTOR');
  const victim=f.byRole('CITIZEN');
  choose(f.room,mafia,victim);choose(f.room,doctor,doctor);
  f.moveToDeadline();
  assert.equal(f.room.phase,'NIGHT_RESULT');
  assert.equal(victim.alive,true);
  assert.ok(!f.room.snapshotFor(f.byRole('POLICE')).publicLog.some(x=>x.text.includes('지난밤')));
  f.moveToDeadline();
  assert.equal(victim.alive,false);
  assert.equal(f.room.phase,'DAY');
  assert.ok(f.room.publicLog.some(x=>x.text.includes('사망했습니다')));
});
test('doctor treatment protects against Mafia attack and notifies only doctor',()=>{
  const f=fixture(),victim=f.byRole('POLICE');
  choose(f.room,f.byRole('MAFIA'),victim);
  choose(f.room,f.byRole('DOCTOR'),victim);
  checkDay(f);
  assert.equal(victim.alive,true);
  assert.ok(f.byRole('DOCTOR').notices.some(x=>x.text.includes('살렸습니다')));
  assert.ok(!f.room.snapshotFor(f.byRole('CITIZEN')).me.notices.some(x=>x.text.includes('살렸습니다')));
});
test('police sees team and Spy is always disguised as a Citizen',()=>{
  const f=fixture();choose(f.room,f.byRole('POLICE'),f.byRole('SPY'));
  f.moveToDeadline();
  assert.equal(f.byRole('POLICE').investigations.at(-1).displayed,'시민팀');
  assert.ok(!f.byRole('CITIZEN').notices.some(x=>x.type==='investigation'));
});
test('Spy sees actual roles, not team only',()=>{
  const f=fixture();choose(f.room,f.byRole('SPY'),f.byRole('DOCTOR'));
  f.moveToDeadline();
  assert.equal(f.byRole('SPY').investigations.at(-1).actualRole,'DOCTOR');
});

test('contact A keeps Mafia attack against a third player',()=>{
  const f=fixture();
  const target=f.byRole('POLICE');
  choose(f.room,f.byRole('MAFIA'),target);
  choose(f.room,f.byRole('SPY'),f.byRole('MAFIA'));
  choose(f.room,f.byRole('DOCTOR'),f.byRole('DOCTOR'));
  checkDay(f);
  assert.equal(f.room.contact.type,'A');
  assert.equal(f.room.contact.night,1);
  assert.equal(target.alive,false);
  assert.ok(f.byRole('SPY').notices.some(x=>x.type==='contact'));
  assert.equal(f.room.secretChat.length,0);
});
test('contact A + healed third player does not kill them',()=>{
  const f=fixture(),target=f.byRole('POLICE');
  choose(f.room,f.byRole('MAFIA'),target);
  choose(f.room,f.byRole('SPY'),f.byRole('MAFIA'));
  choose(f.room,f.byRole('DOCTOR'),target);
  checkDay(f);
  assert.equal(f.room.contact.type,'A');
  assert.equal(target.alive,true);
});
test('contact B cancels attack, never selects an additional victim',()=>{
  const f=fixture(),spy=f.byRole('SPY');
  choose(f.room,f.byRole('MAFIA'),spy);
  choose(f.room,spy,f.byRole('DOCTOR'));
  checkDay(f);
  assert.equal(f.room.contact.type,'B');
  assert.equal(f.room.pendingNight.attackTargetId,spy.id);
  assert.equal(f.room.pendingNight.effectiveAttack,null);
  assert.equal(f.room.pendingNight.deathId,null);
  assert.equal(spy.alive,true);
  assert.equal(spy.investigations.at(-1).actualRole,'DOCTOR');
});
test('simultaneous contact chooses A but still cancels the attack',()=>{
  const f=fixture(),spy=f.byRole('SPY'),mafia=f.byRole('MAFIA');
  choose(f.room,mafia,spy);choose(f.room,spy,mafia);
  checkDay(f);
  assert.equal(f.room.contact.type,'A');
  assert.equal(f.room.pendingNight.effectiveAttack,null);
  assert.equal(spy.alive,true);
  assert.equal(spy.investigations.at(-1).actualRole,'MAFIA');
});
test('the contact night never enables secret chat',()=>{
  const f=fixture(),spy=f.byRole('SPY');
  choose(f.room,spy,f.byRole('MAFIA'));
  f.moveToDeadline();
  assert.equal(f.room.contact.night,1);
  assert.equal(f.room.canChat(spy,'SECRET'),false);
  assert.throws(()=>f.room.sendChat(spy,'SECRET','hello'),/채팅/);
});
test('next night spy loses investigation, joint chat begins and Mafia cannot target spy',()=>{
  const f=fixture();
  choose(f.room,f.byRole('SPY'),f.byRole('MAFIA'));
  choose(f.room,f.byRole('MAFIA'),f.byRole('DOCTOR'));
  choose(f.room,f.byRole('DOCTOR'),f.byRole('DOCTOR'));
  checkDay(f);
  nextNight(f);
  assert.equal(f.room.night,2);
  assert.equal(f.room.actions.has(f.byRole('SPY').id),false);
  assert.equal(f.room.actions.size,4);
  assert.equal(f.room.canChat(f.byRole('SPY'),'SECRET'),true);
  assert.equal(f.room.canChat(f.byRole('MAFIA'),'SECRET'),true);
  assert.equal(f.room.validTargets(f.byRole('MAFIA')).includes(f.byRole('SPY').id),false);
  assert.throws(()=>f.room.selectAbility(f.byRole('SPY'),f.byRole('POLICE').id),/능력을 사용할/);
});
test('secret messages visible only to linked Mafia and Spy',()=>{
  const f=fixture(),spy=f.byRole('SPY');
  choose(f.room,spy,f.byRole('MAFIA'));
  checkDay(f);nextNight(f);
  f.room.sendChat(spy,'SECRET','3번을 조사했어요');
  assert.equal(f.room.snapshotFor(spy).secretChat.length,1);
  assert.equal(f.room.snapshotFor(f.byRole('MAFIA')).secretChat.length,1);
  assert.equal(f.room.snapshotFor(f.byRole('POLICE')).secretChat.length,0);
  assert.equal(f.room.snapshotFor(f.byRole('DOCTOR')).me.contact,null);
});
test('chat limited to its respective phases',()=>{
  const f=fixture(),citizen=f.byRole('CITIZEN');
  assert.throws(()=>f.room.sendChat(citizen,'PUBLIC','hi'),/채팅/);
  checkDay(f);
  f.room.sendChat(citizen,'PUBLIC','안녕하세요');
  assert.equal(f.room.publicChat.length,1);
  assert.throws(()=>f.room.sendChat(citizen,'SECRET','안녕'),/채팅/);
  f.moveToDeadline();
  assert.throws(()=>f.room.sendChat(citizen,'PUBLIC','안녕'),/채팅/);
});
test('chat text is plain and length limited with anti-spam',()=>{
  const f=fixture();checkDay(f);
  const p=f.byRole('DOCTOR');
  f.room.sendChat(p,'PUBLIC','<b>hi</b>');
  assert.equal(f.room.publicChat[0].text,'<b>hi</b>');
  assert.throws(()=>f.room.sendChat(p,'PUBLIC','too quick'),/빠르게/);
  assert.ok(f.room.snapshotFor(p).publicChat[0].text.length<220);
});
test('gangster stun and doctor heal independently affect same player',()=>{
  const f=fixture(),target=f.byRole('POLICE');
  choose(f.room,f.byRole('MAFIA'),target);
  choose(f.room,f.byRole('DOCTOR'),target);
  choose(f.room,f.byRole('GANGSTER'),target);
  checkDay(f);
  assert.equal(target.alive,true);
  assert.equal(f.room.stunnedId,target.id);
  f.moveToDeadline();
  assert.equal(f.room.canVote(target),false);
  assert.throws(()=>f.room.submitVote(target,'SKIP'),/투표할 수/);
});
test('stunned victim may participate in discussion but not primary vote or revote',()=>{
  const f=fixture(),stun=f.byRole('POLICE');
  choose(f.room,f.byRole('GANGSTER'),stun);
  checkDay(f);
  assert.equal(f.room.canChat(stun,'PUBLIC'),true);
  f.moveToDeadline();
  assert.equal(f.room.canVote(stun),false);
  const mafia=f.byRole('MAFIA'),doc=f.byRole('DOCTOR');
  f.room.submitVote(mafia,doc.id);
  f.room.submitVote(doc,mafia.id);
  f.moveToDeadline();
  assert.equal(f.room.phase,'EXTRA_DISCUSSION');
  assert.equal(f.room.canChat(stun,'PUBLIC'),true);
  f.moveToDeadline();
  assert.equal(f.room.phase,'VOTE2');
  assert.equal(f.room.canVote(stun),false);
});
test('vote cannot target self, dead, or be submitted twice',()=>{
  const f=fixture();checkDay(f);f.moveToDeadline();
  const p=f.byRole('POLICE'),other=f.byRole('DOCTOR');
  assert.throws(()=>f.room.submitVote(p,p.id),/유효하지 않은/);
  other.alive=false;
  assert.throws(()=>f.room.submitVote(p,other.id),/유효하지 않은/);
  f.room.submitVote(p,'SKIP');
  assert.throws(()=>f.room.submitVote(p,'SKIP'),/이미 투표/);
});
test('unsubmitted votes are invalid and never converted into skip',()=>{
  const f=fixture();checkDay(f);f.moveToDeadline();f.moveToDeadline();
  assert.equal(f.room.phase,'VOTE_RESULT');
  assert.equal(f.room.voteOutcome.kind,'EMPTY');
  assert.equal(f.room.voteOutcome.valid,0);
  assert.equal(f.room.voteOutcome.counts.length,0);
});
test('one valid skip is not an empty vote',()=>{
  const f=fixture();checkDay(f);f.moveToDeadline();
  f.room.submitVote(f.byRole('MAFIA'),'SKIP');
  f.moveToDeadline();
  assert.equal(f.room.voteOutcome.kind,'SKIP');
  assert.equal(f.room.voteOutcome.valid,1);
});
test('first-round tie including skip starts extra discussion',()=>{
  const f=fixture();checkDay(f);f.moveToDeadline();
  f.room.submitVote(f.byRole('MAFIA'),'SKIP');
  f.room.submitVote(f.byRole('SPY'),f.byRole('POLICE').id);
  f.moveToDeadline();
  assert.equal(f.room.phase,'EXTRA_DISCUSSION');
  assert.equal(f.room.deadline-f.room.phaseStart,60000);
});
test('revote permits any living candidate, not just those tied previously',()=>{
  const f=fixture();checkDay(f);f.moveToDeadline();
  f.room.submitVote(f.byRole('MAFIA'),f.byRole('DOCTOR').id);
  f.room.submitVote(f.byRole('SPY'),f.byRole('POLICE').id);
  f.moveToDeadline();f.moveToDeadline();
  const p=f.byRole('DOCTOR'),target=f.room.players.find(x=>x.alive && x.id!==p.id && ![f.byRole('DOCTOR').id,f.byRole('POLICE').id].includes(x.id));
  assert.equal(f.room.phase,'VOTE2');
  f.room.submitVote(p,target.id);
  assert.equal(f.room.votes.get(p.id).targetId,target.id);
});
test('second-round tie is invalid, with no third voting round',()=>{
  const f=fixture();checkDay(f);f.moveToDeadline();
  f.room.submitVote(f.byRole('MAFIA'),'SKIP');
  f.room.submitVote(f.byRole('SPY'),f.byRole('POLICE').id);
  f.moveToDeadline();f.moveToDeadline();
  f.room.submitVote(f.byRole('MAFIA'),'SKIP');
  f.room.submitVote(f.byRole('SPY'),f.byRole('DOCTOR').id);
  f.moveToDeadline();
  assert.equal(f.room.voteOutcome.kind,'TIE');
  assert.equal(f.room.phase,'VOTE_RESULT');
  f.moveToDeadline();
  assert.equal(f.room.phase,'NIGHT');
});
test('second-round 0 valid votes is invalid',()=>{
  const f=fixture();checkDay(f);f.moveToDeadline();
  f.room.submitVote(f.byRole('MAFIA'),'SKIP');
  f.room.submitVote(f.byRole('SPY'),f.byRole('DOCTOR').id);
  f.moveToDeadline();f.moveToDeadline();f.moveToDeadline();
  assert.equal(f.room.voteOutcome.kind,'EMPTY');
  assert.equal(f.room.phase,'VOTE_RESULT');
});
test('vote expelling Mafia triggers immediate Citizen victory even if Spy alive',()=>{
  const f=fixture();checkDay(f);f.moveToDeadline();
  f.room.submitVote(f.byRole('POLICE'),f.byRole('MAFIA').id);
  f.moveToDeadline();
  assert.equal(f.room.phase,'GAME_OVER');
  assert.equal(f.room.winningTeam,'CITIZEN');
  assert.equal(f.byRole('SPY').alive,true);
  assert.ok(f.room.snapshotFor(f.byRole('SPY')).players.every(x=>x.role));
});
test('parity does not decide Mafia victory, only elimination of all Citizens',()=>{
  const f=fixture();
  const citizens=f.room.players.filter(x=>x.team==='CITIZEN');
  citizens.slice(0,3).forEach(p=>p.alive=false);
  assert.equal(f.room.checkVictory(),false);
  citizens.slice(3).forEach(p=>p.alive=false);
  assert.equal(f.room.checkVictory(),true);
  assert.equal(f.room.winningTeam,'MAFIA');
});
test('nonterminal deaths and expulsions do not expose roles publicly',()=>{
  const f=fixture(),p=f.byRole('POLICE');
  choose(f.room,f.byRole('MAFIA'),p);
  checkDay(f);
  assert.equal(f.room.snapshotFor(f.byRole('MAFIA')).players.find(x=>x.id===p.id).role,undefined);
  assert.equal(f.room.snapshotFor(f.byRole('MAFIA')).players.find(x=>x.id===p.id).team,undefined);
});
test('abort has no winners, clears pending actions, and disallows resumed gameplay',()=>{
  const f=fixture();
  f.room.selectAbility(f.byRole('POLICE'),f.byRole('MAFIA').id);
  f.room.abort('network down');
  assert.equal(f.room.phase,'ABORTED');
  assert.equal(f.room.winningTeam,null);
  assert.equal(f.room.actions.size,0);
  assert.throws(()=>f.room.confirmAbility(f.byRole('POLICE'),f.byRole('MAFIA').id),/현재 단계/);
  f.room.resetLobby(f.people[0]);
  assert.equal(f.room.phase,'LOBBY');
  assert.ok(f.room.players.every(p=>p.role===null && p.alive));
  assert.equal(f.room.contact,null);
});
test('network abort wins precedence over unprocessed scheduled resolution',()=>{
  const f=fixture();
  f.room.abort('client lost');
  f.advance(10*60000);
  assert.equal(f.room.phase,'ABORTED');
  assert.equal(f.room.winningTeam,null);
});
test('disconnecting a human aborts a match regardless of role',()=>{
  const f=fixture();
  const citizen=f.byRole('CITIZEN');
  f.room.removeHuman(citizen,'disconnected');
  assert.equal(f.room.phase,'ABORTED');
  assert.equal(f.room.players.length,6);
  assert.equal(f.room.winningTeam,null);
});
test('already finished game is not changed to abort by later disconnect',()=>{
  const f=fixture();f.byRole('MAFIA').alive=false;
  f.room.checkVictory();
  f.room.removeHuman(f.byRole('POLICE'),'disconnected');
  assert.equal(f.room.phase,'GAME_OVER');
  assert.equal(f.room.winningTeam,'CITIZEN');
});
test('bot fill makes exactly seven seats and assigns same job composition',()=>{
  const f=fixture({humans:1});
  assert.equal(f.room.players.length,7);
  assert.equal(f.room.players.filter(x=>x.bot).length,6);
  assert.deepEqual(f.room.players.map(p=>p.role).sort(),ROLES.slice().sort());
  assert.ok(f.room.players.filter(x=>x.bot).every(x=>x.roleReady));
});
test('bots use abilities and confirm before timeout whenever scheduled',()=>{
  const f=fixture({humans:1});
  f.advance(14000);
  for(const p of f.room.players.filter(x=>x.bot && f.room.usable(x))) {
    const a=f.room.actions.get(p.id);
    assert.equal(a.confirmed,true,`${p.role} failed to confirm`);
    assert.ok(f.room.validTargets(p).includes(a.target));
  }
});
test('bot knowledge does not contain the other hidden jobs before contact',()=>{
  const f=fixture({humans:1});
  const bot=f.room.players.find(x=>x.bot);
  const info=f.room.botKnowledge(bot);
  assert.ok(info.alivePlayers.every(x=>!('role' in x) && !('team' in x)));
  assert.equal(info.partnerId,null);
  assert.ok(!('room' in info) && !('allRoles' in info));
});
test('bots can vote and chat using their own actions',()=>{
  const f=fixture({humans:1});
  f.advance(14000);
  if(f.room.phase==='NIGHT') f.moveToDeadline();
  f.moveToDeadline();
  assert.equal(f.room.phase,'DAY');
  f.advance(55000);
  assert.ok(f.room.publicChat.some(x=>x.bot));
  f.moveToDeadline();
  f.advance(21000);
  assert.ok(f.room.votes.size>=1);
  for(const [id,v] of f.room.votes) {
    assert.notEqual(id,v.targetId);
    assert.ok(v.targetId==='SKIP' || f.room.getPlayer(v.targetId)?.alive);
  }
});
test('bot slots removed when restarting aborted match',()=>{
  const f=fixture({humans:1});
  f.room.abort('connection lost');
  f.room.resetLobby(f.people[0]);
  assert.equal(f.room.players.length,1);
  assert.equal(f.room.players[0].bot,false);
  assert.equal(f.room.night,0);
});

test('linked Spy can see Mafia choice while everyone else cannot',()=>{
  const f=fixture();
  choose(f.room,f.byRole('SPY'),f.byRole('MAFIA'));
  choose(f.room,f.byRole('MAFIA'),f.byRole('DOCTOR'));
  choose(f.room,f.byRole('DOCTOR'),f.byRole('DOCTOR'));
  checkDay(f);nextNight(f);
  const mafia=f.byRole('MAFIA'),spy=f.byRole('SPY'),target=f.room.players.find(p=>p.alive && p.team==='CITIZEN' && p!==mafia);
  f.room.selectAbility(mafia,target.id);
  const spyState=f.room.snapshotFor(spy);
  assert.equal(spyState.me.teamAction.selected,target.id);
  assert.equal(spyState.me.teamAction.confirmed,false);
  const doctorState=f.room.snapshotFor(f.byRole('DOCTOR'));
  assert.equal(doctorState.me.teamAction,null);
  f.room.confirmAbility(mafia,target.id);
  assert.equal(f.room.snapshotFor(spy).me.teamAction.confirmed,true);
});
test('AI-driven games eventually terminate without deadlocks across 80 random seeds',()=>{
  const outcomes={CITIZEN:0,MAFIA:0};
  for(let seed=1;seed<=80;seed++) {
    let clock=1000;
    let x=seed;
    const rng=()=>{x=(x*1664525+1013904223)>>>0;return x/4294967296;};
    const room=new MafiaRoom('SIM',{now:()=>clock,rng});
    const human=room.createPlayer('tester');human.connected=true;
    room.addBots(human,6);room.startDraft(human);
    room.chooseBox(human,0);room.confirmRole(human);
    for(let step=0;step<200 && room.phase!=='GAME_OVER';step++) {
      if(room.deadline===null) throw new Error(`bad phase ${room.phase}`);
      clock=room.deadline+1;
      room.tick();
    }
    assert.equal(room.phase,'GAME_OVER',`seed ${seed} stalled at ${room.phase}`);
    assert.ok(['CITIZEN','MAFIA'].includes(room.winningTeam));
    outcomes[room.winningTeam]++;
    assert.ok(room.players.every(p=>p.role && p.team));
  }
  assert.equal(outcomes.CITIZEN+outcomes.MAFIA,80);
});
