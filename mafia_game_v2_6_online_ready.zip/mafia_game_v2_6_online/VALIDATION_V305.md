# NOIR / SEVEN v3.0.5 validation

- Root cause: tie ordering in Mafia chooseNight() gave 60% of target
  selections to the first three people in room order; the human was
  almost always included.
- Pre-fix Monte Carlo sample (8,000 selections):
  player #1 26.65%, #3 26.66%, #4 26.69%, #5 6.66%, #6 6.64%, #7 6.70%.
- Post-fix Monte Carlo sample (8,000 selections):
  player #1 16.64%, #3 16.65%, #4 16.66%, #5 16.69%, #6 16.70%, #7 16.66%.
- New regression tests: no-information fairness; strategic weighting
  of published role claims; non-disclosure of hidden roles; contacted
  Spy immunity; real ability scheduling/confirmation; browser bundle
  parity; Android/iOS/standalone parity.
- The previous 395 tests remain unchanged except the explicit version
  metadata assertion updated from 3.0.4-beta to 3.0.5-beta.
- Game rules, investigation visibility and secret-chat action proposals
  remain governed by existing engine and tests.

This verification does not prove that all future real matches will have
exactly equal deaths, since player decisions, public evidence, doctor
protection and random variation affect results.
