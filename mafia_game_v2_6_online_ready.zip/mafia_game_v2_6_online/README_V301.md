# NOIR / SEVEN v3.0.1-beta — Always-on offline AI memory + evidence reasoning

## What changed

The v3.0 release only initialized the new per-agent AgentMemory objects in the
LLM execution path. With `NOIR_AI_MODE=rules` (the default) and in offline
HTML, the game fell back to the older v2.8.9 bot implementation. Existing bots
had rudimentary chat history and suspicion, but the v3 memory system was off.

v3.0.1 changes that without requiring cloud credentials, Ollama, or network:

1. **Every bot owns its own AgentMemory**, created at round start even in rules mode.
2. **Immediate observation updates**: after every public/secret message and every
   phase transition, memory is refreshed for each living bot. A bot need not
   speak to receive/remember newly visible information.
3. **Evidence-backed beliefs**: contradictory public role claims and each bot's
   authorized own investigations update an independently held evidence ledger.
   Evidence references are traceable to actual visible events.
4. **Game decisions consult stored beliefs**: vote and ability heuristics still
   honor game rules, but suspicion rankings now incorporate this ledger. Rules
   decisions are logged with their known basis/evidence references.
5. **Channel/role isolation**: citizens cannot read secret chats or another
   bot's private investigation. Contact secrecy, vote limits, time limits and
   game outcomes are unchanged.
6. **One memory system**: the optional server LLM adapter now reuses the same
   per-bot AgentMemory when active, rather than creating an unrelated copy.
7. **Identical offline engine**: source, in-browser offline JavaScript and
   Android/iOS native web assets are generated from the same logic.

## What this does NOT mean

The rules-based engine does **not** become a free-form generative LLM. In
rules mode, interpretation of previously unseen Korean wording can still fail,
and memory-backed inference uses deterministic evidence weights plus role
objectives. A cloud LLM remains **optional** for more flexible responses.
A phone-native offline LLM is still not bundled.

## Play / Deploy

- Web server: `npm start`; open `http://localhost:3000`.
- Offline file: `NOIR_SEVEN_v3_0_1_오프라인.html` works in a supported local browser.
- Production GitHub/Render drop-in ZIP: `mafia_game_v2_6_online_ready.zip`.
- Verify `GET /health`: `version: "3.0.1-beta"`, `ai.offlineMemory: true`,
  `ai.offlineReasoning: true`. `ai.enabled` is **only** the optional LLM status.
- Default: `NOIR_AI_MODE=rules`, no API key or model server required.
- Cloud (optional): `NOIR_AI_MODE=cloud`, `OPENAI_API_KEY=<private key>`,
  `OPENAI_MODEL=gpt-4o-mini`.
- Local PC LLM (optional): `NOIR_AI_MODE=local`, `OLLAMA_URL`, `OLLAMA_MODEL`.

## Key files

- `src/ai/memory.js`: common independent memory and evidence ledger
- `src/bot-mind.js`: offline observation and deterministic belief reasoning
- `src/engine.js`: event-driven synchronization and decision logging
- `src/ai/coordinator.js`: optional LLM decisions using the same memory
- `public/offline-engine.js`: self-contained browser bundle
- `test/agent-v301-offline.test.js`: privacy and functional regression tests

The source ZIP contains native Android/iOS wrapper sources, **not** a built
signed APK/IPA. Physical-device offline/Bluetooth support still needs testing.
