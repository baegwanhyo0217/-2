# NOIR / SEVEN v3.0 (hybrid autonomous AI integration, beta)

This package is a **working extension of v2.8.9**, not a rewrite of its game rules.
It adds server-side agents with independent memory, evidence references, persona,
public/private observations, and real model-generated chat, vote and night-action
proposals. The server validates actions and uses the v2.8.9 rules AI if a model
is unconfigured, times out, or returns an invalid action.

## What works now

- Online LLM through an **OpenAI-compatible Chat Completions** endpoint, after
  you set `NOIR_AI_MODE=cloud`, `OPENAI_API_KEY` and optionally `OPENAI_MODEL`.
- Local LLM through an **Ollama** model server, after you set `NOIR_AI_MODE=local`,
  `OLLAMA_URL` and `OLLAMA_MODEL`. If Ollama and Node run on one PC, this can work
  without an internet connection **after the model is downloaded**.
- Independent per-bot event memories, allowed observations, evidence citations,
  belief adjustments and short natural-language responses. A single model can
  represent six separate agents without sharing their private memories.
- LLM suggestions for discussion speech, mafia/spy secret speech, votes and night
  ability targets. All actions pass existing engine validation.
- Strict fallbacks, request quotas and timeouts. No API key is ever included in
  a browser bundle.
- Previous mobile portrait web UI and all v2.8.9 game rules retained.

## IMPORTANT: what this package does **not** do

- `NOIR_AI_MODE=rules` is the default. It continues the old rule-based behavior.
  Simply uploading this ZIP to GitHub **does not enable a paid LLM**.
- `/offline.html` and the Android/iOS native WebView game assets still use the
  offline browser **rules-based** AI. The phone does **not** run a local language
  model yet. Real on-device inference requires an Android/iOS model runtime,
  quantized weights, native bridge, permission/performance work and device tests.
- The existing native Bluetooth experiment is not newly certified for 7 real
  Android/iOS devices. Do not present it as production-ready multiplayer.
- LLMs can still misunderstand speech, hallucinate and make weak strategic
  choices. Passing tests does not establish human-level reasoning.

## Render: deployment to the existing NOIR service

1. Upload `mafia_game_v2_6_online_ready.zip` to your existing GitHub repository,
   replacing the existing ZIP with the **same name**, and commit.
2. The existing Render build command can stay unchanged:
   `unzip -oq mafia_game_v2_6_online_ready.zip && test -f mafia_game_v2_6_online/server.js`
3. The existing Render start command can stay unchanged:
   `node mafia_game_v2_6_online/server.js`
4. In Render > Environment, set:
   - `NOIR_AI_MODE=cloud`
   - `OPENAI_API_KEY` = YOUR KEY (secret; do not paste into a game chat)
   - `OPENAI_MODEL=gpt-4o-mini` (or another compatible chat model)
5. Deploy. Visit `/health` on your site; it returns `ai.mode` as `cloud` or `rules`.
   The lobby shows `AI ENGINE: ONLINE LLM` only when configured.
6. Cloud model usage can incur API charges. Set `NOIR_AI_MAX_REQUESTS` to cap
   requests per match. The exact pricing depends on the model and provider.

If you want the website to continue with the existing rules bot, omit step 4.

## Local, internet-free PC deployment

1. Install Node.js 20+ and Ollama, then download a Korean-capable model **once**.
   For example: `ollama pull qwen2.5:3b`.
2. Start Ollama (usually its background service is already running).
3. In a terminal inside the full project directory:

```sh
NOIR_AI_MODE=local OLLAMA_URL=http://127.0.0.1:11434 OLLAMA_MODEL=qwen2.5:3b npm start
```

4. Open `http://127.0.0.1:3000`. Disconnect your internet connection and
   continue playing on that PC. This is **not** an offline standalone-phone LLM.

For Windows PowerShell:

```powershell
$env:NOIR_AI_MODE="local"
$env:OLLAMA_URL="http://127.0.0.1:11434"
$env:OLLAMA_MODEL="qwen2.5:3b"
npm start
```

`/health` shows the current configured AI provider (never returns secrets).
The model remains a runtime dependency and is not bundled in this ZIP.

## Tests

```sh
npm test
```

The new tests cover per-agent private observations, independent memories,
model validation, timed actions, stale result rejection, authorized votes and
night actions, model provider payloads, and fallback behavior.

## Configuration

See `.env.example`. This application does not automatically load an `.env`
file. Set variables through your process manager / OS / Render dashboard.

## Data privacy

Model prompts can contain user-submitted **game chat** and the acting AI's
authorized private investigation data. Cloud mode sends these to the chosen
model provider. Do not put personal information in game chat. Local Ollama
mode does not make cloud requests from this program. Models never receive
another player's role by reading the raw authoritative game state.

## Directory layout

- `src/ai/observation.js`: per-agent information allowlist.
- `src/ai/memory.js`: independent event, belief and speech memory.
- `src/ai/providers.js`: OpenAI-compatible or Ollama model adapters.
- `src/ai/coordinator.js`: async decisions, queue and safe fallback.
- `src/engine.js`: unchanged core rules, optional AI coordinator hook.
- `server.js`: model mode detection and protected orchestration.
- `public`: existing mobile web game and rules-only offline mode.

**Release status**: v3.0 AI integration beta. Android/iOS on-device LLM is a
separate development milestone, not a completed feature of this package.
