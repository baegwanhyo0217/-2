# NOIR / SEVEN v3.0.4 — 오프라인 한국어 대화 의도 데이터셋

기준: v3.0.3 전체 게임 엔진. 기존 직업, 접선, 투표, 밤 행동, 추리/기억, 선택형 온라인 LLM 구조를 보존한다.

## 개선 목적

플레이어가 말할 수 있는 모든 한국어 문장을 미리 열거할 수는 없다. 대신 `src/ai/utterance-corpus.json`의 **37개 의도 유형 / 411개 대표 표현**을 기준 데이터로 사용하고 `src/ai/utterance-parser.js`가 다음 신호를 조합해 해석한다.

- 문장 의도(직업 공개/침묵, 조사, 증거, 의심, 투표, 스킵 반대, 판단 보류, 밤 단계, 규칙 질문, 이전 발언, 정정, 동의/반대, 인사 등)
- 명시적 대상 번호 및 복수 대상, 부정 표현, 다른 사람의 발언을 인용하거나 전한 것인지 여부
- 공개 채팅과 접선 후 비밀 채팅의 구분, 현재 게임 단계
- 사전에 등록되지 않은 표현의 유사도와 형태소 일부 패턴

**답변을 예시 문장별로 저장하지 않는다.** 의도 분류 이후 `src/bot-mind.js`가 해당 AI에게 허용된 공개 대화/자기 조사 결과/게임 상태/개인 기억만 조회해 답한다.

## 주요 발언 유형

공개: ROLE_REQUEST, ROLE_SILENCE, WHO_POLICE, INVESTIGATION_QUERY, EVIDENCE_QUERY, EVIDENCE_LACK, EVIDENCE_HAS, UNCERTAIN, DEFER, VOTE_SKIP, VOTE_SKIP_DENY, NIGHT_SKIP, VOTE_QUERY, VOTE_PROPOSE, SUSPICION_QUERY, ACCUSE, DEFEND, COMPARE, CONTRADICTION, CHAT_HISTORY, CLARIFY, REPEAT_REQUEST, AGREE, DISAGREE, CORRECTION, DEESCALATE, LIVING_COUNT, PHASE_QUERY, RULE_QUERY, DEATH_QUERY, GREETING, THANKS.

비밀 채팅: SECRET_ATTACK, SECRET_AVOID, SECRET_SWITCH, SECRET_INFO, SECRET_PLAN.

## 중요한 안전 규칙

- '5번이 스킵한다고 했어'는 5번의 주장을 **전달하는 발언**이지 현재 플레이어의 스킵 확정이 아니다.
- '스킵 안 해'와 '오늘은 스킵하자'를 구분한다. **실제 투표는 투표 UI에서만 제출**한다.
- '7번이 마피아라고 확신해'는 화자 자신의 주장이다. '7번이 마피아라고 주장했어'처럼 남의 발언을 전하는 것과 혼동하지 않는다.
- 경찰 조사 결과는 경찰 자신에게만, 스파이의 실제 조사 결과는 스파이에게만 허용한다. 상대에게 직접 공개한 비밀 정보는 접선 후 비밀 채팅에만 남는다.
- 비밀 채팅의 공격 제안은 유효하지 않은 대상, 확정 불가, 팀원 공격 제한 등 기존 규칙 검증을 우회하지 않는다.
- 진짜 공개 기록이 없다면 기억하지 못했다고 답하며, 경찰 조사 결과나 탈락자의 직업을 지어내지 않는다.
- 기존 AI 6명의 **항상 켜진 오프라인 개인 기억/추리**를 그대로 유지한다. 온라인 LLM 활성화는 선택 사항이다.

## 데이터 확장 방법

1. `src/ai/utterance-corpus.json`에서 가장 적합한 의도의 `examples`에 서로 다른 형태의 **실제 플레이어 표현**을 추가한다. 문장별 고정 응답을 추가하지 않는다.
2. 기존 의도로 해석할 수 없다면 목적과 실제 효과가 명확한 새 의도를 정의하고 `src/ai/utterance-parser.js`에서 긍정/부정/인용문 가드 및 적절한 채널을 추가한다.
3. `src/bot-mind.js`에서 게임의 **합법적인 관찰 정보**만 사용해 대응하도록 설계한다.
4. `npm test`를 실행하고, 결과가 틀린 실제 문장과 의미가 비슷하지만 반대 뜻인 문장(예: '직업 말해' ↔ '직업 말하지 마')을 회귀 테스트에 추가한다.
5. `node tools/build_v289.js`로 오프라인 HTML/Android/iOS 자산까지 함께 재생성한다.

## 테스트

- `npm test`: v3.0.3을 포함한 회귀 테스트 **395개** (v3.0.4 추가 검증 포함)
- 411개 학습/분류 예시와 별도 표현 109개는 개발 중 오류를 보고 보완한 **회귀 자료**다. 독립적인 미래 한국어 발언에 대한 실제 인식률을 뜻하지 않는다.
- 실제 게임 내 질문·요청·제안·정보 보호·게임 단계·채팅 기록 검증은 `test/utterance-v304.test.js`에 추가되어 있다.

## 배포

GitHub root의 `mafia_game_v2_6_online_ready.zip`를 새 배포 ZIP으로 교체하고 커밋한다. Render 설정은 기존 그대로 빌드 `unzip -oq mafia_game_v2_6_online_ready.zip && test -f mafia_game_v2_6_online/server.js`, 실행 `node mafia_game_v2_6_online/server.js`. 서버 `/health`에서 버전 `3.0.4-beta` 및 `ai.dialogueIntents=37`, `ai.dialogueExamples=411` 확인.

브라우저 독립 오프라인 파일 `NOIR_SEVEN_v3_0_4_오프라인.html`은 인터넷 요청 없이 로컬 실행할 수 있다. Android/iOS WebView 자산 코드는 포함되지만 APK/IPA 실행 파일은 제공하지 않는다.

**제약:** 규칙 기반 언어 분류의 한계 때문에 모든 한국어·반어·은유·다중 명령·오탈자에 정확히 대응하는 것은 불가능하다. 별도 LLM 활성화 없이 범용 자연어 생성이나 무제한 추론이 가능해지는 것은 아니다.
