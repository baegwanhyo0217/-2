# NOIR / SEVEN v3.0.2-beta — memory / reasoning audit fixes

This is a drop-in maintenance update for the deployed v3.0.1-beta package.
The existing seven-player mafia rules, timers, secret contact mechanics, UI,
optional cloud LLM adapter and offline browser engine are retained.

## Fixed defects (independently reproduced against v3.0.1)

1. **Repeated evidence inflation** — `AgentMemory.applyBeliefs` permitted the
   same evidence ID to change the same target's suspicion every generation.
   Each `(targetId, evidenceId)` now contributes only once. If a model submits
   old and new evidence in one update, only the new evidence fraction counts.
   Unsupported/invalid updates never consume an evidence ID.
2. **LLM speech counted twice** — `AgentCoordinator` recorded speech after
   `MafiaRoom.sendChat` already recorded it. A single public or secret message
   now increments the sender's memory counter once.
3. **Prior-match public history persisted** — `clearRoundState` reset private
   minds and chat history, but not the authoritative `publicLog`. It now clears
   this log before a new match, preventing prior rounds from seeding AI memory.
4. **Outdated offline build command** — the legacy Python builder omitted
   the discourse and memory modules. It now delegates to the canonical Node
   bundler; `node tools/build_v289.js` and `python tools/build_offline.py`
   create equivalent current assets and native web copies.
5. **Non-portable tests/build scripts** — offline HTML is emitted at
   `offline-standalone.html` in the source project, so the automated tests
   can run outside the original `/mnt/data` build environment.

## Validation performed

- 321 existing tests plus 8 new targeted tests = **329 passing**.
- 70 simulated complete games: 70 reached GAME_OVER, and active-match
  snapshots revealed neither hidden roles nor secret chat to citizens.
- Chromium 390x844 standalone offline run: 7 players, 6 distinct memories,
  all bots saw claim contradictions, no JavaScript errors, no network requests,
  and no horizontal overflow.
- Browser and native engine bundles verified byte-identical.
- Render ZIP unpacked and server, health, HTTP asset routes, and seven-player
  room creation/draft API checked (see `VALIDATION_V302.md`).

## How to use

- Replace the GitHub `mafia_game_v2_6_online_ready.zip` with the attached
  release ZIP, commit, and deploy the new commit on Render.
- Browser with no internet: open `NOIR_SEVEN_v3_0_2_오프라인.html`.
- Source/development: `npm test`, `npm start`, `node tools/build_v289.js`.
- Without a cloud key, the server uses the **rules** AI mode with always-on
  individual evidence and memory. `/health` includes
  `ai.offlineMemory: true` and `ai.offlineReasoning: true`.
- Optional cloud mode: `NOIR_AI_MODE=cloud`, `OPENAI_API_KEY` and model.

**Limits:** rules-mode reasoning is an evidence-scored heuristic, not a
full generative LLM. Cloud inference depends on a configured provider.
Android/iOS APK/IPA native builds and hardware BLE play were not tested.
