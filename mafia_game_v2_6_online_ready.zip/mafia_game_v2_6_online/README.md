**Latest:** v2.8.9 adds compositional Korean utterance analysis, role-safe contextual grounding, and unseen paraphrase regression tests. See README_V289.md.

**Latest:** v2.8.8 fixes public-discussion fallback responses for uncertainty/abstention/night-skip messages and corrects the public version badge. See README_V288.md.

**Latest:** v2.8.7 connects Mafia-Spy secret contact replies to the same prioritized conversation flow as public chat. See README_V287.md.
**Latest:** v2.8.6 fixes 12 dialogue comprehension regression cases. See README_V286.md.

## v2.8.3 time update

- Day discussion (every day, before vote): 60 seconds.
- Extra discussion after first-vote tie: 45 seconds.
- Night ability selection: 60 seconds (unchanged).
- First vote and revote: 30 seconds each (unchanged).
- All other roles, votes, and game rules remain unchanged.

# NOIR / SEVEN v2.7 — 적응형 AI 채팅 + 오프라인 모드

## 빠른 실행

- **오프라인 1인 대전**: `NOIR_SEVEN_오프라인_마피아.html` 파일을 휴대폰 또는 컴퓨터 브라우저에서 엽니다. 서버/인터넷/API 키가 필요하지 않습니다.
- **웹사이트 오프라인 대전**: Node 서버나 Render에 업데이트 파일이 반영된 후 `https://<도메인>/offline.html`에 접속할 수 있습니다. 이 페이지는 인터넷 연결이 있을 때 처음 로딩한 후 서비스워커가 파일들을 캐시하면 오프라인 재접속이 가능합니다. 브라우저의 캐시 삭제 시 다시 온라인으로 로딩해야 합니다.
- **온라인 멀티플레이**: `node server.js` 실행 후 `http://localhost:3000` 방문. 7명의 실제 사용자 또는 일부 AI 플레이어를 지원합니다.

## 변경 사항

AI는 각자 자기 직업/조사 기록/접선한 상대/공개 발언만 받아 독립적으로 의심 점수를 유지합니다. 인물 지목과 경찰 주장·거짓 주장 등 단서를 토대로 대화를 새로 구성하고, 자기 주장을 해명하거나 사용자의 질문에 반응하며, 그 판단을 능력 대상/투표에 반영합니다. 시민팀에게는 스파이·마피아의 비공개 정체와 접선 정보가 입력되지 않습니다. 밤/낮/투표/게임 종료 조건 등 v2.6 확정 규칙은 변경하지 않았습니다.

### 한계

이 AI는 기기 내에서 실행되는 **추론 규칙과 상황별 문장 구성 알고리즘**입니다. 인터넷 API를 호출하지 않으며, 스마트폰에 대형 언어모델을 내려받아 구동하지도 않습니다. 따라서 새로운 질문을 해석하고 발언을 조합하지만 일반적인 거대언어모델처럼 어떤 주제든 이해하거나 자유롭게 토론하지는 못합니다. 온라인 멀티플레이는 서버가 필요하고, 서버 종료 시 정상 게임 진행이 중단됩니다. **오프라인 솔로 모드만 네트워크를 사용하지 않습니다.**

## Render 업그레이드

이미 배포된 `noir-seven-mafia` 서비스에서 `buildCommand`가 `unzip -oq mafia_game_v2_6_online_ready.zip && test -f mafia_game_v2_6_online/server.js`, `startCommand`가 `node mafia_game_v2_6_online/server.js`일 때, GitHub 저장소 루트의 `mafia_game_v2_6_online_ready.zip`를 새 릴리스 ZIP으로 덮어쓰면 기존 자동 배포 설정에서 동일한 파일명과 내부 경로로 실행됩니다. 코드와 설정이 확인되지 않은 서비스에는 이 교체 방법을 그대로 적용하지 마세요.

## 개발 및 테스트

`npm test` — 기존 규칙 회귀 테스트, 챗봇 지식/추론 테스트. `public/offline.html`과 `public/offline-engine.js`는 `tools/build_offline.py`로 생성합니다. `public/sw.js`는 `/api/` 데이터를 캐시하지 않습니다.
