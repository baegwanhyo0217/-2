# NOIR / SEVEN v3.0.2 — Verification report

Audit baseline: GitHub ZIP v3.0.1-beta, Git blob SHA
`575ba65b967e79b4f2fbf2331a78ff57eb7125cf` (149261 bytes).

## Reproduced before the fix

- A repeated `beliefUpdates` entry for the same `(targetId, evidenceId)`
  increased score from 1 to 2 even though nothing new happened.
- One successful LLM message incremented `AgentMemory.turns` twice and
  appended identical text twice to `spoken`.
- After `resetLobby`, `publicLog` still contained the former match's
  game-start and game-over announcements, despite creating new bot minds.
- The obsolete offline Python bundler was not aware of the new CommonJS
  `./ai/memory` and `./discourse-frame` dependencies.

## After the fix

- `npm test`: **329/329 tests pass** (321 prior + 8 new).
- `node tools/stress_v302.js`: 70/70 games terminate normally; hidden roles
  and secret messages do not leak into citizen snapshots.
- The release ZIP was extracted to a separate directory and its actual Node server
  returned `3.0.2-beta` on `/health`, with `ai.mode=rules`,
  `ai.offlineMemory=true`, `ai.offlineReasoning=true`. API create,
  6-bot add, 7-player draft and first-night start succeeded.
- A separately extracted *full source ZIP* passed all 329 tests without
  referencing the original development directory.
- Playwright Chromium (390x844): 7 participants, 6 independent memories,
  contradiction recognized by all bots, 0 page errors, 0 HTTP requests,
  no horizontal overflow.
- Browser offline-engine.js matches the Android and iOS embedded engines.
- Source tree standalone builder is portable and the previous Python command
  delegates to it.

## Not covered by this report

- Real paid LLM provider responses/latency; only mocked LLM calls tested.
- APK/IPA compilation, real Bluetooth hardware or multi-device networking.
- Exhaustive semantic understanding of unrestricted Korean natural language.
- Live Render deployment of v3.0.2: release requires a separate GitHub upload.
