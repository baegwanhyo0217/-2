'use strict';

// Offline-first social-deduction agents. Each bot reads only public statements and
// its own role/investigations/contact information. No remote text API or cheat access.
// Speech is assembled from a context-specific argument, an attitude, evidence,
// and a question or conclusion; it is not a list of full canned chat messages.
const ROLE_WORDS = ['마피아', '스파이', '경찰', '의사', '건달', '시민'];
const PERSONAS = [
  { label:'신중', direct:0.25, talk:3, doubt:0.35, rhythm:['음', '일단', '잠깐'] },
  { label:'직설', direct:0.92, talk:5, doubt:0.62, rhythm:['아니', '잠깐만', '솔직히'] },
  { label:'분석', direct:0.60, talk:4, doubt:0.75, rhythm:['정리하면', '내 생각엔', '일단 사실만 보면'] },
  { label:'감정', direct:0.82, talk:4, doubt:0.48, rhythm:['어?', '잠깐', '이상한데'] },
  { label:'조용', direct:0.18, talk:2, doubt:0.27, rhythm:['음', '나는', '지금은'] },
  { label:'설득', direct:0.60, talk:4, doubt:0.64, rhythm:['내 말 좀 들어봐', '보니까', '일단'] },
];

function choice(xs,rng) { return xs.length ? xs[Math.min(xs.length-1,Math.floor(rng()*xs.length))] : ''; }
function stamp(target) { return target ? `${target.number}번` : ''; }
function clamp(v,lo,hi) { return Math.min(hi,Math.max(lo,v)); }
function normalize(text) { return String(text||'').replace(/\s+/g,' ').trim(); }
function includesSelfClaim(text) {
  return /(?:나는|난|내가|제가|저는|전|나|내 직업|제 직업|저)\s*(?:(?:진짜|사실|원래|확실히)\s*)?(?:경찰|의사|시민|마피아|건달|스파이)/.test(text) ||
    /(?:경찰|의사|시민|마피아|건달|스파이)\s*(?:입니다|이에요|이야|인데|이니까)/.test(text) && !/(?:너|쟤|그 사람|\d번)\s*(?:경찰|의사|시민|마피아|건달|스파이)/.test(text);
}
function claimedRole(text) {
  if (!includesSelfClaim(text)) return null;
  for(const word of ROLE_WORDS) if(text.includes(word)) return word;
  return null;
}
function mentions(text, players) {
  const found=[];
  for(const p of players) {
    const num = new RegExp(`(?:^|[^0-9])${p.number}\\s*(?:번|호|번님)(?![0-9])`);
    if (num.test(text) || (p.name && p.name.length>1 && text.includes(p.name))) found.push(p.id);
  }
  return found;
}
function mindFor(p,rng=Math.random) {
  if (!p.mind) p.mind = {
    persona: choice(PERSONAS,rng), suspicion:Object.create(null), trust:Object.create(null),
    claims:Object.create(null), observations:[], attacks:Object.create(null),
    accusations:[], seenPublic:[], seenSecret:[], spoken:[], turns:0,
    lastOpinion:null, lastRespondedId:null, visitedLast:[], watched:[]
  };
  return p.mind;
}
function adjust(mind,id,score) {
  if (!id) return;
  mind.suspicion[id]=clamp((mind.suspicion[id]||0)+score,-7,9);
}
function legalView(room,p) {
  const view=room.botKnowledge(p);
  const everyone=room.players.map(q=>({id:q.id,number:q.number,name:q.name,alive:q.alive}));
  return { ...view, everyone, publicChat:room.publicChat, publicLog:room.publicLog,
    publicVote:room.voteOutcome && ['VOTE_RESULT','GAME_OVER'].includes(room.phase) ? room.voteOutcome : null,
    secretChat:view.partnerId ? room.secretChat : [] };
}
function findOwnResult(view,id) {return view.investigations.findLast(x=>x.targetId===id) || null;}
function readStatements(p,view,rng) {
  const mind=mindFor(p,rng);
  const roster=view.everyone;
  for(const entry of view.publicChat) {
    if(mind.seenPublic.includes(entry.id)) continue;
    mind.seenPublic.push(entry.id);
    if(entry.senderId===p.id) continue;
    const words=normalize(entry.text);
    const refs=mentions(words,roster);
    const speaker=roster.find(x=>x.id===entry.senderId);
    if(!speaker) continue;
    const claim=claimedRole(words);
    if (claim) {
      const previous=mind.claims[speaker.id];
      if(previous && previous.role!==claim) adjust(mind,speaker.id,2.3);
      mind.claims[speaker.id]={role:claim,at:entry.at,text:words};
      // A police bot knows no other player can simultaneously be the police.
      if(view.role==='POLICE' && claim==='경찰') adjust(mind,speaker.id,5);
      // A spy can compare an actual investigated role against a claimant.
      const verified=findOwnResult(view,speaker.id);
      if(view.role==='SPY' && verified?.actualRole && claim && verified.displayed!==claim) adjust(mind,speaker.id,2.4);
      if(view.role==='POLICE' && verified?.displayed==='마피아팀' && claim!=='마피아') adjust(mind,speaker.id,4);
      if(claim==='경찰' && !/(조사|결과|\d번)/.test(words)) adjust(mind,speaker.id,0.4);
    }
    const aggressive=/(의심|수상|마피아|거짓|구라|이상|못 믿|말 바꿔|수상해|의혹|특이)/.test(words);
    const trusting=/(믿어|믿겠|무죄|시민팀|확실히 시민|아닌 것 같)/.test(words);
    if (aggressive && refs.length) {
      for(const id of refs) if(id!==speaker.id) {
        adjust(mind,id,0.25);
        mind.accusations.push({by:speaker.id,target:id,text:words,at:entry.at});
      }
    }
    if(trusting && refs.length) for(const id of refs) if(id!==speaker.id) adjust(mind,id,-0.13);
    if(refs.includes(p.id) && aggressive) {
      adjust(mind,speaker.id,0.65);
      mind.attacks[speaker.id]=(mind.attacks[speaker.id]||0)+1;
    }
    // A false investigation contradicting the agent's *own* information.
    const claimedInvestigation=/(조사|확인|결과)/.test(words);
    if(claimedInvestigation && refs.length && /(마피아팀|마피아라고|마피아야)/.test(words)) {
      const accused=refs.find(id=>id!==speaker.id) || refs[0];
      const own=findOwnResult(view,accused);
      if(view.role==='POLICE' && own?.displayed==='시민팀') adjust(mind,speaker.id,1.8);
      if(view.role==='SPY' && own?.actualRole && own.actualRole!=='MAFIA') adjust(mind,speaker.id,2);
    }
    if(/(?:건너뛰|스킵)/.test(words) && /(?:아까|방금|처음)/.test(words)) mind.observations.push({kind:'skipShift',speakerId:speaker.id,at:entry.at});
    mind.observations.push({kind:'message',speakerId:speaker.id,mentions:refs,text:words,at:entry.at,id:entry.id,claim});
  }
  if(mind.seenPublic.length>250) mind.seenPublic=mind.seenPublic.slice(-250);
  if(mind.observations.length>80) mind.observations=mind.observations.slice(-80);
  if(mind.accusations.length>50) mind.accusations=mind.accusations.slice(-50);
  // Only a contacted Mafia/Spy may inspect the secret messages.
  for(const entry of view.secretChat) {
    if(mind.seenSecret.includes(entry.id)) continue;
    mind.seenSecret.push(entry.id);
    if(entry.senderId===p.id) continue;
    mind.observations.push({kind:'secret',speakerId:entry.senderId,text:entry.text,at:entry.at,id:entry.id});
  }
  if(mind.seenSecret.length>150) mind.seenSecret=mind.seenSecret.slice(-150);
  return mind;
}
function chooseWeighted(items,rng) {
  const total=items.reduce((s,x)=>s+Math.max(0,x.w),0);
  let k=rng()*total;
  for(const entry of items) {k-=Math.max(0,entry.w);if(k<=0)return entry.item;}
  return items[items.length-1]?.item;
}
function candidates(p,view,validIds,excludeIds=[]) {
  const excluded=new Set([...excludeIds,p.id]);
  return view.alivePlayers.filter(q=>validIds.includes(q.id) && !excluded.has(q.id));
}
function suspicion(mind,view,id) {
  const v=mind.suspicion[id]||0;
  const result=view.investigations.findLast(i=>i.targetId===id);
  if(view.role==='POLICE') return v+(result?.displayed==='마피아팀'?12:result?.displayed==='시민팀'?-2.4:0);
  return v;
}
function strongestSuspect(p,view,mind,validIds) {
  const vals=candidates(p,view,validIds,view.partnerId?[view.partnerId]:[]);
  vals.sort((a,b)=>suspicion(mind,view,b.id)-suspicion(mind,view,a.id));
  return vals[0] || null;
}
function chooseNight(room,p,rng) {
  const view=legalView(room,p), mind=readStatements(p,view,rng);
  const opts=room.validTargets(p);
  if(!opts.length) return null;
  const possible=candidates(p,view,opts);
  if(p.role==='DOCTOR') {
    const likelyThreat = strongestSuspect(p,view,mind,opts);
    const publicTarget = view.publicChat.slice(-6).flatMap(x=>mentions(x.text,view.alivePlayers)).find(x=>x!==p.id);
    if(publicTarget && opts.includes(publicTarget) && rng()<0.26) return publicTarget;
    if(rng()<0.50 || !likelyThreat) return p.id;
    return choice(possible,rng)?.id || p.id;
  }
  if(['POLICE','SPY'].includes(p.role)) {
    const seen=new Set(view.investigations.map(x=>x.targetId));
    const fresh=possible.filter(x=>!seen.has(x.id));
    if(p.role==='SPY' && !view.partnerId) {
      // The spy cannot know which uninvestigated player is actually Mafia.
      const scored=fresh.slice().sort((a,b)=>(mind.suspicion[b.id]||0)-(mind.suspicion[a.id]||0));
      return (rng()<0.63 ? scored[0] : choice(fresh,rng))?.id || choice(possible,rng).id;
    }
    const scored=fresh.slice().sort((a,b)=>suspicion(mind,view,b.id)-suspicion(mind,view,a.id));
    return (rng()<0.72 ? scored[0] : choice(fresh,rng))?.id || choice(possible,rng).id;
  }
  if(p.role==='GANGSTER') {
    const suspect=strongestSuspect(p,view,mind,opts);
    if(suspect && suspicion(mind,view,suspect.id)>0.9 && rng()<0.72) return suspect.id;
  }
  if(p.role==='MAFIA') {
    const expectedTrust = possible.slice().sort((a,b)=>(mind.suspicion[a.id]||0)-(mind.suspicion[b.id]||0));
    return (rng()<0.60 ? choice(expectedTrust.slice(0,Math.min(3,expectedTrust.length)),rng) : choice(possible,rng))?.id;
  }
  return choice(possible,rng)?.id;
}
function chooseVote(room,p,rng) {
  const view=legalView(room,p),mind=readStatements(p,view,rng);
  const list=candidates(p,view,view.alivePlayers.map(q=>q.id),view.partnerId?[view.partnerId]:[]);
  if(!list.length) return 'SKIP';
  const winner=list.slice().sort((a,b)=>suspicion(mind,view,b.id)-suspicion(mind,view,a.id))[0];
  const score=suspicion(mind,view,winner.id);
  if(p.role==='POLICE' && score>8) return winner.id;
  if(p.team==='MAFIA') {
    // After contact, avoid voting out the known partner. Before contact, the spy is unknown.
    if(rng()<0.12 && score<0.4)return 'SKIP';
    return (score>0.25 || rng()<0.65) ? winner.id : choice(list,rng).id;
  }
  if(score>=1.4) return rng()<0.89?winner.id:'SKIP';
  if(view.night===1 && rng()<0.45) return 'SKIP';
  if(rng()<0.2) return 'SKIP';
  return rng()<0.63 ? winner.id : choice(list,rng).id;
}
function recentRelevant(p,view,mind) {
  const obs=mind.observations.filter(x=>x.kind==='message' && x.speakerId!==p.id).slice(-9);
  // Favor explicit questions mentioning the bot, then recent claims that warrant response.
  return obs.findLast(x=>x.mentions.includes(p.id) && /[?？]|왜|해명|수상|의심|마피아/.test(x.text)) ||
    obs.findLast(x=>/[?？]|왜|근거|조사|진짜|거짓/.test(x.text)) || obs.at(-1) || null;
}
function makeSentence({preface,observation,argument,ask},rng) {
  const fragments=[];
  if(preface && rng()<0.79) fragments.push(preface);
  if(observation) fragments.push(observation);
  if(argument) fragments.push(argument);
  if(ask) fragments.push(ask);
  return normalize(fragments.join(' ')).slice(0,210);
}
function formatRef(view,id) {
  const p=view.everyone.find(q=>q.id===id);
  return p ? `${p.number}번` : '그 사람';
}
function decideSpeech(room,p,channel,rng) {
  const view=legalView(room,p), mind=readStatements(p,view,rng);
  const profile=mind.persona;
  const opener=choice(profile.rhythm,rng);
  const other=view.alivePlayers.filter(x=>x.id!==p.id);
  const watched=strongestSuspect(p,view,mind,other.map(x=>x.id));
  const target=watched || choice(other,rng);
  const focus=target?stamp(target):'';
  const recent=recentRelevant(p,view,mind);
  const recentSpeaker=recent?view.everyone.find(x=>x.id===recent.speakerId):null;
  const speakerLabel=stamp(recentSpeaker);
  const score=watched?suspicion(mind,view,watched.id):0;
  const own=findOwnResult(view,watched?.id);
  mind.turns++;
  const decide=(possibilities)=>chooseWeighted(possibilities,rng);
  if(channel==='SECRET') {
    const seen=view.investigations.filter(x=>x.actualRole && x.actualRole!=='MAFIA' && view.alivePlayers.some(p=>p.id===x.targetId));
    const revealing=seen.filter(x=>!mind.spoken.includes('spy:'+x.targetId)).at(-1);
    if(p.role==='SPY' && revealing) {
      mind.spoken.push('spy:'+revealing.targetId);
      const ref=formatRef(view,revealing.targetId);
      return makeSentence({
        preface:opener,
        observation:`접선 전에 ${ref}을 조사했는데 실제 직업이 ${revealing.displayed}였어.`,
        argument:choice([`이 정보는 일단 이용할 수 있겠어.`,`낮에 바로 드러내지 말고 참고하자.`,`살해 대상을 정할 때 생각해 봐.`],rng),
        ask:choice([`오늘 누구를 노릴 생각이야?`,`다른 사람들 의심을 어디로 돌릴까?`],rng)},rng);
    }
    const latest=view.secretChat.at(-1);
    const lastN=latest?.text || '';
    return makeSentence({preface:opener,
      observation:p.role==='MAFIA' ? choice([`오늘 공격은 내가 결정할게.`,`어제 토론에서 말 나온 ${focus}이 신경 쓰여.`,`낮 분위기를 보면 ${focus} 쪽으로 의심이 모일 수도 있어.`],rng) :
        choice([`내가 알아낸 내용하고 낮에 나온 말을 같이 생각해 보자.`,`${focus} 쪽이 계속 언급되던데.`,`공개된 정보만 보면 확신하기 어렵긴 해.`],rng),
      argument:lastN && rng()<0.47?`네 얘기까지 고려하면 서둘러 고를 필요는 없어.`:choice([`표적을 고를 때 추적당하지 않게 조심하자.`,`경찰이 누구라고 주장했는지도 중요해.`,`우리 둘은 낮에 같은 편처럼 보이면 위험해.`],rng),
      ask:p.role==='SPY' ? `최종 결정은 네가 해. 이유는 뭐야?` : `다른 단서 있어?`},rng);
  }

  // The bot reacts to the actual conversation, rather than choosing an unrelated canned phrase.
  if(recent && recent.mentions.includes(p.id) && /(?:의심|수상|마피아|거짓|왜|해명|진짜|경찰)/.test(recent.text) &&
    mind.lastRespondedId!==recent.id && rng()<0.91) {
    mind.lastRespondedId=recent.id;
    const rebuttal=choice([
      `내가 뭘 했다고 나를 의심하는데?`,
      `그렇게 단정하면 오히려 추리가 꼬여.`,
      `내 말 중에 틀린 부분이 정확히 뭔데?`,
      `너도 확실한 정보가 있는 건 아니잖아.`
    ],rng);
    return makeSentence({preface:`${speakerLabel},`,
      observation:choice([`나를 지목했으면 이유부터 말해 줘.`,`나는 아직 네 주장에 동의 못 하겠어.`,`아까부터 내 얘기를 계속 하는데`],rng),
      argument:rebuttal,
      ask:choice([`조사 결과가 있어?`,`다른 증거는 있어?`,`${formatRef(view,recent.speakerId)}은 뭘 근거로 그렇게 생각해?`],rng)},rng);
  }
  const mafiaResult = view.role==='POLICE' ? view.investigations.findLast(x=>x.displayed==='마피아팀' && view.alivePlayers.some(y=>y.id===x.targetId)) : null;
  if(mafiaResult && !mind.spoken.includes(`police:${mafiaResult.targetId}`) && rng()<0.94) {
    mind.spoken.push(`police:${mafiaResult.targetId}`);
    const targetLabel=formatRef(view,mafiaResult.targetId);
    return makeSentence({preface:opener,
      observation:`나 경찰이고 ${mafiaResult.night}번째 밤에 ${targetLabel}을 조사했어. 결과는 마피아팀이야.`,
      argument:choice([`스파이는 경찰한테 시민팀으로 뜨니까 이 결과는 가볍게 넘길 수 없어.`,`다들 내 말을 무조건 믿으라는 건 아니고 근거를 보고 판단해 줘.`,`최소한 ${targetLabel} 해명을 먼저 들어야 한다고 봐.`],rng),
      ask:`${targetLabel}, 네 입장 좀 말해 봐.`},rng);
  }
  if(view.role==='POLICE' && own?.displayed==='시민팀' && score>1 && rng()<0.65) {
    return makeSentence({preface:opener,
      observation:`내가 조사한 ${focus}은 경찰 결과로는 시민팀이었어.`,
      argument:`그래서 ${focus}만 몰아가는 건 조금 이상해.`,
      ask:`다른 근거가 있는 사람 있어?`},rng);
  }
  const contradictory=Object.entries(mind.claims).find(([id,c])=> c.role==='경찰' && id!==p.id && view.role==='POLICE');
  if(contradictory && rng()<0.65){
    const id=contradictory[0];
    return makeSentence({preface:opener,observation:`${formatRef(view,id)}이 경찰이라고 했지?`,
      argument:`나도 경찰이라서 둘 다 진짜일 수는 없어.`,
      ask:`${formatRef(view,id)}, 조사 결과를 제대로 말해 봐.`},rng);
  }
  if(recent?.claim==='경찰' && recentSpeaker && rng()<0.46 && mind.lastRespondedId!==recent.id){
    mind.lastRespondedId=recent.id;
    return makeSentence({preface:`${speakerLabel},`,
      observation:`경찰이라고 했으면 지금까지의 조사 내용을 설명해 줘.`,
      argument:`말로만 경찰이라고 하면 누구든지 속일 수 있잖아.`,
      ask:`몇 번째 밤에 누구를 봤어?`},rng);
  }
  if(recent && /(?:왜|근거|생각|어떻게|누구|투표|조사|믿어)/.test(recent.text) &&
     mind.lastRespondedId!==recent.id && rng()<0.60) {
    mind.lastRespondedId=recent.id;
    return makeSentence({preface:opener,
      observation:recent.mentions.length ? `${speakerLabel}이 ${formatRef(view,recent.mentions[0])}을 얘기했잖아.` : `${speakerLabel} 얘기 듣고 생각해 봤는데,`,
      argument:score>1?`나는 ${focus} 쪽에서 좀 걸리는 부분이 있어.`:`아직 결론 낼 만한 확실한 증거는 없어.`,
      ask:choice([`그렇게 판단한 이유가 뭐야?`,`다른 사람들 생각은 어때?`,`그럼 ${focus}은 어떻게 생각해?`],rng)},rng);
  }
  const opts=[
    {item:'ACCUSATION',w:score>1.2?7:score>0.25?3:1},
    {item:'QUESTION',w:3.1},
    {item:'VOTE_DISCUSSION',w:2.2},
    {item:'RECONCILE',w:1.8},
    {item:'BLUFF',w:p.team==='MAFIA'&&mind.turns>1?0.85:0},
    {item:'OBSERVE',w:3.4},
  ];
  const act=decide(opts);
  const accused=mind.accusations.filter(a=>a.target!==p.id && view.alivePlayers.some(x=>x.id===a.target)).at(-1);
  if(act==='ACCUSATION' && target) {
    const accusation=accused&&rng()<0.5?`아까 ${formatRef(view,accused.by)}도 ${formatRef(view,accused.target)}을 의심한다고 했잖아.`:`${focus} 말투가 좀 걸리네.`;
    return makeSentence({preface:opener,observation:accusation,
      argument:choice([`의심한다고 했을 때 이유가 부족했어.`,`질문에 바로 답하지 않고 다른 얘기로 넘겼어.`,`다른 사람 얘기는 많은데 본인 근거는 별로 없어.`,`그냥 찍자는 게 아니라 앞뒤를 맞춰 보자는 거야.`],rng),
      ask:choice([`${focus}, 설명 좀 해 줘.`,`이 사람을 바로 투표할 정도로 확실한가?`,`다른 사람들은 누구를 더 의심해?`],rng)},rng);
  }
  if(act==='BLUFF'){
    return makeSentence({preface:opener,
      observation:choice([`내가 보기엔 지금 ${focus}을 너무 쉽게 믿는 것 같아.`,`시민 입장에서 보면 ${focus}의 행동이 좀 이상해.`,`누가 경찰인지보다 서로 말이 맞는지가 중요하지.`],rng),
      argument:choice([`한 사람 말만 듣고 표를 몰면 위험해.`,`다른 가능성도 생각해 봐야 해.`,`확정된 정보처럼 이야기하진 말자.`],rng),
      ask:`${focus}, 너는 지금 누구를 찍을 생각이야?`},rng);
  }
  if(act==='VOTE_DISCUSSION'){
    return makeSentence({preface:opener,
      observation:view.night===1?`첫날이라서 밝혀진 정보가 적긴 해.`:`${view.night}번째 밤까지 왔는데도 아직 확실한 사람이 없네.`,
      argument:score>1.4?`그래도 ${focus}에 대한 의심은 그냥 넘기면 안 돼.`:`무작정 내보내기보다 건너뛰는 쪽도 생각해 볼 만해.`,
      ask:choice([`오늘 누구에게 표를 줄지 정했어?`,`다들 건너뛰는 쪽이야, 아니면 퇴출시키자는 쪽이야?`,`${focus}은 투표를 어떻게 할 거야?`],rng)},rng);
  }
  if(act==='RECONCILE' && recentSpeaker){
    return makeSentence({preface:opener,
      observation:`${speakerLabel} 말에도 일리는 있는데`,
      argument:choice([`그 부분만 가지고 ${focus}을 확정하긴 어렵지.`,`오히려 다른 사람 반응을 조금 더 봐야 할 것 같아.`,`근거가 서로 다르니까 한 번씩 다시 설명해 줬으면 해.`],rng),
      ask:`${focus}, 너도 그 얘기 들었지? 어떻게 생각해?`},rng);
  }
  const person=choice(other,rng);
  const ref=stamp(person);
  return makeSentence({preface:opener,
    observation:choice([`아직 누구 말을 믿어야 할지 모르겠어.`,`지금까지 나온 말들을 비교해 보고 있어.`,`밤에 무슨 일이 있었는지는 모두가 아는 게 아니잖아.`,`${ref} 말은 조금 더 들어보고 싶어.`],rng),
    argument:choice([`근거 없는 확신은 위험해.`,`특히 자기 직업을 주장하는 건 누구나 할 수 있어.`,`같은 말을 하더라도 나중에 바뀌는지 봐야겠어.`,`의심받는 사람 반응도 단서가 될 수 있어.`],rng),
    ask:choice([`${ref}, 네가 생각하는 가장 수상한 사람은 누구야?`,`경찰이라고 주장할 사람 있어?`,`어제 밤 정보 있는 사람은 의견을 좀 줘.`,`지금 건너뛰면 다음에는 뭘 보고 판단할까?`],rng)},rng);
}

module.exports={ mindFor, legalView, readStatements, decideSpeech, chooseNight, chooseVote, claimedRole, mentions };
