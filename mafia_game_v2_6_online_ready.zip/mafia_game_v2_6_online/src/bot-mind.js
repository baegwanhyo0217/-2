'use strict';

// Offline-first social-deduction agents. Each bot reads only public statements and
// its own role/investigations/contact information. No remote text API or cheat access.
// Speech is assembled from a context-specific argument, an attitude, evidence,
// and a question or conclusion; it is not a list of full canned chat messages.
const DiscourseFrame = require('./discourse-frame');
const Utterance = require('./ai/utterance-parser');
const {AgentMemory} = require('./ai/memory');
const ROLE_WORDS = ['마피아', '스파이', '경찰', '의사', '건달', '시민'];
const PERSONAS = [
  { label:'신중', direct:0.25, talk:3, doubt:0.35, rhythm:['음','일단','잠깐'] },
  { label:'직설', direct:0.92, talk:5, doubt:0.62, rhythm:['잠깐만','솔직히'] },
  { label:'분석', direct:0.60, talk:4, doubt:0.75, rhythm:['정리하면','내 생각엔','일단 사실만 보면'] },
  { label:'감정', direct:0.82, talk:4, doubt:0.48, rhythm:['어','잠깐','이상한데'] },
  { label:'조용', direct:0.18, talk:2, doubt:0.27, rhythm:['음'] },
  { label:'설득', direct:0.60, talk:4, doubt:0.64, rhythm:['보니까','일단'] },
];

function choice(xs,rng) { return xs.length ? xs[Math.min(xs.length-1,Math.floor(rng()*xs.length))] : ''; }
function stamp(target) { return target ? `${target.number}번` : ''; }
function clamp(v,lo,hi) { return Math.min(hi,Math.max(lo,v)); }
function normalize(text) { return String(text||'').replace(/\s+/g,' ').trim(); }
function roleAsStatement(role) {
  const last=role.charCodeAt(role.length-1);
  const hasJong=last>=0xAC00 && last<=0xD7A3 && (last-0xAC00)%28!==0;
  return role+(hasJong?'이야':'야');
}
function roleAsQuote(role) {
  const last=role.charCodeAt(role.length-1);
  const hasJong=last>=0xAC00 && last<=0xD7A3 && (last-0xAC00)%28!==0;
  return role+(hasJong?'이라고':'라고');
}
function includesSelfClaim(text) {
  return /(?:나는|난|내가|제가|저는|전|나|내 직업|제 직업|저)\s*(?:(?:진짜|사실|원래|확실히)\s*)?(?:경찰|의사|시민|마피아|건달|스파이)/.test(text) ||
    /(?:경찰|의사|시민|마피아|건달|스파이)\s*(?:입니다|이에요|이야|인데|이니까)/.test(text) && !/(?:너|쟤|그 사람|\d번)\s*(?:경찰|의사|시민|마피아|건달|스파이)/.test(text);
}
function claimedRole(text) {
  const t=normalize(text);
  const original=t.match(/(?:^|[,.!?;，]\s*|(?:^|\s)(?:음|솔직히|사실|근데|저기|일단|참고로)\s+|^(?:너네|너희|다들|여러분)\s+)(?:나는|난|내가|제가|저는|전|나|내\s*직업(?:은|이)?|제\s*직업(?:은|이)?|저)\s*(?:(?:진짜|사실|원래|확실히)\s*)?(?:경찰|의사|시민|마피아|건달|스파이)/);
  const additional=t.match(new RegExp(`(?:^|\\s)(?:\\uB098\\uB3C4|\\uC800\\uB3C4)\\s*(${ROLE_WORDS.join('|')})`));
  const selected=original && additional ? (original.index<=additional.index?original:additional) : (original||additional);
  if(!selected)return null;
  const fragment=selected[0];
  const role=ROLE_WORDS.find(word=>fragment.endsWith(word));
  if(!role)return null;
  const rest=t.slice(selected.index+fragment.length);
  // A short question about one's own role is not a declaration; a completed
  // declaration followed by a separate question still counts.
  const firstPunctuation=rest.match(/[.!?\uFF1F]/)?.[0];
  if(firstPunctuation==='?' || firstPunctuation==='\uFF1F')return null;
  // Negative self-statements do not constitute a positive role claim.
  if(/^\s*(?:\uD300)?\s*(?:\uC774|\uAC00)?\s*\uC544\uB2C8/.test(rest))return null;
  return role;
}
// Negative first-person role declarations are public claims about what a speaker
// denies, never positive evidence of their role.
function deniedRole(text) {
  const t=normalize(text);
  if(isQuestion(t))return null;
  const m=t.match(/^(?:(?:너네|너희|다들|여러분|아까|아니|근데)\s+)?(?:나는|난|내가|저는|전|제가|저|나|내\s*직업(?:은|이)?)\s*(?:진짜\s*)?(경찰|의사|시민|마피아|건달|스파이)\s*(?:이|가|은|는)?\s*(?:아니(?:야|다|에요|라고|라고\s*했|라니까|라며)|아닌데|아닙니다|아니라고)/);
  return m?.[1]||null;
}
function orderedMentions(text,players) {
  const matches=[];
  for(const p of players){
    const num=new RegExp(`(?:^|[^0-9])(${p.number})\\s*(?:번|호)(?![0-9])`);
    const found=num.exec(text);
    if(found)matches.push({id:p.id,index:found.index+(found[0].length-found[0].trimStart().length)});
    else if(p.name && p.name.length>1){const i=text.indexOf(p.name);if(i!==-1)matches.push({id:p.id,index:i});}
  }
  return matches.sort((a,b)=>a.index-b.index).map(x=>x.id);
}
function topicSwitchTarget(text,view) {
  const t=normalize(text);
  const m=t.match(/(\d+)\s*번[^.!?]{0,28}?(?:말고|아니고|그만하고|됐고)\s*(\d+)\s*번/);
  if(!m)return null;
  return view.everyone.find(p=>p.number===Number(m[2]))?.id||null;
}
function isReportedSkipVote(text) {
  return /(?:\d+\s*번|그\s*사람|걔).{0,28}(?:스킵|건너뛰).{0,14}(?:한다고|한다던데|했는데|했다|했어|하겠다고|하자고)/.test(text);
}
function declaredStance(text,players) {
  const t=normalize(text);
  const frame=DiscourseFrame.parse(t);
  // Do not turn negated, reported, hypothetical or night-only SKIP language
  // into a promise to skip the public daytime vote.
  if(frame.reported || frame.act==='NIGHT_SKIP' ||
     /(?:스킵|기권|패스|건너\s*뛰).{0,14}(?:안\s*해|안\s*할|하지\s*않|하지\s*말|싫|아니)/.test(t))return null;
  if(/[?？]/.test(t) || /(?:왜|누구|어떻게)\s*(?:찍|투표|스킵|건너뛰)/.test(t))return null;
  // A decision to wait is NOT an irreversible vote decision.
  if(frame.act==='VOTE_SKIP' && !/(?:보류|유보)(?:하|할|했)/.test(t) &&
      !/^(?:\d+\s*번|그\s*사람|걔|쟤).{0,25}(?:스킵|기권|패스)/.test(t)) return 'SKIP';
  // Players cannot skip the night phase. Such a suggestion must not become
  // evidence that they promised to skip the *daytime vote*.
  if(/(?:밤|야간).{0,20}(?:스킵|건너\s*뛰|넘기)/.test(t) && !/(?:투표|표결)/.test(t))return null;
  // Reports of another player's stance are not the current speaker's own vote.
  if(isReportedSkipVote(t))return null;
  // Only *voluntary, stated* voting intentions are evidence, never inferred hidden votes.
  if(/(?:나는|난|내가|저는|전)\s*(?:이번엔|오늘|일단|지금은)?\s*(?:스킵|건너\s*뛰(?:기)?)/.test(t) ||
    /(?:스킵|건너\s*뛰(?:기)?)(?:\s*(?:하자|할게|할래|하고 싶어|하려고))/.test(t))return 'SKIP';
  const refs=mentions(t,players);
  const declares=/(?:찍을게|찍자|투표할게|투표하자|퇴출시키자|뽑을게|표\s*줄게)/.test(t);
  if(declares && refs.length)return refs[0];
  return null;
}
function mentions(text, players) {
  const found=[];
  for(const p of players) {
    const num = new RegExp(`(?:^|[^0-9])${p.number}\\s*(?:번|호|번님)(?![0-9])`);
    if (num.test(text) || (p.name && p.name.length>1 && text.includes(p.name))) found.push(p.id);
  }
  return found;
}
function mindFor(p,rng=Math.random) {
  if (!p.mind) p.mind = {
    persona: choice(PERSONAS,rng), suspicion:Object.create(null), trust:Object.create(null),
    claims:Object.create(null), observations:[], attacks:Object.create(null),
    accusations:[], seenPublic:[], seenSecret:[], spoken:[], turns:0,
    lastOpinion:null, lastRespondedId:null, visitedLast:[], watched:[],
    claimChanges:[], answerIds:[], publicStances:Object.create(null), stanceChanges:[], roleDenials:Object.create(null),
    agentMemory:new AgentMemory(p.number)
  };
  return p.mind;
}
function adjust(mind,id,score) {
  if (!id) return;
  mind.suspicion[id]=clamp((mind.suspicion[id]||0)+score,-7,9);
}
function legalView(room,p) {
  const view=room.botKnowledge(p);
  const everyone=room.players.map(q=>({id:q.id,number:q.number,name:q.name,alive:q.alive,bot:q.bot}));
  return { ...view, everyone, publicChat:room.publicChat, publicLog:room.publicLog,
    publicVote:room.voteOutcome && ['VOTE_RESULT','GAME_OVER'].includes(room.phase) ? room.voteOutcome : null,
    phaseStart:room.phaseStart,
    secretChat:view.partnerId ? room.secretChat : [] };
}
function findOwnResult(view,id) {return view.investigations.findLast(x=>x.targetId===id) || null;}
function readStatements(p,view,rng) {
  const mind=mindFor(p,rng);
  const roster=view.everyone;
  for(const entry of view.publicChat) {
    if(mind.seenPublic.includes(entry.id)) continue;
    mind.seenPublic.push(entry.id);
    if(entry.senderId===p.id) continue;
    const words=normalize(entry.text);
    const refs=mentions(words,roster);
    const speaker=roster.find(x=>x.id===entry.senderId);
    if(!speaker) continue;
    const claim=claimedRole(words);
    const denial=deniedRole(words);
    if(denial){
      if(mind.claims[speaker.id]?.role===denial){
        mind.claimChanges.push({speakerId:speaker.id,from:denial,to:'그 직업 부인',id:entry.id,at:entry.at});
        adjust(mind,speaker.id,1.2);
      }
      mind.roleDenials[speaker.id]={role:denial,at:entry.at,text:words};
      if(mind.claims[speaker.id]?.role===denial)delete mind.claims[speaker.id];
    }
    if (claim) {
      const previous=mind.claims[speaker.id];
      if(previous && previous.role!==claim) {
        adjust(mind,speaker.id,2.3);
        mind.claimChanges.push({speakerId:speaker.id,from:previous.role,to:claim,id:entry.id,at:entry.at});
      }
      mind.claims[speaker.id]={role:claim,at:entry.at,text:words};
      // A police bot knows no other player can simultaneously be the police.
      if(view.role==='POLICE' && claim==='경찰') adjust(mind,speaker.id,5);
      // A spy can compare an actual investigated role against a claimant.
      const verified=findOwnResult(view,speaker.id);
      if(view.role==='SPY' && verified?.actualRole && claim && verified.displayed!==claim) adjust(mind,speaker.id,2.4);
      if(view.role==='POLICE' && verified?.displayed==='마피아팀' && claim!=='마피아') adjust(mind,speaker.id,4);
      if(claim==='경찰' && !/(조사|결과|\d번)/.test(words)) adjust(mind,speaker.id,0.4);
    }

    const aggressive=/(\uC758\uC2EC|\uC218\uC0C1|\uB9C8\uD53C\uC544|\uAC70\uC9D3|\uAD6C\uB77C|\uB9D0 \uBC14\uAFD4)/.test(words);
    const negated=/(\uC544\uB2C8|\uC5C6|\uB2E8\uC815\uD558\uC9C0|\uBABB \uBBFF|\uD655\uC2E4\uD558\uC9C0)/.test(words);
    const affirmative=/(\uB9C8\uD53C\uC544(?:\uD300)?\s*(?:\uAC19\uC544|\uC774\uC57C|\uC57C|\uB2E4)|\uC758\uC2EC\uD574|\uC218\uC0C1\uD574|\uAC70\uC9D3\uB9D0|\uAD6C\uB77C)/.test(words);
    const actualAccusation=aggressive && affirmative && !isQuestion(words) && !negated;
    if(actualAccusation && refs.length) {
      for(const id of refs) if(id!==speaker.id) {
        mind.accusations.push({by:speaker.id,target:id,text:words,at:entry.at});
        // Human testimony is a weak conversational signal, not proof.
        // Bot accusations never amplify another bot's suspicion score.
        if(!speaker.bot)adjust(mind,id,0.08);
      }
    }
    // Being challenged by another bot is not a reason to retaliate.
    if(actualAccusation && refs.includes(p.id))
      mind.attacks[speaker.id]=(mind.attacks[speaker.id]||0)+1;
    // A false investigation contradicting the agent's *own* information.
    const claimedInvestigation=/(조사|확인|결과)/.test(words);
    if(claimedInvestigation && refs.length && /(마피아팀|마피아라고|마피아야)/.test(words)) {
      const accused=refs.find(id=>id!==speaker.id) || refs[0];
      const own=findOwnResult(view,accused);
      if(view.role==='POLICE' && own?.displayed==='시민팀') adjust(mind,speaker.id,1.8);
      if(view.role==='SPY' && own?.actualRole && own.actualRole!=='MAFIA') adjust(mind,speaker.id,2);
    }
    const statedVote=declaredStance(words,roster);
    if(statedVote!==null) {
      const before=mind.publicStances[speaker.id];
      if(before && before!==statedVote) {
        mind.stanceChanges.push({speakerId:speaker.id,from:before,to:statedVote,at:entry.at,id:entry.id});
        // A changed opinion can have an innocent explanation.
      }
      mind.publicStances[speaker.id]=statedVote;
    }

    mind.observations.push({kind:'message',speakerId:speaker.id,mentions:refs,text:words,at:entry.at,id:entry.id,claim});
  }
  if(mind.seenPublic.length>250) mind.seenPublic=mind.seenPublic.slice(-250);
  if(mind.observations.length>80) mind.observations=mind.observations.slice(-80);
  if(mind.accusations.length>50) mind.accusations=mind.accusations.slice(-50);
  if(mind.claimChanges.length>30) mind.claimChanges=mind.claimChanges.slice(-30);
  if(mind.stanceChanges.length>30)mind.stanceChanges=mind.stanceChanges.slice(-30);
  // Only a contacted Mafia/Spy may inspect the secret messages.
  for(const entry of view.secretChat) {
    if(mind.seenSecret.includes(entry.id)) continue;
    mind.seenSecret.push(entry.id);
    if(entry.senderId===p.id) continue;
    mind.observations.push({kind:'secret',speakerId:entry.senderId,text:entry.text,at:entry.at,id:entry.id});
  }
  if(mind.seenSecret.length>150) mind.seenSecret=mind.seenSecret.slice(-150);
  updateCognitiveMemory(p,view,mind);
  return mind;
}
function updateCognitiveMemory(p,view,mind) {
  const mem=mind.agentMemory;
  if(!mem)return;
  mem.observe({
    publicChat:view.publicChat.map(e=>({id:e.id,number:e.number,text:e.text})),
    secretChat:view.secretChat.map(e=>({id:e.id,number:e.number,text:e.text})),
    ownInvestigations:view.investigations,
    publicLog:view.publicLog
  });
  const visibleIds=new Set(view.alivePlayers.filter(x=>x.id!==p.id).map(x=>x.id));
  // A role-claim switch is an observable contradiction, not proof of Mafia.
  for (const change of mind.claimChanges) {
    mem.addInferredEvidence('claim:'+change.id,change.speakerId,1.2,
      '공개 직업 주장이 이전과 달라짐',[change.id],visibleIds);
  }
  // The agent may use ONLY its own confirmed investigation results.
  for (const result of view.investigations) {
    const id='inv:'+result.night+':'+result.targetId;
    if(p.role==='POLICE'){
      const delta=result.displayed==='마피아팀' ? 2 :
        result.displayed==='시민팀' ? -0.8 : 0;
      if(delta) mem.addInferredEvidence('police:'+id,result.targetId,delta,
        '내 경찰 조사에서 '+result.displayed+'으로 표시됨',[id],visibleIds);
    } else if(p.role==='SPY' && result.actualRole){
      // Spy sees the real role; this remains private until deliberately shared.
      if(result.actualRole==='MAFIA') mem.addInferredEvidence('spy:'+id,result.targetId,-2,
        '내 비공개 조사에서 마피아 본체로 확인함',[id],visibleIds);
    }
  }
  // A genuine police bot knows that another police claimant cannot be genuine.
  if(p.role==='POLICE'){
    for(const [id,claim] of Object.entries(mind.claims)){
      if(id===p.id || claim.role!=='경찰')continue;
      const e=view.publicChat.findLast(x=>x.senderId===id && x.text===claim.text);
      if(e)mem.addInferredEvidence('police-claim:'+e.id,id,1.8,
        '내가 경찰인데 다른 참가자가 경찰이라고 공개 주장함',[e.id],visibleIds);
    }
  }
}
// Keep all six memories current even when no bot has a speaking turn.
// No API, internet, or model is involved; each bot gets its own legal view.
function syncRoom(room) {
  for (const p of room.players) {
    if(!p.bot || !p.alive || !p.role)continue;
    try {readStatements(p,legalView(room,p),room.rng);}catch(_) {
      // A malformed chat may not interrupt the authoritative game engine.
    }
  }
}
function recordDecision(room,p,kind,targetId) {
  const view=legalView(room,p);
  const mind=readStatements(p,view,room.rng);
  const mem=mind.agentMemory;
  const belief=mem.beliefs.get(targetId);
  mem.recordDecision({kind,targetId,night:room.night,phase:room.phase,
    evidenceIds:belief?.reasons?.flatMap(x=>x.evidenceIds).slice(-5)||[],
    basis:belief?.reasons?.length ? '개인 관찰 근거 + 직업 목표 + 게임 규칙' :
      '직업 목표 + 제한된 공개 근거 + 전략적 선택'});
}
function chooseWeighted(items,rng) {
  const total=items.reduce((s,x)=>s+Math.max(0,x.w),0);
  let k=rng()*total;
  for(const entry of items) {k-=Math.max(0,entry.w);if(k<=0)return entry.item;}
  return items[items.length-1]?.item;
}
function candidates(p,view,validIds,excludeIds=[]) {
  const excluded=new Set([...excludeIds,p.id]);
  return view.alivePlayers.filter(q=>validIds.includes(q.id) && !excluded.has(q.id));
}
function suspicion(mind,view,id) {
  // Always-on independent evidence ledger changes even non-LLM choices.
  const v=(mind.suspicion[id]||0)+(mind.agentMemory?.beliefs.get(id)?.score||0)*0.65;
  const result=view.investigations.findLast(i=>i.targetId===id);
  if(view.role==='POLICE') return v+(result?.displayed==='마피아팀'?12:result?.displayed==='시민팀'?-2.4:0);
  return v;
}
function strongestSuspect(p,view,mind,validIds) {
  const vals=candidates(p,view,validIds,view.partnerId?[view.partnerId]:[]);
  vals.sort((a,b)=>suspicion(mind,view,b.id)-suspicion(mind,view,a.id));
  return vals[0] || null;
}
function chooseNight(room,p,rng) {
  const view=legalView(room,p), mind=readStatements(p,view,rng);
  const opts=room.validTargets(p);
  if(!opts.length) return null;
  const possible=candidates(p,view,opts);
  if(p.role==='DOCTOR') {
    const likelyThreat = strongestSuspect(p,view,mind,opts);
    const publicTarget = view.publicChat.slice(-6).flatMap(x=>mentions(x.text,view.alivePlayers)).find(x=>x!==p.id);
    if(publicTarget && opts.includes(publicTarget) && rng()<0.26) return publicTarget;
    if(rng()<0.50 || !likelyThreat) return p.id;
    return choice(possible,rng)?.id || p.id;
  }
  if(['POLICE','SPY'].includes(p.role)) {
    const seen=new Set(view.investigations.map(x=>x.targetId));
    const fresh=possible.filter(x=>!seen.has(x.id));
    if(p.role==='SPY' && !view.partnerId) {
      // The spy cannot know which uninvestigated player is actually Mafia.
      const scored=fresh.slice().sort((a,b)=>(mind.suspicion[b.id]||0)-(mind.suspicion[a.id]||0));
      return (rng()<0.63 ? scored[0] : choice(fresh,rng))?.id || choice(possible,rng).id;
    }
    const scored=fresh.slice().sort((a,b)=>suspicion(mind,view,b.id)-suspicion(mind,view,a.id));
    return (rng()<0.72 ? scored[0] : choice(fresh,rng))?.id || choice(possible,rng).id;
  }
  if(p.role==='GANGSTER') {
    const suspect=strongestSuspect(p,view,mind,opts);
    if(suspect && suspicion(mind,view,suspect.id)>0.9 && rng()<0.72) return suspect.id;
  }
  if(p.role==='MAFIA') {
    const avoid=new Set();
    if(view.contacted && view.partnerId) {
      // Newer advice takes priority; a later veto cancels an earlier proposal.
      for(const entry of view.secretChat.slice().reverse()) {
        if(entry.senderId!==view.partnerId || entry.at<room.phaseStart)continue;
        const veto=secretAvoidTarget(entry.text,view);
        if(veto)avoid.add(veto);
        const candidate=secretAttackTarget(entry.text,view);
        if(candidate && opts.includes(candidate) && candidate!==view.partnerId && !avoid.has(candidate))return candidate;
      }
    }
    const available=possible.filter(x=>!avoid.has(x.id));
    const pool=available.length?available:possible;
    // Do not sort tied candidates by room join order. The real player is usually
    // #1 and used to be in the first three entries for a 60% preference branch.
    // With no public evidence, each legal target must have identical weight.
    const weighted=pool.map(candidate=>{
      let w=1;
      const claim=mind.claims[candidate.id]?.role;
      // Public role claims and public pressure on the Mafia can rationally
      // influence strategy; private roles and the bot/human flag never can.
      if(claim==='\uacbd\ucc30')w+=0.7;
      else if(claim==='\uc758\uc0ac')w+=0.25;
      if(mind.attacks[candidate.id])w+=Math.min(0.45,mind.attacks[candidate.id]*0.18);
      if(mind.publicStances[candidate.id]===p.id)w+=0.3;
      return {item:candidate,w};
    });
    return chooseWeighted(weighted,rng)?.id || null;
  }
  return choice(possible,rng)?.id;
}
function chooseVote(room,p,rng) {
  const view=legalView(room,p),mind=readStatements(p,view,rng);
  const list=candidates(p,view,view.alivePlayers.map(q=>q.id),view.partnerId?[view.partnerId]:[]);
  if(!list.length) return 'SKIP';
  const winner=list.slice().sort((a,b)=>suspicion(mind,view,b.id)-suspicion(mind,view,a.id))[0];
  const score=suspicion(mind,view,winner.id);
  if(p.role==='POLICE' && score>8) return winner.id;
  if(p.team==='MAFIA') {
    // After contact, avoid voting out the known partner. Before contact, the spy is unknown.
    if(rng()<0.12 && score<0.4)return 'SKIP';
    return (score>0.25 || rng()<0.65) ? winner.id : choice(list,rng).id;
  }
  if(score>=1.4) return rng()<0.89?winner.id:'SKIP';
  if(view.night===1 && rng()<0.45) return 'SKIP';
  if(rng()<0.2) return 'SKIP';
  return rng()<0.63 ? winner.id : choice(list,rng).id;
}
// Public conversation analysis uses witnessed statements, not invented evidence.
// A question is handled as a request for an answer, never as an excuse to ask more questions.
function formatRef(view,id) {
  const q=view.everyone.find(x=>x.id===id);
  return q ? `${q.number}번` : '그 사람';
}
function makeSentence({preface,observation,argument,ask},rng) {
  const parts=[];
  if(preface && rng()<0.73)parts.push(preface);
  if(observation)parts.push(observation);
  if(argument)parts.push(argument);
  if(ask)parts.push(ask);
  return normalize(parts.join(' ')).slice(0,218);
}

// Commands about roles need an explicit intent, even without a question mark.
// A request to discuss or reveal roles is not a statement to acknowledge with
// "I will keep that in mind". This recognizer shares a path between day chat,
// contacted secret chat, the scheduler and the optional LLM relevance check.
function roleSilenceRequest(text) {
  const t=normalize(text);
  return /(?:직업|역할|정체|신분).{0,28}(?:말하지\s*마|말하지\s*말|공개하지\s*마|공개하지\s*말|밝히지\s*마|밝히지\s*말|얘기하지\s*마|이야기하지\s*마|말하면\s*안\s*돼|공개하면\s*안\s*돼|말할\s*필요\s*없)/.test(t) ||
    /(?:직업|역할|정체|신분).{0,26}(?:비밀로\s*해|숨기자|밝힐\s*필요\s*없|(?:얘기|이야기).{0,8}멈추)/.test(t);
}
function roleDisclosureRequest(text) {
  const t=normalize(text);
  const analyzed=Utterance.classify(t);
  if(!/(?:직업|역할|정체|신분|포지션|누구\s*편)/.test(t) || roleSilenceRequest(t))return null;
  // Avoid mistaking a record of somebody's past disclosure for an order.
  const ask=/(?:직업|역할|정체|신분).{0,29}(?:(?:말해|말하(?:자|라|라고|라고\s*했))|(?:알려|공개(?:해|하(?:자|라|라고))|밝혀|밝히(?:자|라|라고)|얘기(?:해|하(?:자|라|라고))|이야기(?:해|하(?:자|라|라고))|설명(?:해|하(?:자|라))|소개(?:해|하(?:자|라))|공유(?:해|하(?:자|라))|까(?:봐|줘|자)|뭐(?:야|지|냐|니|임|를)?|뭔데|어떤|무슨|궁금|말해\s*봐))/.test(t) ||
    /(?:직업|역할|정체|신분).{0,29}(?:얘기|이야기|설명|소개|공유|말|공개|정리).{0,9}(?:해|하자|하라|하라고|해봐|해줘|해보자|해라|해주라|해주시)/.test(t) ||
    /(?:말해|알려|밝혀|공개해|얘기해|이야기해|설명해|공유해|까봐).{0,23}(?:직업|역할|정체)/.test(t) ||
    /(?:무슨|어떤|뭐\s*하는)\s*(?:직업|역할|정체)/.test(t) ||
    /(?:직업|역할|정체)(?:은|는|이|가)?\s*(?:무엇|뭐)/.test(t) ||
    /^(?:자\s*)?(?:다들|모두|여러분|너희|각자|전원).{0,18}(?:직업|역할|정체)(?:\s*(?:부터|좀|한\s*명씩))?[.!?]*$/.test(t);
  if(!ask && analyzed?.intent!=='ROLE_REQUEST')return null;
  // Merely quoting another person's request is not a fresh order from the human.
  if(/^(?:\d+\s*번|그\s*사람|걔)(?:이|가|은|는).{0,24}(?:직업|역할|정체).{0,15}(?:말하|얘기하|밝히|공개하).{0,8}(?:라고\s*했|자고\s*했)/.test(t))return null;
  const group=/(?:다들|모두|전원|여러분|너희|각자|한\s*명씩|하나씩|차례로|서로|우리\s*모두)/.test(t);
  return {group:group || analyzed?.group || false};
}

// Player messages can be questions, statements, corrections and short follow-ups.
// Routing and answering must inspect the SAME utterance; never substitute a
// generic discussion topic for a player's non-question contribution.
function isQuestion(text) {
  const t=normalize(text).replace(/[.!~]+$/,'').trim();
  if(!t)return false;
  if(/[?？]/.test(t))return true;
  // A declarative game report ending in a period must never become a
  // question merely because it contains a word such as '누구' or '조사'.
  if(/[.。]\s*$/.test(normalize(text)) && !/(?:말해(?:\s*줘)?|알려(?:\s*줘)?|답해(?:\s*줘)?|설명해(?:\s*줘)?|해명해(?:\s*봐)?|대답해|밝혀(?:\s*줘)?|공개해|보여\s*줘|정리해(?:\s*줘)?|공유해|말해봐|얘기해|말하라)\s*$/.test(t))return false;
  if(Utterance.classify(t)?.kind==='question')return true;
  // Role requests without punctuation remain conversational questions.
  if(roleDisclosureRequest(t))return true;
  if(/^(?:나는|난|내가|저는|전|제가|저)\s*.{0,20}(?:시민|경찰|의사|마피아|스파이|건달)(?:이야|야|입니다|이에요|인데)$/.test(t))return false;
  if(/(?:말해\s*줘|답해\s*줘|알려\s*줘|설명해\s*줘|해명해\s*봐|대답해|알려줘|말해봐|답해봐)$/.test(t))return true;
  if(/(?:왜|누구|누가|누굴|뭐|무슨|어떻게|어느|몇\s*번|뭔데|뭐야)/.test(t) &&
    /(?:왜|누구|누가|누굴|뭐|무슨|어떻게|어느|몇\s*번|뭔데|뭐야|생각해|의심해|맞아|이야|냐|니|했어|할거야|할래|말해|찍어|찍을래|투표해|수상해|알아)/.test(t))return true;
  if(/(?:직업|역할).{0,12}(?:말해|알려|뭐|뭔데)|(?:마피아|경찰|시민|의사|스파이|건달).{0,6}(?:맞아|냐|니)$/.test(t))return true;
  if(/(?:너|넌|네가|니가).{0,35}(?:의심해|믿어|동의해|수상해|같아|생각해|찍을래|투표할래)$/.test(t))return true;
  if(/^(?:너|넌|네가|니가|당신)\s*.{0,18}(?:마피아|경찰|의사|시민|건달|스파이)(?:야|냐|니|맞아)$/.test(t))return true;
  return false;
}
function intentOf(text) {
  const t=normalize(text);
  if(!isQuestion(t))return null;
  const semantic=Utterance.classify(t);
  if(semantic){
    const mapped={ROLE_REQUEST:'role',WHO_POLICE:'who_police',INVESTIGATION_QUERY:'investigation',
      EVIDENCE_QUERY:'evidence',SUSPICION_QUERY:'opinion',COMPARE:'compare',
      VOTE_QUERY:'vote',DEATH_QUERY:'death',CLARIFY:'clarify',
      LIVING_COUNT:'alive_count',PHASE_QUERY:'phase',RULE_QUERY:'game_rules',
      CHAT_HISTORY:'chat_history',CONTRADICTION:'contradiction',REPEAT_REQUEST:'repeat_request'};
    if(mapped[semantic.intent])return mapped[semantic.intent];
  }
  if(/(?:뭔\s*소리|무슨\s*말|무슨\s*뜻|이해.*?안\s*돼|다시\s*설명|방금.*?(?:말|뜻)|아까.*?무슨\s*말|그게\s*뭐)/.test(t))return 'clarify';
  if(/(?:밤|야간).{0,18}(?:스킵|건너\s*뛰(?:기)?|넘기)/.test(t))return 'night-skip';
  if(/(?:왜.*?(?:싸우|싸워|다투|다퉈)|그만.*?(?:싸우|싸워|다투)|싸우는\s*이유)/.test(t))return 'deescalate';
  if(/(?:\d+\s*번.{0,20}(?:스킵|건너뛰).{0,20}(?:했|한다|하겠).{0,20}(?:왜|투표)|왜.{0,20}(?:투표|찍).{0,20}(?:스킵|건너뛰))/.test(t))return 'vote_contradiction';
  if(/(?:경찰(?:이|은|은\s*대체)?\s*(?:대체\s*)?누구|누가\s*(?:진짜\s*)?경찰|누구(?:가|야|지)?\s*경찰|경찰\s*몇\s*번)/.test(t))return 'who_police';
  if(/(?:\d+\s*번.*?\d+\s*번).{0,30}(?:중에|둘\s*중|누가\s*더|어느\s*쪽|비교|더\s*수상)|(?:중에|둘\s*중).{0,40}(?:누가\s*더|수상|의심|마피아)/.test(t))return 'compare';
  if(/(?:누가\s*(?:죽|사망)|(?:지난밤|어젯밤).*?(?:죽|사망)|사망자.*누구)/.test(t))return 'death';
  if(/(?:조사.*?(?:누구|몇\s*번|결과|했어|했니|했냐|했냐고|알려|말해)|(?:누구|몇\s*번|\d+번).*?조사|조사\s*기록|(?:시민팀|마피아팀).*?(?:나왔|맞아))/.test(t))return 'investigation';
  if(/(?:왜.*?(?:의심|수상|찍|못\s*믿|마피아|거짓말)|(?:의심|수상).*?이유|근거|증거|해명|왜.*?그렇게|무슨\s*이유)/.test(t))return 'evidence';
  if(/(?:투표|스킵|건너뛰|누구\s*찍|누굴\s*찍|표를\s*줄|누구\s*뽑)/.test(t))return 'vote';
  if(/(?:너|넌|네가|니가|너는|당신)\s*(?:은|는)?\s*(?:마피아|경찰|의사|시민|건달|스파이)(?:야|이야|니|냐|맞아)/.test(t))return 'role';
  if(roleSilenceRequest(t))return 'role_silence';
  if(roleDisclosureRequest(t))return 'role';
  if(/(?:직업|역할|(?:너|넌|네가|니가|당신).*?(?:경찰|의사|시민|스파이|마피아|건달)|(?:경찰|의사|시민|스파이|건달).*?(?:맞아|이야|인가|냐|니))/.test(t))return 'role';
  if(/(?:누가\s*마피아|누굴\s*의심|누구.*?의심|누구.*?수상|어떻게\s*생각|생각은|믿어|동의해|(?:말|주장).{0,10}(?:동의|맞아|어때|믿어)|마피아.*?누구|(?:\d+\s*번|그\s*사람|걔).*?(?:마피아|시민|의심|수상|거짓말))/.test(t))return 'opinion';
  return 'general';
}
function directAddressee(text,view) {
  const t=normalize(text).replace(/^(?:(?:그럼|그러면|근데|그런데|혹시|저기|잠깐|일단|그래서|자|야)[,，:：\s]+){1,2}/, '');
  const m=t.match(/^(\d+)\s*번(?:님)?(?=\s|[,，:：!?]|(?:아|야|너|넌|네가|니가))/);
  if(!m)return null;
  const after=t.slice(m[0].length);
  // “4번은 마피아 같다” is ABOUT 4, not addressed TO 4.
  if(/^(?:은|는|이|가|을|를|의|이랑|하고|한테|에게|부터|도)/.test(after))return null;
  if(/^\s*(?:[,，:：!?]|아|야|너|넌|네가|니가|네\s*(?:직업|역할|말|가|생각)|니\s*(?:직업|역할|생각)|본인\s*(?:직업|생각)|직업|역할|정체|신분|공개|밝혀|말해|답해|왜|넌\s*누구|마피아|경찰|시민|의사|스파이|건달|\d+번)/.test(after))
    return view.everyone.find(q=>q.number===Number(m[1]))?.id || null;
  return null;
}
function previousDialogue(view,entry,p) {
  const i=view.publicChat.findIndex(x=>x.id===entry.id);
  if(i<=0)return null;
  const prior=view.publicChat.slice(Math.max(0,i-12),i).reverse().filter(x=>x.at>=view.phaseStart);
  const latestFromBot=prior.find(x=>x.senderId===p.id);
  const latestOverall=prior[0];
  return {latestFromBot,latestOverall,prior};
}
function contextualSubject(entry,p,view,mind) {
  const from=entry.senderId||entry.speakerId;
  const addressed=directAddressee(entry.text,view);
  const switched=topicSwitchTarget(entry.text,view);
  if(switched)return switched;
  const explicit=orderedMentions(entry.text,view.everyone).filter(id=>id!==addressed && id!==p.id);
  if(explicit.length)return explicit[0];
  // '5번 왜 거짓말했어?' addresses 5 directly. The subject is 5, not missing.
  if(addressed===p.id && /(?:왜|네\s*직업|니\s*직업|너\s*마피아|너\s*거짓말|네가\s*한|본인)/.test(entry.text))return p.id;
  if(/(?:왜\s*(?:나|날|내)|나를\s*(?:왜|의심)|내가\s*수상|날\s*의심)/.test(entry.text))return from;
  const ctx=previousDialogue(view,entry,p);
  if(/(?:그\s*사람|걔|그\s*애|그\s*말|그거|아까|방금|그게|맞아|아니|동의|네\s*말)/.test(entry.text)){
    const priorFromSpeaker=ctx?.prior?.find(x=>x.senderId===from && mentions(x.text,view.everyone).some(id=>id!==p.id));
    if(priorFromSpeaker){const refs=mentions(priorFromSpeaker.text,view.everyone).filter(id=>id!==p.id);if(refs.length)return refs[0];}
    const priorBot=ctx?.latestFromBot || ctx?.latestOverall;
    if(priorBot){const refs=mentions(priorBot.text,view.everyone).filter(id=>id!==p.id);if(refs.length)return refs[0];}
  }
  if(mind.lastOpinion?.targetId && /(?:그\s*사람|걔|그\s*말|그거)/.test(entry.text))return mind.lastOpinion.targetId;
  if(/(?:너|넌|네가|니가|너는|네\s*직업)/.test(entry.text))return p.id;
  return null;
}
function statementKind(text) {
  const t=normalize(text);
  // Explicit agreement with a named speaker must quote that person's actual
  // public statement; a generic 'I agree' response would lose the evidence.
  if(/(?:\d+\s*번).{0,15}(?:말에|의견에|주장에|말은|말이).{0,14}(?:동의|맞는\s*것|맞아|옳아|틀려|동의\s*안|동의하지)/.test(t))
    return /(?:동의\s*안|동의하지|틀려)/.test(t)?'disagree':'agree-ref';
  const semantic=Utterance.classify(t);
  const semanticKinds={ROLE_SILENCE:'role-silence',EVIDENCE_LACK:'uncertainty',
    UNCERTAIN:'uncertainty',DEFER:'uncertainty',VOTE_SKIP:'skip',
    NIGHT_SKIP:'night-skip',VOTE_PROPOSE:'vote',ACCUSE:'accusation',
    DEFEND:'defense',AGREE:'agree',DISAGREE:'disagree',
    CORRECTION:'correction',DEESCALATE:'deescalate',GREETING:'greeting',THANKS:'thanks'};
  // Respect explicit grammar for negative SKIP, role denials and prior
  // claims rather than reinterpreting them as superficial topic keywords.
  if(semantic?.kind==='statement'&&semanticKinds[semantic.intent])
    return semanticKinds[semantic.intent];
  // A night cannot be skipped in NOIR / SEVEN; it is not a vote-_SKIP_.
  if(/(?:밤|야간).{0,18}(?:스킵|건너\s*뛰(?:기)?|넘기)/.test(t))return 'night-skip';
  if(/(?:그만\s*싸|싸우지\s*마|말싸움\s*그만|서로\s*싸|논쟁\s*그만|시끄러|그만\s*다퉈|근거\s*없이.{0,24}(?:마피아|의심|수상|몰아).{0,12}(?:하지\s*마|몰아가지\s*마)|근거\s*없(?:이|는).{0,22}(?:단정|몰아가|비난)|증거\s*없이.{0,22}(?:단정|의심)|근거 없는 의심 그만)/.test(t))return 'deescalate';
  if(/\d+\s*번[^.!?]{0,28}(?:말고|아니고|됐고)\s*\d+\s*번/.test(t))return 'topic-switch';
  if(/(?:\d+\s*번).{0,15}(?:말에|의견에|주장에|말은|말이).{0,14}(?:동의|맞는\s*것|맞아|옳아|틀려|동의\s*안|동의하지)/.test(t))return /(?:동의\s*안|동의하지|틀려)/.test(t)?'disagree':'agree-ref';
  if(roleSilenceRequest(t))return 'role-silence';
  if(deniedRole(t))return 'role-denial';
  if(/\d+\s*번[^.!?]{0,24}\d+\s*번.{0,16}(?:같은\s*팀|한\s*팀|같은\s*편)/.test(t))return 'team-theory';
  if(/(?:내\s*말(?:\s*좀)?\s*들|말\s*좀\s*들어|내\s*말\s*무시|내가\s*말\s*하잖|사람\s*말\s*좀)/.test(t))return 'listen';
  if(/^(?:아니|아니\s*그게|그게\s*아니|정정할게|다시\s*말하면|내\s*말은)/.test(t))return 'correction';
  if(/(?:안녕|하이|ㅎㅇ|반가워)/.test(t) && t.length<17)return 'greeting';
  if(/^(?:응|ㅇㅇ|그래|맞아|맞지|동의|인정|좋아|오케이|ㅇㅋ|그렇지)/.test(t))return 'agree';
  if(claimedRole(t))return 'claim';
  if(/(?:내가|나는|난|전|제가|저는).{0,18}(?:조사했|조사해봤|조사\s*결과)/.test(t))return 'investigation';
  if(/(?:나는|난|내가|저는|전).{0,22}(?:스킵|건너\s*뛰(?:기)?)/.test(t) || /(?:스킵|건너\s*뛰(?:기)?)(?:\s*(?:할게|하자|할래|하려고|하고\s*싶))/.test(t))return 'skip';
  if(/(?:투표할게|찍을게|표\s*줄게|퇴출시키자|투표하자)/.test(t))return 'vote';
  if(/(?:의심\s*(?:안|하지\s*않|하지\s*말)|수상하지\s*않|마피아\s*(?:아니|같지\s*않)|마피아가\s*아니|믿어|결백|무죄)/.test(t))return 'defense';
  if(/(?:의심|수상|마피아\s*(?:같|인\s*것|야|다)|거짓말|구라|말\s*바꿨|수상해)/.test(t))return 'accusation';
  // These are statements of uncertainty, not proof requests. They are very
  // common in short day discussions and should receive direct acknowledgements.
  if(/(?:보류|판단\s*(?:못|안|보류)|아직\s*모르겠|잘\s*모르겠|누군지\s*모르겠|누구인지\s*모르겠|확신\s*(?:없|안\s*서)|(?:확실|명확|뚜렷)(?:한)?\s*(?:증거|근거|단서).{0,10}(?:없|부족)|(?:증거|근거|단서).{0,12}(?:없|부족|안\s*보)|(?:결정|단정)(?:하긴|하기엔)\s*(?:어렵|이르))/.test(t))return 'uncertainty';
  if(/(?:나는|난|내가|저는|전).{0,12}(?:마피아가?\s*아니|스파이가?\s*아니)/.test(t))return 'denial';
  return 'other';
}
function isReactiveMessage(text) {return normalize(text).length>=2;}

function askedForBot(obs,p,view,chat,forced=false) {
  if(!obs || (obs.senderId||obs.speakerId)===p.id || !intentOf(obs.text)) return false;
  if(forced)return true;
  const addressee=directAddressee(obs.text,view);
  if(addressee)return addressee===p.id;
  if(obs.mentions.includes(p.id) && /(?:너|네가|니가|넌|너는)/.test(obs.text))return true;
  // '너' after a bot's own statement is an implicit direct address.
  const idx=chat.findIndex(x=>x.id===obs.id);
  const prior=idx>0?chat[idx-1]:null;
  if(prior?.senderId===p.id && /(?:너|네가|니가|넌|너는|넌데)/.test(obs.text))return true;
  if(obs.mentions.length && !/다들|모두|여러분|누구든/.test(obs.text))return false;
  return /(?:다들|모두|여러분|누구|의견|어떻게|왜)/.test(obs.text);
}

function discussionLedger(room,phaseStart) {
  if(!room.aiDiscussionLedger || room.aiDiscussionLedger.phaseStart!==phaseStart)
    room.aiDiscussionLedger={phaseStart,answered:new Set(),topics:new Set(),genericCount:0};
  return room.aiDiscussionLedger;
}
function reserveTopic(room,phaseStart,key,generic=false) {
  const ledger=discussionLedger(room,phaseStart);
  if(ledger.topics.has(key) || (generic && ledger.genericCount>=6))return false;
  ledger.topics.add(key);
  if(generic)ledger.genericCount++;
  return true;
}

function pickQuestion(room,p,view,mind,replyToId) {
  const chat=view.publicChat;
  const answered=discussionLedger(room,view.phaseStart).answered;
  if(replyToId) {
    const chosen=chat.find(x=>x.id===replyToId);
    if(chosen && chosen.senderId!==p.id && (!answered.has(chosen.id) || roleDisclosureRequest(chosen.text)?.group) && !mind.answerIds.includes(chosen.id) &&
      (!chosen.bot || askedForBot({...chosen,mentions:mentions(chosen.text,view.everyone)},p,view,chat,true)))
      return {...chosen,mentions:mentions(chosen.text,view.everyone)};
  }
  const recent=chat.slice(-14).filter(x=>x.at>=view.phaseStart && x.senderId!==p.id &&
     !mind.answerIds.includes(x.id) && (!answered.has(x.id) || roleDisclosureRequest(x.text)?.group))
    .map(x=>({...x,mentions:mentions(x.text,view.everyone)}));
  return recent.filter(x=>askedForBot(x,p,view,chat)).sort((a,b)=>{
    const da=Number(directAddressee(a.text,view)===p.id);
    const db=Number(directAddressee(b.text,view)===p.id);
    return (db-da)*100 + (chat.findIndex(x=>x.id===b.id)-chat.findIndex(x=>x.id===a.id));
  })[0]||null;
}
function finishInteraction(room,p,view,mind,entry,response) {
  discussionLedger(room,view.phaseStart).answered.add(entry.id);
  mind.answerIds.push(entry.id);
  if(mind.answerIds.length>100)mind.answerIds=mind.answerIds.slice(-100);
  return normalize(`${formatRef(view,entry.senderId||entry.speakerId)}, ${response}`).slice(0,218);
}
function findRecentWords(view,senderId,entryId) {
  const idx=view.publicChat.findIndex(x=>x.id===entryId);
  return view.publicChat.slice(0,idx<0?undefined:idx).reverse().find(x=>x.senderId===senderId && x.at>=view.phaseStart)?.text||'';
}
function factFor(p,view,mind,id,channel='PUBLIC') {
  if(!id)return null;
  const ref=formatRef(view,id);
  const own=findOwnResult(view,id);
  if(view.role==='POLICE' && own) return {strong:own.displayed==='마피아팀',targetId:id,
    text:`${own.night}번째 밤에 ${ref}을 조사했어. 결과는 ${own.displayed}이었어.${own.displayed==='시민팀'?' 다만 스파이도 시민팀으로 표시돼.':''}`,
    kind:'police-result'};
  if(channel==='SECRET' && view.role==='SPY' && own?.actualRole) return {strong:true,targetId:id,
    text:`접선 전에 ${ref}을 조사했고 실제 직업은 ${own.displayed}이었어.`,kind:'spy-result'};
  const shift=mind.claimChanges.findLast(x=>x.speakerId===id);
  if(shift) return {strong:true,targetId:id,
    text:shift.to==='그 직업 부인'?
      `${ref}은 처음엔 ${roleAsQuote(shift.from)} 했다가 나중엔 그 직업이 아니라고 말했어. 공개 발언이 바뀐 건 확인되지만 이유는 알 수 없어.`:
      `${ref}은 처음엔 ${roleAsQuote(shift.from)} 했다가 나중엔 ${roleAsQuote(shift.to)} 했어. 직업 주장이 바뀐 건 채팅에서 직접 확인했어.`,kind:'role-change'};
  if(view.role==='POLICE' && id!==p.id && mind.claims[id]?.role==='경찰') return {strong:true,targetId:id,
    text:`${ref}이 경찰이라고 주장했는데 나도 경찰이야. 경찰은 한 명뿐이니 둘 다 진짜일 수는 없어.`,kind:'counterclaim'};
  const changed=mind.stanceChanges.findLast(x=>x.speakerId===id);
  if(changed) {
    const phrase=value=>value==='SKIP'?'투표 건너뛰기':`${formatRef(view,value)} 투표`;
    return {strong:false,targetId:id,text:`${ref}은 아까 ${phrase(changed.from)}를 이야기했다가 ${phrase(changed.to)}로 입장을 바꿨어. 다만 입장이 바뀐 것만으로 마피아라고 단정할 수는 없어.`,kind:'changed-vote-intent'};
  }
  const claim=mind.claims[id];
  if(claim)return {strong:false,targetId:id,
    text:`${ref}은 자신이 ${roleAsQuote(claim.role)} 주장했어. 하지만 직업을 말했다고 실제로 증명된 건 아니야.`,kind:'unverified-claim'};
  // An accusation is evidence that the ACCUSATION was spoken, not proof of the target's team.
  const discussed=mind.accusations.findLast(x=>x.target===id && x.by!==p.id);
  if(discussed)return {strong:false,targetId:id,
    text:`${formatRef(view,discussed.by)}이 ${ref}을 의심한다고 말했어. 그 말만으로 ${ref}이 마피아라는 증거는 아니야.`,kind:'second-hand'};
  return null;
}
function evidenceAnswer(p,view,mind,id,{direct=false}={}) {
  const ref=formatRef(view,id);
  const evidence=factFor(p,view,mind,id);
  if(!evidence)return direct ?
    `${ref}을 의심할 만한 확인된 근거는 아직 없어. 내가 먼저 의심했다면 성급했어. 지금은 단정하지 않겠어.` :
    `${ref}에 대해 확인된 단서가 없어서 마피아라고 말할 수 없어.`;
  if(evidence.strong)return `${direct?'내가 그렇게 판단한 근거는 이거야. ':''}${evidence.text}`;
  return `${evidence.text} 그래서 지금은 의심만으로 몰아가면 안 된다고 봐.`;
}
function summarizeVisibleFact(p,view,mind,id) {
  if(!id)return '그 사람이 누구인지 특정할 수 없어.';
  const f=factFor(p,view,mind,id);
  if(f?.strong)return f.text;
  if(f && f.kind!=='second-hand')return f.text;
  return `${formatRef(view,id)}의 실제 직업은 알 수 없어. 정체를 입증할 공개 증거는 아직 없어.`;
}
/* v2.8.9: replies are composed from independently inferred discourse features
 * plus real game evidence; there is no per-quote/screenshot answer table.
 * The parser's epistemic stance does not create evidence or reveal secrets.
 */
function groundedForFrame(p,view,mind,targetId) {
  if(targetId) {
    const ref=formatRef(view,targetId),f=factFor(p,view,mind,targetId);
    if(f?.strong)return `다만 ${f.text}`;
    if(f && f.kind!=='second-hand')return `${f.text}`;
    return `${ref}에 대해 확인된 결정적 근거는 아직 없어. 그래서 단정하지 않겠어.`;
  }
  // Only reveal facts the *speaking* AI actually witnessed or investigated.
  const known=view.alivePlayers.filter(x=>x.id!==p.id && x.id!==view.partnerId)
    .map(x=>factFor(p,view,mind,x.id)).filter(f=>f?.strong);
  if(known.length)return `그렇지만 확인할 수 있는 단서는 있어. ${known[0].text}`;
  const latest=view.publicLog.findLast(x=>/지난밤.*(?:사망|죽)|사망자는 없습니다/.test(x.text));
  if(latest)return `공개된 밤 결과는 “${normalize(latest.text).slice(0,55)}”이지만 범인의 신원은 확정되지 않았어.`;
  return '현재 공개 기록만으로 특정인의 정체를 확정할 수는 없어.';
}
function framePhrase(p,mind,variants,rng) {
  // Distribute contextual wording across personalities and turns. This is
  // presentation variation, never a random inference or fabricated fact.
  const i=(p.number + mind.turns + Math.floor(rng()*variants.length))%variants.length;
  return variants[i];
}
function replyFromDiscourseFrame(room,p,view,mind,entry,rng) {
  const frame=DiscourseFrame.parse(entry.text,{phase:room.phase});
  if(frame.reported) {
    if(!/(?:스킵|기권|패스|근거|증거|단서|확신|보류|유보)/.test(entry.text))return null;
    const source=orderedMentions(entry.text,view.everyone)[0];
    const ref=source?formatRef(view,source):'다른 참가자';
    const observed=source?view.publicChat.findLast(x=>x.senderId===source && x.id!==entry.id &&
      /(?:스킵|기권|패스|근거|증거|단서|확신|보류|유보)/.test(x.text)):null;
    return observed?`${ref}이 실제로 “${normalize(observed.text).slice(0,67)}”라고 말한 기록은 있어. 그 주장 자체가 증거는 아니야.`:
      `${ref}이 그렇게 말했다는 네 전언이구나. 공개된 채팅에 같은 발언이 있는지는 아직 확인되지 않았어.`;
  }
  if(!frame.act)return null;
  const id=contextualSubject(entry,p,view,mind);
  const ref=id?formatRef(view,id):null;
  const detail=groundedForFrame(p,view,mind,id);
  const t=normalize(entry.text);
  if(/(?:마피아라고|몰아가|의심|비난|단정).{0,18}(?:하지\s*마|하지\s*말|그만)|(?:근거|증거)\s*없이.{0,20}(?:마피아|몰아가|의심|비난)/.test(t) && !frame.question)
    return '그래. 확인된 근거 없이 누군가를 마피아라고 몰아가지 않겠어. 실제 발언과 조사 결과를 구분하자.';
  const first=framePhrase.bind(null,p,mind);
  const previous=previousDialogue(view,entry,p)?.latestFromBot;
  let opening='';
  if(frame.act==='DENY_ABSENCE') {
    const refPart=ref?`${ref}에 대해서 `:'';
    return `${refPart}증거나 확신이 전혀 없다고 말한 건 아니라는 뜻이구나. 그렇다고 아직 검증되지 않은 사실을 증명된 것으로 취급하진 않을게. ${detail}`;
  }
  if(frame.act==='REJECT_SKIP') {
    return `투표를 스킵하지 않겠다는 입장이구나. 누구에게 표를 줄지는 별도의 선택이고, 아직 실제 투표가 제출된 것은 아니야.`;
  }
  if(frame.act==='NIGHT_SKIP') {
    // The NIGHT stage is mandatory; only a daytime vote has a SKIP ballot.
    return '밤 단계 자체를 건너뛰는 건 규칙상 불가능해. 투표에서 사람을 고르지 않는 선택과는 구분해야 해.';
  }
  if(frame.act==='ASK_EVIDENCE') {
    opening=ref?`${ref}을 의심할 만한 확인된 근거를 묻는 거지.`:
      first(['어떤 근거가 있는지 묻는 거네.','소문이 아니라 실제 증거를 요구하는 말이지.','지금 가진 근거와 증거가 무엇인지 확인하자는 거지.'],rng);
    return `${opening} ${detail}`;
  }
  if(frame.act==='EVIDENCE_CLAIM') {
    opening=ref?`${ref}에 관한 근거가 있다고 말하는 거구나.`:
      '확인할 만한 정보가 있다고 말하는 거지.';
    return `${opening} ${detail} 주장과 검증된 사실은 나눠서 보자.`;
  }
  if(frame.act==='VOTE_SKIP') {
    const abstention=frame.question?
      first(['투표를 건너뛸지 고민하는 거구나.','지금 표를 행사하지 않아도 될지 묻는 거지.'],rng):
      first(['이번 투표를 건너뛰자는 의견이네.','지금은 아무도 퇴출시키지 말자는 제안으로 이해했어.','표를 던지지 않고 넘어가자는 쪽이구나.'],rng);
    if(id && /(?:\d+\s*번|그\s*사람)/.test(t) && !/(?:아무도|누구도)/.test(t)) {
      return `${abstention} ${ref}을 언급했지만 그 사람에게 투표한다는 뜻으로 해석하지 않을게. ${detail}`;
    }
    const known=view.alivePlayers.filter(x=>x.id!==p.id).map(x=>factFor(p,view,mind,x.id)).find(f=>f?.strong);
    if(known)return `${abstention} 다만 ${known.text} 이 단서도 판단에 포함해야 해.`;
    return `${abstention} 확인된 강한 근거가 없다면 고려할 수 있지만, 실제 투표 화면에서 '건너뛰기'를 선택해야 적용돼.`;
  }
  if(frame.act==='DEFER') {
    opening=first(['판단을 조금 더 미루자는 뜻이구나.','아직 결론부터 내리지 말자는 의견이지.','새 정보가 나올 때까지 상황을 보자는 쪽이네.'],rng);
    if(/(?:나도|저도|나\s*역시|그\s*말)/.test(t) && previous && /(?:스킵|보류|판단|기다리)/.test(previous.text))
      opening='방금 나온 판단 보류 의견에 동의한다는 거구나.';
    return `${opening} ${detail}`;
  }
  if(frame.act==='LOW_EVIDENCE') {
    opening=ref?`${ref}에 관해서는 아직 근거가 충분하지 않다고 보는 거지.`:
      first(['지금 증거만으로 누군가를 단정하기 어렵다는 뜻이네.','마피아를 지목할 객관적인 근거가 부족하다는 이야기지.','근거 없는 추측만으로 결론을 내리지 말자는 의견이구나.'],rng);
    return `${opening} ${detail}`;
  }
  if(frame.act==='UNCERTAIN') {
    opening=ref?`${ref}에 대해 아직 확신이 서지 않는 거지.`:
      first(['아직 누구를 의심할지 판단하기 어렵다는 뜻이지.','지금 판단이 애매하다는 건 이해했어.','확신 없이 몰아가고 싶지 않다는 말이네.'],rng);
    return `${opening} ${detail}`;
  }
  return null;
}

function replyToStatement(room,p,view,mind,entry,rng) {
  const common=replyFromDiscourseFrame(room,p,view,mind,entry,rng);
  if(common)return finishInteraction(room,p,view,mind,entry,common);
  const t=normalize(entry.text), kind=statementKind(t), from=entry.senderId||entry.speakerId;
  const addressed=directAddressee(t,view), subject=contextualSubject(entry,p,view,mind);
  const named=mentions(t,view.everyone).filter(x=>x!==addressed && x!==p.id);
  const ref=subject?formatRef(view,subject):null;
  const prev=findRecentWords(view,from,entry.id);
  let response='';
  if(kind==='role-silence') {
    response='알겠어. 지금은 내 직업을 공개하지 않을게. 하지만 다른 사람이 이미 한 직업 주장은 공개 발언으로 기억할게.';
  } else if(kind==='topic-switch') {
    response=subject?`알겠어. ${formatRef(view,subject)}에 관한 이야기로 바꾸자. ${summarizeVisibleFact(p,view,mind,subject)}`:
      '알겠어. 앞서 말한 대상 대신 새로 언급한 사람의 발언을 확인하자.';
  } else if(kind==='agree-ref' || kind==='disagree') {
    const source=orderedMentions(t,view.everyone)[0];
    const stated=view.publicChat.slice(0,view.publicChat.findIndex(x=>x.id===entry.id))
      .findLast(x=>x.senderId===source);
    if(source && stated){
      const quote=normalize(stated.text).slice(0,65);
      response=kind==='agree-ref'?`${formatRef(view,source)}이 “${quote}”라고 말했지. 네가 그 의견에 동의한다는 뜻으로 이해했어. 사실 여부는 별도로 확인하자.`:
        `${formatRef(view,source)}이 “${quote}”라고 말했지. 네가 그 의견에 동의하지 않는다는 뜻이구나. 반박 이유가 공개 기록에 있는지 보자.`;
    } else if(!source) response=kind==='agree-ref'?'앞에서 나온 의견에 동의하는 거지. 어떤 주장을 말하는지 기록과 비교해 볼게.':
      '그 판단에 반대한다는 뜻이지. 어떤 근거에 동의하지 않는지 말해주면 공개 기록과 대조해 볼게.';
    else response=kind==='agree-ref'?`${formatRef(view,source)}의 의견에 동의한다는 뜻이구나. 그 사람이 실제로 무엇을 말했는지는 지금 공개 기록에서 확인되지 않아.`:
      `${formatRef(view,source)}의 의견에 동의하지 않는다는 뜻이구나. 실제 발언 기록을 보고 판단하자.`;
  } else if(kind==='role-denial') {
    response=`네가 ${deniedRole(t)}은 아니라고 분명히 말한 건 들었어. 그 말을 반대로 해석하거나 그 직업이라고 몰아가진 않을게. 하지만 실제 직업은 아직 확인되지 않았어.`;
  } else if(kind==='team-theory') {
    const refs=orderedMentions(t,view.everyone);
    response=`${formatRef(view,refs[0])}과 ${formatRef(view,refs[1])}이 같은 팀이라는 추측이구나. 팀 관계는 공개된 발언만으로 확인할 수 없어. 실제로 일치하는 행동이나 조사 결과가 있는지 살펴봐야 해.`;
  } else if(kind==='deescalate') {
    response='알겠어. 근거 없는 의심과 마피아 단정을 반복하지 않을게. 확인된 사실과 추측을 구분해서 이야기하자.';
  } else if(kind==='listen') {
    const id=subject||(prev?mentions(prev,view.everyone).filter(x=>x!==p.id)[0]:null);
    if(id)response=`네 말 듣고 있어. 아까 ${formatRef(view,id)}에 대해 이야기한 것도 기억해. ${summarizeVisibleFact(p,view,mind,id)}`;
    else response='네 말 듣고 있어. 내 추측부터 꺼내지 말고 네가 제시한 내용에 맞춰 답할게.';
  } else if(kind==='greeting') {
    response='안녕. 지금 나온 공개 정보만 근거로 이야기할게.';
  } else if(kind==='correction') {
    const denial=/(?:안\s*의심|의심\s*안|의심하지\s*않|마피아\s*아니|마피아\s*같지\s*않)/.test(t);
    if(subject && denial)response=`내가 잘못 알아들었어. ${ref}을 의심하지 않는다는 뜻이지. ${summarizeVisibleFact(p,view,mind,subject)}`;
    else if(subject)response=`알겠어, ${ref}에 대한 말을 정정한 거구나. ${summarizeVisibleFact(p,view,mind,subject)}`;
    else response='내가 네 말을 다르게 이해했어. 앞의 추측을 일단 빼고 방금 정정한 내용으로 보겠어.';
  } else if(kind==='agree') {
    const recent=previousDialogue(view,entry,p)?.latestFromBot || previousDialogue(view,entry,p)?.latestOverall;
    if(recent && /스킵|건너뛰/.test(recent.text))response='응, 근거가 모자라면 스킵하는 쪽에 동의한다는 거지. 그건 무리하게 사람을 몰아가는 것보다 신중한 선택이야.';
    else if(recent && /(?:의심|수상|마피아|거짓말)/.test(recent.text))response=`내가 방금 한 말에 동의한다는 거지. 그래도 실제 증거와 추측은 따로 보자.`;
    else response='응, 네 의견은 들었어. 확인되지 않은 사실은 그대로 단정하지 않겠어.';
  } else if(kind==='claim') {
    const role=claimedRole(t);
    if(role==='경찰' && view.role==='POLICE')response='네가 경찰이라고 주장했지. 하지만 나도 경찰이야. 경찰은 한 명뿐이니 서로 주장이 충돌해. 조사 결과로 비교해 보자.';
    else response=`네가 ${roleAsQuote(role)} 주장한 건 들었어. 아직 검증된 정보는 아니니까, 뒤에 나오는 발언이나 조사 결과와 함께 판단할게.`;
    if(subject && subject!==from && subject!==p.id && /(?:조사|마피아팀|시민팀)/.test(t))
      response+=` ${ref}에 관한 말도 네 주장으로 기억해 둘게.`;
  } else if(kind==='investigation') {
    const claimedTeam=/(?:마피아팀|시민팀)/.exec(t)?.[0];
    response=subject ? `네가 ${ref}을 조사했다고 말한 거지${claimedTeam?' 결과가 '+claimedTeam+'이라는 주장도 들었어':''}. 그건 네가 발표한 정보이고, 내가 직접 검증한 결과라고 단정할 수는 없어.` :
      '네가 조사했다고 한 건 알겠어. 누구를 조사한 건지 번호가 있어야 그 발언을 다른 정보와 비교할 수 있어.';
  } else if(kind==='night-skip') {
    response='밤 단계 자체를 건너뛰는 기능은 없어. 이번 투표를 스킵하자는 뜻이면 투표 화면에서 건너뛰기를 선택하면 돼.';
  } else if(kind==='skip') {
    response='이번 투표를 스킵하자는 거지. 나도 확인된 단서가 부족하면 무리하게 누군가를 퇴출시키진 않겠어.';
  } else if(kind==='uncertainty') {
    const prior=previousDialogue(view,entry,p)?.latestFromBot;
    if(/보류|판단/.test(t)) {
      response=prior && /(?:스킵|건너뛰)/.test(prior.text) ?
        '판단을 보류하겠다는 거지. 나도 증거가 없다면 투표를 스킵하는 쪽을 고려할게.':
        '응, 아직 결론을 내리기 어렵다는 거지. 나도 새 단서가 나오기 전에는 누군가를 단정하지 않을게.';
    } else if(/(?:증거|근거|단서|확실)/.test(t)) {
      response='맞아. 확실한 근거가 없으면 누군가를 마피아라고 단정할 수 없어. 다음 발언과 조사 결과를 더 살펴보자.';
    } else {
      response='아직 판단하기 어렵다는 뜻으로 이해했어. 지금 나온 사실만으로 결론을 서두르지 말자.';
    }
  } else if(kind==='vote') {
    response=subject?`${ref}에게 투표하겠다는 뜻이구나. ${summarizeVisibleFact(p,view,mind,subject)} 그걸 감안해 각자 판단하자.`:
      '투표하자는 뜻은 알겠어. 다만 누구에게 표를 줄 건지와 그 근거는 구분해서 이야기하자.';
  } else if(kind==='defense' || kind==='denial') {
    if(subject && subject!==p.id)response=`${ref}을 섣불리 의심하지 말자는 거지. ${summarizeVisibleFact(p,view,mind,subject)} 근거가 없으면 퇴출을 밀어붙이지 않겠어.`;
    else response='네가 마피아가 아니라고 밝힌 건 들었어. 그 자체가 증명은 아니지만, 근거 없이 너를 몰아가지는 않겠어.';
  } else if(kind==='accusation') {
    if(subject && named.length>1 && /(?:랑|과|와|둘|서로|다르|비교)/.test(t))response=`${formatRef(view,named[0])}과 ${formatRef(view,named[1])}의 말을 비교하자는 거구나. 둘의 발언이 실제로 어긋나는지 채팅 내용을 보고 판단해야 해.`;
    else if(subject)response=`${ref}이 수상하다는 의견은 들었어. ${summarizeVisibleFact(p,view,mind,subject)} 이 내용만으로 단정하지는 않을게.`;
    else response='누군가 수상하다는 말은 들었어. 다만 대상이 특정되지 않아서 누구의 발언을 검토해야 할지 모르겠어.';
  } else if(named.length>=2 && /(?:랑|과|와|서로|비교|다르)/.test(t)) {
    response=`${formatRef(view,named[0])}과 ${formatRef(view,named[1])}을 비교하자는 이야기지. 실제로 어떤 주장에 차이가 있는지 확인해 보자.`;
  } else if(subject && subject!==p.id) {
    response=`${ref}에 대해 이야기하는 거지. ${summarizeVisibleFact(p,view,mind,subject)}`;
  } else if(/(?:고마워|ㄱㅅ|감사)/.test(t)) {
    response='응. 새 정보가 나오면 같이 따져 보자.';
  } else if(/(?:이해가\s*안|뭔\s*소리|말이\s*안\s*돼)/.test(t)) {
    response='내 설명이 엉뚱했구나. 내가 말한 사실과 추측을 구분해서 다시 말할게. 지금 확인된 단서는 많지 않아.';
  } else {
    // A terse, honest acknowledgement is better than a long generic speech
    // that every AI repeats when the player's sentence has no known intent.
    response='의견은 들었어. 지금은 확인된 사실을 중심으로 판단할게.';
  }
  return finishInteraction(room,p,view,mind,entry,response);
}
function topicOf(question,p,view,mind) {
  return contextualSubject(question,p,view,mind);
}
function rulesAnswer(q) {
  if(/경찰/.test(q)&&/(?:능력|역할|하는|뭐|설명)/.test(q))
    return '경찰은 밤마다 한 명을 조사해 시민팀인지 마피아팀인지 확인해. 다만 스파이는 조사 결과에 시민팀으로 표시돼.';
  if(/의사/.test(q))return '의사는 밤에 한 명을 치료할 수 있고 자기 자신도 치료할 수 있어. 치료 대상 선택은 밤 단계에서만 가능해.';
  if(/건달/.test(q))return '건달은 밤에 한 명을 지목해 그 사람의 다음 날 투표권을 제한하는 능력이 있어.';
  if(/스파이/.test(q)&&/(?:접선|능력|역할|하는)/.test(q))return '스파이는 마피아팀이야. 접선이 성공한 뒤 정해진 다음 날 밤부터 비밀 채팅을 사용할 수 있어.';
  if(/마피아/.test(q)&&/(?:능력|역할|승리|조건|하는)/.test(q))return '마피아는 밤에 공격 대상을 선택해. 시민팀 전원이 제거되면 마피아팀이 승리하고, 마피아가 제거되면 시민팀이 이겨.';
  if(/(?:스킵|기권|투표|표결)/.test(q))return '낮 투표에서는 사람을 지목하거나 스킵할 수 있어. 투표하지 않는 것과 스킵 표를 내는 것은 달라. 동률이면 45초 추가 토론 뒤 한 번 재투표해.';
  if(/(?:밤|야간)/.test(q)&&/(?:건너|스킵|패스|생략)/.test(q))return '밤 단계는 생략할 수 없어. 각자의 직업별 능력은 정해진 제한 시간과 대상 규칙을 따라야 해.';
  if(/접선/.test(q))return '마피아와 스파이는 접선에 성공해야 서로를 확인하고, 그다음 날 밤부터 비밀 채팅을 사용할 수 있어.';
  if(/(?:재투표|동률)/.test(q))return '1차 투표에서 동률이면 45초 추가 토론과 30초 재투표를 진행해. 세 번째 투표는 없어.';
  if(/(?:토론|시간|초)/.test(q))return '기본 낮 토론은 60초, 1차 투표는 30초야. 동률이면 45초 추가 토론 후 30초 재투표해. 밤 행동 제한 시간은 60초야.';
  return '공개 규칙을 설명할게. 참가자 7명은 마피아 1, 스파이 1, 경찰 1, 의사 1, 건달 1, 시민 2명이야. 구체적인 직업이나 투표 규칙을 말해줘.';
}
function corpusSpecialAnswer(room,p,view,mind,entry,channel='PUBLIC') {
  const parsed=Utterance.classify(entry.text,{phase:room.phase,channel});
  if(!parsed)return null;
  const t=normalize(entry.text);
  const from=entry.senderId||entry.speakerId;
  if(parsed.intent==='LIVING_COUNT'){
    const alive=view.everyone.filter(x=>x.alive);
    return `현재 생존자는 ${alive.length}명이야. ${alive.map(x=>`${x.number}번`).join(', ')}이 살아 있어. 실제 직업은 공개된 정보만으로 알 수 없어.`;
  }
  if(parsed.intent==='PHASE_QUERY'){
    const names={LOBBY:'대기실',BOXES:'직업 선택 준비',NIGHT:'밤 행동',NIGHT_RESULT:'밤 결과',DAY:'낮 토론',VOTE1:'1차 투표',EXTRA_DISCUSSION:'추가 토론',VOTE2:'재투표',VOTE_RESULT:'투표 결과',GAME_OVER:'게임 종료',ABORTED:'게임 중단'};
    return `지금은 ${view.night}번째 밤 기준 ${names[room.phase]||room.phase} 단계야. 밤·낮·투표는 정해진 순서에 따라 진행돼.`;
  }
  if(parsed.intent==='RULE_QUERY')return rulesAnswer(t);
  if(parsed.intent==='CHAT_HISTORY'){
    const messages=(channel==='SECRET'?view.secretChat:view.publicChat).filter(x=>x.id!==entry.id);
    const explicit=orderedMentions(t,view.everyone);
    const aboutMe=/(?:내가|나는|난|제가|저는|내\s*말)/.test(t);
    const id=aboutMe?from:explicit[0]||null;
    const found=messages.slice().reverse().find(x=>!id||x.senderId===id);
    if(!found)return id?`${formatRef(view,id)}의 앞선 발언을 이 채팅에서 찾을 수 없어.`:'앞선 발언이 이 채팅에 보이지 않아.';
    const label=formatRef(view,found.senderId);
    return `${label}이 앞에서 “${normalize(found.text).slice(0,95)}”라고 말한 기록이 있어. 다만 그 말이 사실이라는 증거는 별개야.`;
  }
  if(parsed.intent==='CONTRADICTION'){
    const id=contextualSubject(entry,p,view,mind);
    const name=id?formatRef(view,id):'특정 참가자';
    const changes=[...mind.claimChanges,...mind.stanceChanges].filter(x=>!id||x.speakerId===id);
    const last=changes.at(-1);
    if(last&&last.to==='그 직업 부인')return `${name}은 앞에서 ${roleAsQuote(last.from)} 했다가 뒤에는 그 직업이 아니라고 말했어. 공개 기록상 발언이 달라진 건 맞아.`;
    if(last&&mind.claimChanges.includes(last))return `${name}이 ${roleAsQuote(last.from)} 했다가 ${roleAsQuote(last.to)} 했어. 공개된 직업 주장이 바뀐 건 확인돼.`;
    if(last)return `${name}이 공개적으로 밝힌 투표 입장을 바꾼 기록이 있어. 그렇다고 마피아로 확정되는 것은 아니야.`;
    return `${name}의 발언이 모순된다는 주장은 들었어. 하지만 현재 확인된 직업·투표 입장 변경 기록은 없어. 어떤 두 발언인지 알려줘.`;
  }
  return null;
}
function answerQuestion(room,p,view,mind,question,rng) {
  const common=replyFromDiscourseFrame(room,p,view,mind,question,rng);
  if(common)return finishInteraction(room,p,view,mind,question,common);
  const intent=intentOf(question.text);
  const fromId=question.senderId||question.speakerId;
  const id=topicOf(question,p,view,mind);
  const ref=id?formatRef(view,id):null;
  const q=normalize(question.text);
  const prior=previousDialogue(view,question,p);
  const special=corpusSpecialAnswer(room,p,view,mind,question);
  if(special)return finishInteraction(room,p,view,mind,question,special);
  if(intent==='repeat_request') {
    const original=prior?.prior?.find(x=>x.senderId===fromId &&
      x.id!==question.id && intentOf(x.text) && intentOf(x.text)!=='repeat_request');
    if(original){
      const reply=answerQuestion(room,p,view,mind,original,rng);
      const prefix=formatRef(view,fromId)+', ';
      return finishInteraction(room,p,view,mind,question,
        `아까 “${normalize(original.text).slice(0,45)}”라고 물었지. ${reply.startsWith(prefix)?reply.slice(prefix.length):reply}`);
    }
    return finishInteraction(room,p,view,mind,question,
      '대답을 다시 요청한 건 알겠어. 앞서 했던 질문이 현재 대화에서 보이지 않아. 무엇을 물었는지 한 번 더 말해줘.');
  }
  let response='';
  if(intent==='night-skip') {
    response='밤 단계는 건너뛸 수 없어. 지금 투표를 건너뛰자는 뜻이라면 투표 화면에서 스킵을 선택하면 돼.';
  } else if(intent==='who_police') {
    const declared=Object.entries(mind.claims).filter(([id,c])=>c.role==='경찰').map(([id])=>formatRef(view,id));
    if(view.role==='POLICE') response=declared.length?
      `나는 경찰이야. 공개적으로 경찰이라고 주장한 사람은 ${declared.join(', ')}이지만, 다른 사람의 주장까지 진짜라는 뜻은 아니야.`:
      '나는 경찰이야. 내 조사 결과와 다른 사람들의 발언을 비교해서 판단해 줘.';
    else response=declared.length?
      `경찰이라고 공개적으로 주장한 사람은 ${declared.join(', ')}이야. 다만 누가 진짜 경찰인지는 확인되지 않았어.`:
      '아직 공개적으로 경찰이라고 밝힌 사람은 확인하지 못했어. 비공개 직업은 임의로 추측해서 알려줄 수 없어.';
  } else if(intent==='compare') {
    const pair=orderedMentions(q,view.everyone).filter(x=>x!==p.id || !directAddressee(q,view)).slice(0,2);
    if(pair.length<2)response='비교할 두 사람의 번호를 알려줘. 기록에 없는 단서는 만들지 않을게.';
    else {
      const [a,b]=pair,fa=factFor(p,view,mind,a),fb=factFor(p,view,mind,b);
      const aa=formatRef(view,a),bb=formatRef(view,b);
      if(fa?.strong && !fb?.strong)response=`${aa}과 ${bb}을 비교하면 ${aa}에게 더 분명한 단서가 있어. ${fa.text} ${bb}에 관해선 확인된 강한 단서가 없어.`;
      else if(fb?.strong && !fa?.strong)response=`${aa}과 ${bb}을 비교하면 ${bb}에게 더 분명한 단서가 있어. ${fb.text} ${aa}에 관해선 확인된 강한 단서가 없어.`;
      else if(fa?.strong && fb?.strong)response=`${aa}과 ${bb} 모두 따져볼 단서가 있어. ${fa.text} ${fb.text}`;
      else response=`${aa}과 ${bb} 모두 확인된 결정적인 근거가 부족해. 지금은 둘 중 누가 더 수상하다고 단정할 수 없어.`;
    }
  } else if(intent==='vote_contradiction') {
    const source=orderedMentions(q,view.everyone)[0];
    const publicStance=source?mind.publicStances[source]:null;
    const line=source?view.publicChat.findLast(x=>x.senderId===source&&/(?:스킵|건너뛰)/.test(x.text)&&x.id!==question.id):null;
    if(source && (publicStance==='SKIP'||line))response=`${formatRef(view,source)}이 스킵하겠다고 말한 기록이 있어. 그건 ${formatRef(view,source)}에게 투표하라는 뜻이 아니야. 실제 투표는 별개이고, 누가 투표를 요구했는지는 기록을 봐야 해.`;
    else if(source)response=`${formatRef(view,source)}이 스킵한다고 했다는 네 말은 들었어. 다만 공개 기록에서 확인되지 않으니 사실로 단정하진 않을게. 스킵과 특정인 투표는 다른 선택이야.`;
    else response='스킵하겠다는 말과 누군가에게 투표하자는 말은 달라. 누가 어떤 입장을 밝혔는지 공개 발언을 확인해 보자.';
  } else if(intent==='clarify') {
    const last=prior?.latestFromBot||prior?.latestOverall;
    if(last) {
      const content=normalize(last.text).slice(0,95);
      if(/(?:주장|진짜|증명|확인되지|확정)/.test(content))
        response=`아까 내가 말한 건 “${content}”이야. 누군가 그렇게 말했다는 사실과 그 말이 진짜라는 건 다르다는 뜻이야.`;
      else response=`내가 방금 “${content}”라고 했지. 확인된 정보와 아직 추측인 부분을 구분해서 보자는 뜻이야.`;
    } else response='내가 바로 앞에서 한 말이 보이지 않아. 어떤 발언을 말하는지 번호나 내용을 짚어주면 정확히 설명할게.';
  } else if(intent==='deescalate') {
    response='서로 같은 의심을 반복하기보다 근거를 보자는 뜻이야. 나도 확인되지 않은 말을 사실처럼 되풀이하지 않을게.';
  } else if(intent==='death') {
    const line=view.publicLog.filter(x=>/지난밤 .*사망|지난밤 사망자는 없습니다/.test(x.text)).at(-1);
    response=line?`${line.text} 그게 지금 공개된 결과야. 누가 공격했는지는 공개되지 않았어.`:'아직 밤 사망 결과가 발표되지 않았어.';
  } else if(intent==='investigation') {
    if(view.role==='POLICE') {
      const specified=id && id!==p.id && id!==fromId?findOwnResult(view,id):null;
      if(specified)response=`${ref}은 ${specified.night}번째 밤에 조사했어. 결과는 ${specified.displayed}이야.${specified.displayed==='시민팀'?' 다만 스파이는 시민팀으로 나올 수 있어.':''}`;
      else if(id && id!==p.id && id!==fromId && /(?:조사했|조사\s*결과)/.test(q))response=`${ref}은 아직 조사한 기록이 없어. 결과를 지어내지 않을게.`;
      else response=view.investigations.length?`내가 직접 조사한 기록은 ${view.investigations.slice(-3).map(x=>`${formatRef(view,x.targetId)}: ${x.displayed}`).join(', ')}야. 시민팀 결과에 스파이가 포함될 수 있어.`:'나는 경찰이지만 아직 공개할 조사 결과가 없어.';
    } else if(view.role==='SPY' || view.role==='MAFIA') {
      response='내가 가진 비공개 정보를 여기서 확인해 주지는 않을게. 공개된 조사 주장은 따로 검증해야 해.';
    } else {
      response='난 경찰 조사 결과를 갖고 있지 않아. 다른 사람이 공개한 조사 주장은 들을 수 있지만 내가 조사했다고 말할 순 없어.';
    }
  } else if(intent==='vote') {
    if(id && id!==p.id && id!==fromId && /(?:\d+번|그\s*사람|걔)/.test(q)) {
      const evidence=factFor(p,view,mind,id);
      response=evidence?.strong?`${ref}을 투표 대상으로 생각할 만한 단서는 있어. ${evidence.text}`:`${ref}에게 투표하자는 말이지. 하지만 지금 ${ref}을 퇴출시킬 충분한 근거는 없어. 나는 스킵도 고려하고 있어.`;
    } else {
      const eligible=view.alivePlayers.filter(x=>x.id!==p.id && x.id!==view.partnerId);
      const top=strongestSuspect(p,view,mind,eligible.map(x=>x.id));
      const evidence=top?factFor(p,view,mind,top.id):null;
      response=top && evidence?.strong && suspicion(mind,view,top.id)>0.8?`지금은 ${formatRef(view,top.id)}에게 투표할 생각이야. ${evidence.text}`:
        '확인된 근거가 부족하니 이번엔 스킵을 고려 중이야. 새 증거가 나오면 판단을 바꿀게.';
    }
  } else if(intent==='role_silence') {
    response='알겠어. 지금은 직업을 공개하지 않을게. 이미 누군가 말한 직업 주장과 실제 직업은 구분할게.';
  } else if(intent==='role') {
    const aboutOther=id && id!==p.id && id!==fromId;
    if(aboutOther) {
      response=summarizeVisibleFact(p,view,mind,id);
    } else if(/(?:너|넌|네가|니가|당신).*?마피아/.test(q)) {
      response=view.team==='MAFIA'?'나는 마피아가 아니야. 하지만 내 말만 믿지 말고 공개된 행동으로 판단해.':'아니, 나는 마피아팀이 아니야. 내 주장도 다른 정보와 대조해서 판단해 줘.';
    } else if(view.role==='POLICE') {
      response=view.investigations.length?`나는 경찰이야. 내가 직접 조사한 결과는 ${view.investigations.map(x=>`${formatRef(view,x.targetId)} ${x.displayed}`).join(', ')}야.`:'나는 경찰이야. 조사 결과는 아직 없어.';
    } else if(view.team==='MAFIA') {
      response='내 직업은 지금 밝히지 않을게. 내가 무슨 직업이라고 말하든 그 주장만으로 확인되진 않으니까.';
    } else {
      // Keep a consistent disclosure decision across repeated questions in
      // this round: changing between an identity claim and secrecy randomly
      // on every prompt makes a bot appear to contradict its own memory.
      if(!mind.roleDisclosure) mind.roleDisclosure=rng()<0.60?'REVEAL':'WITHHOLD';
      response=mind.roleDisclosure==='REVEAL'?`내 직업은 ${roleAsStatement(({CITIZEN:'시민',GANGSTER:'건달',DOCTOR:'의사',POLICE:'경찰'})[view.role])}. 이 말만으로 확정하지는 마.`:'직업은 아직 공개하지 않을게. 대신 확인 가능한 발언을 기준으로 이야기하자.';
    }
  } else if(intent==='evidence') {
    if(!id)response='어느 사람에 대한 근거를 묻는지 정확하지 않아. 번호로 말해 주면 그 사람의 공개된 발언을 확인할게.';
    else if(id===p.id && directAddressee(q,view)===p.id && /(?:거짓말|구라|말\s*바꿨)/.test(q)) {
      const priorOwn=view.publicChat.filter(x=>x.senderId===p.id && x.id!==question.id).slice(-3);
      response=priorOwn.length?`${formatRef(view,p.id)}인 내가 한 말이 서로 모순된다는 뜻으로 들었어. 공개된 내 발언 기록을 기준으로 확인해야 해. 추측을 사실이라고 말하진 않을게.`:`${formatRef(view,p.id)}인 내가 거짓말했다는 근거는 지금 공개 기록에 없어. 확인할 만한 내 발언이 나오면 그걸 기준으로 판단하자.`;
    } else if(id===fromId && /(?:왜.*?(?:나|날|내)|나를.*?의심)/.test(q)) {
      const hadAccused=view.publicChat.some(x=>x.senderId===p.id && mentions(x.text,view.everyone).includes(fromId) &&
        /(?:의심|수상|마피아|거짓말)/.test(x.text));
      response=hadAccused?evidenceAnswer(p,view,mind,fromId,{direct:true}):'나는 너를 마피아라고 단정해서 지목한 적은 없어. 의심할 근거는 아직 없어. 네 발언을 확인하고 판단하려는 거야.';
    } else response=evidenceAnswer(p,view,mind,id,{direct:true});
  } else if(intent==='opinion') {
    if(/(?:내\s*말|내가\s*한\s*말|나를|날).{0,18}(?:믿|동의)/.test(q)) {
      const recent=findRecentWords(view,fromId,question.id);
      if(recent && claimedRole(recent))response=`네가 아까 ${roleAsQuote(claimedRole(recent))} 말한 건 기억해. 다만 그 발언만으로 진짜인지 확인할 수는 없어.`;
      else response='네 말을 무시한 건 아니야. 다만 믿는 것과 사실로 확인하는 건 구분해서 판단하려고 해.';
    } else {
    const broad=/(?:누가|누굴|누구).{0,20}(?:마피아|의심|수상)|(?:마피아|의심).{0,15}누구/.test(q);
    if(id && id!==p.id && !broad) {
      const recent=view.publicChat.findLast(x=>x.senderId===id && x.id!==question.id);
      if(/(?:말에\s*동의|말\s*믿|그\s*말\s*맞|뭐라고\s*했)/.test(q) && recent)response=`${ref}이 “${normalize(recent.text).slice(0,70)}”라고 말한 건 들었어. 그렇지만 그 말이 사실인지는 다른 단서와 비교해야 해.`;
      else response=summarizeVisibleFact(p,view,mind,id);
    } else {
      const eligible=view.alivePlayers.filter(x=>x.id!==p.id && x.id!==view.partnerId);
      const strong=eligible.map(x=>({x,fact:factFor(p,view,mind,x.id)})).filter(x=>x.fact?.strong);
      response=strong.length?`${formatRef(view,strong[0].x.id)}을 살펴볼 이유가 있어. ${strong[0].fact.text}`:
        '현재 누가 마피아인지 확실한 단서가 없어. 말투가 아니라 조사 결과와 실제 발언을 기준으로 보려고 해.';
    }
    }
  } else {
    if(/(?:맞지|맞아|동의해)/.test(q))response='네 말이 어떤 주장인지는 들었어. 다만 직업이나 마피아 여부는 검증 없이 맞다고 확정할 수 없어.';
    else if(id && id!==p.id)response=`${ref}에 관해 묻는 거지. ${summarizeVisibleFact(p,view,mind,id)}`;
    else response='질문을 정확히 이해하지 못했어. 알아듣지 못한 부분을 임의로 추리하지 않을게. 대상이나 행동을 구체적으로 말해줘.';
  }
  return finishInteraction(room,p,view,mind,question,response);
}
// PRIVATE TEAM DISCUSSION: used only once Mafia and Spy have truly contacted.
// This cannot call the public reply functions: those assume a public transcript
// and deliberately refuse to share investigations. Each answer is anchored in
// the partner's actual message, the speaker's own knowledge and public evidence.
function secretAttackTarget(text,view) {
  const t=normalize(text);
  const attack=/(?:공격|살해|죽일|죽이|죽여|잡자|노리|노려|처리하|킬|\d+\s*번(?:으로|로)\s*(?:가자|하자|바꾸자|정하자|선택하자)|\d+\s*번\s*(?:선택|타겟|목표))/.test(t) && !/(?:투표|스킵|퇴출)/.test(t);
  if(!attack)return null;
  const ids=orderedMentions(t,view.everyone);
  if(!ids.length)return null;
  const ban=!!secretAvoidTarget(t,view);
  const switched=/(?:말고|대신|바꿔|변경|옮기|전환)/.test(t) && ids.length>=2;
  if(ban && !switched)return null;
  const candidate=switched?ids[ids.length-1]:ids[0];
  if(!view.alivePlayers.some(x=>x.id===candidate))return null;
  return candidate;
}
function secretAvoidTarget(text,view) {
  const t=normalize(text);
  const ids=orderedMentions(t,view.everyone);
  if(!ids.length)return null;
  if(/(?:말고|대신)/.test(t) && ids.length>1 && /(?:공격|죽이|죽일|죽여|살해|노리|처리)/.test(t))return ids[0];
  if(/(?:공격|살해|죽이|죽일|죽여|노리|처리).{0,12}(?:하지\s*마|하지\s*말|말자|안\s*돼|취소|반대)|(?:죽이지|죽이면|공격하면|공격하는\s*건).{0,8}(?:마|말|안\s*돼)|(?:공격|죽이|죽일|살해)\s*안\s*해/.test(t))return ids[0];
  return null;
}
function secretRecentPartnerMessage(room,p,view,mind,replyToId) {
  const partner=view.partnerId;
  if(!view.contacted || !partner)return null;
  if(!mind.secretAnswerIds)mind.secretAnswerIds=[];
  const entry=replyToId?view.secretChat.find(x=>x.id===replyToId):
    view.secretChat.slice().reverse().find(x=>x.senderId===partner && !mind.secretAnswerIds.includes(x.id));
  if(!entry || entry.senderId!==partner || mind.secretAnswerIds.includes(entry.id))return null;
  return entry;
}
function secretEvidence(p,view,mind,id) {
  const ref=formatRef(view,id);
  const own=findOwnResult(view,id);
  if(p.role==='SPY' && own?.actualRole)
    return `${ref}은 내가 ${own.night}번째 밤에 직접 조사했고 실제 직업은 ${own.displayed}로 확인됐어.`;
  const claim=mind.claims[id];
  if(claim)return `${ref}이 낮에 ${roleAsQuote(claim.role)} 주장한 건 봤어. 하지만 조사로 확인된 건 아니야.`;
  const line=view.publicChat.findLast(x=>x.senderId===id);
  if(line)return `${ref}이 낮에 한 마지막 말은 “${normalize(line.text).slice(0,48)}”였어. 그 말만으론 실제 직업을 알 수 없어.`;
  return `${ref}에 관한 확인된 단서는 아직 없어.`;
}
function secretSharedIntel(view,requestedId=null) {
  // Report what the partner told us, not a privileged read of the other role.
  const reports=[];
  for(const entry of view.secretChat.slice().reverse()) {
    if(entry.senderId!==view.partnerId)continue;
    const text=normalize(entry.text);
    const ids=orderedMentions(text,view.everyone);
    if(!ids.length || !/(?:조사|확인|알아봤|직업은)/.test(text))continue;
    const role=text.match(/(?:경찰|의사|건달|시민|마피아|스파이)/)?.[0];
    if(!role)continue;
    if(requestedId && !ids.includes(requestedId))continue;
    const id=ids[0];
    if(reports.some(x=>x.id===id))continue;
    reports.push({id,role});
  }
  return reports;
}
function secretInvestigations(p,view,requestedId=null) {
  if(p.role!=='SPY') {
    const received=secretSharedIntel(view,requestedId);
    if(received.length)return `네가 비밀 채팅에서 ${received.map(x=>`${formatRef(view,x.id)}은 ${x.role}`).join(', ')}라고 조사 결과를 알려줬지. 나는 직접 확인할 수 없어서 네가 공유한 정보로만 기억하고 있어.`;
    return requestedId?`${formatRef(view,requestedId)}에 대해 네가 공유한 조사 결과는 아직 없어. 내가 직접 조사한 기록도 없어.`:
      '나는 직접 조사할 수 없어. 네가 조사한 기록을 공유해 주면 그 내용에 맞춰 함께 논의할게.';
  }
  const found=requestedId ? view.investigations.findLast(x=>x.targetId===requestedId) : null;
  if(requestedId && !found)return `${formatRef(view,requestedId)}은 내가 조사한 기록이 없어. 결과를 지어내지 않을게.`;
  const list=(requestedId?[found]:view.investigations).filter(x=>x?.actualRole);
  return list.length?`내가 직접 조사한 기록은 ${list.map(x=>`${formatRef(view,x.targetId)} ${x.displayed}(${x.night}번째 밤)`).join(', ')}야. 다른 사람의 직업은 추측일 뿐이야.`:
    '아직 공유할 직접 조사 기록이 없어. 확인하지 않은 사람의 직업은 모른다고 할게.';
}
function secretTargetFromLastMessage(view,entry) {
  const switched=topicSwitchTarget(entry.text,view);
  if(switched)return switched;
  const ids=orderedMentions(entry.text,view.everyone);
  return ids.find(x=>x!==view.partnerId && x!==view.selfId) || ids[0] || null;
}
function answerSecret(room,p,view,mind,entry) {
  const t=normalize(entry.text);
  const semantic=Utterance.classify(t,{phase:room.phase,channel:'SECRET'});
  const special=corpusSpecialAnswer(room,p,view,mind,entry,'SECRET');
  const partner=view.partnerId;
  const refId=secretTargetFromLastMessage(view,entry);
  const refs=orderedMentions(t,view.everyone);
  const target=secretAttackTarget(t,view)||
    (semantic && ['SECRET_ATTACK','SECRET_SWITCH'].includes(semantic.intent)?refs.at(-1):null);
  const valid=target && target!==p.id && target!==partner;
  const attackWord=(/(?:공격|살해|죽|킬|노리|처리|습격|제거|\d+\s*번(?:으로|로)\s*(?:가자|하자|바꾸자|정하자|선택)|타겟|목표)/.test(t) && !/(?:투표|스킵|퇴출)/.test(t)) ||
    !!(semantic && ['SECRET_ATTACK','SECRET_AVOID','SECRET_SWITCH'].includes(semantic.intent));
  const requestInfo=/(?:조사|정보|결과|직업).{0,26}(?:누구|몇\s*번|뭐|알려|말해|공유|했|확인)|(?:누구|몇\s*번).{0,20}(?:조사|알아)/.test(t);
  const rolePrompt=roleDisclosureRequest(t);
  const ownAction=p.role==='MAFIA'?room.actions.get(p.id):null;
  const confirmed=ownAction?.confirmed;
  const ownTarget=ownAction?.target||ownAction?.selected;
  let reply=special||'';
  if(special) {
    // Do not turn a direct rule/memory answer into idle strategy narration.
  } else if(semantic?.intent==='SECRET_AVOID') {
    const exclude=refs[0];
    reply=exclude?`${formatRef(view,exclude)}을 공격하지 말자는 뜻이지. ${confirmed?'이미 확정된 공격은 이 밤에 바꿀 수 없어.':'확정 전이라면 다른 후보를 고를게.'}`:
      '공격을 피하자는 의견은 들었어. 확정 전이라면 공격 대상을 다시 검토할게.';
  } else if(semantic?.intent==='SECRET_PLAN' && !refs.length && !/(?:조사|확인|결과|직업|의사|경찰|건달|시민팀|마피아팀)/.test(t)) {
    if(confirmed)reply=`나는 이미 ${formatRef(view,ownTarget)} 공격을 확정했어. 이번 밤에는 바꿀 수 없어.`;
    else if(ownTarget)reply=`현재 ${formatRef(view,ownTarget)}을 공격 후보로 선택했지만 확정 전이야. 실제 확인된 정보를 보고 다시 판단할 수 있어.`;
    else reply=p.role==='MAFIA'?'아직 공격 대상을 확정하지 않았어. 공개 발언과 네 조사 정보를 보고 살아 있는 시민팀 후보를 고를게.':'조사 결과를 비교해서 공격 후보를 제안할게. 최종 공격 대상은 마피아가 정해.';
  } else if(semantic?.intent==='SECRET_INFO') {
    reply=secretInvestigations(p,view,refId&&refId!==p.id&&refId!==partner?refId:null);
  } else if(/(?:아니\s*그게|그게\s*아니|정정|말고|대신|바꿔|변경|옮기|전환)/.test(t) && target) {
    if(!valid)reply='그 사람은 우리 팀이거나 나 자신이어서 공격 대상으로 정할 수 없어. 다른 살아 있는 사람을 골라야 해.';
    else if(confirmed)reply=`${formatRef(view,target)}으로 바꾸자는 뜻이지. 하지만 난 이미 ${formatRef(view,ownTarget)} 공격을 확정해서 이번 밤엔 변경할 수 없어.`;
    else reply=`알겠어. 이전 후보 대신 ${formatRef(view,target)}을 공격 후보로 바꾸자는 뜻이지. ${secretEvidence(p,view,mind,target)} ${p.role==='MAFIA'?'확정 전이라면 그 제안을 반영할게.':'최종 공격 선택은 네가 해.'}`;
  } else if(/(?:왜\s*내\s*말\s*무시|대답\s*해|내\s*말\s*들|말\s*좀\s*들|헛소리|엉뚱|그\s*얘기\s*말고)/.test(t)) {
    reply=`네 말을 무시한 건 아니야. 방금 한 말에 맞춰 답할게. ${refId?`${formatRef(view,refId)} 얘기부터 보자. ${secretEvidence(p,view,mind,refId)}`:'공격 대상이나 조사 정보 중 무엇을 확인할지 말해줘.'}`;
  } else if(/(?:무슨\s*말|뭔\s*뜻|다시\s*설명|아까\s*말|방금\s*말)/.test(t)) {
    const old=view.secretChat.slice(0,view.secretChat.findIndex(x=>x.id===entry.id)).reverse().find(x=>x.senderId===p.id);
    reply=old?`내가 아까 “${normalize(old.text).slice(0,72)}”라고 했어. 그건 내가 가진 정보나 후보를 설명한 것이지, 실제 공격이 확정됐다는 뜻은 아니야.`:'지금 내가 바로 앞에서 한 말을 찾을 수 없어. 어떤 부분인지 다시 말해주면 설명할게.';
  } else if(roleSilenceRequest(t)) {
    reply='알겠어. 공개 채팅에서는 접선한 우리 팀의 직업과 관계를 말하지 않을게.';
  } else if(rolePrompt || /(?:너|넌|네가|니가|너희|우린|우리).{0,20}(?:직업|스파이|마피아|같은\s*팀|한\s*팀)|(?:직업|역할)\s*(?:뭐|뭔데|알려)/.test(t)) {
    if(refId && refId!==partner && refId!==p.id && rolePrompt)
      reply=secretInvestigations(p,view,refId);
    else reply=`난 ${p.role==='SPY'?'스파이':'마피아'}야. 우리는 접선한 같은 팀이야. 비밀 채팅에선 서로 정체를 숨길 필요가 없어.`;
  } else if(p.role==='MAFIA' && refId && /(?:조사|확인|알아봤)/.test(t) &&
      /(?:경찰|의사|건달|시민|마피아|스파이)/.test(t) &&
      !/(?:뭐|누구|어때|알려|말해|맞아|맞니|맞지)/.test(t)) {
    const role=t.match(/(?:경찰|의사|건달|시민|마피아|스파이)/)?.[0];
    reply=`${formatRef(view,refId)}이 ${role}라는 조사 정보를 공유하는 거지. 네가 직접 확인한 결과로 기억할게. 나는 조사할 수 없으니 그 외의 사람 역할은 단정하지 않겠어.`;
  } else if(requestInfo || /(?:누구|누굴).{0,12}(?:조사|확인)/.test(t)) {
    reply=secretInvestigations(p,view,refId && refId!==p.id && refId!==partner?refId:null);
  } else if(attackWord && secretAvoidTarget(t,view) && !/(?:말고|대신)/.test(t)) {
    reply=refId?`${formatRef(view,refId)}을 공격하지 말자는 뜻이지. ${confirmed?'이미 확정한 공격은 바꿀 수 없어.':'확정 전이라면 다른 대상을 고려할게.'}`:'공격을 보류하자는 뜻이지. 지금은 확정된 행동을 임의로 바꾸지 않겠어.';
  } else if(attackWord && target) {
    if(!valid)reply=`${formatRef(view,target)}은 우리 편이거나 나 자신이야. 공격 대상이 될 수 없으니 다른 사람을 골라야 해.`;
    else if(confirmed)reply=`${formatRef(view,target)} 공격 제안은 들었어. 하지만 이미 ${formatRef(view,ownTarget)} 공격을 확정했으니 이번 밤엔 바꿀 수 없어.`;
    else reply=`${formatRef(view,target)}을 공격하자는 제안이구나. ${secretEvidence(p,view,mind,target)} ${p.role==='MAFIA'?'아직 행동을 확정하지 않았다면 이 후보를 고려할게.':'공격 결정은 마피아인 네가 해야 해. 나는 정보를 공유할게.'}`;
  } else if(/(?:누구|누굴|몇\s*번|어디).{0,16}(?:공격|죽|살해|노리)|(?:공격|살해|죽일).{0,18}(?:누구|누굴|할까|할래|어때|생각)/.test(t)) {
    if(p.role==='MAFIA' && confirmed)reply=`나는 이미 ${formatRef(view,ownTarget)} 공격을 확정했어. 이번 밤에는 변경할 수 없어.`;
    else if(p.role==='MAFIA' && ownTarget)reply=`현재 ${formatRef(view,ownTarget)}을 임시 선택했어. 최종 확정 전까지 다른 후보도 논의할 수 있어.`;
    else reply='아직 공격 대상을 확정하지 않았어. 낮에 확인한 발언이나 스파이의 실제 조사 기록을 근거로 후보를 정하자.';
  } else if(/(?:\d+\s*번|그\s*사람|걔).{0,20}(?:경찰|의사|시민|마피아|스파이|수상|믿|의심|어때|맞아|확실|누구)/.test(t) && refId && !/(?:스킵|투표|찍을|퇴출)/.test(t)) {
    if(refId===partner || refId===p.id)reply=`${formatRef(view,refId)}은 접선한 우리 마피아팀이야. 밖에서는 그 사실을 숨겨야 해.`;
    else reply=`${formatRef(view,refId)}에 대해 묻는 거지. ${secretEvidence(p,view,mind,refId)} 아는 사실과 추측을 구분해 판단하자.`;
  } else if(/(?:스킵|투표|찍을|퇴출)/.test(t)) {
    reply=refId?`낮에 ${formatRef(view,refId)}에게 투표하자는 얘기구나. 실제 투표와 밤 공격은 다른 선택이야. 공개된 근거와 우리 팀의 생존을 같이 고려하자.`:'낮 투표는 밤 공격과 별개야. 근거가 부족하면 스킵도 가능하지만, 승패 조건을 고려해 전략을 정하자.';
  } else if(/(?:고마워|ㄱㅅ|감사)/.test(t)) {
    reply='응. 네가 알려준 내용도 기억하고 다음 판단에 참고할게.';
  } else if(/^(?:응|ㅇㅇ|그래|맞아|동의|좋아|오케이|ㅇㅋ|알겠)/.test(t)) {
    reply='좋아. 방금 논의한 후보와 조사 정보를 계속 염두에 둘게. 최종 행동이 확정되면 바꿀 수 없다는 점도 기억하자.';
  } else if(/(?:안녕|하이|ㅎㅇ|반가워)/.test(t) && t.length<20) {
    reply='안녕. 접선했으니 이제 이 채팅에서 공격 대상과 조사 정보를 함께 논의할 수 있어.';
  } else if(/(?:보류|기다려|잠깐|아직\s*하지)/.test(t)) {
    reply=confirmed?'이미 공격 행동을 확정했다면 되돌릴 수는 없어.':'알겠어. 후보를 더 살펴보고 확정 전까지 논의하자.';
  } else if(refId) {
    reply=`${formatRef(view,refId)} 이야기로 이해했어. ${secretEvidence(p,view,mind,refId)} 그 사람에게 관해 확인하고 싶은 게 있으면 더 말해줘.`;
  } else {
    const echo=t.slice(0,55);
    reply=`“${echo}”라고 말한 건 들었어. 이 내용이 공격 대상 제안인지, 조사 결과를 묻는 건지 확실하지 않아. 이해하지 못한 부분은 지어내지 않을게.`;
  }
  mind.secretAnswerIds ||= [];
  mind.secretAnswerIds.push(entry.id);
  if(mind.secretAnswerIds.length>120)mind.secretAnswerIds=mind.secretAnswerIds.slice(-90);
  return normalize(`${formatRef(view,partner)}, ${reply}`).slice(0,218);
}
function decideSpeech(room,p,channel,rng,options={}) {
  const view=legalView(room,p),mind=readStatements(p,view,rng),profile=mind.persona;
  mind.turns++;
  const opener=choice(profile.rhythm,rng);
  if(channel==='SECRET') {
    const partnerEntry=secretRecentPartnerMessage(room,p,view,mind,options.replyToId);
    if(partnerEntry) return answerSecret(room,p,view,mind,partnerEntry);
    if(options.replyToId) return null; // Old/answered message: never produce unrelated filler.
    const fresh=view.investigations.filter(x=>x.actualRole && x.actualRole!=='MAFIA' && view.alivePlayers.some(y=>y.id===x.targetId))
      .find(x=>!mind.spoken.includes('spy:'+x.targetId));
    if(p.role==='SPY' && fresh) {
      mind.spoken.push('spy:'+fresh.targetId);
      return `${formatRef(view,fresh.targetId)}을 조사했고 실제 직업은 ${fresh.displayed}이었어. 이건 내가 직접 알아낸 정보야. 살해 대상을 정할 때 참고해.`;
    }
    // A single unsolicited strategy opener per night. Follow-up turns must
    // respond to the partner instead of repeating the same monologue.
    const idleKey='secret-opener:'+view.night;
    if(mind.spoken.includes(idleKey))return null;
    mind.spoken.push(idleKey);
    const focus=strongestSuspect(p,view,mind,view.alivePlayers.map(x=>x.id));
    return p.role==='MAFIA' ? `오늘 공격 대상은 내가 정할게. ${focus?formatRef(view,focus.id)+'은 공개 채팅에서 언급됐지만':'공개된 정보가 부족하니'} 이유 없이 단정하지 말고 판단하자.` :
      `지금까지 얻은 조사 정보와 낮 채팅을 함께 보자. 최종 공격 대상은 네가 정해.`;
  }
  const asked=pickQuestion(room,p,view,mind,options.replyToId);
  if(asked) return intentOf(asked.text) ? answerQuestion(room,p,view,mind,asked,rng) : replyToStatement(room,p,view,mind,asked,rng);
  const mafiaResult=view.role==='POLICE' && view.investigations.findLast(x=>x.displayed==='마피아팀' && view.alivePlayers.some(y=>y.id===x.targetId));
  if(mafiaResult && !mind.spoken.includes('police:'+mafiaResult.targetId) && reserveTopic(room,view.phaseStart,'police-result:'+p.id+':'+mafiaResult.targetId)) {
    mind.spoken.push('police:'+mafiaResult.targetId);
    return `내가 경찰이고 ${mafiaResult.night}번째 밤에 ${formatRef(view,mafiaResult.targetId)}을 조사했어. 결과는 마피아팀이야. 그 사람이 왜 의심받는지 설명할 수 있는 실제 조사 결과야.`;
  }
  const counter=Object.entries(mind.claims).find(([id,c])=>id!==p.id && c.role==='경찰' && view.role==='POLICE');
  if(counter && !mind.spoken.includes('counter:'+counter[0]) && reserveTopic(room,view.phaseStart,'counterclaim:'+p.id+':'+counter[0])) {
    mind.spoken.push('counter:'+counter[0]);
    return `${formatRef(view,counter[0])}은 경찰이라고 주장했지. 나도 경찰이야. 경찰은 한 명뿐이니까 둘 다 진짜일 수는 없어. 이게 내 의심의 이유야.`;
  }
  const shift=mind.claimChanges.findLast(x=>!mind.spoken.includes('changed:'+x.id) && !discussionLedger(room,view.phaseStart).topics.has('role-change:'+x.id));
  if(shift) {
    reserveTopic(room,view.phaseStart,'role-change:'+shift.id);
    mind.spoken.push('changed:'+shift.id);
    mind.lastOpinion={targetId:shift.speakerId,reason:'role-change'};
    return shift.to==='그 직업 부인'?
      `${formatRef(view,shift.speakerId)}은 앞에선 ${shift.from}이라고 했다가 지금은 그 직업이 아니라고 말했어. 바뀐 이유는 아직 모르니까 확인해 보자.`:
      `${formatRef(view,shift.speakerId)}은 앞에서 ${shift.from}, 뒤에는 ${roleAsQuote(shift.to)} 했어. 직업 주장이 바뀐 건 실제 채팅에 남아 있으니 그 이유를 확인하고 판단하자.`;
  }
  const voteShift=mind.stanceChanges.findLast(x=>!mind.spoken.includes('vote-shift:'+x.id) && !discussionLedger(room,view.phaseStart).topics.has('vote-shift:'+x.id));
  if(voteShift) {
    reserveTopic(room,view.phaseStart,'vote-shift:'+voteShift.id);
    mind.spoken.push('vote-shift:'+voteShift.id);
    const phrase=value=>value==='SKIP'?'건너뛰기':formatRef(view,value)+' 투표';
    return `${formatRef(view,voteShift.speakerId)}은 처음엔 ${phrase(voteShift.from)}, 지금은 ${phrase(voteShift.to)}라고 했어. 생각이 바뀔 순 있지만 이유는 아직 확인되지 않았어.`;
  }
  const lastClaim=Object.entries(mind.claims).find(([id,c])=>!mind.spoken.includes('claim:'+id+':'+c.role) && !discussionLedger(room,view.phaseStart).topics.has('claim:'+id+':'+c.role) && !mind.claimChanges.some(x=>x.speakerId===id) && id!==p.id);
  if(lastClaim) {
    reserveTopic(room,view.phaseStart,'claim:'+lastClaim[0]+':'+lastClaim[1].role);
    mind.spoken.push('claim:'+lastClaim[0]+':'+lastClaim[1].role);
    return `${formatRef(view,lastClaim[0])}이 ${roleAsQuote(lastClaim[1].role)} 주장했어. 말 자체는 확인됐지만 진짜 그 직업인지는 아직 증명되지 않았어. 말과 조사 결과는 구분해야 해.`;
  }
  const list=view.alivePlayers.filter(x=>x.id!==p.id);
  const strong=list.map(x=>({q:x,fact:factFor(p,view,mind,x.id)}))
    .filter(x=>x.fact?.strong).sort((a,b)=>suspicion(mind,view,b.q.id)-suspicion(mind,view,a.q.id));
  const topicForFact=entry=>{
    if(entry.fact.kind==='role-change') {
      const shift=mind.claimChanges.findLast(x=>x.speakerId===entry.q.id);
      return shift?'role-change:'+shift.id:null;
    }
    if(entry.fact.kind==='police-result')return 'police-result:'+p.id+':'+entry.q.id;
    if(entry.fact.kind==='counterclaim')return 'counterclaim:'+p.id+':'+entry.q.id;
    return 'fact:'+entry.q.id+':'+entry.fact.kind;
  };
  if(strong.length) {
    const entry=strong.find(x=>topicForFact(x) && !discussionLedger(room,view.phaseStart).topics.has(topicForFact(x)));
    if(entry) {
      reserveTopic(room,view.phaseStart,topicForFact(entry));
      mind.spoken.push('fact:'+entry.q.id+':'+entry.fact.kind);
      mind.lastOpinion={targetId:entry.q.id,reason:entry.fact.kind};
      return `${opener}, ${entry.fact.text} 이건 막연한 느낌이 아니라 확인 가능한 단서야.`;
    }
  }
  const publicResult=view.publicLog.findLast(x=>/지난밤 .*사망|지난밤 사망자는 없습니다/.test(x.text));
  const topics=[
    `현재 공개된 사실은 ${publicResult?.text || '아직 밤 사망 결과가 없다는 점'}이야. 그 이유가 누구 때문인지는 알려지지 않았어.`,
    `나는 아직 누가 마피아인지 확신할 증거가 없어. 말투만으로 누군가를 퇴출시키는 건 위험해.`,
    `누가 다른 사람을 의심한다는 사실과 실제로 마피아라는 증거는 달라. 두 가지를 구분해서 판단하자.`,
    `자기 직업을 주장하는 건 누구나 할 수 있어. 조사 내용이나 앞서 했던 말과 맞는지 확인해야 해.`,
    `확실한 근거가 없으면 이번 투표를 건너뛰고 다음 밤 정보를 기다리는 것도 합리적이야.`,
    `나는 지금은 판단을 보류할게. 새 단서가 나오기 전까지 같은 의심을 반복하지는 않겠어.`
  ];
  const offset=(p.number + Math.floor(view.night||1)*2 + mind.turns-1)%topics.length;
  const index=Array.from({length:topics.length},(_,i)=>(offset+i)%topics.length)
    .find(i=>reserveTopic(room,view.phaseStart,'topic:'+i,true));
  if(index===undefined)return null;
  mind.spoken.push('topic:'+index);
  if(mind.spoken.length>160)mind.spoken=mind.spoken.slice(-120);
  return `${opener}, ${topics[index]}`;
}

module.exports={ mindFor, legalView, readStatements, decideSpeech, chooseNight, chooseVote, syncRoom, recordDecision, claimedRole, mentions, isQuestion, directAddressee, isReactiveMessage, roleDisclosureRequest, parseDiscourse:DiscourseFrame.parse, parseUtterance:Utterance.classify };
