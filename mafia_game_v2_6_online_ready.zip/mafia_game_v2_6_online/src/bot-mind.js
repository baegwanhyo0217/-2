'use strict';

// Offline-first social-deduction agents. Each bot reads only public statements and
// its own role/investigations/contact information. No remote text API or cheat access.
// Speech is assembled from a context-specific argument, an attitude, evidence,
// and a question or conclusion; it is not a list of full canned chat messages.
const ROLE_WORDS = ['마피아', '스파이', '경찰', '의사', '건달', '시민'];
const PERSONAS = [
  { label:'신중', direct:0.25, talk:3, doubt:0.35, rhythm:['음', '일단', '잠깐'] },
  { label:'직설', direct:0.92, talk:5, doubt:0.62, rhythm:['아니', '잠깐만', '솔직히'] },
  { label:'분석', direct:0.60, talk:4, doubt:0.75, rhythm:['정리하면', '내 생각엔', '일단 사실만 보면'] },
  { label:'감정', direct:0.82, talk:4, doubt:0.48, rhythm:['어?', '잠깐', '이상한데'] },
  { label:'조용', direct:0.18, talk:2, doubt:0.27, rhythm:['음', '나는', '지금은'] },
  { label:'설득', direct:0.60, talk:4, doubt:0.64, rhythm:['내 말 좀 들어봐', '보니까', '일단'] },
];

function choice(xs,rng) { return xs.length ? xs[Math.min(xs.length-1,Math.floor(rng()*xs.length))] : ''; }
function stamp(target) { return target ? `${target.number}번` : ''; }
function clamp(v,lo,hi) { return Math.min(hi,Math.max(lo,v)); }
function normalize(text) { return String(text||'').replace(/\s+/g,' ').trim(); }
function includesSelfClaim(text) {
  return /(?:나는|난|내가|제가|저는|전|나|내 직업|제 직업|저)\s*(?:(?:진짜|사실|원래|확실히)\s*)?(?:경찰|의사|시민|마피아|건달|스파이)/.test(text) ||
    /(?:경찰|의사|시민|마피아|건달|스파이)\s*(?:입니다|이에요|이야|인데|이니까)/.test(text) && !/(?:너|쟤|그 사람|\d번)\s*(?:경찰|의사|시민|마피아|건달|스파이)/.test(text);
}
function claimedRole(text) {
  if (!includesSelfClaim(text)) return null;
  for(const word of ROLE_WORDS) if(text.includes(word)) return word;
  return null;
}
function declaredStance(text,players) {
  const t=normalize(text);
  if(/[?？]/.test(t) || /(?:왜|누구|어떻게)\s*(?:찍|투표|스킵|건너뛰)/.test(t))return null;
  // Only *voluntary, stated* voting intentions are evidence, never inferred hidden votes.
  if(/(?:나는|난|내가|저는|전)\s*(?:이번엔|오늘|일단|지금은)?\s*(?:스킵|건너뛰)/.test(t) ||
    /(?:스킵|건너뛰)(?:하자|할게|할래|하고 싶어)/.test(t))return 'SKIP';
  const refs=mentions(t,players);
  const declares=/(?:찍을게|찍자|투표할게|투표하자|퇴출시키자|뽑을게|표\s*줄게)/.test(t);
  if(declares && refs.length)return refs[0];
  return null;
}
function mentions(text, players) {
  const found=[];
  for(const p of players) {
    const num = new RegExp(`(?:^|[^0-9])${p.number}\\s*(?:번|호|번님)(?![0-9])`);
    if (num.test(text) || (p.name && p.name.length>1 && text.includes(p.name))) found.push(p.id);
  }
  return found;
}
function mindFor(p,rng=Math.random) {
  if (!p.mind) p.mind = {
    persona: choice(PERSONAS,rng), suspicion:Object.create(null), trust:Object.create(null),
    claims:Object.create(null), observations:[], attacks:Object.create(null),
    accusations:[], seenPublic:[], seenSecret:[], spoken:[], turns:0,
    lastOpinion:null, lastRespondedId:null, visitedLast:[], watched:[],
    claimChanges:[], answerIds:[], publicStances:Object.create(null), stanceChanges:[]
  };
  return p.mind;
}
function adjust(mind,id,score) {
  if (!id) return;
  mind.suspicion[id]=clamp((mind.suspicion[id]||0)+score,-7,9);
}
function legalView(room,p) {
  const view=room.botKnowledge(p);
  const everyone=room.players.map(q=>({id:q.id,number:q.number,name:q.name,alive:q.alive}));
  return { ...view, everyone, publicChat:room.publicChat, publicLog:room.publicLog,
    publicVote:room.voteOutcome && ['VOTE_RESULT','GAME_OVER'].includes(room.phase) ? room.voteOutcome : null,
    phaseStart:room.phaseStart,
    secretChat:view.partnerId ? room.secretChat : [] };
}
function findOwnResult(view,id) {return view.investigations.findLast(x=>x.targetId===id) || null;}
function readStatements(p,view,rng) {
  const mind=mindFor(p,rng);
  const roster=view.everyone;
  for(const entry of view.publicChat) {
    if(mind.seenPublic.includes(entry.id)) continue;
    mind.seenPublic.push(entry.id);
    if(entry.senderId===p.id) continue;
    const words=normalize(entry.text);
    const refs=mentions(words,roster);
    const speaker=roster.find(x=>x.id===entry.senderId);
    if(!speaker) continue;
    const claim=claimedRole(words);
    if (claim) {
      const previous=mind.claims[speaker.id];
      if(previous && previous.role!==claim) {
        adjust(mind,speaker.id,2.3);
        mind.claimChanges.push({speakerId:speaker.id,from:previous.role,to:claim,id:entry.id,at:entry.at});
      }
      mind.claims[speaker.id]={role:claim,at:entry.at,text:words};
      // A police bot knows no other player can simultaneously be the police.
      if(view.role==='POLICE' && claim==='경찰') adjust(mind,speaker.id,5);
      // A spy can compare an actual investigated role against a claimant.
      const verified=findOwnResult(view,speaker.id);
      if(view.role==='SPY' && verified?.actualRole && claim && verified.displayed!==claim) adjust(mind,speaker.id,2.4);
      if(view.role==='POLICE' && verified?.displayed==='마피아팀' && claim!=='마피아') adjust(mind,speaker.id,4);
      if(claim==='경찰' && !/(조사|결과|\d번)/.test(words)) adjust(mind,speaker.id,0.4);
    }
    const aggressive=/(의심|수상|마피아|거짓|구라|이상|못 믿|말 바꿔|수상해|의혹|특이)/.test(words);
    const trusting=/(믿어|믿겠|무죄|시민팀|확실히 시민|아닌 것 같)/.test(words);
    if (aggressive && refs.length) {
      for(const id of refs) if(id!==speaker.id) {
        adjust(mind,id,0.25);
        mind.accusations.push({by:speaker.id,target:id,text:words,at:entry.at});
      }
    }
    if(trusting && refs.length) for(const id of refs) if(id!==speaker.id) adjust(mind,id,-0.13);
    if(refs.includes(p.id) && aggressive) {
      adjust(mind,speaker.id,0.65);
      mind.attacks[speaker.id]=(mind.attacks[speaker.id]||0)+1;
    }
    // A false investigation contradicting the agent's *own* information.
    const claimedInvestigation=/(조사|확인|결과)/.test(words);
    if(claimedInvestigation && refs.length && /(마피아팀|마피아라고|마피아야)/.test(words)) {
      const accused=refs.find(id=>id!==speaker.id) || refs[0];
      const own=findOwnResult(view,accused);
      if(view.role==='POLICE' && own?.displayed==='시민팀') adjust(mind,speaker.id,1.8);
      if(view.role==='SPY' && own?.actualRole && own.actualRole!=='MAFIA') adjust(mind,speaker.id,2);
    }
    const statedVote=declaredStance(words,roster);
    if(statedVote!==null) {
      const before=mind.publicStances[speaker.id];
      if(before && before!==statedVote) {
        mind.stanceChanges.push({speakerId:speaker.id,from:before,to:statedVote,at:entry.at,id:entry.id});
        adjust(mind,speaker.id,0.5);
      }
      mind.publicStances[speaker.id]=statedVote;
    }

    mind.observations.push({kind:'message',speakerId:speaker.id,mentions:refs,text:words,at:entry.at,id:entry.id,claim});
  }
  if(mind.seenPublic.length>250) mind.seenPublic=mind.seenPublic.slice(-250);
  if(mind.observations.length>80) mind.observations=mind.observations.slice(-80);
  if(mind.accusations.length>50) mind.accusations=mind.accusations.slice(-50);
  if(mind.claimChanges.length>30) mind.claimChanges=mind.claimChanges.slice(-30);
  if(mind.stanceChanges.length>30)mind.stanceChanges=mind.stanceChanges.slice(-30);
  // Only a contacted Mafia/Spy may inspect the secret messages.
  for(const entry of view.secretChat) {
    if(mind.seenSecret.includes(entry.id)) continue;
    mind.seenSecret.push(entry.id);
    if(entry.senderId===p.id) continue;
    mind.observations.push({kind:'secret',speakerId:entry.senderId,text:entry.text,at:entry.at,id:entry.id});
  }
  if(mind.seenSecret.length>150) mind.seenSecret=mind.seenSecret.slice(-150);
  return mind;
}
function chooseWeighted(items,rng) {
  const total=items.reduce((s,x)=>s+Math.max(0,x.w),0);
  let k=rng()*total;
  for(const entry of items) {k-=Math.max(0,entry.w);if(k<=0)return entry.item;}
  return items[items.length-1]?.item;
}
function candidates(p,view,validIds,excludeIds=[]) {
  const excluded=new Set([...excludeIds,p.id]);
  return view.alivePlayers.filter(q=>validIds.includes(q.id) && !excluded.has(q.id));
}
function suspicion(mind,view,id) {
  const v=mind.suspicion[id]||0;
  const result=view.investigations.findLast(i=>i.targetId===id);
  if(view.role==='POLICE') return v+(result?.displayed==='마피아팀'?12:result?.displayed==='시민팀'?-2.4:0);
  return v;
}
function strongestSuspect(p,view,mind,validIds) {
  const vals=candidates(p,view,validIds,view.partnerId?[view.partnerId]:[]);
  vals.sort((a,b)=>suspicion(mind,view,b.id)-suspicion(mind,view,a.id));
  return vals[0] || null;
}
function chooseNight(room,p,rng) {
  const view=legalView(room,p), mind=readStatements(p,view,rng);
  const opts=room.validTargets(p);
  if(!opts.length) return null;
  const possible=candidates(p,view,opts);
  if(p.role==='DOCTOR') {
    const likelyThreat = strongestSuspect(p,view,mind,opts);
    const publicTarget = view.publicChat.slice(-6).flatMap(x=>mentions(x.text,view.alivePlayers)).find(x=>x!==p.id);
    if(publicTarget && opts.includes(publicTarget) && rng()<0.26) return publicTarget;
    if(rng()<0.50 || !likelyThreat) return p.id;
    return choice(possible,rng)?.id || p.id;
  }
  if(['POLICE','SPY'].includes(p.role)) {
    const seen=new Set(view.investigations.map(x=>x.targetId));
    const fresh=possible.filter(x=>!seen.has(x.id));
    if(p.role==='SPY' && !view.partnerId) {
      // The spy cannot know which uninvestigated player is actually Mafia.
      const scored=fresh.slice().sort((a,b)=>(mind.suspicion[b.id]||0)-(mind.suspicion[a.id]||0));
      return (rng()<0.63 ? scored[0] : choice(fresh,rng))?.id || choice(possible,rng).id;
    }
    const scored=fresh.slice().sort((a,b)=>suspicion(mind,view,b.id)-suspicion(mind,view,a.id));
    return (rng()<0.72 ? scored[0] : choice(fresh,rng))?.id || choice(possible,rng).id;
  }
  if(p.role==='GANGSTER') {
    const suspect=strongestSuspect(p,view,mind,opts);
    if(suspect && suspicion(mind,view,suspect.id)>0.9 && rng()<0.72) return suspect.id;
  }
  if(p.role==='MAFIA') {
    const expectedTrust = possible.slice().sort((a,b)=>(mind.suspicion[a.id]||0)-(mind.suspicion[b.id]||0));
    return (rng()<0.60 ? choice(expectedTrust.slice(0,Math.min(3,expectedTrust.length)),rng) : choice(possible,rng))?.id;
  }
  return choice(possible,rng)?.id;
}
function chooseVote(room,p,rng) {
  const view=legalView(room,p),mind=readStatements(p,view,rng);
  const list=candidates(p,view,view.alivePlayers.map(q=>q.id),view.partnerId?[view.partnerId]:[]);
  if(!list.length) return 'SKIP';
  const winner=list.slice().sort((a,b)=>suspicion(mind,view,b.id)-suspicion(mind,view,a.id))[0];
  const score=suspicion(mind,view,winner.id);
  if(p.role==='POLICE' && score>8) return winner.id;
  if(p.team==='MAFIA') {
    // After contact, avoid voting out the known partner. Before contact, the spy is unknown.
    if(rng()<0.12 && score<0.4)return 'SKIP';
    return (score>0.25 || rng()<0.65) ? winner.id : choice(list,rng).id;
  }
  if(score>=1.4) return rng()<0.89?winner.id:'SKIP';
  if(view.night===1 && rng()<0.45) return 'SKIP';
  if(rng()<0.2) return 'SKIP';
  return rng()<0.63 ? winner.id : choice(list,rng).id;
}
// Public conversation analysis uses witnessed statements, not invented evidence.
// A question is handled as a request for an answer, never as an excuse to ask more questions.
function formatRef(view,id) {
  const q=view.everyone.find(x=>x.id===id);
  return q ? `${q.number}번` : '그 사람';
}
function makeSentence({preface,observation,argument,ask},rng) {
  const parts=[];
  if(preface && rng()<0.73)parts.push(preface);
  if(observation)parts.push(observation);
  if(argument)parts.push(argument);
  if(ask)parts.push(ask);
  return normalize(parts.join(' ')).slice(0,218);
}
function intentOf(text) {
  const t=normalize(text);
  if(!/[?？]|왜|뭐|무엇|누구|어떻게|말해|답해|알려|근거|증거|의견|투표|스킵|건너뛰|조사|직업|의심|믿어|해명|생각해/.test(t))return null;
  if(/누가\s*(?:죽|사망)|(?:지난밤|어젯밤).*?(?:죽|사망)|사망자.*누구/.test(t))return 'death';
  if(/(?:조사.*?(?:누구|몇\s*번|결과|했어|했니|했냐|알려|말해)|(?:누구|몇\s*번).*?조사|조사\s*기록)/.test(t))return 'investigation';
  if(/(?:왜.*?(?:의심|수상|찍|마피아|못\s*믿)|(?:의심|수상).*?이유|근거|증거|해명|왜.*?그렇게|무슨\s*이유)/.test(t))return 'evidence';
  if(/(?:투표|스킵|건너뛰|누구\s*찍|누굴\s*찍|표를\s*줄)/.test(t))return 'vote';
  if(/(?:직업|(?:너|넌|네가|니가|당신).*?(?:경찰|의사|시민|스파이|마피아)|(?:경찰|의사|시민|스파이).*?(?:맞아|이야|인가|냐|니))/.test(t))return 'role';
  if(/(?:누가\s*마피아|누굴\s*의심|누구.*?의심|누구.*?수상|어떻게\s*생각|생각은|믿어|마피아.*?누구|\d+\s*번.*?(?:마피아|시민|의심|수상))/.test(t))return 'opinion';
  if(/[?？]|(?:말해|답해|알려|설명해)/.test(t))return 'general';
  return null;
}
function directAddressee(text,view) {
  const t=normalize(text);
  const match=t.match(/^(\d+)\s*번\s*(?:[,，:：]|님|너|넌|니가|네가|왜\s*(?:나|날|내))/);
  if(match) return view.everyone.find(q=>q.number===Number(match[1]))?.id || null;
  return null;
}
function askedForBot(obs,p,view,chat,forced=false) {
  if(!obs || (obs.senderId||obs.speakerId)===p.id || !intentOf(obs.text)) return false;
  if(forced)return true;
  const addressee=directAddressee(obs.text,view);
  if(addressee)return addressee===p.id;
  if(obs.mentions.includes(p.id) && /(?:너|네가|니가|넌|너는)/.test(obs.text))return true;
  // '너' after a bot's own statement is an implicit direct address.
  const idx=chat.findIndex(x=>x.id===obs.id);
  const prior=idx>0?chat[idx-1]:null;
  if(prior?.senderId===p.id && /(?:너|네가|니가|넌|너는|넌데)/.test(obs.text))return true;
  if(obs.mentions.length && !/다들|모두|여러분|누구든/.test(obs.text))return false;
  return /(?:다들|모두|여러분|누구|의견|어떻게|왜)/.test(obs.text);
}
function pickQuestion(p,view,mind,replyToId) {
  const chat=view.publicChat;
  if(replyToId) {
    const chosen=chat.find(x=>x.id===replyToId);
    if(chosen && !mind.answerIds.includes(chosen.id) && askedForBot({...chosen,mentions:mentions(chosen.text,view.everyone)},p,view,chat,true))return {...chosen,mentions:mentions(chosen.text,view.everyone)};
  }
  // Reply to a fresh question directed at this bot, otherwise respond to one open question.
  const recent=chat.slice(-14).filter(x=>x.at>=view.phaseStart && x.senderId!==p.id && !mind.answerIds.includes(x.id))
    .map(x=>({...x,mentions:mentions(x.text,view.everyone)}));
  return recent.filter(x=>askedForBot(x,p,view,chat)).sort((a,b)=>{
    const da=Number(a.mentions.includes(p.id)),db=Number(b.mentions.includes(p.id));
    return (db-da)*100 + (chat.findIndex(x=>x.id===b.id)-chat.findIndex(x=>x.id===a.id));
  })[0]||null;
}
function factFor(p,view,mind,id,channel='PUBLIC') {
  if(!id)return null;
  const ref=formatRef(view,id);
  const own=findOwnResult(view,id);
  if(view.role==='POLICE' && own) return {strong:own.displayed==='마피아팀',targetId:id,
    text:`${own.night}번째 밤에 ${ref}을 조사했어. 결과는 ${own.displayed}이었어.${own.displayed==='시민팀'?' 다만 스파이도 시민팀으로 표시돼.':''}`,
    kind:'police-result'};
  if(channel==='SECRET' && view.role==='SPY' && own?.actualRole) return {strong:true,targetId:id,
    text:`접선 전에 ${ref}을 조사했고 실제 직업은 ${own.displayed}이었어.`,kind:'spy-result'};
  const shift=mind.claimChanges.findLast(x=>x.speakerId===id);
  if(shift) return {strong:true,targetId:id,
    text:`${ref}은 처음엔 ${shift.from}이라고 했다가 나중엔 ${shift.to}이라고 했어. 직업 주장이 바뀐 건 채팅에서 직접 확인했어.`,kind:'role-change'};
  if(view.role==='POLICE' && id!==p.id && mind.claims[id]?.role==='경찰') return {strong:true,targetId:id,
    text:`${ref}이 경찰이라고 주장했는데 나도 경찰이야. 경찰은 한 명뿐이니 둘 다 진짜일 수는 없어.`,kind:'counterclaim'};
  const changed=mind.stanceChanges.findLast(x=>x.speakerId===id);
  if(changed) {
    const phrase=value=>value==='SKIP'?'투표 건너뛰기':`${formatRef(view,value)} 투표`;
    return {strong:false,targetId:id,text:`${ref}은 아까 ${phrase(changed.from)}를 이야기했다가 ${phrase(changed.to)}로 입장을 바꿨어. 다만 입장이 바뀐 것만으로 마피아라고 단정할 수는 없어.`,kind:'changed-vote-intent'};
  }
  const claim=mind.claims[id];
  if(claim)return {strong:false,targetId:id,
    text:`${ref}은 자신이 ${claim.role}이라고 주장했어. 하지만 직업을 말했다고 실제로 증명된 건 아니야.`,kind:'unverified-claim'};
  // An accusation is evidence that the ACCUSATION was spoken, not proof of the target's team.
  const discussed=mind.accusations.findLast(x=>x.target===id && x.by!==p.id);
  if(discussed)return {strong:false,targetId:id,
    text:`${formatRef(view,discussed.by)}이 ${ref}을 의심한다고 말했어. 그 말만으로 ${ref}이 마피아라는 증거는 아니야.`,kind:'second-hand'};
  return null;
}
function evidenceAnswer(p,view,mind,id,{direct=false}={}) {
  const ref=formatRef(view,id);
  const evidence=factFor(p,view,mind,id);
  if(!evidence)return direct ?
    `${ref}을 의심할 만한 확인된 근거는 아직 없어. 내가 먼저 의심했다면 성급했어. 지금은 단정하지 않겠어.` :
    `${ref}에 대해 확인된 단서가 없어서 마피아라고 말할 수 없어.`;
  if(evidence.strong)return `${direct?'내가 그렇게 판단한 근거는 이거야. ':''}${evidence.text}`;
  return `${evidence.text} 그래서 지금은 의심만으로 몰아가면 안 된다고 봐.`;
}
function topicOf(question,p,view,mind) {
  const named=question.mentions.filter(x=>x!==p.id);
  if(named.length)return named[0];
  if(/(?:나를|날|내가|내\s*말|나는|난)\s*(?:왜|의심|찍)|왜\s*(?:나|날|내)/.test(question.text))return question.senderId||question.speakerId;
  if(mind.lastOpinion?.targetId && view.everyone.some(x=>x.id===mind.lastOpinion.targetId))return mind.lastOpinion.targetId;
  return question.senderId||question.speakerId;
}
function answerQuestion(room,p,view,mind,question,rng) {
  const intent=intentOf(question.text);
  const fromId=question.senderId||question.speakerId;
  const to=formatRef(view,fromId);
  const id=topicOf(question,p,view,mind),ref=formatRef(view,id);
  let response='';
  if(intent==='death') {
    const line=view.publicLog.filter(x=>/지난밤 .*사망|지난밤 사망자는 없습니다/.test(x.text)).at(-1);
    response=line ? `${line.text} 그게 지금 공개된 결과야. 사망 이유나 범인은 공개되지 않았어.` :
      `아직 공개된 사망 발표가 없어. 확인할 수 있는 정보만 가지고 이야기하자.`;
  } else if(intent==='investigation') {
    if(view.role==='POLICE') {
      const results=view.investigations.slice(-3);
      response=results.length ? `경찰 조사 결과는 ${results.map(x=>`${x.night}번째 밤 ${formatRef(view,x.targetId)}: ${x.displayed}`).join(', ')}야. 시민팀으로 나왔더라도 스파이일 가능성은 남아.` :
        `나는 경찰이지만 아직 공개할 조사 결과가 없어. 확인하지 않은 사람의 결과를 지어내지는 않을게.`;
    } else if(view.role==='SPY' || view.role==='MAFIA') {
      response=`조사 결과를 공개할 생각은 없어. 남들이 말하는 조사 주장도 검증 전에는 사실로 받아들이지 말자.`;
    } else {
      response=`나는 경찰 조사 결과를 갖고 있지 않아. 누구를 조사했다고 거짓으로 말할 수는 없어.`;
    }
  } else if(intent==='role') {
    if(/(?:너|넌|네가|니가|당신).*?마피아/.test(question.text)) {
      response=view.team==='MAFIA' ? `나는 마피아가 아니야. 다만 내 말을 믿으라는 주장만으로 판단하지는 마.` :
        `아니, 나는 마피아팀이 아니야. 물론 내 말도 공개된 행동과 대조해서 판단해 줘.`;
    } else if(id && id!==p.id && id!==fromId && !/(?:너|넌|네\s*직업|니\s*직업)/.test(question.text)) {
      const fact=factFor(p,view,mind,id);
      response=fact?fact.text:`${ref}의 실제 직업은 알 수 없어. 직접 확인한 결과 없이 단정하면 안 돼.`;
    } else if(view.role==='POLICE' && view.investigations.length) response=`나는 경찰이야. 내가 직접 확인한 결과는 ${view.investigations.map(x=>`${formatRef(view,x.targetId)} ${x.displayed}`).join(', ')}야.`;
    else if(view.team==='MAFIA')response=`지금 내 직업은 공개하지 않을게. 직업 주장만 듣고 믿기보다는 실제 발언을 비교해 보자.`;
    else response=rng()<0.60 ? `내 직업은 ${view.role==='CITIZEN'?'시민':view.role==='GANGSTER'?'건달':view.role==='DOCTOR'?'의사':'경찰'}이야. 이 말만으로 믿으라는 건 아니야.` :
      `직업은 아직 공개하지 않을게. 확실히 모르는 걸 아는 척하지는 않을 거야.`;
  } else if(intent==='vote') {
    const eligible=view.alivePlayers.filter(x=>x.id!==p.id && x.id!==view.partnerId);
    const top=strongestSuspect(p,view,mind,eligible.map(x=>x.id));
    const fact=top?factFor(p,view,mind,top.id):null;
    if(top && fact?.strong && suspicion(mind,view,top.id)>0.8)response=`현재는 ${formatRef(view,top.id)}에게 투표할 생각이야. ${fact.text}`;
    else response=`지금은 단독으로 퇴출시킬 만큼 확실한 근거가 없어서 건너뛰기를 고려하고 있어. 새 증거가 나오면 판단을 바꿀 거야.`;
  } else if(intent==='evidence' || intent==='opinion') {
    const direct=intent==='evidence';
    if(intent==='opinion' && /(?:누가|누구).*?(?:마피아|의심|수상)|(?:마피아|의심).*?누구/.test(question.text) && !question.mentions.length){
      const eligible=view.alivePlayers.filter(x=>x.id!==p.id && x.id!==view.partnerId);
      const withProof=eligible.map(x=>({x,fact:factFor(p,view,mind,x.id)})).filter(x=>x.fact?.strong);
      response=withProof.length ? `${formatRef(view,withProof[0].x.id)}을 우선 살펴봐야겠어. ${withProof[0].fact.text}` :
        `아직 누가 마피아인지 알 만한 확실한 단서가 없어. 누군가를 찍어서 말하지는 않겠어.`;
    } else response=evidenceAnswer(p,view,mind,id,{direct});
    if(direct && /(?:왜\s*(?:나|날|내)|나를.*의심)/.test(question.text) && id===p.id)response=evidenceAnswer(p,view,mind,fromId,{direct:true});
  } else {
    // Broad questions still receive a conclusion grounded in the visible discussion.
    const latest=mind.claimChanges.at(-1);
    if(latest)response=`지금 가장 확인할 만한 건 ${formatRef(view,latest.speakerId)}의 직업 주장이 바뀌었다는 점이야. 처음엔 ${latest.from}, 나중엔 ${latest.to}라고 했어.`;
    else response=`현재 확실한 정보는 낮에 공개된 발언과 밤 사망 발표뿐이야. 확인되지 않은 직업이나 공격 대상을 사실처럼 말하지 않겠어.`;
  }
  mind.answerIds.push(question.id);
  if(mind.answerIds.length>100)mind.answerIds=mind.answerIds.slice(-100);
  return normalize(`${to}, ${response}`).slice(0,218);
}
function decideSpeech(room,p,channel,rng,options={}) {
  const view=legalView(room,p),mind=readStatements(p,view,rng),profile=mind.persona;
  mind.turns++;
  const opener=choice(profile.rhythm,rng);
  if(channel==='SECRET') {
    const fresh=view.investigations.filter(x=>x.actualRole && x.actualRole!=='MAFIA' && view.alivePlayers.some(y=>y.id===x.targetId))
      .find(x=>!mind.spoken.includes('spy:'+x.targetId));
    if(p.role==='SPY' && fresh) {
      mind.spoken.push('spy:'+fresh.targetId);
      return `${formatRef(view,fresh.targetId)}을 조사했고 실제 직업은 ${fresh.displayed}이었어. 이건 내가 직접 알아낸 정보야. 살해 대상을 정할 때 참고해.`;
    }
    const focus=strongestSuspect(p,view,mind,view.alivePlayers.map(x=>x.id));
    return p.role==='MAFIA' ? `오늘 공격 대상은 내가 정할게. ${focus?formatRef(view,focus.id)+'은 공개 채팅에서 언급됐지만':'공개된 정보가 부족하니'} 이유 없이 단정하지 말고 판단하자.` :
      `지금까지 얻은 조사 정보와 낮 채팅을 함께 보자. 최종 공격 대상은 네가 정해.`;
  }
  const asked=pickQuestion(p,view,mind,options.replyToId);
  if(asked) return answerQuestion(room,p,view,mind,asked,rng);
  const mafiaResult=view.role==='POLICE' && view.investigations.findLast(x=>x.displayed==='마피아팀' && view.alivePlayers.some(y=>y.id===x.targetId));
  if(mafiaResult && !mind.spoken.includes('police:'+mafiaResult.targetId)) {
    mind.spoken.push('police:'+mafiaResult.targetId);
    return `내가 경찰이고 ${mafiaResult.night}번째 밤에 ${formatRef(view,mafiaResult.targetId)}을 조사했어. 결과는 마피아팀이야. 그 사람이 왜 의심받는지 설명할 수 있는 실제 조사 결과야.`;
  }
  const counter=Object.entries(mind.claims).find(([id,c])=>id!==p.id && c.role==='경찰' && view.role==='POLICE');
  if(counter && !mind.spoken.includes('counter:'+counter[0])) {
    mind.spoken.push('counter:'+counter[0]);
    return `${formatRef(view,counter[0])}은 경찰이라고 주장했지. 나도 경찰이야. 경찰은 한 명뿐이니까 둘 다 진짜일 수는 없어. 이게 내 의심의 이유야.`;
  }
  const shift=mind.claimChanges.findLast(x=>!mind.spoken.includes('changed:'+x.id));
  if(shift) {
    mind.spoken.push('changed:'+shift.id);
    mind.lastOpinion={targetId:shift.speakerId,reason:'role-change'};
    return `${formatRef(view,shift.speakerId)}은 앞에서 ${shift.from}, 뒤에는 ${shift.to}이라고 했어. 직업 주장이 바뀐 건 실제 채팅에 남아 있으니 그 이유를 확인하고 판단하자.`;
  }
  const voteShift=mind.stanceChanges.findLast(x=>!mind.spoken.includes('vote-shift:'+x.id));
  if(voteShift) {
    mind.spoken.push('vote-shift:'+voteShift.id);
    const phrase=value=>value==='SKIP'?'건너뛰기':formatRef(view,value)+' 투표';
    return `${formatRef(view,voteShift.speakerId)}은 처음엔 ${phrase(voteShift.from)}, 지금은 ${phrase(voteShift.to)}라고 했어. 생각이 바뀔 순 있지만 이유는 아직 확인되지 않았어.`;
  }
  const lastClaim=Object.entries(mind.claims).find(([id,c])=>!mind.spoken.includes('claim:'+id+':'+c.role) && id!==p.id);
  if(lastClaim) {
    mind.spoken.push('claim:'+lastClaim[0]+':'+lastClaim[1].role);
    return `${formatRef(view,lastClaim[0])}이 ${lastClaim[1].role}이라고 주장했어. 말 자체는 확인됐지만 진짜 그 직업인지는 아직 증명되지 않았어. 말과 조사 결과는 구분해야 해.`;
  }
  const list=view.alivePlayers.filter(x=>x.id!==p.id);
  const strong=list.map(x=>({q:x,fact:factFor(p,view,mind,x.id)}))
    .filter(x=>x.fact?.strong).sort((a,b)=>suspicion(mind,view,b.q.id)-suspicion(mind,view,a.q.id));
  if(strong.length) {
    const entry=strong.find(x=>!mind.spoken.includes('fact:'+x.q.id+':'+x.fact.kind));
    if(entry) {
      mind.spoken.push('fact:'+entry.q.id+':'+entry.fact.kind);
      mind.lastOpinion={targetId:entry.q.id,reason:entry.fact.kind};
      return `${opener}, ${entry.fact.text} 이건 막연한 느낌이 아니라 확인 가능한 단서야.`;
    }
  }
  const publicResult=view.publicLog.findLast(x=>/지난밤 .*사망|지난밤 사망자는 없습니다/.test(x.text));
  const topics=[
    `현재 공개된 사실은 ${publicResult?.text || '아직 밤 사망 결과가 없다는 점'}이야. 그 이유가 누구 때문인지는 알려지지 않았어.`,
    `나는 아직 누가 마피아인지 확신할 증거가 없어. 말투만으로 누군가를 퇴출시키는 건 위험해.`,
    `누가 다른 사람을 의심한다는 사실과 실제로 마피아라는 증거는 달라. 두 가지를 구분해서 판단하자.`,
    `자기 직업을 주장하는 건 누구나 할 수 있어. 조사 내용이나 앞서 했던 말과 맞는지 확인해야 해.`,
    `확실한 근거가 없으면 이번 투표를 건너뛰고 다음 밤 정보를 기다리는 것도 합리적이야.`,
    `나는 지금은 판단을 보류할게. 새 단서가 나오기 전까지 같은 의심을 반복하지는 않겠어.`
  ];
  const offset=(p.number + Math.floor(view.night||1)*2 + mind.turns-1)%topics.length;
  const index=Array.from({length:topics.length},(_,i)=>(offset+i)%topics.length)
    .find(i=>!mind.spoken.includes('topic:'+i)) ?? offset;
  mind.spoken.push('topic:'+index);
  if(mind.spoken.length>160)mind.spoken=mind.spoken.slice(-120);
  return `${opener}, ${topics[index]}`;
}

module.exports={ mindFor, legalView, readStatements, decideSpeech, chooseNight, chooseVote, claimedRole, mentions };
