'use strict';

// All provider calls happen on the Node server. API keys are never included
// in the browser bundle or returned by the public API.
function configuration(env=process.env) {
  const requested=String(env.NOIR_AI_MODE||'rules').toLowerCase();
  if (!['rules','cloud','local','auto'].includes(requested))
    throw new Error('NOIR_AI_MODE must be rules, cloud, local or auto');
  let mode=requested;
  if (mode==='auto') mode=env.OPENAI_API_KEY ? 'cloud' : env.OLLAMA_URL ? 'local' : 'rules';
  if (mode==='cloud' && !env.OPENAI_API_KEY) mode='rules';
  if (mode==='local' && !env.OLLAMA_URL) mode='rules';
  return {
    mode,
    model:mode==='cloud' ? env.OPENAI_MODEL||'gpt-4o-mini' :
      mode==='local' ? env.OLLAMA_MODEL||'qwen2.5:3b' : '',
    key:mode==='cloud' ? env.OPENAI_API_KEY : null,
    cloudUrl:env.OPENAI_BASE_URL||'https://api.openai.com/v1',
    localUrl:env.OLLAMA_URL||'',
    timeoutMs:Math.max(1200,Math.min(15000,Number(env.NOIR_AI_TIMEOUT_MS)||6500)),
    maxParallel:Math.max(1,Math.min(4,Number(env.NOIR_AI_MAX_PARALLEL)||2)),
    maxRequests:Math.max(1,Math.min(300,Number(env.NOIR_AI_MAX_REQUESTS)||90))
  };
}

function parseJSONContent(raw) {
  const text=typeof raw==='string' ? raw : '';
  if(!text || text.length>20000) throw new Error('Invalid model output size');
  let result;
  try {result=JSON.parse(text);} catch {
    const matched=text.match(/\{[\s\S]*\}/);
    if (!matched) throw new Error('Model did not return JSON');
    result=JSON.parse(matched[0]);
  }
  if (!result || typeof result!=='object' || Array.isArray(result)) throw new Error('Invalid model JSON');
  return result;
}

class ModelProvider {
  constructor(config=configuration(),fetchFn=globalThis.fetch) {
    this.config=config;this.fetch=fetchFn;
  }
  async generate(messages,timeoutMs) {
    const {mode,model,key,cloudUrl,localUrl}=this.config;
    if (mode==='rules') throw new Error('Provider is not configured');
    const budget=Math.max(1000,Math.min(this.config.timeoutMs,timeoutMs||this.config.timeoutMs));
    let url,headers,body;
    if (mode==='cloud') {
      const u=new URL(cloudUrl.replace(/\/$/,'')+'/chat/completions');
      if (u.protocol!=='https:' && !['localhost','127.0.0.1'].includes(u.hostname))
        throw new Error('Cloud model endpoint must use HTTPS');
      url=u.href;
      headers={'Content-Type':'application/json','Authorization':`Bearer ${key}`};
      body={model,messages,temperature:0.65,max_tokens:450,response_format:{type:'json_object'}};
    } else {
      const u=new URL(localUrl.replace(/\/$/,'')+'/api/chat');
      if (!['http:','https:'].includes(u.protocol)) throw new Error('Invalid local model URL');
      url=u.href;
      headers={'Content-Type':'application/json'};
      body={model,messages,stream:false,format:'json',options:{temperature:0.65,num_predict:450}};
    }
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),budget);
    try {
      const response=await this.fetch(url,{method:'POST',headers,
        body:JSON.stringify(body),signal:controller.signal});
      if(!response.ok) throw new Error(`Model HTTP ${response.status}`);
      const raw=await response.text();
      if(raw.length>100000) throw new Error('Model response too large');
      const envelope=JSON.parse(raw);
      const content=mode==='cloud' ? envelope.choices?.[0]?.message?.content : envelope.message?.content;
      return parseJSONContent(content);
    } finally {clearTimeout(timer);}
  }
}
module.exports = {configuration,parseJSONContent,ModelProvider};
