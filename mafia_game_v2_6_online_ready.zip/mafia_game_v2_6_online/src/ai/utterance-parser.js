'use strict';
// Deterministic, offline Korean utterance understanding. The JSON bank is a
// set of INTENT EXAMPLES, not an answer lookup table. Grammar guards and
// context/polarity features decide whether a candidate is legal, then
// character similarity handles unseen synonyms/word order. Unknown input is
// returned as null rather than forcing a wrong label.
const {intents:INTENTS}=require('./utterance-corpus.json');
const {parse:discourse}=require('../discourse-frame');
const rx={
 ROLE:/(?:직업|역할|정체|신분|포지션|무슨\s*팀|누구\s*편)/,
 REVEAL:/(?:공개|밝히|말해|말하|얘기|이야기|설명|소개|공유|알려|까봐|까\s*줘|뭐야|뭔데|뭔\s*직업|무엇|무슨|어떤|궁금|알고\s*싶|누구\s*편|어느\s*팀)/,
 ROLE_NO:/(?:(?:얘기|이야기).{0,8}(?:멈추|그만|중단)|말하지\s*않|말하지\s*마|말하지\s*말|공개하지\s*마|밝히지\s*마|밝힐\s*필요\s*없|숨기|비밀|금지|이야기\s*그만|얘기\s*그만|공개하면\s*안)/,
 REQUEST:/(?:말해|설명|알려|답해|제시|보여|말하라|하라고|말해봐|말해줘|줄래|뭐야|누구|누가|누굴|뭔데|왜|어떻게|있니|있어|맞아|해봐|해줘|어떤|무슨|몇\s*번|몇\s*명|궁금|할까|할래|거야|할거|되니|되나|나요|하자|밝혀|찾아)/,
 POLICE:/(?:경찰|형사)/,
 INVESTIGATION:/(?:조사|수사|검사|탐문|확인해\s*봤|알아\s*봤)/,
 EVIDENCE:/(?:증거|근거|단서|정황|물증|입증|뒷받침|자료|확증|기록|그렇게\s*생각|그렇게\s*판단|이유)/,
 EVIDENCE_WEAK:/(?:없|부족|빈약|약해|모자|못\s*찾|불충분|뚜렷하지\s*않|확인하지\s*못|찾지\s*못|없잖|못\s*봤)/,
 CONFIDENT:/(?:있어|있다|충분|발견|나왔|확보|봤어|확인했|명백)/,
 UNCERTAIN:/(?:모르|헷갈|확신\s*안|확신\s*없|애매|불확실|난감|갈팡질팡|결론이\s*안|못\s*정하|판단이\s*안|확답\s*못)/,
 DEFER:/(?:(?:단정|판단|결론|투표|결정).{0,16}(?:이르|성급|아직\s*아니)|유보|보류|관망|지켜\s*보|두고\s*보|기다리|미루|서두르지|나중에|새\s*정보|추가\s*정보|성급|서두를|관찰한\s*다음)/,
 SKIP:/(?:스킵|패스|기권|건너\s*뛰|생략|아무도\s*찍지|한\s*명도\s*지목하지|빈\s*표|표\s*안\s*내|투표하지\s*않|퇴출시키지\s*말|표결\s*생략)/,
 SKIP_NO:/(?:스킵|패스|기권).{0,25}(?:못\s*받아들|안\s*받아들|거절)|(?:스킵|패스|기권|건너\s*뛰|생략).{0,20}(?:안\s*해|안\s*할|하지\s*않|하지\s*마|하지\s*말|생각이\s*없|반대|싫|하면\s*안|할\s*생각\s*없)|(?:스킵|기권|패스)\s*(?:안|못)/,
 NIGHT:/(?:밤|야간|나이트)/,
 VOTE:/(?:투표|표결|표\s*(?:던지|주|줄|줘|넣|행사|몰)|표를\s*몰아\s*주|지목|퇴출|처형|찍|뽑|표를|표는)/,
 DOUBT:/(?:의심|수상|마피아|범인|거짓말|구라|믿기\s*어렵|숨기|이상|찜찜)/,
 NEGATE_DOUBT:/(?:아니|아냐|아닌|아닐|의심하지\s*마|의심하지\s*않|의심할\s*필요\s*없|의심\s*안|못\s*믿|안\s*수상|수상하지\s*않|믿어|결백|무죄|몰아가지\s*마)/,
 COMPARE:/(?:\d+\s*번.{0,18}\d+\s*번.{0,10}(?:중|더)|비교|둘\s*중|누가\s*더|어느\s*쪽|대\s*\d+\s*번|차이|서로\s*같은\s*팀|서로\s*다른\s*팀|나란히)/,
 CHANGE:/(?:앞(?:에서)?\s*한\s*말.{0,20}(?:지금|현재).{0,20}(?:말|안\s*맞)|말(?:이랑|과).{0,16}안\s*맞|말\s*바꿨|말이\s*바뀌|말이\s*바뀐|앞뒤|모순|서로\s*다르|주장이\s*다르|거짓말|전에\s*했다|아까랑\s*지금|변경)/,
 HISTORY:/(?:아까|방금|전에|이전|직전|저번|앞에|지난\s*대화|기억|뭐라\s*했|뭐라고\s*했|발언\s*내용|누가\s*말|했던\s*말|지난\s*말)/,
 CLARIFY:/(?:쉽게\s*(?:설명|말)|풀어\s*(?:줘|주|설명)|이해할\s*수\s*있게|무슨\s*뜻|무슨\s*말|무슨\s*소리|뭔\s*뜻|뭔\s*소리|다시\s*설명|풀어\s*(?:설명|얘기)|풀어서\s*말|구체적|헷갈|이해를\s*못|의미)/,
 REPEAT:/(?:다시\s*답|답변해|대답해|질문에\s*답|물어본\s*거|안\s*답|말\s*돌리|내\s*말\s*무시|아까\s*질문|직전\s*질문|같은\s*질문)/,
 AGREE:/(?:동의|동감|찬성|같은\s*생각|공감|맞는\s*소리|그\s*말\s*맞|나도\s*그렇게\s*생각|받아들일게)/,
 DISAGREE:/(?:(?:못|안)\s*받아들|받아들이지\s*(?:못|않)|받아들일\s*수\s*없|반대|동의\s*못|동의하지\s*않|생각이\s*다르|의견이\s*달|틀렸|아니라고\s*생각|납득\s*못|인정\s*(?:못|안|하기\s*어렵)|받아들이기\s*어렵)/,
 CORRECTION:/(?:내(?:가\s*한)?\s*말.{0,20}(?:다르게|잘못).{0,16}(?:받아들|이해)|정정|다시\s*말|내\s*말은|내가\s*잘못\s*말|그게\s*아니|오해|말\s*취소|아니\s*내가)/,
 SOCIAL_FIGHT:/(?:싸우|다투|몰아가|비난|욕하지|논쟁\s*그만|시끄러)/,
 LIVE:/(?:살아|생존|남아\s*있|탈락하지\s*않|남은\s*(?:사람|인원|참가자)|생존자)/,
 COUNT:/(?:몇\s*명|몇\s*대\s*몇|숫자|명단|누구|인원|사람|참가자)/,
 PHASE:/(?:해야\s*하는\s*순서|진행\s*순서|현재\s*순서|단계|턴|차례|몇\s*번째|게임\s*진행|지금\s*낮|지금\s*밤|언제\s*투표|토론\s*중)/,
 RULE:/(?:규칙|능력|승리\s*조건|방법|어떻게\s*하|접선|재투표|자기\s*자신\s*치료|뭐\s*하|하는\s*일)/,
 DEAD:/(?:사망|죽었|죽은|제거|탈락|킬\s*당|밤\s*결과)/,
 GREET:/(?:안녕|하이|ㅎㅇ|반가|반갑|좋은\s*게임|잘해\s*보자)/,
 THANK:/(?:고마|고맙|감사|땡큐|ㄱㅅ|수고)/
};
const order=INTENTS.map(x=>x.id);
const byId=new Map(INTENTS.map(x=>[x.id,x]));
const mapSynonym=[
  [/(?:정체|신분|포지션|역할)/g,'직업'],
  [/(?:물증|확증|입증|뒷받침|자료|정황|단서|증거)/g,'근거'],
  [/(?:패스|기권|건너\s*뛰|생략)/g,'스킵'],
  [/(?:형사)/g,'경찰'],
  [/(?:수사|탐문|검사)/g,'조사'],
  [/(?:뭐라고\s*했|뭐라\s*했|무슨\s*말\s*했)/g,'발언'],
  [/(?:알려줘|말해줘|밝혀줘|공개해줘|말해봐|얘기해봐|설명해봐)/g,'공개해'],
  [/(?:범인|늑대)/g,'마피아'],
  [/(?:어제\s*밤|어젯밤|지난\s*밤)/g,'밤']
];
function canonical(s) {
  let t=String(s||'').normalize('NFC').toLowerCase().replace(/[\u200b-\u200d\ufeff]/g,'').replace(/[.,!?;:()[\]{}“”‘’~…]+/g,' ').replace(/\s+/g,' ').trim();
  for(const [re,v] of mapSynonym)t=t.replace(re,v);
  return t.replace(/\d+\s*(?:번|호)(?:님)?/g,'선수').replace(/\s+/g,'').trim();
}
function grams(s) {
  const g=new Set();
  for(let i=0;i<s.length-1;i++)g.add(s.slice(i,i+2));
  for(let i=0;i<s.length-2;i++)g.add(s.slice(i,i+3));
  return g;
}
const prepared=INTENTS.map(g=>({...g,ex:g.examples.map(s=>({s:canonical(s),g:grams(canonical(s))}))}));
const canonicalExamples=new Map();
for(const item of prepared)for(const ex of item.ex)canonicalExamples.set(ex.s,item.id);
function dice(a,b){let common=0;for(const x of a)if(b.has(x))common++;return 2*common/(a.size+b.size||1);}
function isQuestionForm(t){return /[?？]/.test(t)||/(?:무엇|누구|누가|누굴|왜|어떻게|무슨|뭐야|뭔데|어때|할래|할까|있어|있냐|알려|설명|밝혀|공개|말해|대답|몇\s*번|몇\s*명|어느|해줘|줄래|해봐|하라|하자|해라|해주|해주면|뭐지|뭐임|됨|돼\s*\?|가능|어딨)/.test(t);}
function isReport(t) {
  if(/(?:뭐라고|뭐라|무슨 말을)/.test(t))return false;
  return /^(?:\d+\s*(?:번|호)|그\s*사람|걔|쟤).{0,28}(?:하라고\s*했|하랬|하자고\s*했|해달랬|한다고\s*했|하던데|했다던데|했다고\s*했|라고\s*했)/.test(t);
}
function valid(id,t,frame,question,channel='PUBLIC'){
  const f=rx;
  if(id.startsWith('SECRET_') && channel!=='SECRET')return false;
  switch(id){
    case 'SECRET_ATTACK':return /(?:공격|습격|죽일|죽이|죽여|살해|처리|제거|노리|노려|잡자|타겟|목표|\d+\s*번.{0,12}(?:가자|보내자))/.test(t) && !/(?:하지\s*말|안\s*하|취소|제외|빼자|건드리지|놔두|살려두)/.test(t) && !/(?:말고|대신)/.test(t) && !question;
    case 'SECRET_AVOID':return /(?:공격|습격|죽일|죽이|죽여|살해|처리|제거|노리|건드리|살려두|제외|빼자|놔두)/.test(t)&&/(?:하지\s*말|안\s*하|취소|제외|빼자|건드리지|놔두|살려두|반대)/.test(t)&&!/(?:말고|대신)/.test(t);
    case 'SECRET_SWITCH':return /\d+\s*번/.test(t) && /(말고|대신|바꿔|변경|아니고|제외하고|관두고)/.test(t);
    case 'SECRET_INFO':return /(조사|정보|수사|신원|실제\s*직업|알아낸|확인한|내역|역할)/.test(t) && question;
    case 'SECRET_PLAN':return /(공격|살해|죽일|죽이|노리|목표|타겟|전략|계획)/.test(t) && question;
    case 'ROLE_SILENCE':return f.ROLE.test(t)&&f.ROLE_NO.test(t);
    case 'ROLE_REQUEST':return (f.ROLE.test(t)||/(?:경찰|의사|마피아|시민|건달|스파이).{0,12}(?:맞아|맞니|냐)/.test(t)) && !f.ROLE_NO.test(t) && question && !isReport(t);
    case 'WHO_POLICE':return f.POLICE.test(t)&&/(?:누구|누가|몇\s*번|자처|밝힌\s*사람|주장한\s*사람|나온\s*사람)/.test(t) && !isReport(t);
    case 'INVESTIGATION_QUERY':return f.INVESTIGATION.test(t) && question && !isReport(t);
    case 'EVIDENCE_QUERY':return f.EVIDENCE.test(t) && question && !/^(?:난|나는|내가).{0,20}(?:없|부족)/.test(t);
    case 'EVIDENCE_LACK':return frame.act==='LOW_EVIDENCE'||(f.EVIDENCE.test(t)&&f.EVIDENCE_WEAK.test(t)&&!question && !/없는\s*건\s*아니|없다는\s*뜻이\s*아니/.test(t));
    case 'EVIDENCE_HAS':return frame.act==='EVIDENCE_CLAIM'||(f.EVIDENCE.test(t)&&f.CONFIDENT.test(t)&&!f.EVIDENCE_WEAK.test(t)&&!question);
    case 'UNCERTAIN':return frame.act==='UNCERTAIN'||(f.UNCERTAIN.test(t)&&!question);
    case 'DEFER':return frame.act==='DEFER'||(f.DEFER.test(t)&&!question && !f.SKIP.test(t));
    case 'VOTE_SKIP':return frame.act==='VOTE_SKIP' && !frame.question || (f.SKIP.test(t)&&!f.SKIP_NO.test(t)&&!f.NIGHT.test(t)&&!question);
    case 'VOTE_SKIP_DENY':return frame.act==='REJECT_SKIP'||f.SKIP_NO.test(t);
    case 'NIGHT_SKIP':return frame.act==='NIGHT_SKIP'||(f.NIGHT.test(t)&&f.SKIP.test(t) && !f.SKIP_NO.test(t));
    case 'VOTE_QUERY':return f.VOTE.test(t)&&question&&!f.NIGHT.test(t)&&!f.SKIP_NO.test(t);
    case 'VOTE_PROPOSE':return f.VOTE.test(t)&&!question && !f.SKIP.test(t);
    case 'SUSPICION_QUERY':return f.DOUBT.test(t) && question && !f.EVIDENCE.test(t) && !f.COMPARE.test(t) && !isReport(t);
    case 'ACCUSE':return f.DOUBT.test(t)&&!question&&!f.NEGATE_DOUBT.test(t)&&!f.CHANGE.test(t);
    case 'DEFEND':return (f.NEGATE_DOUBT.test(t)||/(?:믿어|결백|무죄|시민팀)/.test(t))&&!question&&!f.CHANGE.test(t);
    case 'COMPARE':return f.COMPARE.test(t) && question;
    case 'CONTRADICTION':return f.CHANGE.test(t) && (f.HISTORY.test(t)||/(?:모순|말\s*바꿨|앞뒤|서로\s*다르)/.test(t)) && !isReport(t);
    case 'CHAT_HISTORY':return f.HISTORY.test(t) && (/(?:말|발언|기억|주장|대화|뭐라|뭐라고)/.test(t)) && question && !isReport(t);
    case 'CLARIFY':return f.CLARIFY.test(t) && question;
    case 'REPEAT_REQUEST':return f.REPEAT.test(t) && !isReport(t);
    case 'AGREE':return f.AGREE.test(t)&&!f.DISAGREE.test(t)&&!question;
    case 'DISAGREE':return f.DISAGREE.test(t)&&!question;
    case 'CORRECTION':return f.CORRECTION.test(t)&&!question;
    case 'DEESCALATE':return f.SOCIAL_FIGHT.test(t)&&!question;
    case 'LIVING_COUNT':return f.LIVE.test(t)&&f.COUNT.test(t)&&question;
    case 'PHASE_QUERY':return f.PHASE.test(t)&&question && !f.NIGHT.test(t) || f.PHASE.test(t)&&f.NIGHT.test(t)&&question && !f.SKIP.test(t);
    case 'RULE_QUERY':return f.RULE.test(t)&&question && !(f.ROLE.test(t) && !/(?:능력|규칙|하는\s*일|승리\s*조건|방법)/.test(t)) && !isReport(t);
    case 'DEATH_QUERY':return f.DEAD.test(t)&&question&&!f.VOTE.test(t);
    case 'GREETING':return f.GREET.test(t)&&t.length<=25;
    case 'THANKS':return f.THANK.test(t)&&t.length<=28;
    default:return false;
  }
}
function featureClassify(t,frame,channel='PUBLIC') {
  // Slot/act inference composes lexical concepts, grammatical polarity,
  // speaker attribution and question/imperative forms. This works on new
  // phrasings which never appeared in the example bank.
  const x=t.replace(/\s+/g,' ').trim();
  const ask=/(?:[?？]|(?:추천해|골라\s*줘|들려\s*줘|왜|누구|누가|누굴|무슨|뭐|뭔(?!가)|어떤|어떻게|어느|몇\s*명|몇\s*번|어딨|어딘|있냐|있니|있어\?|할까|할래|할거|보니|봤어|이야|인가|니|냐|지\?|가요|나요|할\s*수|될까|될지|그런지|궁금|알고\s*싶|알려|말해|설명|보여|보여줘|정리해|답해|찾아|공유해|공개해|밝혀|소개해|풀어줘|해봐|해줘|해주라|말\s*좀|좀\s*말|좀\s*설명|말하라|밝히라|설명하라|설명\s*좀|누구인지|어디로|왜\s*안|내용\s*돌려))/.test(x);
  const imperative=/(?:하자|말자|말해|밝혀|공개해|설명해|보여|알려|얘기해|찍자|보자|말라|그만|해라|해봐|해줘|해주|할래|하지\s*마|하지\s*말|바꾸자|대답해|답해)/.test(x);
  const aboutRoles=rx.ROLE.test(x)||/(?:시민|경찰|의사|마피아|건달|스파이).{0,10}(?:맞아|맞니|맞냐)/.test(x);
  const askRole=aboutRoles && !rx.ROLE_NO.test(x) &&
    (ask || imperative || /(?:포지션|직업|정체|역할).{0,14}(?:말|알|궁금|공개|밝|까|설명|소개|공유|뭔|무슨|어떤)/.test(x));
  const aboutGameRules=/(?:규칙|능력|승리\s*조건|재투표|동률|접선|자기\s*자신\s*치료|스킵과\s*기권|스킵이랑\s*기권)/.test(x)||
    /(?:경찰|의사|건달|마피아|스파이)(?:은|는|이|가|의)?\s*(?:밤마다|밤에|할\s*수|뭐\s*하|하는\s*일|역할\s*설명|어떻게\s*하|남도\s*살)/.test(x);
  const skip=rx.SKIP.test(x)||/(?:표\s*(?:행사|던지|주|넣).{0,13}(?:안\s*할|않을|못\s*하|싫)|아무(?:한테|에게)도\s*표\s*(?:안|못|없))/.test(x);
  const skipNo=rx.SKIP_NO.test(x)||
    /(?:스킵|패스|기권|건너\s*뛰|생략).{0,17}(?:마음\s*없|전혀\s*없|절대\s*반대|난\s*반대|안\s*돼|싫어|안\s*함|못\s*하|않을|하면\s*안|하지\s*마|하지\s*말)/.test(x)||
    /(?:반대|안\s*해|안\s*할|절대\s*싫).{0,14}(?:스킵|패스|기권)/.test(x)||
    /(?:표를?\s*(?:꼭|반드시)\s*(?:던지|주|행사)|기권할\s*마음\s*(?:전혀\s*)?없)/.test(x);
  const night=rx.NIGHT.test(x);
  const nightSkip=night && /(스킵|패스|생략|건너|넘어가|넘기|지나치|안\s*하|없이\s*끝내)/.test(x);
  const publicVote=rx.VOTE.test(x) || /(?:표\s*행사|표\s*주|표\s*넣|표\s*몰|퇴출|처형)/.test(x);
  const aboutSuspicion=rx.DOUBT.test(x)||/(?:누굴\s*믿|누굴\s*의심|범인|거짓말|누가\s*수상)/.test(x);
  const doubtNeg=rx.NEGATE_DOUBT.test(x)||/(?:무죄|결백|믿을\s*만|믿어주|범인\s*아닐|마피아\s*아닐)/.test(x);
  const evidenceQuestion=rx.EVIDENCE.test(x)&&ask ||
    /(?:왜|뭘\s*보고|무엇을\s*보고|어떤\s*이유).{0,30}(?:의심|수상|찍|생각|판단|마피아|범인|보는|보고)/.test(x);
  if(isReport(x))return null;
  if(frame.act==='LOW_EVIDENCE' && !/[?？]/.test(x))return 'EVIDENCE_LACK';
  if(channel==='SECRET'){
    const ids=[...x.matchAll(/(\d+)\s*번/g)];
    if(ids.length>=2 && /(?:말고|대신|아니고|바꾸|변경|옮기|전환)/.test(x))return 'SECRET_SWITCH';
    if(ids.length && /(?:공격|습격|죽이|죽일|노리|건드리|살려|제외|빼자)/.test(x) &&
      /(?:하지\s*마|하지\s*말|하지\s*않|안\s*해|취소|건드리지|살려두|제외|빼자|반대)/.test(x))return 'SECRET_AVOID';
    if(/(?:조사|신원|정보|알아낸|실제\s*직업|직업\s*정보)/.test(x) && ask && !/너\s*직업|네\s*직업/.test(x))return 'SECRET_INFO';
    if(/(?:공격|습격|살해|목표|타겟|전략|계획|누굴\s*먼저)/.test(x) && ask && !ids.length && !/(?:조사|결과|확인|의사|경찰|건달|시민팀|마피아팀)/.test(x))return 'SECRET_PLAN';
    if(ids.length && /(?:공격|습격|죽이|죽일|처리|제거|노리|노려|잡자|타겟|목표|먼저\s*보내)/.test(x)&&!ask)return 'SECRET_ATTACK';
  }
  // Denials and phase distinctions are higher-priority than topic similarity.
  if(aboutRoles && rx.ROLE_NO.test(x) && !/(?:공개하지\s*마\?|말하지\s*마\?)/.test(x))return 'ROLE_SILENCE';
  if(/(?:너|넌|네가|니가|당신).{0,12}(?:마피아|시민|경찰|의사|스파이|건달)(?:야|이야|냐|니|맞아|같아)[?？]?\s*$/.test(x))return 'ROLE_REQUEST';
  if(/(?:(?:너|넌|네가|니가|너는).{0,15}(?:거짓말|구라).{0,8}(?:했|하|맞|니|냐)|왜.{0,25}(?:거짓말|구라|속였))/.test(x)&&ask)return 'EVIDENCE_QUERY';

  if(skipNo || frame.act==='REJECT_SKIP') return 'VOTE_SKIP_DENY';
  if(/(?:아무(?:한테|에게)도.{0,18}(?:표|투표).{0,16}(?:안|않|못)|(?:이번|오늘|난|나는).{0,18}(?:표|투표).{0,14}(?:안\s*할래|안\s*할게|않을래|안\s*하겠))/.test(x))return 'VOTE_SKIP';
  if(nightSkip)return 'NIGHT_SKIP';
  if(aboutGameRules && (ask||imperative||/(?:역할\s*설명|스킵이랑\s*기권)/.test(x)))return 'RULE_QUERY';
  if(rx.POLICE.test(x)&&/(?:누구|누가|몇\s*번|자처|주장한|행세|나온\s*사람)/.test(x)
     && !/(?:조사|능력)/.test(x))return 'WHO_POLICE';
  if(askRole)return 'ROLE_REQUEST';
  if((rx.INVESTIGATION.test(x)||/(?:검사|탐문)/.test(x))&& (ask||/(?:내역|기록)\s*좀/.test(x))
     && !/(?:내가|나는|난).{0,10}(?:조사|확인)\s*(?:했|해봤)/.test(x))return 'INVESTIGATION_QUERY';
  if(/(?:생존|남은\s*인원|살아\s*있|살아\s*남|남아\s*있|탈락\s*안|탈락하지\s*않)/.test(x)&&
    (rx.COUNT.test(x)||/(?:몇|명단|세\s*줘)/.test(x)))return 'LIVING_COUNT';
  if(/(?:희생|사망|죽은|죽었|죽었니|탈락자|밤\s*결과)/.test(x) && (ask||/누구|몇\s*번|있니|나왔/.test(x)))return 'DEATH_QUERY';
  if((rx.PHASE.test(x)||/(?:무슨\s*차례|몇\s*번째\s*토론|몇\s*번째\s*밤|지금\s*낮|지금\s*밤|어디까지\s*왔)/.test(x))
     && (ask||/(?:무슨\s*차례|몇\s*번째|해야\s*하는\s*순서|진행\s*순서)/.test(x)) && !nightSkip)return 'PHASE_QUERY';
  if(/(?:직전|아까|앞선).{0,15}질문.{0,8}(?:뭘|무슨|뭐|했어|했지|기억)/.test(x))return 'CHAT_HISTORY';
  if(rx.REPEAT.test(x)||/(?:내\s*질문|내가\s*물|물은\s*데|질문에).{0,20}(?:답|대답|왜\s*안)/.test(x))return 'REPEAT_REQUEST';
  if(rx.CHANGE.test(x)||/(?:말이\s*달라|말\s*바뀐|발언이\s*달라|주장을\s*바꿨)/.test(x)){
    if(/(?:모순|앞뒤|말\s*바|말이\s*바뀌|말이\s*바뀐|말이\s*달|발언이\s*달|주장.*다르|앞(?:에서)?.{0,15}말.{0,20}지금|말이랑.{0,15}안\s*맞)/.test(x))return 'CONTRADICTION';
  }
  if((rx.HISTORY.test(x)||/(?:첫날|직전|전에|앞서)/.test(x)) &&
    /(?:발언|뭐라|뭐라고|말했|말한|했던\s*말|질문|기억|대화)/.test(x) && ask)return 'CHAT_HISTORY';
  if(rx.CLARIFY.test(x) && (ask||/(?:풀어\s*(?:줘|설명)|다시\s*설명|쉽게\s*풀어|이해할\s*수\s*있게)/.test(x)))return 'CLARIFY';
  if(evidenceQuestion && !/^(?:난|나는|내가).{0,16}(?:근거|증거|단서).{0,12}(?:없|부족)/.test(x))return 'EVIDENCE_QUERY';
  if(rx.EVIDENCE.test(x)&& (rx.EVIDENCE_WEAK.test(x)||/(?:입증이\s*어렵|확인하기\s*어렵|몰아갈\s*수\s*없|판단.*어렵)/.test(x))&&!ask)return 'EVIDENCE_LACK';
  if(/(?:말만\s*듣|느낌만|감만).{0,26}(?:몰아|확신|판단|단정|모르|찍|퇴출)/.test(x))return 'EVIDENCE_LACK';
  if(rx.EVIDENCE.test(x)&& rx.CONFIDENT.test(x) && !rx.EVIDENCE_WEAK.test(x)&&!ask ||
     /(?:내가\s*직접\s*확인|입증\s*가능|결정적인\s*자료)/.test(x) && !ask)return 'EVIDENCE_HAS';
  if(skip&&!skipNo&&!nightSkip && !ask)return 'VOTE_SKIP';
  if(skip&&!skipNo&&!nightSkip && ask)return 'VOTE_QUERY';
  if((rx.DEFER.test(x)||frame.act==='DEFER') && !skip ||/(?:결정\s*내릴\s*때.{0,13}아(?:닌|니)|좀\s*더\s*이야기\s*듣|조금만\s*더.{0,22}결론|결론.{0,10}(?:나중|뒤|말자))/.test(x))return 'DEFER';
  if(rx.UNCERTAIN.test(x)||/(?:감이\s*안|누구.{0,15}난감|판단\s*안\s*되|정리가\s*안\s*됐)/.test(x))return 'UNCERTAIN';
  if(rx.COMPARE.test(x)&&ask && /(?:\d+\s*번|둘|두\s*사람|서로)/.test(x))return 'COMPARE';
  if(aboutSuspicion && (ask || /(?:어떤\s*사람|누가|누굴|누구).{0,20}(?:마피아|범인|수상|의심)/.test(x)) && !doubtNeg && !evidenceQuestion)return 'SUSPICION_QUERY';
  if(doubtNeg && !ask && (aboutSuspicion||/(?:무죄|결백|시민팀|범인\s*아닐|마피아\s*아닐)/.test(x)) && !/(?:믿어주면\s*안|믿을\s*수\s*없|못\s*믿|안\s*믿)/.test(x))return 'DEFEND';
  if((aboutSuspicion || /(?:믿어주면\s*안|믿을\s*수\s*없|못\s*믿|안\s*믿)/.test(x)) && !ask && !rx.CORRECTION.test(x) && !/(?:말이\s*달라|말\s*바꿨|앞뒤|모순)/.test(x))return 'ACCUSE';
  if(publicVote && ask && !nightSkip)return 'VOTE_QUERY';
  if(publicVote && !ask && !skipNo && !skip && !rx.DEFER.test(x) && /(하자|하겠|할게|찍|몰자|몰아\s*주자|넣|표\s*행사|투표)/.test(x))return 'VOTE_PROPOSE';
  if(rx.CORRECTION.test(x)||/(?:아니\s*그런\s*말|바로잡|말한\s*적\s*없)/.test(x))return 'CORRECTION';
  if(rx.SOCIAL_FIGHT.test(x) && /(?:그만|중단|대신|말자|멈춰|하지\s*마)/.test(x))return 'DEESCALATE';
  if(rx.DISAGREE.test(x))return 'DISAGREE';
  if(rx.AGREE.test(x)||/(?:내가\s*보기에도\s*맞|그\s*말\s*맞|그건\s*인정)/.test(x))return 'AGREE';
  if(rx.GREET.test(x)&&x.length<32)return 'GREETING';
  if(rx.THANK.test(x)&&x.length<55)return 'THANKS';
  return null;
}
function classify(text,options={}) {
  const t=String(text||'').normalize('NFC').trim();
  if(!t||t.length>400)return null;
  const frame=discourse(t,{phase:options.phase||'DAY'});
  const question=isQuestionForm(t), canonicalText=canonical(t), fingerprint=grams(canonicalText);
  const report=isReport(t);
  // The corpus is labeled intent examples, NEVER complete answers. Exact
  // examples can resolve unusual grammar, while all other text uses the same
  // compositional guards + graded lexical similarity.
  const remembered=canonicalExamples.get(canonicalText);
  if(remembered && !report && (!remembered.startsWith('SECRET_') || options.channel==='SECRET')) {
    const type=byId.get(remembered);
    // Do not turn a negated disclosure into the positive intent, even if the
    // surface form contains a literal training phrase.
    if(!(remembered==='ROLE_REQUEST' && rx.ROLE_NO.test(t)))
      return {intent:remembered,kind:type.kind,confidence:1,topic:type.topic,
        group:/(?:다들|모두|각자|전원|여러분|한\s*명씩|차례로|너희|우리\s*모두)/.test(t),
        frame,numberMentions:[...t.matchAll(/(\d+)\s*(?:번|호)(?!\d)/g)].map(x=>Number(x[1]))};
  }
  // Unseen phrases use compositional grammar, polarity and context features.
  const feature=featureClassify(t,frame,options.channel||'PUBLIC');
  if(feature && (!report || feature==='CHAT_HISTORY')) {
    const g=byId.get(feature);
    return {intent:feature,kind:g.kind,confidence:0.88,topic:g.topic,
      group:/(?:다들|모두|각자|전원|여러분|한\s*명씩|차례로|너희|우리\s*모두|전체)/.test(t),
      frame,numberMentions:[...t.matchAll(/(\d+)\s*(?:번|호)(?!\d)/g)].map(x=>Number(x[1]))};
  }
  // Safety priorities: a negated request is not a request to reveal a role;
  // refusing to skip must never be recorded as the choice to skip.
  const priority=['ROLE_SILENCE','VOTE_SKIP_DENY','NIGHT_SKIP','WHO_POLICE','RULE_QUERY'];
  const winners=[];
  for(const item of prepared) {
    if(!valid(item.id,t,frame,question,options.channel||'PUBLIC'))continue;
    let best=0;
    for(const x of item.ex){const similarity=dice(fingerprint,x.g);if(similarity>best)best=similarity;}
    // Strong semantic anchors make the label meaningful even when no example
    // is especially close. Short/ambiguous utterances need a closer example.
    const anchored=(item.id.startsWith('SECRET_') || priority.includes(item.id) || ['ROLE_REQUEST','INVESTIGATION_QUERY','EVIDENCE_QUERY','EVIDENCE_LACK','DEFER','UNCERTAIN','VOTE_QUERY','VOTE_SKIP','LIVING_COUNT','CHAT_HISTORY','PHASE_QUERY','CONTRADICTION','DEATH_QUERY'].includes(item.id));
    const threshold=anchored?0.23:0.37;
    if(best<threshold)continue;
    let score=best + (anchored?0.055:0);
    if(item.id==='ROLE_REQUEST' && /(?:직업|역할|정체|신분|포지션)/.test(t))score+=0.09;
    if(item.id==='RULE_QUERY' && /(?:능력|규칙|승리\s*조건|재투표|접선)/.test(t))score+=0.12;
    if(item.id==='NIGHT_SKIP'&&frame.act==='NIGHT_SKIP')score+=0.3;
    if(item.id==='VOTE_SKIP'&&frame.act==='VOTE_SKIP')score+=0.24;
    if(item.id==='VOTE_SKIP_DENY'&&frame.act==='REJECT_SKIP')score+=0.3;
    winners.push({id:item.id,kind:item.kind,score,exampleSimilarity:best});
  }
  winners.sort((a,b)=>b.score-a.score || order.indexOf(a.id)-order.indexOf(b.id));
  const best=winners[0];if(!best)return null;
  const second=winners[1];
  // A lexically ambiguous pair is deliberately left unknown unless grammar
  // has already resolved polarity or the role disclosure/silence distinction.
  if(second && best.score-second.score<0.022 && best.score<0.48 && !priority.includes(best.id))return null;
  return {intent:best.id,kind:best.kind,confidence:Math.max(0,Math.min(1,best.score)),
    topic:byId.get(best.id).topic,group:/(?:다들|모두|각자|전원|여러분|한\s*명씩|차례로|너희|우리\s*모두)/.test(t),
    frame,numberMentions:[...t.matchAll(/(\d+)\s*(?:번|호)(?!\d)/g)].map(x=>Number(x[1]))};
}
module.exports={classify,canonical,INTENTS};
