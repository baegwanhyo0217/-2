'use strict';

const PERSONAS = Object.freeze([
  { style:'analytical', goal:'compare verifiable evidence before making claims' },
  { style:'careful', goal:'avoid unjustified accusations and ask precise questions' },
  { style:'direct', goal:'answer questions clearly and state uncertainty openly' },
  { style:'negotiator', goal:'seek explanations before committing to a vote' },
  { style:'skeptical', goal:'check contradictions without equating suspicion with proof' },
  { style:'strategic', goal:'plan votes and actions while respecting role constraints' }
]);

class AgentMemory {
  constructor(agentNumber) {
    this.persona = PERSONAS[(Number(agentNumber) - 1 + PERSONAS.length) % PERSONAS.length];
    this.publicIds = new Set();
    this.secretIds = new Set();
    this.privateKeys = new Set();
    this.systemIds = new Set();
    this.evidenceApplied = new Set();
    this.events = [];
    this.decisions = [];
    this.beliefs = new Map();
    this.spoken = [];
    this.turns = 0;
  }
  observe(view) {
    for (const e of view.publicChat) {
      if (this.publicIds.has(e.id)) continue;
      this.publicIds.add(e.id);
      this.events.push({ id:e.id, type:'PUBLIC_STATEMENT', number:e.number,
        text:e.text, reliability:'unverified_statement' });
    }
    for (const e of view.secretChat) {
      if (this.secretIds.has(e.id)) continue;
      this.secretIds.add(e.id);
      this.events.push({ id:e.id, type:'SECRET_STATEMENT', number:e.number,
        text:e.text, reliability:'unverified_partner_statement' });
    }
    for (const r of view.ownInvestigations) {
      const k = `${r.night}:${r.targetId}`;
      if (this.privateKeys.has(k)) continue;
      this.privateKeys.add(k);
      this.events.push({ id:'inv:'+k, type:'OWN_INVESTIGATION', targetId:r.targetId,
        displayed:r.displayed, ...(r.actualRole ? { actualRole:r.actualRole } : {}),
        reliability:'confirmed_private_observation' });
    }
    // Authoritative announcements are public facts, not player allegations.
    // Never convert a player's claimed role into a verified game event.
    for (const e of view.publicLog || []) {
      const key = `game:${e.at}:${e.text}`;
      if (this.systemIds.has(key)) continue;
      this.systemIds.add(key);
      this.events.push({id:key,type:'PUBLIC_GAME_EVENT',text:String(e.text).slice(0,220),
        reliability:'confirmed_public_event'});
    }
    if (this.events.length > 150) this.events.splice(0, this.events.length-150);
  }
  applyBeliefs(updates, visibleIds) {
    if (!Array.isArray(updates)) return;
    for (const change of updates.slice(0,4)) {
      if (!change || typeof change !== 'object' || typeof change.targetId !== 'string') continue;
      if (!visibleIds.has(change.targetId)) continue;
      const ids = Array.isArray(change.evidenceIds) ? change.evidenceIds.filter(
        id => typeof id==='string' && this.events.some(e=>e.id===id)).slice(0,4) : [];
      // No evidence references -> speculative suspicion may not become a stored fact.
      if (!ids.length) continue;
      const delta = Number(change.delta);
      if (!Number.isFinite(delta) || Math.abs(delta)>2) continue;
      const prev=this.beliefs.get(change.targetId) || { score:0, reasons:[] };
      const next={ score:Math.max(-5,Math.min(5,prev.score+delta)),
        reasons:[...prev.reasons,{note:String(change.reason||'uncertain').slice(0,100), evidenceIds:ids}].slice(-5) };
      this.beliefs.set(change.targetId,next);
    }
  }
  addInferredEvidence(key,targetId,delta,reason,evidenceIds,visibleIds) {
    if (this.evidenceApplied.has(key)) return;
    this.evidenceApplied.add(key);
    this.applyBeliefs([{targetId,delta,reason,evidenceIds}],visibleIds);
  }
  recordDecision(entry) {
    if (!entry || typeof entry !== 'object') return;
    this.decisions.push({kind:String(entry.kind||''),targetId:entry.targetId || null,
      night:Number(entry.night)||0,phase:String(entry.phase||''),
      evidenceIds:Array.isArray(entry.evidenceIds) ? entry.evidenceIds.slice(0,5) : [],
      basis:String(entry.basis||'rules_based_heuristic').slice(0,100)});
    if (this.decisions.length > 15) this.decisions.shift();
  }
  recordSpeech(text) {
    this.spoken.push(text);
    if (this.spoken.length>9) this.spoken.shift();
    this.turns++;
  }
  compact() {
    return {
      persona:this.persona,
      events:this.events.slice(-30),
      beliefs:Array.from(this.beliefs,([targetId,value])=>({targetId,...value})),
      recentOwnSpeech:this.spoken.slice(-6),
      latestDecisions:this.decisions.slice(-5),
      turns:this.turns
    };
  }
}
module.exports = { AgentMemory, PERSONAS };
