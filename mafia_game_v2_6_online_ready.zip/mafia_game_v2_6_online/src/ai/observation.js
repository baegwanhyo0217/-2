'use strict';

// Security boundary: create an explicit per-agent allowlist. Never send the
// raw room, player list, other players' investigations or their private minds
// to a language model. This object is the ONLY source used by the AI adapter.
function observationFor(room, agent, plan) {
  if (!agent || !agent.bot || !room.players.includes(agent)) throw new Error('Invalid bot');
  const state = room.snapshotFor(agent);
  const me = state.me;
  const channel = plan.kind === 'SECRET_CHAT' ? 'SECRET' : 'PUBLIC';
  const publicChat = state.publicChat.slice(-36).map(event => ({
    id: event.id, number: event.number, text: String(event.text).slice(0,220),
    source: 'player_statement', channel: 'PUBLIC'
  }));
  // Even a contacted AI has no right to read secret chat in a public-only
  // phase unless this player's own view actually contains those messages.
  const secretChat = (state.secretChat || []).slice(-24).map(event => ({
    id: event.id, number: event.number, text: String(event.text).slice(0,220),
    source: 'partner_statement', channel: 'SECRET'
  }));
  const allMessages = channel === 'SECRET' ? secretChat : publicChat;
  const reply = plan.replyToId ? allMessages.find(event => event.id === plan.replyToId) || null : null;
  // Per-player investigation result is private and must never be reconstructed
  // from the authoritative roster. The official engine supplies this array.
  const investigations = (me.investigations || []).map(result => ({
    night: result.night, targetId: result.targetId, displayed: result.displayed,
    ...(agent.role === 'SPY' && result.actualRole ? { actualRole: result.actualRole } : {})
  }));
  const phase = state.phase;
  const available = plan.kind === 'ABILITY' ? me.validTargets :
    plan.kind === 'VOTE' ? state.players.filter(p => p.alive && p.id !== me.id).map(p => p.id).concat('SKIP') : [];
  return Object.freeze({
    phase, phaseStart: state.phaseStart, deadline: state.deadline, night: state.night,
    me: { id: me.id, number: me.number, role: me.role, team: me.team, alive: me.alive },
    roster: state.players.map(p => ({ id:p.id, number:p.number, name:p.name, alive:p.alive })),
    ownInvestigations: investigations,
    contact: me.contact && ['MAFIA', 'SPY'].includes(me.role) ? {
      partnerId: me.contact.partnerId, partnerNumber: me.contact.partnerNumber,
      active: !!me.canSecretChat
    } : null,
    publicChat, secretChat, reply,
    publicLog: (state.publicLog || []).slice(-12).map(e => ({ text:e.text })),
    publicVoteOutcome: state.voteOutcome || null,
    task: plan.kind, channel, legalTargets: available,
    myConfirmedAbility: !!me.action?.confirmed,
    mySelectedAbility: me.action?.selected || null
  });
}

module.exports = { observationFor };
