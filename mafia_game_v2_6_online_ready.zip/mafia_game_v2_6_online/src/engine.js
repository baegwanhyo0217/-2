'use strict';

const crypto = require('node:crypto');
const BotMind = require('./bot-mind');
const ROLES = ['MAFIA', 'SPY', 'POLICE', 'DOCTOR', 'GANGSTER', 'CITIZEN', 'CITIZEN'];
const ROLE_KO = {
  MAFIA: '마피아', SPY: '스파이', POLICE: '경찰', DOCTOR: '의사',
  GANGSTER: '건달', CITIZEN: '시민'
};
const TEAM = { MAFIA: 'MAFIA', SPY: 'MAFIA', POLICE: 'CITIZEN',
  DOCTOR: 'CITIZEN', GANGSTER: 'CITIZEN', CITIZEN: 'CITIZEN' };
const DEFAULT_DURATIONS = {
  NIGHT: 60000, NIGHT_RESULT: 4500, DAY: 60000,
  VOTE1: 30000, EXTRA_DISCUSSION: 45000, VOTE2: 30000,
  VOTE_RESULT: 4500
};
const MAX_CHAT_LENGTH = 220;
const BOT_NAMES = ['도윤', '서아', '민준', '하린', '지호', '수빈', '유진'];

function rule(condition, message) { if (!condition) throw new Error(message); }
function shuffled(items, rng) {
  const out = items.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}
function pick(items, rng) { return items.length ? items[Math.floor(rng() * items.length)] : null; }
function sanitizeName(value) {
  return String(value || '').replace(/[\r\n<>]/g, '').trim().slice(0, 18) || '익명';
}
function sanitizeChat(value) {
  return String(value || '').replace(/[\u0000-\u001F\u007F]/g, '').trim().slice(0, MAX_CHAT_LENGTH);
}
function publicActor(p) {
  return { id: p.id, number: p.number, name: p.name, bot: p.bot, alive: p.alive,
    boxPicked: p.boxIndex !== null, roleReady: p.roleReady };
}

class MafiaRoom {
  constructor(code, options = {}) {
    this.code = code;
    this.now = options.now || Date.now;
    this.rng = options.rng || Math.random;
    this.durations = { ...DEFAULT_DURATIONS, ...options.durations };
    this.onChange = options.onChange || (() => {});
    this.botController = options.botController || null;
    this.players = [];
    this.hostId = null;
    this.phase = 'LOBBY';
    this.phaseStart = this.now();
    this.deadline = null;
    this.night = 0;
    this.boxAssignments = null;
    this.boxOwners = null;
    this.actions = new Map();
    this.votes = new Map();
    this.contact = null;
    this.stunnedId = null;
    this.pendingNight = null;
    this.voteOutcome = null;
    this.publicLog = [];
    this.publicChat = [];
    this.secretChat = [];
    this.winningTeam = null;
    this.abortReason = null;
    this.botPlans = [];
    this.updatedAt = this.now();
  }

  update() { this.updatedAt = this.now(); this.onChange(this); }
  getPlayer(id) { return this.players.find(p => p.id === id); }
  hasActiveMatch() { return !['LOBBY', 'ABORTED', 'GAME_OVER'].includes(this.phase); }
  isHost(p) { return !!p && p.id === this.hostId; }
  ensureHost(p) { rule(this.isHost(p), '방장만 사용할 수 있습니다.'); }
  ensurePhase(...phases) { rule(phases.includes(this.phase), '현재 단계에서는 사용할 수 없습니다.'); }
  nextNumber() {
    for (let n = 1; n <= 7; n++) if (!this.players.some(p => p.number === n)) return n;
    return null;
  }

  createPlayer(name, bot = false) {
    this.ensurePhase('LOBBY');
    rule(this.players.length < 7, '방 인원이 가득 찼습니다.');
    const id = crypto.randomUUID();
    const p = {
      id, number: this.nextNumber(), name: sanitizeName(name), bot,
      token: bot ? null : crypto.randomBytes(24).toString('hex'),
      connected: false, connection: null, role: null, team: null, alive: true,
      boxIndex: null, roleReady: false, notices: [], investigations: [],
      lastChatAt: -Infinity
    };
    this.players.push(p);
    if (!this.hostId && !bot) this.hostId = id;
    this.log(`${p.number}번 ${p.name}님이 입장했습니다.${bot ? ' (AI)' : ''}`);
    this.update();
    return p;
  }

  addBots(actor, count = 1) {
    this.ensureHost(actor);
    this.ensurePhase('LOBBY');
    rule(Number.isInteger(count) && count >= 1 && count <= 6, 'AI 추가 인원이 올바르지 않습니다.');
    rule(this.players.length + count <= 7, '참가 인원은 7명까지입니다.');
    for (let i = 0; i < count; i++) {
      const used = new Set(this.players.map(p => p.name));
      const name = BOT_NAMES.find(n => !used.has(n)) || `AI ${i + 1}`;
      this.createPlayer(name, true);
    }
  }
  removeBots(actor) {
    this.ensureHost(actor);
    this.ensurePhase('LOBBY');
    this.players = this.players.filter(p => !p.bot);
    this.log('AI 플레이어를 제거했습니다.');
    this.update();
  }
  removeHuman(p, reason = '접속 종료') {
    if (!this.players.includes(p)) return;
    const mustAbort = this.hasActiveMatch();
    this.players = this.players.filter(x => x.id !== p.id);
    if (this.hostId === p.id) this.hostId = this.players.find(x => !x.bot)?.id || null;
    if (mustAbort) this.abort(`${p.number}번 ${p.name}: ${reason}`);
    else { this.log(`${p.number}번 ${p.name}님이 나갔습니다.`); this.update(); }
  }

  log(text) {
    this.publicLog.push({ at: this.now(), text });
    if (this.publicLog.length > 50) this.publicLog.shift();
  }
  notice(p, text, type = 'info') {
    if (!p) return;
    p.notices.push({ id: crypto.randomUUID(), at: this.now(), text, type });
    if (p.notices.length > 20) p.notices.shift();
  }
  phaseTo(phase, duration = null) {
    this.phase = phase;
    this.phaseStart = this.now();
    this.deadline = duration === null ? null : this.phaseStart + duration;
    this.botPlans = [];
    this.scheduleBots();
    this.update();
  }

  startDraft(actor) {
    this.ensureHost(actor);
    this.ensurePhase('LOBBY');
    rule(this.players.length === 7, '게임을 시작하려면 7명이 필요합니다.');
    rule(this.players.filter(p => !p.bot).every(p => p.connected), '모든 실제 플레이어가 연결되어야 합니다.');
    this.clearRoundState();
    this.boxAssignments = shuffled(ROLES, this.rng);
    this.boxOwners = Array(7).fill(null);
    this.log('직업 상자 7개가 준비되었습니다. 각자 한 개를 선택하세요.');
    this.phaseTo('BOXES');
  }
  clearRoundState() {
    this.botController?.resetRoom?.(this);
    this.night = 0;
    this.contact = null;
    this.stunnedId = null;
    this.pendingNight = null;
    this.voteOutcome = null;
    this.winningTeam = null;
    this.abortReason = null;
    this.publicChat = [];
    this.secretChat = [];
    this.actions.clear();
    this.votes.clear();
    for (const p of this.players) {
      p.role = null; p.team = null; p.alive = true; p.boxIndex = null;
      p.roleReady = false; p.notices = []; p.investigations = []; p.mind = null;
    }
  }
  chooseBox(p, index) {
    this.ensurePhase('BOXES');
    rule(p && this.players.includes(p), '참가자만 상자를 선택할 수 있습니다.');
    rule(!p.bot, 'AI의 상자는 서버가 배정합니다.');
    rule(Number.isInteger(index) && index >= 0 && index < 7, '올바르지 않은 상자입니다.');
    rule(p.boxIndex === null, '이미 상자를 선택했습니다.');
    rule(this.boxOwners[index] === null, '이미 선택된 상자입니다.');
    this.assignBox(p, index);
    this.completeBotBoxesIfReady();
    this.update();
  }
  assignBox(p, index) {
    this.boxOwners[index] = p.id;
    p.boxIndex = index;
    p.role = this.boxAssignments[index];
    p.team = TEAM[p.role];
    this.notice(p, `당신의 직업은 ${ROLE_KO[p.role]}입니다.`, 'role');
  }
  completeBotBoxesIfReady() {
    if (!this.players.filter(p => !p.bot).every(p => p.boxIndex !== null)) return;
    for (const p of this.players.filter(p => p.bot)) {
      const open = this.boxOwners.map((owner, i) => owner === null ? i : -1).filter(i => i !== -1);
      this.assignBox(p, pick(open, this.rng));
      p.roleReady = true;
    }
    this.maybeBeginAfterDraft();
  }
  confirmRole(p) {
    this.ensurePhase('BOXES');
    rule(p && p.boxIndex !== null, '먼저 직업 상자를 선택하세요.');
    p.roleReady = true;
    this.maybeBeginAfterDraft();
    this.update();
  }
  maybeBeginAfterDraft() {
    if (this.players.length === 7 && this.players.every(p => p.boxIndex !== null && p.roleReady)) this.startNight();
  }

  usable(p) {
    if (!p || !p.alive) return false;
    if (p.role === 'CITIZEN') return false;
    if (p.role === 'SPY' && this.contact && this.night > this.contact.night) return false;
    return true;
  }
  validTargets(p) {
    if (!this.usable(p)) return [];
    return this.players.filter(q => q.alive && (
      p.role === 'DOCTOR' || q.id !== p.id
    ) && !(
      p.role === 'MAFIA' && this.contact && this.night > this.contact.night && q.role === 'SPY'
    )).map(q => q.id);
  }
  startNight() {
    this.night += 1;
    this.pendingNight = null;
    this.stunnedId = null;
    this.actions.clear();
    this.voteOutcome = null;
    for (const p of this.players) if (this.usable(p)) {
      this.actions.set(p.id, { selected: null, confirmed: false, target: null,
        auto: false, fromLastSelection: false, confirmedAt: null });
    }
    this.log(`${this.night}번째 밤이 시작되었습니다.`);
    this.phaseTo('NIGHT', this.durations.NIGHT);
  }
  selectAbility(p, targetId) {
    this.ensurePhase('NIGHT');
    rule(this.usable(p), '야간 능력을 사용할 수 없습니다.');
    const action = this.actions.get(p.id);
    rule(action && !action.confirmed, '이미 행동을 확정하여 변경할 수 없습니다.');
    rule(this.validTargets(p).includes(targetId), '해당 플레이어는 선택할 수 없습니다.');
    action.selected = targetId;
    this.update();
  }
  confirmAbility(p, targetId) {
    this.ensurePhase('NIGHT');
    const action = this.actions.get(p?.id);
    rule(action && !action.confirmed, '행동을 확정할 수 없습니다.');
    rule(action.selected !== null && action.selected === targetId, '먼저 대상을 임시 선택하세요.');
    rule(this.validTargets(p).includes(targetId), '유효하지 않은 대상입니다.');
    action.confirmed = true;
    action.target = targetId;
    action.confirmedAt = this.now();
    this.notice(p, '능력 사용 대상이 확정되었습니다. 더 이상 변경할 수 없습니다.');
    if (this.allActionsConfirmed()) this.resolveNight();
    else this.update();
  }
  allActionsConfirmed() {
    return Array.from(this.actions.values()).every(a => a.confirmed);
  }
  finalizeNightActions() {
    for (const [id, action] of this.actions) {
      if (action.confirmed) continue;
      const p = this.getPlayer(id);
      if (action.selected !== null && this.validTargets(p).includes(action.selected)) {
        action.target = action.selected;
        action.fromLastSelection = true;
        this.notice(p, '제한 시간이 종료되어 마지막으로 선택한 대상이 확정되었습니다.');
      } else if (p.role === 'DOCTOR') {
        action.target = p.id;
        action.auto = true;
        this.notice(p, '대상을 선택하지 않아 자신을 자동 치료합니다.');
      } else {
        action.target = pick(this.validTargets(p), this.rng);
        action.auto = true;
        this.notice(p, '제한 시간이 종료되어 대상이 자동 선택되었습니다.');
      }
      action.confirmed = true;
      action.confirmedAt = this.now();
    }
  }
  playerByRole(role) { return this.players.find(p => p.role === role); }
  actionTarget(role) {
    const p = this.playerByRole(role);
    return p && this.actions.get(p.id)?.target || null;
  }
  resolveNight() {
    if (this.phase !== 'NIGHT') return;
    this.finalizeNightActions();
    const mafia = this.playerByRole('MAFIA');
    const spy = this.playerByRole('SPY');
    const police = this.playerByRole('POLICE');
    const doctor = this.playerByRole('DOCTOR');
    const gangster = this.playerByRole('GANGSTER');
    const mafiaTarget = this.actionTarget('MAFIA');
    const spyTarget = this.actionTarget('SPY');
    const policeTarget = this.actionTarget('POLICE');
    const doctorTarget = this.actionTarget('DOCTOR');
    const gangsterTarget = this.actionTarget('GANGSTER');

    // Investigations are simultaneous, irrespective of the order in which clients submitted.
    if (spyTarget && spy?.alive && this.actions.has(spy.id)) {
      const target = this.getPlayer(spyTarget);
      spy.investigations.push({ night: this.night, targetId: target.id,
        actualRole: target.role, displayed: ROLE_KO[target.role] });
      this.notice(spy, `${target.number}번 ${target.name}의 실제 직업: ${ROLE_KO[target.role]}`, 'investigation');
    }
    if (policeTarget && police?.alive) {
      const target = this.getPlayer(policeTarget);
      const displayed = target.role === 'MAFIA' ? '마피아팀' : '시민팀';
      police.investigations.push({ night: this.night, targetId: target.id, displayed });
      this.notice(police, `${target.number}번 ${target.name}의 소속 조사 결과: ${displayed}`, 'investigation');
    }

    const beforeContact = !this.contact;
    const contactA = beforeContact && spy?.alive && spyTarget === mafia?.id;
    const contactB = beforeContact && spy?.alive && mafiaTarget === spy.id;
    if (contactA || contactB) {
      this.contact = { night: this.night, type: contactA ? 'A' : 'B' };
      this.notice(mafia, '스파이와 접선했습니다. 다음 날 밤부터 비밀 채팅을 사용할 수 있습니다.', 'contact');
      this.notice(spy, '마피아와 접선했습니다. 다음 날 밤부터 비밀 채팅을 사용할 수 있으며 조사 능력은 종료됩니다.', 'contact');
    }
    const attackCanceled = !!(spy?.alive && mafiaTarget === spy.id);
    if (attackCanceled && mafia) {
      this.notice(mafia, '스파이 대상 공격이 취소되었습니다. 이번 밤에는 추가 공격할 수 없습니다.', 'contact');
    }
    const effectiveAttack = attackCanceled ? null : mafiaTarget;
    const saved = !!(effectiveAttack && doctor?.alive && doctorTarget === effectiveAttack);
    const deathId = effectiveAttack && !saved ? effectiveAttack : null;
    if (doctor?.alive && doctorTarget) {
      this.notice(doctor, saved ? '당신이 선택한 플레이어를 살렸습니다.' :
        '당신이 선택한 플레이어는 공격받지 않았습니다.', saved ? 'success' : 'info');
    }
    this.pendingNight = { deathId, stunId: gangster?.alive ? gangsterTarget : null,
      attackTargetId: mafiaTarget, effectiveAttack, saved, contactType: contactA ? 'A' : contactB ? 'B' : null };
    this.phaseTo('NIGHT_RESULT', this.durations.NIGHT_RESULT);
  }
  publishMorning() {
    if (this.phase !== 'NIGHT_RESULT') return;
    const result = this.pendingNight || {};
    const victim = result.deathId ? this.getPlayer(result.deathId) : null;
    if (victim) victim.alive = false;
    const stunned = result.stunId ? this.getPlayer(result.stunId) : null;
    this.stunnedId = stunned?.alive ? stunned.id : null;
    if (stunned?.alive) this.notice(stunned, '당신은 오늘 투표에 참여할 수 없습니다.', 'warning');
    if (victim) this.log(`지난밤 ${victim.number}번 ${victim.name}이(가) 사망했습니다.`);
    else this.log('지난밤 사망자는 없습니다.');
    if (this.checkVictory()) return;
    this.log('날이 밝았습니다. 1분 동안 토론을 진행해 주세요.');
    this.phaseTo('DAY', this.durations.DAY);
  }

  canChat(p, channel = 'PUBLIC') {
    if (!p || !p.alive || !this.players.includes(p)) return false;
    if (channel === 'PUBLIC') return ['DAY', 'EXTRA_DISCUSSION'].includes(this.phase);
    if (channel === 'SECRET') return this.phase === 'NIGHT' &&
      !!this.contact && this.night > this.contact.night &&
      ['MAFIA', 'SPY'].includes(p.role) &&
      this.playerByRole('MAFIA')?.alive && this.playerByRole('SPY')?.alive;
    return false;
  }
  sendChat(p, channel, input) {
    rule(this.canChat(p, channel), '현재 채팅을 사용할 수 없습니다.');
    const text = sanitizeChat(input);
    rule(text.length > 0, '채팅 메시지를 입력하세요.');
    rule(this.now() - p.lastChatAt >= 650, '메시지를 너무 빠르게 보내고 있습니다.');
    // Minimal abuse filter, not a game mechanic. Messages are always rendered as text, never HTML.
    rule(!/(?:시발|씨발|병신|개새끼)/i.test(text), '부적절한 표현은 전송할 수 없습니다.');
    p.lastChatAt = this.now();
    const entry = { id: crypto.randomUUID(), at: this.now(), senderId: p.id,
      number: p.number, name: p.name, bot: p.bot, text, channel };
    const arr = channel === 'SECRET' ? this.secretChat : this.publicChat;
    arr.push(entry);
    if (arr.length > 100) arr.shift();
    this.update();
    if (channel === 'PUBLIC') this.scheduleReactions(p, text, entry);
    if (channel === 'SECRET' && !p.bot) this.scheduleSecretReaction(p, entry);
  }

  startVote(number) {
    this.votes.clear();
    this.voteOutcome = null;
    this.log(number === 1 ? '1차 투표가 시작되었습니다.' : '재투표가 시작되었습니다.');
    this.phaseTo(number === 1 ? 'VOTE1' : 'VOTE2', this.durations[number === 1 ? 'VOTE1' : 'VOTE2']);
  }
  canVote(p) {
    return !!p && p.alive && this.stunnedId !== p.id &&
      ['VOTE1', 'VOTE2'].includes(this.phase);
  }
  submitVote(p, targetId) {
    rule(this.canVote(p), '투표할 수 없습니다.');
    rule(!this.votes.has(p.id), '이미 투표를 제출했습니다.');
    rule(targetId === 'SKIP' || (targetId !== p.id &&
      this.players.some(q => q.id === targetId && q.alive)), '유효하지 않은 투표 대상입니다.');
    this.votes.set(p.id, { targetId, at: this.now() });
    this.notice(p, targetId === 'SKIP' ? '투표 건너뛰기를 제출했습니다.' : '투표를 제출했습니다.');
    this.update();
  }
  tallyVote() {
    const counts = new Map();
    for (const entry of this.votes.values()) {
      counts.set(entry.targetId, (counts.get(entry.targetId) || 0) + 1);
    }
    if (!this.votes.size) return { kind: 'EMPTY', counts: [], valid: 0 };
    const max = Math.max(...counts.values());
    const winners = Array.from(counts.entries()).filter(([, n]) => n === max).map(([id]) => id);
    const list = Array.from(counts.entries()).map(([targetId, count]) => ({ targetId, count }));
    return { kind: winners.length > 1 ? 'TIE' : winners[0] === 'SKIP' ? 'SKIP' : 'EXPEL',
      targetId: winners.length === 1 ? winners[0] : null,
      tiedIds: winners.length > 1 ? winners : [], counts: list, valid: this.votes.size };
  }
  resolveVote() {
    if (!['VOTE1', 'VOTE2'].includes(this.phase)) return;
    const isFirst = this.phase === 'VOTE1';
    const outcome = this.tallyVote();
    this.voteOutcome = { ...outcome, round: isFirst ? 1 : 2 };
    if (outcome.kind === 'TIE' && isFirst) {
      this.log('최다 득표 동률이 발생했습니다. 45초 동안 추가 토론합니다.');
      this.phaseTo('EXTRA_DISCUSSION', this.durations.EXTRA_DISCUSSION);
      return;
    }
    if (outcome.kind === 'EXPEL') {
      const eliminated = this.getPlayer(outcome.targetId);
      eliminated.alive = false;
      this.log(`투표 결과 ${eliminated.number}번 ${eliminated.name}이(가) 퇴출되었습니다.`);
      if (this.checkVictory()) return;
    } else if (outcome.kind === 'SKIP') {
      this.log('투표 건너뛰기가 단독 최다 득표했습니다. 퇴출자는 없습니다.');
    } else if (outcome.kind === 'EMPTY') {
      this.log('유효표가 없습니다. 투표 무효, 퇴출자는 없습니다.');
    } else {
      this.log('재투표에서도 동률이 발생했습니다. 퇴출자는 없습니다.');
    }
    this.phaseTo('VOTE_RESULT', this.durations.VOTE_RESULT);
  }
  checkVictory() {
    const mafia = this.playerByRole('MAFIA');
    if (!mafia?.alive) { this.finishGame('CITIZEN'); return true; }
    if (!this.players.some(p => p.alive && p.team === 'CITIZEN')) {
      this.finishGame('MAFIA'); return true;
    }
    return false;
  }
  finishGame(team) {
    this.winningTeam = team;
    this.log(team === 'CITIZEN' ? '마피아가 제거되었습니다. 시민팀이 승리했습니다!' :
      '시민팀 전원이 제거되었습니다. 마피아팀이 승리했습니다!');
    this.phaseTo('GAME_OVER');
  }
  abort(reason) {
    if (['ABORTED', 'GAME_OVER', 'LOBBY'].includes(this.phase)) return;
    this.abortReason = reason || '연결 문제';
    this.winningTeam = null;
    this.pendingNight = null;
    this.actions.clear(); this.votes.clear();
    this.log(`게임 연결 문제로 판이 중단되었습니다. ${this.abortReason}`);
    this.phaseTo('ABORTED');
  }
  resetLobby(actor) {
    this.ensureHost(actor);
    this.ensurePhase('GAME_OVER', 'ABORTED');
    if (this.phase === 'ABORTED') this.players = this.players.filter(p => !p.bot);
    this.clearRoundState();
    this.boxOwners = null; this.boxAssignments = null;
    this.log('새 게임을 위한 인원 모집을 시작합니다.');
    this.phaseTo('LOBBY');
  }

  // The bot only sees its own role, its own investigation history, public data,
  // and a contact partner once contact has genuinely happened.
  botKnowledge(p) {
    const partner = this.contact ?
      this.players.find(q => q.id !== p.id && ['MAFIA', 'SPY'].includes(q.role)) : null;
    return { role: p.role, team: p.team, selfId: p.id, playerNumber: p.number,
      alivePlayers: this.players.filter(q => q.alive).map(q => ({ id: q.id, number: q.number, name: q.name })),
      investigations: p.investigations.map(i => ({ ...i })),
      partnerId: ['MAFIA', 'SPY'].includes(p.role) && this.contact ? partner?.id : null,
      contacted: ['MAFIA','SPY'].includes(p.role) && !!this.contact, night: this.night };
  }
  botNightTarget(p) {
    return BotMind.chooseNight(this,p,this.rng);
  }
  botVoteTarget(p) {
    return BotMind.chooseVote(this,p,this.rng);
  }
  botChatText(p, channel, replyToId = null) {
    const mind=BotMind.mindFor(p,this.rng);
    if(!mind.recentLines) mind.recentLines=[];
    let line=BotMind.decideSpeech(this,p,channel,this.rng,replyToId?{replyToId}:{});
    // Do not replace a direct answer with a generic line merely for duplicate avoidance.
    if(!line)return null;
    if(!replyToId && mind.recentLines.includes(line))
      line=BotMind.decideSpeech(this,p,channel,this.rng);
    if(!line)return null;
    mind.recentLines.push(line);
    if(mind.recentLines.length>12)mind.recentLines.shift();
    return line;
  }
  scheduleReactions(sender,text,entry) {
    if (!['DAY','EXTRA_DISCUSSION'].includes(this.phase) || !entry) return;
    const now=this.now();
    if(!sender.bot && !this.players.includes(sender))return;
    if(this.deadline-now<1150)return;
    const isQuestion=BotMind.isQuestion(text);
    const view={everyone:this.players};
    const directId=BotMind.directAddressee(text,view);
    const addressed=this.players.filter(x=>x.bot && x.alive && x.id!==sender.id &&
      (directId ? x.id===directId : x.name.length>1 &&
        new RegExp('^'+x.name+'(?:[,:：，\\s]|님|아|야)').test(text)));
    // Bot-to-bot spontaneous reactions create feedback loops; permit only an
    // explicitly addressed question. Human statements are meaningful turns too.
    if(sender.bot && (!isQuestion || !/[?？]/.test(text) || !addressed.length))return;
    if(!sender.bot && !BotMind.isReactiveMessage(text))return;
    const candidates=this.players.filter(x=>x.bot && x.alive && x.id!==sender.id);
    if(!candidates.length)return;
    let bot=addressed[0] || null;
    const prior=this.publicChat.length>=2?this.publicChat[this.publicChat.length-2]:null;
    const referBack=/(?:뭔\s*소리|무슨\s*말|무슨\s*뜻|방금|그게\s*무슨|설명해|응|맞아|그래|동의|아니\s*그게|그건\s*아니)/.test(text);
    if(!bot && !sender.bot && referBack && prior?.bot)
      bot=candidates.find(x=>x.id===prior.senderId)||null;
    if(!bot && !sender.bot && /(?:너|넌|네가|니가|너는|네\s*말)/.test(text) && prior?.bot)
      bot=candidates.find(x=>x.id===prior.senderId)||null;
    if(!bot && !sender.bot && isQuestion && /(?:왜.*?(?:나|날|내)|나를.*?의심)/.test(text))
      bot=candidates.findLast(x=>x.mind?.lastOpinion?.targetId===sender.id)||null;
    if(!bot && !sender.bot) {
      const subjects=BotMind.mentions(text,this.players);
      // An accusation ABOUT a bot should be assessed by another participant,
      // unless the player addresses that bot directly.
      bot=pick(candidates.filter(x=>!subjects.includes(x.id)),this.rng)||pick(candidates,this.rng);
    }
    if(!bot)return;
    // Prevent flood when a human types numerous fragments. Direct questions
    // still take priority, up to the ordinary discussion deadline.
    const queued=this.botPlans.filter(x=>!x.done && x.kind==='PUBLIC_CHAT' && x.replyToId).length;
    if(queued>=12 && !isQuestion)return;
    const at=Math.min(Math.max(now+900,bot.lastChatAt+780),this.deadline-140);
    if(at<=now)return;
    const pending=this.botPlans.find(plan=>!plan.done && plan.id===bot.id && plan.kind==='PUBLIC_CHAT');
    if(pending) {
      if(pending.replyToId && pending.replyToId!==entry.id) {
        const followUpAt=Math.min(Math.max(at,pending.at+900),this.deadline-140);
        if(followUpAt>now)this.botPlans.push({id:bot.id,kind:'PUBLIC_CHAT',at:followUpAt,done:false,replyToId:entry.id});
      } else {
        pending.at=Math.min(pending.at,at);
        pending.replyToId=entry.id;
      }
      return;
    }
    this.botPlans.push({id:bot.id,kind:'PUBLIC_CHAT',at,done:false,replyToId:entry.id});
  }
  scheduleSecretReaction(sender, entry) {
    // Only the *contacted* teammate can reply. Never broadcast or let another bot read it.
    if (!entry || entry.channel !== 'SECRET' || sender.bot || !this.canChat(sender, 'SECRET')) return;
    const partner=this.players.find(p => p.bot && p.alive && p.id!==sender.id &&
      ['MAFIA','SPY'].includes(p.role) && this.canChat(p,'SECRET'));
    if (!partner || this.deadline-this.now()<1250) return;
    const pendingReplies=this.botPlans.filter(plan => !plan.done && plan.kind==='SECRET_CHAT' && plan.replyToId && plan.id===partner.id);
    if (pendingReplies.some(plan => plan.replyToId===entry.id) || pendingReplies.length>=15) return;
    const now=this.now();
    // Keep the existing question queued and append a follow-up. Do not overwrite a
    // player's earlier question just because they sent a second sentence.
    const previous=pendingReplies.reduce((mx,x)=>Math.max(mx,x.at),now);
    const at=Math.max(now+850,partner.lastChatAt+710,previous+(pendingReplies.length?740:0));
    if(at>=this.deadline-180)return;
    const unused=this.botPlans.find(plan => !plan.done && plan.id===partner.id && plan.kind==='SECRET_CHAT' && !plan.replyToId);
    if(unused && !pendingReplies.length) {
      unused.replyToId=entry.id;
      unused.at=at;
    } else {
      this.botPlans.push({id:partner.id,kind:'SECRET_CHAT',at,done:false,replyToId:entry.id});
    }
  }
  scheduleBots() {
    const duration = this.deadline !== null ? this.deadline - this.phaseStart : 0;
    const schedule = (p, kind, minFraction, maxFraction) => {
      const at = this.phaseStart + Math.max(80, duration * (minFraction + this.rng() * (maxFraction - minFraction)));
      this.botPlans.push({ id: p.id, kind, at, done: false });
    };
    if (this.phase === 'NIGHT') {
      for (const p of this.players.filter(x => x.bot && x.alive)) {
        if (this.usable(p)) {
          // Once partners can talk, let an AI Mafia consult the human Spy
          // before locking in an irreversible attack selection.
          if (p.role==='MAFIA' && this.canChat(p,'SECRET')) schedule(p,'ABILITY',0.73,0.83);
          else schedule(p,'ABILITY',0.05,0.22);
        }
        if (this.canChat(p, 'SECRET')) {
          schedule(p, 'SECRET_CHAT', 0.015, 0.12);
          if (this.rng() < 0.68) schedule(p, 'SECRET_CHAT', 0.26, 0.65);
        }
      }
    }
    if (['DAY', 'EXTRA_DISCUSSION'].includes(this.phase)) {
      const speakers=this.players.filter(x => x.bot && x.alive);
      const offset=speakers.length?Math.floor(this.rng()*speakers.length):0;
      for(let i=0;i<speakers.length;i++) {
        const p=speakers[(i+offset)%speakers.length];
        BotMind.mindFor(p,this.rng);
        // Space out contributions over the discussion instead of making every
        // bot interrupt at once in the first ten seconds.
        const fraction=0.055+(i+this.rng()*0.45)*0.78/speakers.length;
        this.botPlans.push({id:p.id,kind:'PUBLIC_CHAT',at:this.phaseStart+Math.max(80,duration*fraction),done:false});
        if(this.rng()<0.30)schedule(p,'PUBLIC_CHAT',0.72,0.92);
      }
    }
    if (['VOTE1', 'VOTE2'].includes(this.phase)) {
      for (const p of this.players.filter(x => x.bot && x.alive && this.stunnedId !== x.id)) {
        schedule(p, 'VOTE', 0.10, 0.60);
      }
    }
  }
  actBot(plan) {
    try {
      if (this.botController?.handlePlan?.(this,plan)) return;
    } catch (error) { /* Misconfigured optional LLM must not break game rules. */ }
    this.actBotLegacy(plan);
  }
  actBotLegacy(plan) {
    const p = this.getPlayer(plan.id);
    if (!p?.alive) return;
    try {
      if (plan.kind === 'ABILITY' && this.phase === 'NIGHT' && this.usable(p)) {
        const t = this.botNightTarget(p);
        if (t) {
          this.selectAbility(p, t);
          this.confirmAbility(p, t);
        }
      } else if (plan.kind === 'SECRET_CHAT' && this.canChat(p, 'SECRET')) {
        // Answer human turns before unsolicited strategizing. Preserve chat
        // cooldown without silently dropping a pending direct reply.
        if(!plan.replyToId && this.botPlans.some(q=>!q.done && q.id===p.id && q.kind==='SECRET_CHAT' && q.replyToId))return;
        if(this.now()-p.lastChatAt<660) {
          const at=p.lastChatAt+710;
          if(at<this.deadline-100)this.botPlans.push({...plan,at,done:false});
          return;
        }
        const line=this.botChatText(p,'SECRET',plan.replyToId);
        if(line)this.sendChat(p,'SECRET',line);
      } else if (plan.kind === 'PUBLIC_CHAT' && this.canChat(p, 'PUBLIC')) {
        // A direct reply should not be lost to the chat anti-spam cooldown.
        if(this.now()-p.lastChatAt<660) {
          const when=p.lastChatAt+690;
          if(when<this.deadline) this.botPlans.push({...plan,at:when,done:false});
          return;
        }
        const line=this.botChatText(p, 'PUBLIC', plan.replyToId);
        if(line)this.sendChat(p, 'PUBLIC', line);
      } else if (plan.kind === 'VOTE' && this.canVote(p) && !this.votes.has(p.id)) {
        this.submitVote(p, this.botVoteTarget(p));
      }
    } catch (e) { /* A bot missing a turn is subject to the ordinary automatic rules. */ }
  }
  tick() {
    if (this.deadline === null) return;
    const now = this.now();
    // Copy because actions can change the phase while iterating.
    for (const plan of this.botPlans.slice()) {
      if (plan.done || plan.at > now) continue;
      plan.done = true;
      const expected = this.phase;
      this.actBot(plan);
      if (this.phase !== expected) break;
    }
    if (this.deadline === null || now < this.deadline) return;
    switch (this.phase) {
      case 'NIGHT': this.resolveNight(); break;
      case 'NIGHT_RESULT': this.publishMorning(); break;
      case 'DAY': this.startVote(1); break;
      case 'VOTE1': case 'VOTE2': this.resolveVote(); break;
      case 'EXTRA_DISCUSSION': this.startVote(2); break;
      case 'VOTE_RESULT': this.startNight(); break;
      default: break;
    }
  }

  snapshotFor(p) {
    const finished = this.phase === 'GAME_OVER';
    const privateAction = this.actions.get(p?.id);
    const canSeeSecret = p && ['MAFIA', 'SPY'].includes(p.role) &&
      !!this.contact && this.night > this.contact.night;
    const seesPartner = !!p && ['MAFIA', 'SPY'].includes(p.role) && !!this.contact;
    const partner = seesPartner ? this.players.find(q => q.id !== p.id && ['MAFIA', 'SPY'].includes(q.role)) : null;
    return {
      code: this.code, phase: this.phase, phaseStart: this.phaseStart,
      deadline: this.deadline, serverNow: this.now(), night: this.night,
      players: this.players.map(x => ({ ...publicActor(x),
        ...(finished ? { role: x.role, team: x.team } : {}) })),
      hostId: this.hostId,
      seatsMax: 7,
      boxes: this.boxOwners ? this.boxOwners.map((id, index) => ({ index, chosen: id !== null,
        pickerId: id })) : [],
      me: p ? { id: p.id, number: p.number, name: p.name, role: p.role,
        roleKo: p.role ? ROLE_KO[p.role] : null, team: p.team, alive: p.alive,
        connected: p.connected, boxIndex: p.boxIndex, roleReady: p.roleReady,
        isHost: this.isHost(p), canAct: this.phase === 'NIGHT' && this.usable(p),
        validTargets: this.phase === 'NIGHT' ? this.validTargets(p) : [],
        action: privateAction ? { selected: privateAction.selected, confirmed: privateAction.confirmed,
          target: privateAction.target, auto: privateAction.auto } : null,
        teamAction: p.role === 'SPY' && this.phase === 'NIGHT' && this.contact &&
          this.night > this.contact.night && this.playerByRole('MAFIA')?.alive ? (() => {
            const a = this.actions.get(this.playerByRole('MAFIA').id);
            return a ? { selected:a.selected, confirmed:a.confirmed, target:a.target } : null;
          })() : null,
        canVote: this.canVote(p), voted: this.votes.has(p.id),
        stunned: this.stunnedId === p.id,
        canPublicChat: this.canChat(p, 'PUBLIC'), canSecretChat: this.canChat(p, 'SECRET'),
        notices: p.notices.slice(-12), investigations: p.investigations.slice(),
        contact: seesPartner ? { night: this.contact.night, type: this.contact.type,
          partnerId: partner?.id, partnerNumber: partner?.number, partnerName: partner?.name } : null } : null,
      publicLog: this.publicLog.slice(-18), publicChat: this.publicChat.slice(-80),
      secretChat: canSeeSecret ? this.secretChat.slice(-80) : [],
      voteOutcome: ['VOTE_RESULT', 'GAME_OVER'].includes(this.phase) ? this.voteOutcome : null,
      winningTeam: finished ? this.winningTeam : null,
      abortReason: this.phase === 'ABORTED' ? this.abortReason : null
    };
  }
}

module.exports = { MafiaRoom, ROLES, ROLE_KO, TEAM, DEFAULT_DURATIONS,
  shuffled, sanitizeChat, sanitizeName };
