'use strict';
/*
 * Compositional Korean discourse frames for offline NOIR / SEVEN.
 * This is not a generative language model. Lexical *families* identify features
 * (evidence, confidence, intent, negation, timing, and source attribution),
 * and rules combine them. Unknown expressions remain uncertain rather than
 * inventing a fact or forcing every utterance into a scripted example.
 * Keeping the frame independent of roles prevents secret information leakage.
 */
const normalize = text => String(text || '').normalize('NFKC').replace(/\s+/g, ' ').trim();
const EVIDENCE = /(?:증거|근거|단서|확증|정황|정보|자료|기록|조사\s*결과|확인된\s*(?:사실|내용)|뒷받침|입증)/;
const DECISION = /(?:판단|결론|결정|지목|투표|퇴출|몰아가|단정|확신|의심|찍|선택)/;
const CONFIDENCE_NEG = /(?:확신(?:이|은|도)?\s*(?:없|안\s*서|못\s*(?:하|하겠|서))|확신\s*못|장담\s*못|확실(?:치|하지|하진)\s*않|불확실|불분명|불투명|애매|모호|헷갈|모르겠|모르겠다|모르는\s*것|누군지\s*모르|누가\s*마피아인지\s*모르|잘\s*모르|아직\s*몰|감이\s*안\s*(?:잡히|잡힌|잡혀)|긴가민가|섣부르|섣불리\s*판단|확답(?:은|도)?\s*못|자신(?:이|은)?\s*없)/;
const EVIDENCE_LACK = /(?:없|없어|없다|부족|모자|빈약|약해|약하|희박|불충분|안\s*보이|못\s*보|확인\s*못|찾지\s*못|안\s*나왔|안\s*나와|나오지\s*않|적다|적은|적어|미약|뚜렷하지\s*않)/;
const EVIDENCE_PRESENT = /(?:있어|있다|있지|나왔|나와|확보|발견|찾았|직접\s*봤|증명|확인했|충분해|확실해|명백해|확정됐)/;
const DEFER = /(?:보류|유보|관망|지켜\s*(?:보|볼|봐)|두고\s*(?:보|볼|봐)|좀\s*더\s*(?:보|볼|봐)|기다리|추가\s*정보|다음\s*정보|다음\s*날|다음\s*밤|내일\s*보|나중에\s*판단|천천히\s*(?:결정|판단|하)|결론.*?(?:이르|미루|나중|성급|늦추)|판단.*?(?:이르|미루|나중|늦추)|결정.*?(?:이르|미루|나중|늦추)|지목.*?(?:이른|이르|성급)|퇴출.*?(?:시키지\s*말|하지\s*말)|(?:새|추가)\s*(?:단서|정보).{0,15}(?:나오|생기).{0,12}(?:다시|그때)|서두르지|성급하게\s*판단|당장은\s*못|지금은\s*못|잠시\s*멈추|미뤄\s*두)/;
const SKIP = /(?:스킵|패스|기권|생략|건너\s*뛰|넘어\s*가|넘기|넘길|넘겨|지나가|표(?:를|는)?\s*(?:안\s*던|안\s*주|안\s*찍|던지지|주지\s*않|찍지\s*않)|표.{0,17}(?:안\s*할|안\s*하|하지\s*않)|누구(?:한테|에게)도.{0,16}표.{0,14}(?:싫|안|못)|아무도\s*(?:안\s*찍|찍지\s*말|안\s*뽑|뽑지\s*말)|투표\s*(?:안|하지\s*말|보류|유보|없)|표결\s*(?:없|보류|유보))/;
const NIGHT = /(?:밤|야간|밤\s*턴|밤\s*단계|야간\s*단계|야간\s*행동|나이트)/;
const VOTE = /(?:투표|표결|표(?:를|는)?\s*(?:던지|주|찍)|스킵\s*표|표\s*행사|퇴출|지목|찍을)/;
const DISAGREE_WITH_ABSENCE = /(?:(?:없(?:어|다|다고|다는|는)?|부족(?:하|해|하다|하다는)?).{0,18}(?:말(?:한|했)?\s*게|뜻|건|것은|게)\s*아니|(?:없는|부족한)\s*건\s*아니|없는\s*것\s*같지\s*않|부족하지\s*않|확신\s*없다는\s*게\s*아니)/;
const NEGATE_SKIP = /(?:스킵|패스|기권).{0,25}(?:못\s*받아들|안\s*받아들|거절)|(?:스킵|패스|기권|건너\s*뛰|넘어\s*가|넘기).{0,14}(?:하지\s*마|하면\s*안|하진\s*않|하지\s*않|할\s*생각\s*없|안\s*해|안\s*할|안\s*함|아니|싫)|(?:스킵|패스)\s*(?:안\s*할|하지\s*말)|(?:건너\s*뛰지\s*말|넘기지\s*말)/;
const REPORT_START = /^(?:(?:저기|근데|그런데|참고로|아까|방금|듣기로는)[,\s]*)?(?:\d+\s*(?:번|호)|그\s*사람|걔|쟤|누군가|누가)\s*(?:은|는|이|가|도)?\s*/;
const REPORT_VERB = /(?:한다고|한다는|한다던데|하겠다고|하자고|하던데|했대|한대|라(?:고|며)|말(?:했|하)|주장|했다(?:더라|던데)|했었다(?:더라|던데))/;
const REQUEST_EVIDENCE = /(?:왜|무슨\s*이유|어떤\s*이유|이유.{0,10}(?:뭐|뭔|알려)|뭘\s*보고|대체\s*뭘\s*보고|뭘\s*믿고|뭔\s*근거|무슨\s*증거|무슨\s*단서|(?:증거|근거|단서).{0,16}(?:있|뭐|어디|말해|알려|보여|갖고|나왔|확인했|제시)|(?:내놓|제시|보여\s*줘|들어\s*봐|말해\s*봐).{0,16}(?:증거|근거|단서)?)/;
const ASK_MARK = /[?？]|(?:뭐야|뭔데|왜|어떻게|할까|할래|어때|말해\s*줘|보여\s*줘|알려\s*줘|있나|있니|있냐|될까|맞아|맞지|뭐지|뭐냐|뭐임)\s*[.!~]*$/;
const ABSENCE_RE = /(?:없|부족|모자|적어|빈약|불충분)/;
const DENY_ABSENCE = /(?:증거|근거|단서|확신).{0,12}(?:없|부족).{0,18}(?:(?:게|건|것|뜻|말)(?:\s*(?:아니|아냐))|(?:아니|아냐)|말한\s*적\s*없)|(?:없(?:는|다는|다고)|부족(?:하다는|하다고)).{0,12}(?:뜻|말|건|게).{0,8}(?:아니|아냐)/;

function clauses(text) {
  // Discourse particles matter: in “수상하지만 근거는 없다” the latter
  // clause overrides confidence in the former, while its subject persists.
  return normalize(text).split(/(?:[.!?。！？]+\s*|[,，;；]+\s*|\s*(?:하지만|그치만|그렇지만|그러나|반면에|그런데|근데|다만)\s*)/)
    .map(s=>s.trim()).filter(Boolean);
}
function near(left,right,text,distance=21) {
  const a=text.search(left),b=text.search(right);
  if(a<0||b<0)return false;
  return Math.abs(a-b)<=distance;
}
function evidenceIsMissing(t) {
  if (/(?:없(?:다|어|다는|다고|다던|는)?|부족(?:해|하다|하다는)?).{0,18}(?:뜻|말|건|게|것).{0,7}(?:아니|않)/.test(t))return false;
  const noEvidence=near(EVIDENCE,EVIDENCE_LACK,t,24) ||
    /(?:뒷받침|입증|확인)(?:할|할만한)?\s*(?:만한)?\s*(?:게|것|자료)?\s*(?:없|안|못)/.test(t) ||
    /(?:말|느낌|추측|감|주장)(?:만|뿐)\s*(?:이라|인데|으로는|가지고(?:는)?|으로).{0,24}(?:사람|확신|판단|단정|결론|못|안|어렵|찍)/.test(t);
  return noEvidence && !DISAGREE_WITH_ABSENCE.test(t);
}
function strongEvidence(t) {
  if(!EVIDENCE.test(t)||evidenceIsMissing(t))return false;
  return near(EVIDENCE,EVIDENCE_PRESENT,t,24);
}
function seemsUncertain(t){
  return CONFIDENCE_NEG.test(t) ||
    /(?:누굴|누가|누구를|누구인지|누군지|어느\s*쪽인지).{0,20}(?:모르|못\s*(?:정|고르|판단)|헷갈)/.test(t) ||
    /(?:확실|분명|뚜렷|납득|결정적).{0,16}(?:않|안\s*되|못|없|부족)/.test(t) ||
    /(?:누굴|누구를|누가).{0,22}(?:안\s*정|못\s*정|고르기\s*어렵)/.test(t) ||
    /(?:단정|퇴출|찍|결론|결정).{0,16}(?:못|어렵|이르|지\s*말)/.test(t);
}
function isReported(t){
  // “7번이 마피아라고 생각해/확신해” is MY allegation, not 7번's report.
  // Bare “라고” is insufficient evidence of reported speech.
  if(/(?:라고|라며)\s*(?:확신|생각|판단|믿|봐|보는|추측|추정|느끼|의심)/.test(t))return false;
  // A sentence about another player's uncertainty or vote is not a report
  // of the *speaker's* own intention.
  return REPORT_START.test(t) && REPORT_VERB.test(t) && !/(?:난|나는|내가|나도|저는|내\s*생각)/.test(t.slice(0,25));
}
function askFrom(t) {
  const q=ASK_MARK.test(t) || /(?:근거|증거|단서).{0,14}(?:제시해(?:\s*봐)?|내놔|말해\s*줘|보여\s*줘|알려\s*줘)\s*[.!]*$/.test(t);
  // Mere “근거가 없어?” asks whether evidence exists; it does not assert lack.
  const evidenceQuestion = q && (EVIDENCE.test(t) || REQUEST_EVIDENCE.test(t));
  return {question:q,evidenceQuestion};
}

function parse(text,{phase='DAY'}={}) {
  const t=normalize(text);
  const pieces=clauses(t);
  const last=pieces.at(-1)||t;
  const ask=askFrom(t);
  const reported=isReported(t);
  const eLack=evidenceIsMissing(t);
  const eYes=strongEvidence(t);
  const unclear=seemsUncertain(t);
  const waiting=DEFER.test(t);
  const rejectSkip=SKIP.test(t) && NEGATE_SKIP.test(t);
  const deniedAbsence=DENY_ABSENCE.test(t) || DISAGREE_WITH_ABSENCE.test(t) || /(?:확신|증거|근거|단서).{0,15}(?:없|부족).{0,14}(?:건|게|말|뜻).{0,6}(?:아니|아냐)/.test(t);
  const proposedSkip=SKIP.test(t) && !rejectSkip;
  const sleep=NIGHT.test(t);
  const hasVote=VOTE.test(t);
  const nightSkip=sleep && proposedSkip && (!hasVote || near(NIGHT,SKIP,t,15) && !near(VOTE,SKIP,t,13));
  const voteSkip=proposedSkip && !nightSkip;
  const explicitNoVote=/(?:아무도|누구도|사람|한\s*명도).{0,16}(?:찍지\s*말|안\s*찍|표\s*주지\s*말|투표하지\s*말)/.test(t);
  const deferOnly=waiting && !voteSkip && !nightSkip;
  const requestEvidence=ask.evidenceQuestion && (REQUEST_EVIDENCE.test(t) || /(?:증거|근거|단서|정황).{0,14}(?:있|없|뭐|보여|알려)/.test(t));
  const evidencePolarity= eLack ? 'insufficient' : eYes ? 'available' : null;
  let act=null,confidence=0;
  if(reported) {
    // Reported speech about somebody else must be interpreted downstream as
    // a record to verify, NOT as the current speaker's policy.
    return {act:null,reported:true,question:ask.question, evidencePolarity,uncertain:unclear,waiting,phase,t};
  }
  // Questions are routed ahead of assertions; the question may ask about a
  // hypothetical or deny an earlier statement, not state a new vote intention.
  if(deniedAbsence && !ask.question){act='DENY_ABSENCE';confidence=3;}
  else if(rejectSkip){act='REJECT_SKIP';confidence=3;}
  else if(requestEvidence){act='ASK_EVIDENCE';confidence=3;}
  else if(nightSkip){act='NIGHT_SKIP';confidence=3;}
  else if(voteSkip){act='VOTE_SKIP';confidence=3;}
  else if(eLack){act='LOW_EVIDENCE';confidence=3;}
  else if(deferOnly){act='DEFER';confidence=2;}
  else if(unclear){act='UNCERTAIN';confidence=2;}
  else if(eYes && /(?:\b|^)(?:난|나는|내가|내\s*생각|확실|진짜|있어|있지)/.test(t)){act='EVIDENCE_CLAIM';confidence=2;}
  else if(explicitNoVote){act='VOTE_SKIP';confidence=2;}
  if(act==='LOW_EVIDENCE' && DISAGREE_WITH_ABSENCE.test(t))act=null;
  if(act==='UNCERTAIN' && /(?:안\s*모르는|모르는\s*건\s*아니|확신이\s*없는\s*건\s*아니)/.test(t))act=null;
  // Don't infer the user promised to SKIP from “스킵할까?”; the decision is
  // still tentative. Only explicit affirmative declarations count elsewhere.
  return {act,confidence,reported:false,question:ask.question,evidencePolarity,uncertain:unclear,
    waiting,nightSkip,voteSkip,explicitNoVote,phase,t,last};
}
module.exports={parse,normalize,clauses,evidenceIsMissing,isReported};
