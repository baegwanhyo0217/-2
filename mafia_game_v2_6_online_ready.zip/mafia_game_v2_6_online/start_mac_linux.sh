#!/bin/sh
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  printf 'Node.js 20+ is required. Install from https://nodejs.org/\n'
  exit 1
fi
printf 'Open http://localhost:3000 in your browser.\n'
exec node server.js
