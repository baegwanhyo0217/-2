'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const os = require('node:os');
const { MafiaRoom } = require('./src/engine');

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const DEBUG_SPEED = Number(process.env.MAFIA_TEST_SPEED || 1);
const SPEED = Number.isFinite(DEBUG_SPEED) && DEBUG_SPEED > 0 ? DEBUG_SPEED : 1;
const rooms = new Map();
const tokens = new Map();
const responses = new Map();
const PUBLIC_DIR = path.join(__dirname, 'public');
const mime = { '.html':'text/html; charset=utf-8', '.css':'text/css; charset=utf-8',
  '.js':'application/javascript; charset=utf-8', '.svg':'image/svg+xml',
  '.webmanifest':'application/manifest+json; charset=utf-8', '.png':'image/png' };
const phases = ['NIGHT','NIGHT_RESULT','DAY','VOTE1','EXTRA_DISCUSSION','VOTE2','VOTE_RESULT'];
const durations = SPEED === 1 ? undefined : Object.fromEntries(
  phases.map(key => [key, Math.max(180, Math.round(({
    NIGHT:60000, NIGHT_RESULT:4500, DAY:60000, VOTE1:30000,
    EXTRA_DISCUSSION:45000, VOTE2:30000, VOTE_RESULT:4500
  })[key] / SPEED))]));

function makeCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  for (let attempt = 0; attempt < 100; attempt++) {
    let code = '';
    for (let i = 0; i < 6; i++) code += chars[crypto.randomInt(chars.length)];
    if (!rooms.has(code)) return code;
  }
  throw new Error('방 생성에 실패했습니다.');
}
function createRoom() {
  const code = makeCode();
  const room = new MafiaRoom(code, { durations, onChange: broadcastRoom });
  rooms.set(code, room);
  return room;
}
function findMember(token) {
  const record = tokens.get(token);
  if (!record) throw new Error('참가자 정보가 만료되었습니다. 다시 입장해 주세요.');
  const room = rooms.get(record.code);
  const player = room?.getPlayer(record.id);
  if (!room || !player || player.token !== token) {
    tokens.delete(token);
    throw new Error('참가자 정보를 찾을 수 없습니다. 다시 입장해 주세요.');
  }
  return { room, player };
}
function replyJson(res, status, obj) {
  res.writeHead(status, { 'Content-Type':'application/json; charset=utf-8',
    'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff' });
  res.end(JSON.stringify(obj));
}
function getJSON(req) {
  return new Promise((resolve,reject) => {
    const chunks = []; let size = 0;
    req.on('data', chunk => {
      size += chunk.length;
      if (size > 16384) { reject(new Error('요청 크기 초과')); req.destroy(); return; }
      chunks.push(chunk);
    });
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); }
      catch { reject(new Error('잘못된 요청 형식입니다.')); }
    });
    req.on('error', reject);
  });
}
function event(res, name, data) {
  if (res.destroyed || res.writableEnded) return;
  res.write(`event: ${name}\ndata: ${JSON.stringify(data)}\n\n`);
}
function broadcastRoom(room) {
  const subscribers = responses.get(room.code);
  if (!subscribers) return;
  for (const [id,res] of subscribers) {
    const p = room.getPlayer(id);
    if (p) event(res, 'state', room.snapshotFor(p));
  }
}
function rejectState(res, error) { replyJson(res, 400, { ok:false, error:error.message || String(error) }); }

async function handleApi(req, res, url) {
  if (req.method === 'GET' && url.pathname === '/api/state') {
    const { room, player } = findMember(url.searchParams.get('token'));
    return replyJson(res, 200, { ok:true, state:room.snapshotFor(player) });
  }
  if (req.method === 'GET' && url.pathname === '/api/stream') {
    const { room, player } = findMember(url.searchParams.get('token'));
    res.writeHead(200, { 'Content-Type':'text/event-stream; charset=utf-8',
      'Cache-Control':'no-store, no-transform', 'Connection':'keep-alive',
      'X-Accel-Buffering':'no', 'X-Content-Type-Options':'nosniff' });
    res.write(': connected\n\n');
    if (!responses.has(room.code)) responses.set(room.code, new Map());
    const subscribers = responses.get(room.code);
    if (subscribers.get(player.id) && subscribers.get(player.id) !== res) {
      const old = subscribers.get(player.id);
      subscribers.set(player.id, res);
      old.end();
    } else subscribers.set(player.id, res);
    player.connected = true;
    player.lastHeartbeatAt = Date.now();
    room.update();
    event(res, 'state', room.snapshotFor(player));
    res.on('close', () => {
      if (subscribers.get(player.id) !== res) return;
      subscribers.delete(player.id);
      if (!subscribers.size) responses.delete(room.code);
      player.connected = false;
      // A disconnected participant invalidates the active round immediately.
      tokens.delete(player.token);
      room.removeHuman(player, '접속 종료 또는 네트워크 장애');
    });
    return;
  }
  if (req.method !== 'POST') return replyJson(res, 405, { ok:false, error:'지원하지 않는 요청입니다.' });
  const body = await getJSON(req);
  if (url.pathname === '/api/create') {
    const room = createRoom();
    const p = room.createPlayer(body.name);
    tokens.set(p.token, { code:room.code, id:p.id });
    return replyJson(res, 200, { ok:true, token:p.token, code:room.code });
  }
  if (url.pathname === '/api/join') {
    const code = String(body.code || '').trim().toUpperCase();
    const room = rooms.get(code);
    if (!room) throw new Error('방 코드를 찾을 수 없습니다.');
    if (room.phase !== 'LOBBY') throw new Error('현재 모집 중인 방이 아닙니다.');
    const p = room.createPlayer(body.name);
    tokens.set(p.token, { code:room.code, id:p.id });
    return replyJson(res, 200, { ok:true, token:p.token, code:room.code });
  }
  if (url.pathname === '/api/action') {
    const { room, player } = findMember(body.token);
    const type = body.type;
    switch (type) {
      case 'heartbeat': player.lastHeartbeatAt = Date.now(); break;
      case 'addBots': room.addBots(player, Number(body.count)); break;
      case 'removeBots': room.removeBots(player); break;
      case 'start': room.startDraft(player); break;
      case 'chooseBox': room.chooseBox(player, Number(body.index)); break;
      case 'confirmRole': room.confirmRole(player); break;
      case 'selectAbility': room.selectAbility(player, String(body.targetId || '')); break;
      case 'confirmAbility': room.confirmAbility(player, String(body.targetId || '')); break;
      case 'chat': room.sendChat(player, body.channel, body.text); break;
      case 'vote': room.submitVote(player, String(body.targetId || '')); break;
      case 'resetLobby': room.resetLobby(player); break;
      case 'leave': {
        const subs = responses.get(room.code);
        const stream = subs?.get(player.id);
        if (stream) {
          subs.delete(player.id);
          stream.end();
        }
        tokens.delete(player.token);
        room.removeHuman(player, '자발적 퇴장');
        break;
      }
      default: throw new Error('알 수 없는 행동입니다.');
    }
    return replyJson(res, 200, { ok:true });
  }
  return replyJson(res, 404, { ok:false, error:'API를 찾을 수 없습니다.' });
}

const server = http.createServer(async (req,res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    if (url.pathname === '/health') return replyJson(res, 200, { ok:true, rooms:rooms.size, version:'2.8.4' });
    if (url.pathname.startsWith('/api/')) return await handleApi(req,res,url);
    if (req.method !== 'GET') return replyJson(res, 405, { ok:false, error:'Method Not Allowed' });
    const assets = { '/':'index.html', '/index.html':'index.html', '/style.css':'style.css',
      '/app.js':'app.js','/manifest.webmanifest':'manifest.webmanifest', '/sw.js':'sw.js','/offline.html':'offline.html','/offline-engine.js':'offline-engine.js', '/local.html':'local.html', '/local-controller.js':'local-controller.js','/native-bridge.js':'native-bridge.js',
      '/icons/icon-192.png':'icons/icon-192.png', '/icons/icon-512.png':'icons/icon-512.png' };
    const file = assets[url.pathname];
    if (!file) return replyJson(res, 404, { ok:false, error:'Not Found' });
    const filePath = path.join(PUBLIC_DIR, file);
    res.writeHead(200, {
      'Content-Type':mime[path.extname(file)] || 'application/octet-stream',
      'Cache-Control':(file.endsWith('.html') || file==='sw.js') ? 'no-cache' : 'public, max-age=60',
      'X-Content-Type-Options':'nosniff',
      'Referrer-Policy':'no-referrer',
      'Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; manifest-src 'self'; base-uri 'none'; object-src 'none'"
    });
    fs.createReadStream(filePath).pipe(res);
  } catch(e) {
    if (!res.headersSent) rejectState(res,e);
    else res.end();
  }
});
setInterval(() => {
  for (const room of rooms.values()) {
    if (room.hasActiveMatch()) {
      const stale = room.players.find(p => !p.bot && p.connected &&
        Date.now() - (p.lastHeartbeatAt || 0) > 9000);
      if (stale) {
        const res = responses.get(room.code)?.get(stale.id);
        if (res) { responses.get(room.code).delete(stale.id); res.end(); }
        tokens.delete(stale.token);
        room.removeHuman(stale, '네트워크 응답 중단');
      }
    }
    room.tick();
  }
}, 180).unref();
setInterval(() => {
  for (const subs of responses.values()) for (const res of subs.values()) {
    if (!res.destroyed && !res.writableEnded) res.write(': ping\n\n');
  }
  const threshold = Date.now() - 90 * 60 * 1000;
  for (const [code,room] of rooms) if (room.updatedAt < threshold &&
    !Array.from(responses.get(code)?.values() || []).length) {
      for (const p of room.players) if (p.token) tokens.delete(p.token);
      rooms.delete(code);
    }
}, 10000).unref();

if (require.main === module) server.listen(PORT, HOST, () => {
  console.log(`NOIR / 07 — PC browser: http://localhost:${PORT}`);
  if (HOST==='0.0.0.0' || HOST==='::') {
    const addresses=new Set();
    for (const iface of Object.values(os.networkInterfaces())) for (const record of iface || []) {
      if (record.family==='IPv4' && !record.internal) addresses.add(record.address);
    }
    for (const ip of addresses) console.log(`Phone (same Wi-Fi): http://${ip}:${PORT}`);
  }
  if (SPEED !== 1) console.log(`TEST SPEED x${SPEED}; 정식 룰은 x1 입니다.`);
});
module.exports = { server, rooms, tokens, createRoom };
