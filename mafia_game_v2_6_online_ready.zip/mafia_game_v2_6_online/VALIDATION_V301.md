# NOIR / SEVEN v3.0.1 — Validation

## Source behavior

The rules mode now initializes per-agent AgentMemory objects in `BotMind.mindFor`,
updates them from the game event pipeline, and feeds verified evidence into
existing suspicion-based vote/night heuristics.

## Automated regression checks

- All 313 prior unit/integration tests retained.
- 7 new tests check: independent memory without LLM; immediate chat memory;
  police-only investigation privacy; Mafia–Spy-only secret chat memory;
  evidence-driven rule vote and decision trace; hosted LLM sharing the same
  memory object; and no-network browser-bundled memory.
- Run: `npm test`.

## Security constraints

- One player's private role is not added to another bot's public observation.
- Private investigations remain specific to the investigator.
- Only genuinely contacted Mafia/Spy see secret messages.
- LLM is optional, its outputs remain game-rule validated, and private
  credentials stay server-side.

## Honest scope

Rule-based cognition tracks evidence and updates scores. It is **not** an
unrestricted natural-language reasoning LLM. Hardware-specific Android/iOS
models and BLE gameplay have not been independently validated here.

## Browser and deploy smoke tests

- Tested standalone single-file HTML at **390×844 mobile viewport** with
  Chromium and Playwright: seven players, six independently allocated memories,
  public role-claim contradiction recognized by all six agents, zero page
  errors, zero network requests and no horizontal overflow.
- Fixed an existing single-file HTML issue: previously inlined app scripts ran
  in the document head before `#root` existed. Scripts now execute after body.
- Extracted the Render-ready ZIP and started the actual Node server with
  `NOIR_AI_MODE=rules`: `/health`, `/`, `/offline.html`, `/offline-engine.js`,
  `/app.js`, and `/sw.js` all returned HTTP 200. Health reports
  `ai.offlineMemory: true`, `ai.offlineReasoning: true` and `ai.enabled: false`.
